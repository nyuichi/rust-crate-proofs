(declare-sort t 0)

(declare-fun tqtint (t) Int)

(assert
  (forall ((i t))
    (and
      (<= 0 (tqtint i))
      (<= (tqtint i) 340282366920938463463374607431768211455))))

(declare-sort t1 0)

(declare-fun tqtint1 (t1) Int)

(assert
  (forall ((i t1))
    (and (<= 0 (tqtint1 i)) (<= (tqtint1 i) 18446744073709551615))))

(declare-fun pow2 (Int) Int)

(assert (= (pow2 0) 1))

(assert (forall ((n Int)) (=> (<= 0 n) (= (pow2 (+ n 1)) (* 2 (pow2 n))))))

(assert (= (pow2 1) 2))

(assert
  (forall ((n Int) (m Int))
    (=> (and (<= 0 n) (<= 0 m)) (= (pow2 (+ n m)) (* (pow2 n) (pow2 m))))))

(assert (forall ((i Int)) (=> (<= 0 i) (< 0 (pow2 i)))))

(assert (= (pow2 0) 1))

(assert (= (pow2 1) 2))

(assert (= (pow2 2) 4))

(assert (= (pow2 3) 8))

(assert (= (pow2 4) 16))

(assert (= (pow2 5) 32))

(assert (= (pow2 6) 64))

(assert (= (pow2 7) 128))

(assert (= (pow2 8) 256))

(assert (= (pow2 9) 512))

(assert (= (pow2 10) 1024))

(assert (= (pow2 11) 2048))

(assert (= (pow2 12) 4096))

(assert (= (pow2 13) 8192))

(assert (= (pow2 14) 16384))

(assert (= (pow2 15) 32768))

(assert (= (pow2 16) 65536))

(assert (= (pow2 17) 131072))

(assert (= (pow2 18) 262144))

(assert (= (pow2 19) 524288))

(assert (= (pow2 20) 1048576))

(assert (= (pow2 21) 2097152))

(assert (= (pow2 22) 4194304))

(assert (= (pow2 23) 8388608))

(assert (= (pow2 24) 16777216))

(assert (= (pow2 25) 33554432))

(assert (= (pow2 26) 67108864))

(assert (= (pow2 27) 134217728))

(assert (= (pow2 28) 268435456))

(assert (= (pow2 29) 536870912))

(assert (= (pow2 30) 1073741824))

(assert (= (pow2 31) 2147483648))

(assert (= (pow2 32) 4294967296))

(assert (= (pow2 33) 8589934592))

(assert (= (pow2 34) 17179869184))

(assert (= (pow2 35) 34359738368))

(assert (= (pow2 36) 68719476736))

(assert (= (pow2 37) 137438953472))

(assert (= (pow2 38) 274877906944))

(assert (= (pow2 39) 549755813888))

(assert (= (pow2 40) 1099511627776))

(assert (= (pow2 41) 2199023255552))

(assert (= (pow2 42) 4398046511104))

(assert (= (pow2 43) 8796093022208))

(assert (= (pow2 44) 17592186044416))

(assert (= (pow2 45) 35184372088832))

(assert (= (pow2 46) 70368744177664))

(assert (= (pow2 47) 140737488355328))

(assert (= (pow2 48) 281474976710656))

(assert (= (pow2 49) 562949953421312))

(assert (= (pow2 50) 1125899906842624))

(assert (= (pow2 51) 2251799813685248))

(assert (= (pow2 52) 4503599627370496))

(assert (= (pow2 53) 9007199254740992))

(assert (= (pow2 54) 18014398509481984))

(assert (= (pow2 55) 36028797018963968))

(assert (= (pow2 56) 72057594037927936))

(assert (= (pow2 57) 144115188075855872))

(assert (= (pow2 58) 288230376151711744))

(assert (= (pow2 59) 576460752303423488))

(assert (= (pow2 60) 1152921504606846976))

(assert (= (pow2 61) 2305843009213693952))

(assert (= (pow2 62) 4611686018427387904))

(assert (= (pow2 63) 9223372036854775808))

(assert (= (pow2 64) 18446744073709551616))

(declare-fun x () t)

(declare-fun y () t)

(declare-fun x_hi () t1)

(declare-fun x_lo () t1)

(declare-fun y_hi () t1)

(declare-fun y_lo () t1)

(assert (= (tqtint x) (+ (* (tqtint1 x_hi) (pow2 64)) (tqtint1 x_lo))))

(assert (= (tqtint y) (+ (* (tqtint1 y_hi) (pow2 64)) (tqtint1 y_lo))))

(assert
  (= (* (tqtint x) (tqtint y)) (* (+ (* (tqtint1 x_hi) (pow2 64)) (tqtint1
                                                                    x_lo)) 
  (tqtint
    y))))

(assert
  (= (* (tqtint x) (tqtint y)) (* (tqtint x) (+ (* (tqtint1 y_hi) (pow2 64)) 
  (tqtint1
    y_lo)))))

(assert
  (not
  (= (* (tqtint x) (tqtint y)) (* (+ (* (tqtint1 x_hi) (pow2 64)) (tqtint1
                                                                    x_lo)) (+ (* 
  (tqtint1
    y_hi) (pow2 64)) (tqtint1 y_lo))))))

(check-sat)
