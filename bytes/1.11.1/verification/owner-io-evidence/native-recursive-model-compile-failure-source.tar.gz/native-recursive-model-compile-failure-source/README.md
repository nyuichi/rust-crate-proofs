# Exact native compilation failure archive

The source files match the pre-run SHA-256 manifest. The native compiler rejected two raw `@` view operators in the new recursive logic model; no tests ran. This is a compilation failure, not a native test or proof result.
