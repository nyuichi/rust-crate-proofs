//! Bounded stock `IoSlice` boundary attempt. Kept only in the private probe
//! until its missing contracts are captured; the replacement API uses slices.

use creusot_std::prelude::*;

#[logic(open)]
fn io_slice_bytes(slices: Seq<std::io::IoSlice<'_>>) -> Seq<u8> {
    pearlite! { slices.map(|part: std::io::IoSlice<'_>| part.as_ref()@).flatten() }
}

#[ensures((^destination)@ == destination@.concat(io_slice_bytes(sources@)))]
pub fn append_io_slices_attempt(
    destination: &mut super::exclusive::ExclusiveBytes,
    sources: &[std::io::IoSlice<'_>],
) {
    let initial = snapshot!(destination@);
    let mut index = 0;
    #[invariant(index@ <= sources@.len())]
    #[invariant(destination@ == initial.concat(io_slice_bytes(sources@[0..index@])))]
    #[variant(sources@.len() - index@)]
    while index < sources.len() {
        destination.extend_from_slice(&sources[index]);
        index += 1;
    }
}
