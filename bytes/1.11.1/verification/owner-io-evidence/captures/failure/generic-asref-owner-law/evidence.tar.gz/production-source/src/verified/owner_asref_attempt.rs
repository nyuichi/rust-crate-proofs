//! First generic `AsRef<[u8]>` owner-copy attempt, kept only until its actual
//! stock-verifier result is captured.

use creusot_std::prelude::*;

use super::exclusive::ExclusiveBytes;

#[ensures(result.0@ == source@)]
#[ensures(result.1@ == source.as_ref()@)]
pub fn copy_from_asref_attempt<T: View + AsRef<[u8]>>(
    source: T,
) -> (T, ExclusiveBytes) {
    let copied = ExclusiveBytes::copy_from_slice(source.as_ref());
    (source, copied)
}
