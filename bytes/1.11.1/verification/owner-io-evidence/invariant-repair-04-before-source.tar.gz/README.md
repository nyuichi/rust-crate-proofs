Exact pre-run candidate 04 source snapshot.
