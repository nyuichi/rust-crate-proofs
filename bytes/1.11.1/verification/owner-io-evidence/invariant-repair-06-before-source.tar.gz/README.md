Exact pre-run candidate 06 source snapshot.
