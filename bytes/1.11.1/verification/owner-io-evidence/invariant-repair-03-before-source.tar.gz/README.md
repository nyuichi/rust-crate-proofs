Exact pre-run candidate 03 source snapshot.
