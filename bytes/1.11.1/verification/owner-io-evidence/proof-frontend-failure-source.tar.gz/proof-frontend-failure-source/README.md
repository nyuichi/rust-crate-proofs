# Exact source and frontend failure archive

This directory contains the exact source matching the wrapper's pre-run source fingerprint, copied before any source edit, plus the complete wrapper log. The frontend failed before VC generation with E0614 in the Box<[u8]> byte view due to one excessive dereference. This is a translation/compiler failure, not a proof result.
