# Reproduced scatter read bug

The exact source (matching the pre-run source hashes) and full native test log show the old `count < self.remaining()` guard skipping the second 2-byte destination after consuming 2 of 4 available bytes. The regression expected count 4, but the broken body returned 2. This is intentional failing-before-fix evidence, not a final validation result.
