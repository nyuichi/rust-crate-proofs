# Exact current private proof run and remaining scatter failures

The full source snapshot matches the wrapper pre-run SHA-256 fingerprint. The generated proof artifacts cover the entire new owner I/O module. All module obligations passed except the four null leaves of `Coma.vc_read_scatter_prefix` (22/26); the wrapper returned 1. This is not a passing proof. The source, full log, feature graph, private Std manifest and proof JSON are retained before further source edits.
