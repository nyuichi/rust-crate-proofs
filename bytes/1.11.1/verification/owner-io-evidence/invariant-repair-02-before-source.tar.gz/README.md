Exact pre-run candidate 02 source snapshot.
