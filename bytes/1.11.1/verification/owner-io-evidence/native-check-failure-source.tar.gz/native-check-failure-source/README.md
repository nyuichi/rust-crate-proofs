# Native test failure source archive

This is the exact source captured by `native-check-source-before.json` before the run, with the complete native log and result record. Source hash checks can be reproduced from the JSON manifest. The compiler completed; 52/54 native tests passed and two newly added expectation assertions failed. This is a native test result, not a proof result.
