Exact pre-run candidate 05 source snapshot.
