# Capacity and numeric address evidence handoff

The frozen bytes proof base is commit `ee5d362ad2132428edd6485dbd723455336a6fd3`.

`patches/bytes-capacity-address-full-from-ee5d362a.patch` is generated directly from the archived final positive source snapshot and applies cleanly to that baseline. Its SHA-256 is listed in `SHA256SUMS`. It includes the capacity contracts plus the address metadata contracts/client for `Cargo.toml`, `raw_vec.rs`, `exclusive.rs`, `scoped.rs`, and `callbacks.rs`. The smaller `address-source.patch` is only the address delta atop a capacity-shaped source and is not by itself applicable to the original ee5d362 baseline. The earlier concatenated patch is retained and labeled incomplete for audit clarity.

The local Creusot std source delta is applied in this order: `creusot-std-alloc-capacity.patch`, then `creusot-std-address-model.patch`. The exact local std candidate `Vec` source, package manifest, native and Creusot Cargo feature graphs, tool configuration, proof/native logs, and hash receipts are preserved in `evidence/address-positive`.

Capacity proof: 261 Coma and JSON files, 0 null leaves, full-coverage false. Missing-spare negative: exactly one null leaf at `RecoveredAllocation::into_vec`.

Address proof: 262 Coma and JSON files, 0 null leaves, full-coverage false. Its missing-spare negative has exactly one null leaf at `RecoveredAllocation::into_vec`. The archived address caller observes the returned Vec and then drops it implicitly. Root's planned explicit `ExclusiveBytes::from_vec(output).close()` is an additional lifecycle obligation and must be included in the integrated actual-source gate before claiming that the numeric address client also closes via B1/B3.

The address observer is an opaque numeric `Int` for actual Vec terms. It establishes numeric address continuity for nonzero capacity across B1, shared ownership/recovery, and B2. It does not establish pointer identity/provenance, permissions, liveness, dereferenceability, injectivity, zero-cap allocation existence, or address stability after mutation/reallocation.
