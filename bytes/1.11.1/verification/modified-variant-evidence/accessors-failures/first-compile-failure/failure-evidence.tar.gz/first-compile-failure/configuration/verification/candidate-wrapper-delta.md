# Candidate wrapper delta

This private verification copy adds environment-only `CARGO_TARGET_DIR` and `CARGO_BUILD_JOBS=1` overrides immediately after sourcing the pinned activation script. It preserves the wrapper lock, feature selection, target arguments, proof commands and Creusot/Why3 setup. No root wrapper, Rust source, or Cargo manifest is changed by this override.
