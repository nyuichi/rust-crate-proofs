use crate::{ghost::invariant::Tokens, prelude::*};
use ::std::thread::{self, Builder, JoinHandle, ScopedJoinHandle};

/// Extension trait for [`JoinHandle`].
pub trait JoinHandleExt<T> {
    /// Predicate that specifies the valid return results for the handle.
    #[logic(prophetic)]
    fn valid_result(self, x: T) -> bool;

    /// This function is a wrapper `self.join().unwrap()`.
    ///
    /// This function panics only on stack-overflow or OOM on the spawned thread.
    // NOTE: This is a way to avoid ::std::thread::Result, which:
    //  - contains a dyn;
    //  - we don't know how to handle the Err case in Creusot.
    #[ensures(self.valid_result(result))]
    fn join_unwrap(self) -> T;
}

impl<T> JoinHandleExt<T> for JoinHandle<T> {
    #[logic(opaque, prophetic)]
    fn valid_result(self, _x: T) -> bool {
        dead
    }

    #[ensures(self.valid_result(result))]
    #[trusted]
    fn join_unwrap(self) -> T {
        self.join().unwrap()
    }
}

impl<T> JoinHandleExt<T> for ScopedJoinHandle<'_, T> {
    #[logic(opaque, prophetic)]
    fn valid_result(self, _x: T) -> bool {
        dead
    }

    #[ensures(self.valid_result(result))]
    #[trusted]
    fn join_unwrap(self) -> T {
        self.join().unwrap()
    }
}

extern_spec! {
    impl<T> JoinHandle<T> {
        #[ensures(true)] // no spec, but you can call this if you want
        fn is_finished(&self) -> bool;
    }

    impl<T> ScopedJoinHandle<'_, T> {
        #[ensures(true)] // no spec, but you can call this if you want
        fn is_finished(&self) -> bool;
    }
}

/// Creusot wrapper around [`std::thread::spawn`].
///
/// The only difference is that the closure gives access to a fresh token object
#[requires(forall<t: Ghost<Tokens>> (forall<ns> t.contains(ns)) ==> f.precondition((t,)))]
#[ensures(exists<t: Ghost<Tokens>> (forall<ns> t.contains(ns)) && forall<r> result.valid_result(r) ==> f.postcondition_once((t,), r))]
#[trusted]
pub fn spawn<F, T>(f: F) -> JoinHandle<T>
where
    F: FnOnce(Ghost<Tokens>) -> T + Send + 'static,
    T: Send + 'static,
{
    ::std::thread::spawn(|| f(Tokens::new()))
}

/// Creusot's replacement for [`Scope`].
pub struct Scope<'scope, 'env: 'scope> {
    inner: &'scope thread::Scope<'scope, 'env>,
}

impl<'scope, 'env: 'scope> Scope<'scope, 'env> {
    #[requires(forall<t: Ghost<Tokens>> (forall<ns> t.contains(ns)) ==> f.precondition((t,)))]
    #[ensures(exists<t: Ghost<Tokens>> (forall<ns> t.contains(ns)) && forall<r> result.valid_result(r) ==> f.postcondition_once((t,), r))]
    #[trusted]
    pub fn spawn<F, T>(&mut self, f: F) -> ScopedJoinHandle<'scope, T>
    where
        F: FnOnce(Ghost<Tokens>) -> T + Send + 'scope,
        T: Send + 'scope,
    {
        self.inner.spawn(|| f(Tokens::new()))
    }

    /// Attempts to start a scoped worker while keeping an explicit mutable
    /// slot owned by the parent until the worker actually begins.
    ///
    /// Returns `None` if the operating system cannot create the thread; the
    /// underlying `io::Error` is discarded. On that normal return, the startup
    /// closure was dropped without invoking `f`, so the slot is unchanged.
    /// `F: Copy` ensures that dropping the unstarted closure cannot run a user
    /// destructor that mutates state aliased with the slot. No guarantee is
    /// made for other external state.
    #[requires(forall<s: &mut S, t: Ghost<Tokens>>
        *s == *slot && ^s == ^slot && (forall<ns> t.contains(ns)) ==>
            f.precondition((s, t)))]
    #[ensures(match result {
        Some(join) => exists<s: &mut S, t: Ghost<Tokens>>
            *s == *slot && ^s == ^slot && (forall<ns> t.contains(ns)) &&
            forall<r> join.valid_result(r) ==> f.postcondition_once((s, t), r),
        None => ^slot == *slot
    })]
    #[trusted]
    pub fn try_spawn_with_slot<S, F, T>(
        &mut self,
        stack_size: Option<usize>,
        slot: &'scope mut S,
        f: F,
    ) -> Option<ScopedJoinHandle<'scope, T>>
    where
        S: Send + 'scope,
        F: FnOnce(&mut S, Ghost<Tokens>) -> T + Copy + Send + 'scope,
        T: Send + 'scope,
    {
        let builder = match stack_size {
            Some(size) => Builder::new().stack_size(size),
            None => Builder::new(),
        };
        match builder.spawn_scoped(self.inner, move || f(slot, Tokens::new())) {
            Ok(join) => Some(join),
            Err(_error) => None,
        }
    }
}

/// Creusot wrapper around [`std::thread::scope`].
#[requires(forall<s> inv(s) ==> f.precondition((s,)))]
#[ensures(exists<s> inv(s) && f.postcondition_once((s,),result))]
#[trusted]
pub fn scope<'env, F, T>(f: F) -> T
where
    F: for<'scope> FnOnce(&mut Scope<'scope, 'env>) -> T,
{
    ::std::thread::scope(|s| f(&mut Scope { inner: s }))
}
