//! Parent-retained lease across a fallible `Builder::spawn_scoped` call.
//!
//! The attempted closure holds only a mutable borrow of the parent-owned slot.
//! It takes the `ReadHandle` after it starts. If thread creation returns `Err`,
//! the closure has not run and the slot still owns the handle for explicit
//! parent-side retirement. If creation succeeds, the worker returns the handle
//! to the parent after reading; it never drops the affine lease.
use super::*;
use creusot_std::ghost::invariant::Tokens;

#[requires(tokens.contains(retirement::PUBLICATION()))]
#[ensures(result.0 == if index@ < input@.len() {Some(input@[index@])} else {None})]
#[ensures(result.2 != result.3)]
pub fn parent_retained_builder_attempt(
    input: Vec<u8>,
    index: usize,
    force_builder_error: bool,
    mut tokens: Ghost<Tokens<'_>>,
) -> (Option<u8>, bool, bool, bool) {
    use creusot_std::std::thread::JoinHandleExt;

    let mut owner = Owner::new(input);
    let (left, right, context) = owner.share_pair();
    let mut left_slot = Some(left);

    let worker = ::std::thread::scope(|scope| {
        let slot = &mut left_slot;
        let builder = if force_builder_error {
            // An invalid stack request makes std return an error without
            // starting the closure, exercising the same ownership branch.
            ::std::thread::Builder::new().stack_size(usize::MAX)
        } else {
            ::std::thread::Builder::new()
        };
        match builder.spawn_scoped(scope, move || {
            let handle = slot.take().expect("worker started with occupied lease slot");
            let value = if index < handle.len() {
                Some(handle.read(index))
            } else {
                None
            };
            (value, handle)
        }) {
            Ok(join) => Some(join.join_unwrap()),
            Err(_) => None,
        }
    });
    let spawned = worker.is_some();

    let (value, left) = match worker {
        Some(worker) => worker,
        None => {
            let handle = left_slot
                .take()
                .expect("failed spawn left the parent-owned lease in its slot");
            let value = if index < handle.len() {
                Some(handle.read(index))
            } else {
                None
            };
            (value, handle)
        }
    };

    let left = left.close(&context, ghost! { tokens.reborrow() });
    let right = right.close(&context, tokens);
    let flags = owner.close(context, left, right);
    (value, spawned, flags.0, flags.1)
}

#[cfg(all(test, not(creusot)))]
mod tests {
    use super::*;

    fn token() -> Ghost<Tokens<'static>> {
        ghost! { Tokens::new().into_inner() }
    }

    #[test]
    fn successful_builder_returns_lease_to_parent_for_close() {
        for len in [0, 1, 5] {
            for spare in [0, 8] {
                let mut input = Vec::with_capacity(len + spare);
                input.extend((0..len).map(|i| (181 + i) as u8));
                let expected = input.get(2).copied();
                let (value, spawned, first_last, second_last) =
                    parent_retained_builder_attempt(input, 2, false, token());
                assert_eq!(value, expected);
                assert!(spawned);
                assert_ne!(first_last, second_last);
            }
        }
    }

    #[test]
    fn builder_error_keeps_lease_in_parent_slot_for_close() {
        for len in [0, 1, 5] {
            for spare in [0, 8] {
                let mut input = Vec::with_capacity(len + spare);
                input.extend((0..len).map(|i| (191 + i) as u8));
                let expected = input.get(2).copied();
                let (value, spawned, first_last, second_last) =
                    parent_retained_builder_attempt(input, 2, true, token());
                assert_eq!(value, expected);
                assert!(!spawned);
                assert_ne!(first_last, second_last);
            }
        }
    }
}

// Compile-time interface probes: Creusot's modeled `Scope` is not the std
// `Scope` accepted by `Builder::spawn_scoped`, and its raw projection is
// private. These functions are never called.
#[allow(dead_code)]
fn builder_with_creusot_scope_type_mismatch() {
    creusot_std::std::thread::scope(|scope| {
        let _ = ::std::thread::Builder::new().spawn_scoped(scope, || ());
    });
}

#[allow(dead_code)]
fn builder_with_private_scope_projection() {
    creusot_std::std::thread::scope(|scope| {
        let _ = ::std::thread::Builder::new().spawn_scoped(scope.inner, || ());
    });
}
