//! Bounded Deserialize candidate for the modified verified byte owner.

use alloc::{string::String, vec::Vec};
use core::{cmp, fmt};
use serde::{de, Deserialize, Deserializer};

use crate::verified::exclusive::ExclusiveBytes;

struct ExclusiveBytesVisitor;

impl<'de> de::Visitor<'de> for ExclusiveBytesVisitor {
    type Value = ExclusiveBytes;

    fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("byte array")
    }

    fn visit_seq<V>(self, mut seq: V) -> Result<Self::Value, V::Error>
    where
        V: de::SeqAccess<'de>,
    {
        let len = cmp::min(seq.size_hint().unwrap_or(0), 4096);
        let mut values = Vec::with_capacity(len);
        while let Some(value) = seq.next_element()? {
            values.push(value);
        }
        Ok(ExclusiveBytes::from_vec(values))
    }

    fn visit_bytes<E>(self, bytes: &[u8]) -> Result<Self::Value, E>
    where
        E: de::Error,
    {
        Ok(ExclusiveBytes::copy_from_slice(bytes))
    }

    fn visit_byte_buf<E>(self, bytes: Vec<u8>) -> Result<Self::Value, E>
    where
        E: de::Error,
    {
        Ok(ExclusiveBytes::from_vec(bytes))
    }

    fn visit_str<E>(self, value: &str) -> Result<Self::Value, E>
    where
        E: de::Error,
    {
        Ok(ExclusiveBytes::copy_from_str(value))
    }

    fn visit_string<E>(self, value: String) -> Result<Self::Value, E>
    where
        E: de::Error,
    {
        Ok(ExclusiveBytes::from_string(value))
    }
}

impl<'de> Deserialize<'de> for ExclusiveBytes {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(ExclusiveBytesVisitor)
    }
}

#[cfg(all(test, not(creusot), feature = "std"))]
mod tests {
    use super::*;
    use core::fmt;
    use serde_test::{assert_de_tokens, Token};

    struct ClosedBytes(Option<ExclusiveBytes>);

    impl ClosedBytes {
        fn new(bytes: ExclusiveBytes) -> Self {
            Self(Some(bytes))
        }

        fn as_slice(&self) -> &[u8] {
            self.0.as_ref().unwrap().as_slice()
        }
    }

    impl Drop for ClosedBytes {
        fn drop(&mut self) {
            if let Some(bytes) = self.0.take() {
                bytes.close();
            }
        }
    }

    impl fmt::Debug for ClosedBytes {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            fmt::Debug::fmt(self.as_slice(), f)
        }
    }

    impl PartialEq for ClosedBytes {
        fn eq(&self, other: &Self) -> bool {
            self.as_slice() == other.as_slice()
        }
    }

    impl<'de> Deserialize<'de> for ClosedBytes {
        fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'de>,
        {
            ExclusiveBytes::deserialize(deserializer).map(Self::new)
        }
    }

    fn check(tokens: &[Token], expected: &[u8]) {
        let expected = ClosedBytes::new(ExclusiveBytes::copy_from_slice(expected));
        assert_de_tokens(&expected, tokens);
    }

    #[test]
    fn exclusive_bytes_deserialize_common_byte_token_shapes() {
        check(&[Token::Bytes(b"")], b"");
        check(&[Token::Bytes(b"bytes")], b"bytes");
        check(&[Token::ByteBuf(b"owned")], b"owned");
        check(&[Token::Str("text")], b"text");
        check(&[Token::String("owned string")], b"owned string");
        check(
            &[
                Token::Seq { len: Some(3) },
                Token::U8(1),
                Token::U8(2),
                Token::U8(3),
                Token::SeqEnd,
            ],
            &[1, 2, 3],
        );
    }
}
