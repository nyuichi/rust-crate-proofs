# Production variant admission record

Target: bytes 1.11.1, `verified,std`, stock pinned Creusot, x86_64,
normal-return scoped threads. Status: implementation/proof pending, NOT ADMITTED.
See MODIFIED_VARIANT_SPEC.md; this record does not complete arbitrary sharing,
mutable APIs or all feature/configuration obligations.

## Changed premise and bounded question

D05 permits reopening only on an actual representation/interface change.
The production entry now replaces implicit Clone(&self)/callback ownership with
Owner::share_pair(&mut self), borrowed ReadHandle views, an explicit CloseContext,
consuming ReadHandle::close and consuming Owner::close. Actual source lives in
`src/verified/`; canonical physical bridges are included via
`src/verified_ownership.rs`. This is the user-selected route 1, not an annotation
or wrapper retry of the old API. No original Clone/Deref/Drop proof is inferred.

Question: can one compatible representation establish actual byte values,
sharing across real thread boundaries, read access through peer retirement,
receipt-derived exactly-one recovery and unconditional consuming parent cleanup?

Positive checks: native empty/spare-capacity/read-bound cases; one integrated
production translation/proof with every generated proof leaf closed; formal byte
result and unique-final-observer contracts; actual affine capabilities reach B3;
no new bytes protocol trust; exact source/configuration/archive correspondence.
Negative checks: missing Acquire must reject peer synchronization; missing reader
fraction/receipt must prevent final cleanup, including an empty reader; caller
contracts and Rust borrows must reject unmatched/missing completion where tested.
Different negative checks establish different claims (Rust typing versus VCs).

Stop policy: classify frontend errors separately from VCs, preserve failures,
review the interface after two equivalent VC failures, restructure at the third.
Do not increase timeouts or add wrappers to evade unchanged frozen decisions.
Astra is the architecture implementer; Luna audits resources/source/evidence.

## Required body and representation boundaries

| Actual boundary | Required relation |
|---|---|
| Owner::new -> B1/FrozenOwner | Input Vec model becomes initialized physical slots; Vec owner consumed |
| Owner::share_pair -> B4/lifetime split | Both real slices equal input contents; half anchor plus two quarters of same lifetime |
| ReadHandle::read | Index-bounded result is that actual input byte |
| ReadHandle::close -> native retirement | Unique ticket consumed; receipt last flag matches actual Release RMW; nonlast returns no peer fractions |
| Final retirement -> Acquire | Actual peer fractions extracted through deferred acquire witness only after native fence |
| Consuming context finish | Matched authoritative receipt fragments derive XOR and completed retirement |
| Owner::close -> B3 | All fractions reunited, full lifetime ended, actual full region/recovery consumed once |
| Scoped callers | Real spawn/join contracts compose byte and cleanup postconditions; peer-retirement witness keeps another reader live |

The atomic primitive is unchanged: src/verified/atomic.rs and
verification/probes/weak-native-publication/src/primitive.rs have SHA256
`dc94853b3009ccedce53d4f1edb41f85ab9b317e6cc651ec815d6b5f8259968e`.
The existing B1/B3/B4 physical contracts, stock thread contracts, synthetic
lifetime/resource algebra and weak-memory primitive assumptions remain explicit
TCB. Their adequacy is not proved by counting this variant's VCs. Mutable B4 is
not exercised in this admission; D01 remains frozen and a later exclusive model
must reject its preserved counterexample.

## Results

Pending. Entry routing regression alone: original native default passes1256 tests
in17 suites and original no_std check passes. See modified-variant-evidence/
entry-regression.json. These are compatibility observations, not variant proof.
