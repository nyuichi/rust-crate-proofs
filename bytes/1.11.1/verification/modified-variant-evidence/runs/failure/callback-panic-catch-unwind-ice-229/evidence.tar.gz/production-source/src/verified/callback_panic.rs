//! Candidate panic-boundary adaptation for `verified::callbacks`; not wired in.
//! No translation or proof was run. This uses the current private Owner / B2
//! architecture and adds no trusted contracts.

use super::*;
use alloc::boxed::Box;
use core::any::Any;

/// A caught payload remains owned until the allocation has been closed/thawed.
type Caught<T> = Result<T, Box<dyn Any + Send + 'static>>;

/// Diagnostic candidate: each worker retains its affine ReadHandle outside the
/// catch closure, then explicitly retires it after either catch result returns.
/// The parent joins owned outcomes before consuming Owner through close.
pub(crate) fn with_shared_read_caught<F, G, R, S>(
    input: Vec<u8>,
    first: F,
    second: G,
) -> (Caught<R>, Caught<S>)
where
    F: Send + for<'a> FnOnce(&'a [u8]) -> R,
    G: Send + for<'a> FnOnce(&'a [u8]) -> S,
    R: Send,
    S: Send,
{
    use creusot_std::std::thread::{self, JoinHandleExt};

    let mut owner = Owner::new(input);
    let (left, right, context) = owner.share_pair();
    let parent = &context;
    let (left, right) = thread::scope(move |scope| {
        let left = scope.spawn(move |tokens| {
            let bytes = left.bytes;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
                first(bytes)
            }));
            let closed = left.close(parent, tokens);
            (outcome, closed)
        });
        let right = scope.spawn(move |tokens| {
            let bytes = right.bytes;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
                second(bytes)
            }));
            let closed = right.close(parent, tokens);
            (outcome, closed)
        });
        (left.join_unwrap(), right.join_unwrap())
    });

    let flags = owner.close(context, left.1, right.1);
    proof_assert!(flags.0 != flags.1);
    (left.0, right.0)
}

/// Optional wrapper to preserve the existing callback API's panic behavior:
/// complete both handle retirements and Owner cleanup before resuming either
/// captured panic. If both callbacks panic, the left payload is resumed and the
/// right payload is dropped after cleanup.
pub(crate) fn with_shared_read_resume<F, G, R, S>(
    input: Vec<u8>,
    first: F,
    second: G,
) -> (R, S)
where
    F: Send + for<'a> FnOnce(&'a [u8]) -> R,
    G: Send + for<'a> FnOnce(&'a [u8]) -> S,
    R: Send,
    S: Send,
{
    let (first, second) = with_shared_read_caught(input, first, second);
    match (first, second) {
        (Ok(first), Ok(second)) => (first, second),
        (Err(payload), Ok(_)) | (Err(payload), Err(_)) => {
            std::panic::resume_unwind(payload)
        }
        (Ok(_), Err(payload)) => std::panic::resume_unwind(payload),
    }
}

/// B2 variant sketch. On callback errors it first explicitly closes the Vec
/// returned by thaw, then resumes the callback panic; successful calls return
/// the recovered Vec and both owned callback outputs.
pub(crate) fn with_shared_read_then_thaw_caught<F, G, R, S>(
    input: Vec<u8>,
    first: F,
    second: G,
) -> (Vec<u8>, Caught<R>, Caught<S>)
where
    F: Send + for<'a> FnOnce(&'a [u8]) -> R,
    G: Send + for<'a> FnOnce(&'a [u8]) -> S,
    R: Send,
    S: Send,
{
    use creusot_std::std::thread::{self, JoinHandleExt};

    let mut owner = Owner::new(input);
    let (left, right, context) = owner.share_pair();
    let parent = &context;
    let (left, right) = thread::scope(move |scope| {
        let left = scope.spawn(move |tokens| {
            let bytes = left.bytes;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
                first(bytes)
            }));
            let closed = left.close(parent, tokens);
            (outcome, closed)
        });
        let right = scope.spawn(move |tokens| {
            let bytes = right.bytes;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
                second(bytes)
            }));
            let closed = right.close(parent, tokens);
            (outcome, closed)
        });
        (left.join_unwrap(), right.join_unwrap())
    });

    let (bytes, first_last, second_last) = owner.thaw(context, left.1, right.1);
    proof_assert!(first_last != second_last);
    (bytes, left.0, right.0)
}

pub(crate) fn with_shared_read_then_thaw_resume<F, G, R, S>(
    input: Vec<u8>,
    first: F,
    second: G,
) -> (Vec<u8>, R, S)
where
    F: Send + for<'a> FnOnce(&'a [u8]) -> R,
    G: Send + for<'a> FnOnce(&'a [u8]) -> S,
    R: Send,
    S: Send,
{
    let (bytes, first, second) = with_shared_read_then_thaw_caught(input, first, second);
    match (first, second) {
        (Ok(first), Ok(second)) => (bytes, first, second),
        (Err(payload), Ok(second)) => {
            exclusive::ExclusiveBytes::from_vec(bytes).close();
            drop(second);
            std::panic::resume_unwind(payload)
        }
        (Ok(first), Err(payload)) => {
            exclusive::ExclusiveBytes::from_vec(bytes).close();
            drop(first);
            std::panic::resume_unwind(payload)
        }
        (Err(payload), Err(other_payload)) => {
            exclusive::ExclusiveBytes::from_vec(bytes).close();
            drop(other_payload);
            std::panic::resume_unwind(payload)
        }
    }
}

/* Failure-phase notes:

- `catch_unwind` returns normally only for unwind panics; `panic=abort`, process
  aborts, and double-panic abort do not reach explicit close.
- Catch results carry `Box<dyn Any + Send>` across worker joins. This is a likely
  first translator boundary; converting/dropping the payload before parent
  cleanup would let a panic in its destructor bypass Owner::close.
- The current `FnOnce` contract models normal call/postcondition only. It does
  not say when a panic occurs or what state it leaves in callback captures.
  `AssertUnwindSafe` suppresses Rust's marker check but proves no such property.
- No stock Creusot `catch_unwind`, `AssertUnwindSafe`, or unwind-effect spec was
  found. This code intentionally has no trusted substitute.
- Current thread `Scope::spawn` takes ownership of each handle in its closure.
  A spawn failure before the closure runs leaves no explicit close receipt; the
  wrapper's contract only specifies normal return. Builder/spawn-failure recovery
  is a separate representation/interface experiment.
*/

#[cfg(all(test, not(creusot), feature = "std"))]
mod tests {
    use super::*;
    use alloc::vec::Vec;
    use core::sync::atomic::{AtomicBool, Ordering};
    use std::sync::Arc;

    #[test]
    fn catches_first_second_and_both_callback_panics() {
        // Empty payload with spare capacity, first callback panics.
        let input = Vec::with_capacity(8);
        let (first, second) = with_shared_read_caught(
            input,
            |_bytes| -> usize { panic!("first callback") },
            |bytes| bytes.len(),
        );
        assert!(first.is_err());
        assert_eq!(second.unwrap(), 0);

        // Nonempty payload with spare capacity, second callback panics.
        let mut input = Vec::with_capacity(12);
        input.extend_from_slice(b"bytes");
        let (first, second) = with_shared_read_caught(
            input,
            |bytes| bytes.len(),
            |_bytes| -> usize { panic!("second callback") },
        );
        assert_eq!(first.unwrap(), 5);
        assert!(second.is_err());

        // Both callbacks panic; owner cleanup still follows both explicit closes.
        let input = Vec::new();
        let (first, second) = with_shared_read_caught(
            input,
            |_bytes| -> () { panic!("first callback") },
            |_bytes| -> () { panic!("second callback") },
        );
        assert!(first.is_err());
        assert!(second.is_err());
    }

    #[test]
    fn thaw_returns_original_allocation_after_a_caught_callback_panic() {
        let mut input = Vec::with_capacity(12);
        input.extend_from_slice(b"thaw");
        let pointer = input.as_ptr();
        let capacity = input.capacity();

        let (bytes, first, second) = with_shared_read_then_thaw_caught(
            input,
            |_bytes| -> usize { panic!("thaw callback") },
            |bytes| bytes.len(),
        );
        assert_eq!(bytes.as_ptr(), pointer);
        assert_eq!(bytes.capacity(), capacity);
        assert_eq!(bytes, b"thaw");
        assert!(first.is_err());
        assert_eq!(second.unwrap(), 4);
        exclusive::ExclusiveBytes::from_vec(bytes).close();
    }

    #[test]
    fn thaw_resume_closes_bytes_before_dropping_peer_result_and_resuming() {
        struct DropFlag(Arc<AtomicBool>);
        impl Drop for DropFlag {
            fn drop(&mut self) {
                self.0.store(true, Ordering::SeqCst);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let callback_drop = Arc::clone(&dropped);
        let mut input = Vec::with_capacity(8);
        input.extend_from_slice(b"x");
        let resumed = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
            with_shared_read_then_thaw_resume(
                input,
                move |_bytes| DropFlag(callback_drop),
                |_bytes| -> () { panic!("resume callback") },
            )
        }));
        assert!(resumed.is_err());
        assert!(dropped.load(Ordering::SeqCst));
    }

    #[test]
    fn shared_resume_closes_owner_before_resuming_both_callback_panics() {
        let input = Vec::with_capacity(16);
        let resumed = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            with_shared_read_resume(
                input,
                |_bytes| -> () { panic!("first callback") },
                |_bytes| -> () { panic!("second callback") },
            )
        }));
        assert!(resumed.is_err());
    }
}
