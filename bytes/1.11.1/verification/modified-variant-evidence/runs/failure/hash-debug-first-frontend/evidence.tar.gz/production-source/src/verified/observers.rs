//! Equality observers backed by the verified standard slice comparison contract.

use creusot_std::prelude::*;
use alloc::vec::Vec;
use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};

use super::exclusive::ExclusiveBytes;

impl DeepModel for ExclusiveBytes {
    type DeepModelTy = Seq<Int>;

    #[logic(open)]
    fn deep_model(self) -> Self::DeepModelTy {
        pearlite! { self@.map(|byte: u8| byte@) }
    }
}

impl PartialEq for ExclusiveBytes {
    #[ensures(result == (self.deep_model() == other.deep_model()))]
    fn eq(&self, other: &Self) -> bool {
        <Self as AsRef<[u8]>>::as_ref(self) == <Self as AsRef<[u8]>>::as_ref(other)
    }
}

impl Eq for ExclusiveBytes {}

impl PartialOrd for ExclusiveBytes {
    #[ensures(result == (*self).deep_model().partial_cmp_log((*other).deep_model()))]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(<Self as Ord>::cmp(self, other))
    }
}

impl Ord for ExclusiveBytes {
    #[ensures(result == (*self).deep_model().cmp_log((*other).deep_model()))]
    fn cmp(&self, other: &Self) -> Ordering {
        <Self as AsRef<[u8]>>::as_ref(self).cmp(<Self as AsRef<[u8]>>::as_ref(other))
    }
}

impl Hash for ExclusiveBytes {
    fn hash<H: Hasher>(&self, state: &mut H) {
        state.write(self.as_slice())
    }
}

impl fmt::Debug for ExclusiveBytes {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_tuple("ExclusiveBytes")
            .field(&self.as_slice())
            .finish()
    }
}

#[logic(open)]
#[requires(0 <= byte && byte <= 255)]
fn decimal_byte_model(byte: Int) -> Seq<Int> {
    pearlite! {
        if byte < 10 {
            Seq::singleton(48 + byte)
        } else if byte < 100 {
            Seq::singleton(48 + byte / 10).push_back(48 + byte % 10)
        } else {
            Seq::singleton(48 + byte / 100)
                .push_back(48 + (byte / 10) % 10)
                .push_back(48 + byte % 10)
        }
    }
}

#[logic(open)]
#[variant(bytes.len())]
fn decimal_list_model(bytes: Seq<Int>) -> Seq<Int> {
    pearlite! {
        if bytes.len() == 0 {
            Seq::empty()
        } else if bytes.len() == 1 {
            decimal_byte_model(bytes[0])
        } else {
            decimal_byte_model(bytes[0])
                .concat(seq![44, 32])
                .concat(decimal_list_model(bytes.subsequence(1, bytes.len())))
        }
    }
}

#[logic(open)]
fn debug_model(bytes: Seq<Int>) -> Seq<Int> {
    pearlite! {
        seq![69, 120, 99, 108, 117, 115, 105, 118, 101, 66, 121, 116, 101, 115, 40, 91]
            .concat(decimal_list_model(bytes))
            .concat(seq![93, 41])
    }
}

/// Diagnostic output function with an exact ASCII model for this Debug impl.
#[ensures(result@.to_bytes().map(|byte: u8| byte@) == debug_model(value.deep_model()))]
fn debug_string(value: &ExclusiveBytes) -> alloc::string::String {
    std::format!("{:?}", value)
}

/// A concrete hasher used only to state the byte effect of the trait call.
struct ByteLogHasher {
    log: Vec<u8>,
}

impl View for ByteLogHasher {
    type ViewTy = Seq<u8>;

    #[logic]
    fn view(self) -> Self::ViewTy {
        pearlite! { self.log@ }
    }
}

impl Hasher for ByteLogHasher {
    fn finish(&self) -> u64 {
        0
    }

    #[ensures((^self)@ == self@.concat(bytes@))]
    fn write(&mut self, bytes: &[u8]) {
        self.log.extend(bytes.iter().copied());
    }
}

/// Diagnostic caller: require the standard `Hash` implementation to feed the
/// exact byte sequence to a concrete, specified hasher.
#[ensures((^state)@ == state@.concat(value@))]
fn hash_to_byte_log(value: &ExclusiveBytes, state: &mut ByteLogHasher) {
    value.hash(state);
}

/// Compares two exclusive owners, then releases both allocations explicitly.
#[ensures(result == (left.deep_model() == right.deep_model()))]
pub fn equal_then_close(left: ExclusiveBytes, right: ExclusiveBytes) -> bool {
    let equal = left == right;
    left.close();
    right.close();
    equal
}

/// Orders two exclusive owners, then explicitly releases both allocations.
#[ensures(result == left.deep_model().cmp_log(right.deep_model()))]
pub fn cmp_then_close(left: ExclusiveBytes, right: ExclusiveBytes) -> Ordering {
    let ordering = left.cmp(&right);
    left.close();
    right.close();
    ordering
}

#[cfg(all(test, not(creusot), feature = "std"))]
mod tests {
    use super::*;
    use std::format;

    #[test]
    fn ordering_matches_lexicographic_slice_order_and_closes() {
        let left = ExclusiveBytes::copy_from_slice(b"byte");
        let right = ExclusiveBytes::copy_from_slice(b"bytes");
        assert_eq!(cmp_then_close(left, right), Ordering::Less);
    }

    #[test]
    fn hash_and_debug_match_the_borrowed_slice_representation() {
        use std::hash::Hasher as _;

        let expected: &[u8] = b"hash and debug";
        let bytes = ExclusiveBytes::copy_from_slice(expected);

        let mut actual_hasher = std::collections::hash_map::DefaultHasher::new();
        bytes.hash(&mut actual_hasher);
        let mut expected_hasher = std::collections::hash_map::DefaultHasher::new();
        expected_hasher.write(expected);
        assert_eq!(actual_hasher.finish(), expected_hasher.finish());

        assert_eq!(
            format!("{:?}", bytes),
            "ExclusiveBytes([104, 97, 115, 104, 32, 97, 110, 100, 32, 100, 101, 98, 117, 103])"
        );
        assert_eq!(
            debug_string(&bytes),
            "ExclusiveBytes([104, 97, 115, 104, 32, 97, 110, 100, 32, 100, 101, 98, 117, 103])"
        );

        let mut recorder = ByteLogHasher { log: Vec::new() };
        hash_to_byte_log(&bytes, &mut recorder);
        assert_eq!(recorder.log.as_slice(), expected);

        bytes.close();
    }
}
