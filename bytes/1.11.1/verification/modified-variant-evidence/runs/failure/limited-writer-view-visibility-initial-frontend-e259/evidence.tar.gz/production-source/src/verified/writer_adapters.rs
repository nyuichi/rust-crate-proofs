//! Bounded writers over concrete initialized byte owners.

use super::exclusive::ExclusiveBytes;
use creusot_std::prelude::*;

/// Appends at most `limit` bytes to one exclusively borrowed owner.
pub struct LimitedWriter<'a> {
    owner: &'a mut ExclusiveBytes,
    remaining: usize,
}

impl<'a> LimitedWriter<'a> {
    #[logic(open)]
    pub fn owner_view(self) -> Seq<u8> {
        pearlite! { (*self.owner)@ }
    }

    #[logic(open)]
    pub fn remaining_view(self) -> Int {
        pearlite! { self.remaining@ }
    }

    /// Borrows `owner` and creates a writer with the given append budget.
    #[ensures(result.owner_view() == owner@)]
    #[ensures(result.remaining_view() == limit@)]
    pub fn new(owner: &'a mut ExclusiveBytes, limit: usize) -> Self {
        Self { owner, remaining: limit }
    }

    /// Returns the number of bytes this writer may still append.
    #[ensures(result@ == self.remaining_view())]
    pub fn remaining(&self) -> usize {
        self.remaining
    }

    /// Appends `source` if the whole slice fits; failure leaves bytes and budget unchanged.
    #[ensures(result == (source@.len() <= self.remaining_view()))]
    #[ensures(if result {
        (^self).owner_view() == self.owner_view().concat(source@) &&
        (^self).remaining_view() == self.remaining_view() - source@.len()
    } else {
        (^self).owner_view() == self.owner_view() &&
        (^self).remaining_view() == self.remaining_view()
    })]
    pub fn write_slice(&mut self, source: &[u8]) -> bool {
        if source.len() > self.remaining {
            false
        } else {
            self.owner.extend_from_slice(source);
            self.remaining -= source.len();
            true
        }
    }

    /// Returns the borrowed owner with all successful appends applied.
    #[ensures(result@ == self.owner_view())]
    pub fn into_inner(self) -> &'a mut ExclusiveBytes {
        self.owner
    }
}
