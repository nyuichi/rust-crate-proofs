use std::sync::{Arc, atomic::AtomicUsize};

struct DropCapture(Arc<AtomicUsize>);
impl Drop for DropCapture {
    fn drop(&mut self) {}
}

fn require_copy_slot_callback<S, F, T>(slot: &mut S, f: F)
where
    S: Send,
    F: FnOnce(&mut S, ()) -> T + Copy + Send,
    T: Send,
{
    let _ = (slot, f);
}

fn main() {
    let mut slot = 0usize;
    let capture = DropCapture(Arc::new(AtomicUsize::new(0)));
    require_copy_slot_callback(&mut slot, move |slot, ()| {
        let _keep_capture = &capture;
        *slot
    });
}
