use std::io;
use std::sync::{Arc, atomic::{AtomicUsize, Ordering}};
use std::thread::{self, Builder};

struct MutateOnDrop(Arc<AtomicUsize>);
impl Drop for MutateOnDrop {
    fn drop(&mut self) { self.0.store(1, Ordering::SeqCst); }
}

fn attempt(slot: &mut Arc<AtomicUsize>, guard: MutateOnDrop) -> io::Result<()> {
    thread::scope(|scope| {
        let slot = slot;
        Builder::new().stack_size(usize::MAX).spawn_scoped(scope, move || {
            let _keep_slot_borrowed = slot;
            let _keep_guard = guard;
        }).map(|join| join.join().unwrap())
    })
}

fn main() {
    let shared = Arc::new(AtomicUsize::new(0));
    let mut slot = shared.clone();
    let guard = MutateOnDrop(shared.clone());
    assert!(attempt(&mut slot, guard).is_err());
    assert_eq!(slot.load(Ordering::SeqCst), 1);
}
