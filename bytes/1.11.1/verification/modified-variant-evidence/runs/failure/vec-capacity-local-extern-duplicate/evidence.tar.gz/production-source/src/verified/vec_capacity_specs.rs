//! Candidate generic Vec metadata contracts; not yet admitted or compiled.
//! These clauses are a standard-library TCB extension, never a bytes protocol.
use alloc::{vec::Vec, alloc::Allocator};
use creusot_std::prelude::*;

#[logic(opaque)]
pub(crate) fn capacity_model<T, A: Allocator>(vector: Vec<T, A>) -> Int { dead }

extern_spec! {
    impl<T, A: Allocator> Vec<T, A> {
        #[check(ghost)]
        #[ensures(result@ == capacity_model(*self))]
        #[ensures(result@ >= self@.len())]
        fn capacity(&self) -> usize;

        #[check(terminates)]
        #[ensures((^self)@ == self@)]
        #[ensures(capacity_model(^self) >= self@.len() + additional@)]
        #[ensures(capacity_model(^self) >= capacity_model(*self))]
        fn reserve(&mut self, additional: usize);

        #[check(terminates)]
        #[ensures((^self)@ == self@)]
        #[ensures(capacity_model(^self) >= self@.len() + additional@)]
        #[ensures(capacity_model(^self) >= capacity_model(*self))]
        fn reserve_exact(&mut self, additional: usize);

    }
    impl<T> Vec<T> {
        #[check(terminates)]
        #[ensures(result@ == Seq::empty())]
        #[ensures(capacity_model(result) >= requested@)]
        fn with_capacity(requested: usize) -> Vec<T>;
    }
}

#[ensures(result.0@ == input@)]
#[ensures(result.1@ >= input@.len() + additional@)]
fn reserve_observer(mut input: Vec<u8>, additional: usize) -> (Vec<u8>, usize) {
    input.reserve(additional);
    let capacity=input.capacity();
    (input,capacity)
}
