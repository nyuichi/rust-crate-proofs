//! Equality observers backed by the verified standard slice comparison contract.

use alloc::vec::Vec;
use creusot_std::prelude::*;
use core::cmp::Ordering;

use super::exclusive::ExclusiveBytes;

impl DeepModel for ExclusiveBytes {
    type DeepModelTy = Seq<Int>;

    #[logic(open)]
    fn deep_model(self) -> Self::DeepModelTy {
        pearlite! { self@.map(|byte: u8| byte@) }
    }
}

impl PartialEq for ExclusiveBytes {
    #[ensures(result == (self.deep_model() == other.deep_model()))]
    fn eq(&self, other: &Self) -> bool {
        <Self as AsRef<[u8]>>::as_ref(self) == <Self as AsRef<[u8]>>::as_ref(other)
    }
}

impl Eq for ExclusiveBytes {}

impl PartialOrd for ExclusiveBytes {
    #[ensures(result == (*self).deep_model().partial_cmp_log((*other).deep_model()))]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(<Self as Ord>::cmp(self, other))
    }
}

impl Ord for ExclusiveBytes {
    #[ensures(result == (*self).deep_model().cmp_log((*other).deep_model()))]
    fn cmp(&self, other: &Self) -> Ordering {
        <Self as AsRef<[u8]>>::as_ref(self).cmp(<Self as AsRef<[u8]>>::as_ref(other))
    }
}

/// Compares two exclusive owners, then releases both allocations explicitly.
#[ensures(result == (left.deep_model() == right.deep_model()))]
pub fn equal_then_close(left: ExclusiveBytes, right: ExclusiveBytes) -> bool {
    let equal = left == right;
    left.close();
    right.close();
    equal
}

/// Orders two exclusive owners, then explicitly releases both allocations.
#[ensures(result == left.deep_model().cmp_log(right.deep_model()))]
pub fn cmp_then_close(left: ExclusiveBytes, right: ExclusiveBytes) -> Ordering {
    let ordering = left.cmp(&right);
    left.close();
    right.close();
    ordering
}

/// Stable 64-bit polynomial digest over bytes, processed from left to right.
///
/// This is a deterministic summary function, not Rust's `Hash` protocol and
/// not a cryptographic digest.
#[logic(open)]
#[variant(bytes.len())]
pub fn stable_digest_model(bytes: Seq<Int>) -> Int {
    pearlite! {
        if bytes.len() == 0 {
            0
        } else {
            (stable_digest_model(bytes.subsequence(0, bytes.len() - 1)) * 257
                + bytes[bytes.len() - 1]) % 18446744073709551616
        }
    }
}

/// A lowercase ASCII hex digit. The precondition keeps the addition in range.
#[logic(open)]
pub fn hex_digit_model(nibble: Int) -> Int {
    pearlite! {
        if nibble < 10 { 48 + nibble } else { 87 + nibble }
    }
}

#[requires(nibble@ <= 15)]
#[ensures(result@ == hex_digit_model(nibble@))]
fn encode_hex_digit(nibble: u8) -> u8 {
    if nibble < 10 {
        b'0' + nibble
    } else {
        b'a' + (nibble - 10)
    }
}

/// The two lowercase hexadecimal digits for one byte.
#[logic(open)]
pub fn hex_byte_model(byte: Int) -> Seq<Int> {
    pearlite! {
        Seq::singleton(hex_digit_model(byte / 16))
            .push_back(hex_digit_model(byte % 16))
    }
}

/// The concatenated lowercase hexadecimal representation of a byte sequence.
#[logic(open)]
#[variant(bytes.len())]
pub fn hex_bytes_model(bytes: Seq<Int>) -> Seq<Int> {
    pearlite! {
        if bytes.len() == 0 {
            Seq::empty()
        } else {
            hex_bytes_model(bytes.subsequence(0, bytes.len() - 1))
                .concat(hex_byte_model(bytes[bytes.len() - 1]))
        }
    }
}

impl ExclusiveBytes {
    /// Computes the specified 64-bit polynomial digest over this byte sequence.
    #[ensures(result@ == stable_digest_model(self.deep_model()))]
    pub fn stable_digest(&self) -> u64 {
        let input = self.as_slice();
        let mut digest = 0u64;
        let mut index = 0usize;

        #[invariant(index@ <= input@.len())]
        #[invariant(digest@ == stable_digest_model(self.deep_model().subsequence(0, index@)))]
        #[variant(input@.len() - index@)]
        while index < input.len() {
            digest = digest
                .wrapping_mul(257u64)
                .wrapping_add(input[index] as u64);
            index += 1;
        }

        digest
    }

    /// Creates a new owner containing two lowercase hex digits per input byte.
    ///
    /// The returned owner has the exact byte model in `hex_bytes_model`; callers
    /// release it explicitly with [`ExclusiveBytes::close`].
    #[ensures(result.deep_model() == hex_bytes_model(self.deep_model()))]
    pub fn hex_bytes(&self) -> ExclusiveBytes {
        let input = self.as_slice();
        let mut output = ExclusiveBytes::from_vec(Vec::new());
        let mut index = 0usize;

        #[invariant(index@ <= input@.len())]
        #[invariant(output.deep_model() ==
            hex_bytes_model(self.deep_model().subsequence(0, index@)))]
        #[variant(input@.len() - index@)]
        while index < input.len() {
            let byte = input[index];
            let pair = [encode_hex_digit(byte / 16), encode_hex_digit(byte % 16)];
            output.append_initialized_slice(&pair);
            index += 1;
        }

        output
    }
}

/// Computes both summaries, then explicitly closes the source owner.
#[ensures(result.0@ == stable_digest_model(source.deep_model()))]
#[ensures(result.1.deep_model() == hex_bytes_model(source.deep_model()))]
pub fn digest_and_hex_close(source: ExclusiveBytes) -> (u64, ExclusiveBytes) {
    let digest = source.stable_digest();
    let encoded = source.hex_bytes();
    source.close();
    (digest, encoded)
}

#[cfg(all(test, not(creusot), feature = "std"))]
mod tests {
    use super::*;

    #[test]
    fn ordering_matches_lexicographic_slice_order_and_closes() {
        let left = ExclusiveBytes::copy_from_slice(b"byte");
        let right = ExclusiveBytes::copy_from_slice(b"bytes");
        assert_eq!(cmp_then_close(left, right), Ordering::Less);
    }
}

#[cfg(all(test, not(creusot), feature = "std"))]
mod deterministic_tests {
    use super::{digest_and_hex_close, ExclusiveBytes};
    use std::vec;

    #[test]
    fn deterministic_digest_and_hex_model_match_and_close() {
        let (digest, encoded) = digest_and_hex_close(
            ExclusiveBytes::from_vec(vec![0x00, 0x0a, 0x10, 0xff]),
        );
        let expected_digest = (((0u64.wrapping_mul(257).wrapping_add(0x00))
            .wrapping_mul(257).wrapping_add(0x0a))
            .wrapping_mul(257).wrapping_add(0x10))
            .wrapping_mul(257).wrapping_add(0xff);
        assert_eq!(digest, expected_digest);
        assert_eq!(encoded.as_slice(), b"000a10ff");
        encoded.close();
    }

    #[test]
    fn empty_deterministic_summaries_close() {
        let (digest, encoded) = digest_and_hex_close(ExclusiveBytes::from_vec(vec![]));
        assert_eq!(digest, 0);
        assert!(encoded.is_empty());
        encoded.close();
    }
}
