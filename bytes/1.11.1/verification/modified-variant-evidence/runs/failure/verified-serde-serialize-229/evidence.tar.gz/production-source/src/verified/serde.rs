//! Serde support for the modified verified byte owner.

use crate::verified::exclusive::ExclusiveBytes;
use serde::{Serialize, Serializer};

impl Serialize for ExclusiveBytes {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_bytes(self.as_slice())
    }
}

#[cfg(all(test, not(creusot), feature = "std"))]
mod tests {
    use super::*;
    use serde_test::{assert_ser_tokens, Token};

    #[test]
    fn exclusive_bytes_serialize_as_byte_tokens() {
        for (input, expected) in [
            (&b""[..], &b""[..]),
            (&b"bytes"[..], &b"bytes"[..]),
        ] {
            let value = ExclusiveBytes::copy_from_slice(input);
            assert_ser_tokens(&value, &[Token::Bytes(expected)]);
            value.close();
        }
    }
}
