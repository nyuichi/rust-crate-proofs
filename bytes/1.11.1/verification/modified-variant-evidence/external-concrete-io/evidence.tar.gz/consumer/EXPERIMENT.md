# Downstream concrete IO contract experiment

Changed premise: concrete std::io implementations have body-proved contracts, but
outside-crate callability has not been checked. Depend on exact archived
production-closed-io-263 source and committed main 011d21cc. The live worktree later
contains root's portable atomic changes; those are not selected for this capture.
No production/std edits.

Use fully qualified concrete Read::read/Write::write/flush calls. Prove min-length
read, suffix consumption, destination prefix/tail frame; append and unchanged
flush contents; consuming explicit cleanup for owned values. Return io::Result
unchanged to avoid unrelated error payload handling. Native tests cover empty,
short and full buffers. No generic trait/default-method law, error/unwind cleanup,
or arbitrary external implementation correctness is claimed.

Stop: preserve first structural obstruction and review; two equivalent semantic
failures require interface review, three require restructuring. No added trust,
no timeout or solver-count escalation. Proof uses shared lock, elevated first,
one solver, 1024 MiB, existing pinned TCB.
