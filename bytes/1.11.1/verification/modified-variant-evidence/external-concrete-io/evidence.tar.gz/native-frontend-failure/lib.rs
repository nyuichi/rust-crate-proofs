use bytes::verified::{cursor::Cursor, exclusive::ExclusiveBytes};
use creusot_std::prelude::*;
use std::io::{Read, Write};

#[ensures(match result {
    Ok(count) => count@ == (if dst@.len() < cursor@.len() { dst@.len() } else { cursor@.len() })
        && (^cursor)@ == cursor@[count@..]
        && (forall<i: Int> 0 <= i && i < count@ ==> (^dst)@[i] == cursor@[i])
        && (forall<i: Int> count@ <= i && i < dst@.len() ==> (^dst)@[i] == dst@[i]),
    Err(_) => false,
})]
pub fn read_concrete(cursor: &mut Cursor<'_>, dst: &mut [u8]) -> std::io::Result<usize> {
    <Cursor<'_> as Read>::read(cursor, dst)
}

#[ensures(match result.0 { Ok(count) => count@ == source@.len(), Err(_) => false })]
#[ensures(result.1 == if index@ < input@.len() + source@.len() {
    Some(input@.concat(source@)[index@])
} else { None })]
pub fn write_then_close(input: Vec<u8>, source: &[u8], index: usize)
    -> (std::io::Result<usize>, Option<u8>)
{
    let mut owner = ExclusiveBytes::from_vec(input);
    let written = <ExclusiveBytes as Write>::write(&mut owner, source);
    let observed = owner.get(index);
    owner.close();
    (written, observed)
}

#[ensures(match result.0 { Ok(()) => true, Err(_) => false })]
#[ensures(result.1 == if index@ < input@.len() { Some(input@[index@]) } else { None })]
pub fn flush_then_close(input: Vec<u8>, index: usize)
    -> (std::io::Result<()>, Option<u8>)
{
    let mut owner = ExclusiveBytes::from_vec(input);
    let flushed = <ExclusiveBytes as Write>::flush(&mut owner);
    let observed = owner.get(index);
    owner.close();
    (flushed, observed)
}

#[cfg(all(test, not(creusot)))]
mod tests {
    use super::*;

    #[test]
    fn concrete_read_prefix_and_tail() {
        for n in 0..=4 {
            for capacity in 0..=5 {
                let input: Vec<u8> = (0..n).map(|i| 20+i).collect();
                let mut cursor = Cursor::new(&input);
                let mut destination = vec![199; capacity];
                let count = read_concrete(&mut cursor, &mut destination).unwrap();
                assert_eq!(count, input.len().min(capacity));
                assert_eq!(&destination[..count], &input[..count]);
                assert!(destination[count..].iter().all(|b| *b==199));
                assert_eq!(cursor.chunk(), &input[count..]);
            }
        }
    }

    #[test]
    fn concrete_write_and_flush_close() {
        for input in [vec![], vec![1, 2]] {
            for source in [vec![], vec![3, 4]] {
                let expected = [input.as_slice(), source.as_slice()].concat();
                for index in 0..=expected.len() {
                    let (count, observed) = write_then_close(input.clone(), &source, index);
                    assert_eq!(count.unwrap(), source.len());
                    assert_eq!(observed, expected.get(index).copied());
                }
            }
            for index in 0..=input.len() {
                let (result, observed) = flush_then_close(input.clone(), index);
                result.unwrap();
                assert_eq!(observed, input.get(index).copied());
            }
        }
    }
}
