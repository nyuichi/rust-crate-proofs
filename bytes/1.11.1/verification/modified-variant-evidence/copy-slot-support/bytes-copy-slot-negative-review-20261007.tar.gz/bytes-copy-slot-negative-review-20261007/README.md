# Explicit-slot scoped spawn candidate: positive caller and adequacy negative

This is a read-only diagnostic package assembled from isolated `/tmp` snapshots. No production repository file or installed `creusot-std` source was changed. The modified standard wrapper compiled from a copied Creusot 0.13.0 source tree via the captured Cargo path override.

## Candidate

`candidate/thread-slot-wrapper.patch` adds `Scope::try_spawn_with_slot`. It accepts a `Builder` stack-size option, an explicitly parent-owned `&mut S` slot, and a `Copy + Send` `FnOnce`. On normal `None`, its contract says only that the slot remains unchanged. On `Some`, the contract uses the child reborrow and fresh `Tokens` to connect a valid join result to the callback postcondition. The wrapper discards `io::Error` details. `Copy` avoids a user `Drop` running when an unstarted closure is dropped. No guarantee is made about other external state, unwind behavior, or bytes-specific ownership.

The candidate was checked by native tests and actual Creusot translation/proof in a scratch package. The successful caller is preserved in `candidate/parent-retained-caller.rs`; native test output is `positive-native/native-test.log` (2 passed, including forced Builder failure with parent slot available for explicit close). The positive full proof log reports `Proved (256 files)`. Its full augmented evidence archive is separately preserved at `/tmp/bytes-copy-slot-positive-augmented-20261007-v3.tar.gz` (SHA-256 `728a49f81def0a6585aa0abcb9ca9c9dbf8bfe21d3199758543bf3941cb9523c`). Requested and effective feature graphs are copied alongside the native output.

## Adequacy negative

`candidate/mutated-slot-negative.rs` declares that `None` preserves a mutable `usize`, then assigns `1` and returns `None`. Native-to-Creusot translation passed (exit 0). The actual proof run failed exactly the intended VC:

```
Goal Coma.vc_bad_mutate_then_none: ✘
Error: 1 unproved file
Error: 'why3find prove' failed
```

`evidence/mutated-slot-negative-proof.json` records `vc_bad_mutate_then_none: null`. The full capture includes the candidate source graph, generated Coma, proof JSON, run manifest and source hashes. Capture SHA-256: `8dd93014c04786580f39db0d2c187d1dae114f1e11fe56b4705b8a4df1c4f435`.

The first negative fixture is retained in `initial-fixture-syntax-failure/`; it used `#[requires(*slot == 0)]` and failed frontend typechecking because the contract compared `usize` and logic `Int`. It was corrected by removing that unnecessary precondition and assigning `1` directly. The successful translation and expected unproved VC are in the later v2 capture, not the syntax-failure attempt.

## Source hashes

- Candidate wrapper source: `2f209af914f7367be36b3edb8e8fe9ca880bfc2340ff4a1fa13a050c4c63a8b6`
- Candidate patch: `2e852512028d4317c17030292762b389bd5b03ba84139098c3c2e1891dea74fa`
- Positive caller: `1f9a6560672e2b94f462d62c582ce188c7ace676210f2de2648d42ab7ac3caba`
- Mutated-slot negative source: `573d36d83d39e14b827bced8b6efadf63c701a6790c6c9c7c8fdafaacb7e2746`
