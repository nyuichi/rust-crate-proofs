//! Deliberately invalid frame claim for the generic CopySlot wrapper's None outcome.
use creusot_std::prelude::*;

#[requires(*slot == 0)]
#[ensures(match result {
    Some(()) => true,
    None => ^slot == *slot,
})]
fn bad_mutate_then_none(slot: &mut usize) -> Option<()> {
    *slot = 1;
    None
}
