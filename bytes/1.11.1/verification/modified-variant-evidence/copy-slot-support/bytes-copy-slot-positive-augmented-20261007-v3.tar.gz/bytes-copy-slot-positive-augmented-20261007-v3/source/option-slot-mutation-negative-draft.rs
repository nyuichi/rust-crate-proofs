//! Negative companion for `None => ^slot == *slot`; assignment makes the false ensure deterministic.
use creusot_std::prelude::*;

#[requires(*slot == 0)]
#[ensures(match result {
    Some(()) => true,
    None => ^slot == *slot,
})]
fn bad_mutate_then_none(slot: &mut usize) -> Option<()> {
    *slot = 1;
    None
}
