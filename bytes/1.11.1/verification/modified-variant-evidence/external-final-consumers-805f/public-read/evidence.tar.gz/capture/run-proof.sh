#!/usr/bin/env bash
set -euo pipefail
consumer_tag=$1
package_name=$2
consumer_root=$(cd "$(dirname "$0")/$consumer_tag" && pwd)
tool_root=/workspace/bytes-proof-tools
source "$tool_root/activate.sh"
export CARGO_NET_OFFLINE=true
cd "$consumer_root"
exec 9>"${BYTES_PROOF_LOCK:-/tmp/itoa-creusot-proof.lock}"
flock 9
task_config="${TMPDIR:-/tmp}/bytes-downstream-final-287-${consumer_tag}-creusot-config"
mkdir -p "$task_config/creusot"
sed 's/^memlimit = .*/memlimit = 1024/' \
    "$XDG_CONFIG_HOME/creusot/why3.conf" > "$task_config/creusot/why3.conf"
export XDG_CONFIG_HOME="$task_config"

native_tree=$(cargo tree --locked --no-default-features -e features --edges normal,build)
printf '%s\n' "$native_tree" > native-effective-features.log
proof_tree=$(cargo tree --locked --no-default-features -F creusot-std/creusot -F creusot-std/nightly -e features --edges normal,build)
printf '%s\n' "$proof_tree" > proof-effective-features.log
if [[ "$native_tree $proof_tree" == *'creusot-std feature "sc-drf"'* ]]; then
  printf 'sc-drf must be disabled\n' >&2
  exit 2
fi
cargo test --locked --lib > native.log 2>&1
cargo clean --package "$package_name"
rm -rf -- verif
cargo creusot --only=coma -- --locked --lib
cargo creusot clean --force
cargo creusot --only=prove --why3find-arg=-j --why3find-arg=1
