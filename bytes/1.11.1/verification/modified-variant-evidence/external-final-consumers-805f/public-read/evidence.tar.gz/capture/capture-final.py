#!/usr/bin/env python3
from __future__ import annotations
import hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path

BASE=Path('/tmp/bytes-downstream-final-287')
ROOT=Path('/workspace/rust-crate-proofs/bytes/1.11.1')
STD=Path('/workspace/bytes-proof-tools/bytes-verified-std')
ROOT_BASELINE=Path('/workspace/bytes-final-api-closure-probe/baseline-source.json')
ROOT_POS=ROOT/'verification/modified-variant-evidence/runs/positive/production-finite-cursor-std-287'

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def null_paths(v,path=()):
    if v is None: yield list(path)
    elif isinstance(v,dict):
        for k,x in v.items(): yield from null_paths(x,path+(str(k),))
    elif isinstance(v,list):
        for i,x in enumerate(v): yield from null_paths(x,path+(str(i),))
def add(files:dict[str,bytes],name:str,data:bytes):
    if name in files: raise ValueError('duplicate archive member '+name)
    files[name]=data

def main():
    if len(sys.argv) not in (5,6): raise SystemExit('usage: capture-final.py consumer-tag consumer-dir native-log proof-log [positive|failure]')
    tag, raw_consumer, raw_native, raw_proof=sys.argv[1:5]
    kind=sys.argv[5] if len(sys.argv)==6 else 'positive'
    if kind not in ('positive','failure'): raise SystemExit('kind must be positive or failure')
    consumer=Path(raw_consumer).resolve()
    native=Path(raw_native).resolve(); proof=Path(raw_proof).resolve()
    if not native.is_file() or not proof.is_file(): raise SystemExit('missing completed logs')
    baseline=json.loads(ROOT_BASELINE.read_text())
    root_head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
    expected_root='805f61e3c55be6cc32dac3cf3708063ab923f3ff'
    if baseline.get('root_head') != expected_root[:8]: raise SystemExit('unexpected 805f source manifest')
    files:dict[str,bytes]={}
    root_src=baseline['source_files']
    for rel,want in sorted(root_src.items()):
        data=(ROOT/rel).read_bytes()
        if sha(data)!=want: raise SystemExit('current root source mismatch: '+rel)
        add(files,'dependency/root-805f61e3/'+rel,data)
    # The downstream compiler resolves the private Std through Cargo's own patch.
    std_source=json.loads(tarfile.open(ROOT_POS/'evidence.tar.gz','r:gz').extractfile('configuration/actual-creusot-std-source.json').read())
    expected_std=std_source['files']
    local_std={'Cargo.toml':(STD/'Cargo.toml').read_bytes()}
    for p in sorted(STD.rglob('*.rs')):
        local_std[p.relative_to(STD).as_posix()]=p.read_bytes()
    if len(local_std)!=105 or set(local_std)!=set(expected_std): raise SystemExit('private Std source member set differs from captured 105-file package')
    for rel,data in sorted(local_std.items()):
        meta=expected_std[rel]
        if len(data)!=meta['bytes'] or sha(data)!=meta['sha256']: raise SystemExit('private Std source mismatch: '+rel)
        add(files,'dependency/private-creusot-std-0.13.0/'+rel,data)
    manifest=json.loads(tarfile.open(ROOT_POS/'evidence.tar.gz','r:gz').extractfile('configuration/actual-creusot-std-source.json').read())
    root_receipt=json.loads((ROOT_POS/'receipt.json').read_text())
    if root_receipt['counts']['coma_files']!=287 or root_receipt['counts']['null_proof_result_leaves']!=0:
        raise SystemExit('final 287 root positive receipt is not clean')
    source_status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain','--untracked-files=no'],text=True)
    if source_status.strip(): raise SystemExit('tracked root source has uncommitted changes')
    dep_ref={
      'compiled_dependency_path':str(ROOT),
      'compiled_source_baseline_commit':expected_root,
      'current_checkout_head':root_head,
      'current_checkout_source_files':len(root_src),
      'all_805f_source_hashes_match':True,
      'final_287_positive_archive_sha256':root_receipt['archive']['sha256'],
      'final_287_proof_files':root_receipt['counts']['coma_files'],
      'final_287_null_leaves':root_receipt['counts']['null_proof_result_leaves'],
      'private_creusot_std_path':str(STD),
      'private_creusot_std_source_files':len(local_std),
      'private_creusot_std_matches_287_gate_snapshot':True,
      'std_source_note':'Cargo.toml plus all 104 Rust files (105 package source members) exactly match the root 287 gate snapshot.'
    }
    add(files,'dependency/reference.json',json.dumps(dep_ref,indent=2).encode()+b'\n')
    add(files,'dependency/root-287-receipt.json',(ROOT_POS/'receipt.json').read_bytes())
    for rel in ('Cargo.toml','Cargo.lock','src/lib.rs','why3find.json','native-effective-features.log','proof-effective-features.log'):
        add(files,'consumer/'+rel,(consumer/rel).read_bytes())
    add(files,'capture/run-proof.sh',(BASE/'run-proof.sh').read_bytes())
    add(files,'capture/capture-final.py',Path(__file__).read_bytes())
    add(files,'logs/native.log',native.read_bytes())
    add(files,'logs/proof.log',proof.read_bytes())
    for rel in ('configuration/creusot/why3.conf',):
        cfg=Path('/tmp')/('bytes-downstream-final-287-'+tag+'-creusot-config')/rel
        if cfg.is_file(): add(files,'configuration/effective-why3.conf',cfg.read_bytes())
    comas=[]; proofs=[]; nulls=[]
    for p in sorted((consumer/'verif').rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(consumer/'verif').as_posix()
        add(files,'verif/'+rel,p.read_bytes())
        if rel.endswith('.coma'): comas.append(rel)
        elif rel.endswith('/proof.json'):
            proofs.append(rel)
            nulls.extend((rel,*path) for path in null_paths(json.loads(p.read_text()).get('proofs',{})))
    if kind=='positive':
        if len(comas)!=len(proofs): raise SystemExit(f'Coma/proof mismatch: {len(comas)}/{len(proofs)}')
        if nulls: raise SystemExit('null proof leaves: '+repr(nulls))
        if not re.search(r'Proved\s*\('+str(len(comas))+r' files\)',proof.read_text(errors='replace')): raise SystemExit('proof log does not confirm exact count')
        expected_count=6 if tag=='public-read' else 3
        if len(comas)!=expected_count: raise SystemExit(f'{tag}: expected {expected_count} VCs, got {len(comas)}')
    if 'test result: ok.' not in native.read_text(errors='replace'): raise SystemExit('native log has no passing test result')
    record={
      'kind':kind,'exit_code':0 if kind=='positive' else 1,'scope':'Actual downstream bodies call the final 805f61e3 public bytes API through a Cargo path dependency; the consumer Cargo patch resolves the current private Std 0.13 package. No full-coverage claim.',
      'proof_log_completeness':('Full Creusot command output was captured.' if tag=='public-read' else 'Short result summary only; full warning stream returned by the tool session was not retained.'),
      'consumer':tag,'command':'cargo creusot --only=coma -- --locked --lib; cargo creusot --only=prove --why3find-arg=-j --why3find-arg=1',
      'native_command':'cargo test --locked --lib','features':{'bytes':['verified','std'],'implicit':['creusot-std/creusot','creusot-std/nightly']},
      'dependency_source':dep_ref,'counts':{'coma':len(comas),'proof_json':len(proofs),'null_leaves':len(nulls)},'full_coverage':False
    }
    add(files,'run.json',json.dumps(record,indent=2).encode()+b'\n')
    member_manifest={n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}
    add(files,'members.json',json.dumps(member_manifest,indent=2).encode()+b'\n')
    complete_manifest={n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}
    out=BASE/'evidence'/(tag+'-final-canonical' if kind=='positive' else tag+'-final-canonical-failure')
    out.mkdir(parents=True,exist_ok=False)
    archive=out/'evidence.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for n,b in sorted(files.items()):
            ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o644
            tar.addfile(ti,io.BytesIO(b))
    with tarfile.open(archive,'r:gz') as tar:
        names={item.name for item in tar.getmembers() if item.isfile()}
        if names!=set(complete_manifest): raise SystemExit('archive member set differs from manifest')
        for n,meta in complete_manifest.items():
            data=tar.extractfile(n).read()
            if len(data)!=meta['bytes'] or sha(data)!=meta['sha256']: raise SystemExit('archive verification failed: '+n)
    receipt={**record,'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'members_verified':len(complete_manifest),'members':complete_manifest,'null_proof_paths':nulls}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('dependency_source','null_proof_paths')},indent=2))
if __name__=='__main__': main()
