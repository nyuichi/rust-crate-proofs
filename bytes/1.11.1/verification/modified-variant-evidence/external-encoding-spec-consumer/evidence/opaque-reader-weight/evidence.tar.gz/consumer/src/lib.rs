#![allow(unexpected_cfgs)]

use bytes::verified::{cursor::Cursor, encoding_spec, exclusive::ExclusiveBytes};
use creusot_std::prelude::*;
use std::vec::Vec;

/// A downstream caller consumes the public byte model, writes through the
/// public method contract, reads both bytes, and closes the allocation.
#[ensures(result.0 != None && result.0.unwrap_logic()@ == value@ / 256)]
#[ensures(result.1 != None && result.1.unwrap_logic()@ == value@ % 256)]
pub fn external_be_u16_roundtrip(value: u16) -> (Option<u8>, Option<u8>) {
    proof_assert!(encoding_spec::model_be_bytes(value@, 2)[0] == value@ / 256);
    proof_assert!(encoding_spec::model_be_bytes(value@, 2)[1] == value@ % 256);

    let mut bytes = ExclusiveBytes::from_vec(Vec::new());
    bytes.write_u16_be(value);
    let first = bytes.get(0);
    let second = bytes.get(1);
    bytes.close();
    (first, second)
}

/// The same downstream composition for little-endian output.
#[ensures(result.0 != None && result.0.unwrap_logic()@ == value@ % 256)]
#[ensures(result.1 != None && result.1.unwrap_logic()@ == value@ / 256)]
pub fn external_le_u16_roundtrip(value: u16) -> (Option<u8>, Option<u8>) {
    proof_assert!(encoding_spec::model_le_bytes(value@, 2)[0] == value@ % 256);
    proof_assert!(encoding_spec::model_le_bytes(value@, 2)[1] == value@ / 256);

    let mut bytes = ExclusiveBytes::from_vec(Vec::new());
    bytes.write_u16_le(value);
    let first = bytes.get(0);
    let second = bytes.get(1);
    bytes.close();
    (first, second)
}

/// Checks whether the public checked variable-width Cursor contract can be
/// consumed by a downstream crate without access to private weight helpers.
#[ensures(match result.0 {
    Some(value) => input@.len() >= 2
        && value@ == input@[0]@ * 256 + input@[1]@
        && result.1@ == input@.len() - 2,
    None => input@.len() < 2 && result.1@ == input@.len()
})]
pub fn external_variable_u16_be(input: &[u8]) -> (Option<u64>, usize) {
    let mut cursor = Cursor::new(input);
    let value = cursor.try_get_uint_be(2);
    (value, cursor.remaining())
}

#[cfg(all(test, not(creusot)))]
mod tests {
    use super::*;
    #[test]
    fn external_writer_models_match_bytes() {
        for value in [0, 1, 255, 256, 32768, u16::MAX] {
            let be = value.to_be_bytes();
            let le = value.to_le_bytes();
            assert_eq!(external_be_u16_roundtrip(value), (Some(be[0]), Some(be[1])));
            assert_eq!(external_le_u16_roundtrip(value), (Some(le[0]), Some(le[1])));
        }
    }
    #[test]
    fn external_reader_consumes_exact_width() {
        for input in [b"".as_slice(), b"a", b"ab", b"abc"] {
            let expected = if input.len() < 2 { None } else { Some(input[0] as u64 * 256 + input[1] as u64) };
            assert_eq!(external_variable_u16_be(input), (expected, input.len() - if expected.is_some() {2} else {0}));
        }
    }
}
