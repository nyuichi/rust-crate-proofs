# bytes 1.11.1 alloc and generic Vec capacity proposal

## Status

This is a scratch proposal and evidence set under `/tmp/bytes-nostd-alloc-exposure`. No installed Creusot std file or tracked bytes source was edited. The pinned toolchain is `nightly-2026-06-22`.

## Patch files

- Generic Vec capacity, try-reserve, and alloc-spec exposure: [`generic-vec-capacity-try-reserve-and-alloc-exposure.patch`](/tmp/bytes-nostd-alloc-exposure/generic-vec-capacity-try-reserve-and-alloc-exposure.patch), SHA-256 `3fb15fe81bb4e5582631b7009594dc78a7af9adff73d4e56b7bc83af129d753b`.
- Caller patch based on the original 255 source: [`exclusive-capacity-caller-and-alloc-feature.patch`](/tmp/bytes-nostd-alloc-exposure/exclusive-capacity-caller-and-alloc-feature.patch), SHA-256 `b7dc01d7db2ec029d9a5ef17b9c8587c712cdd40f77652240da2adee00e2e06a`.
- No-fuzz caller patch against current bytes HEAD `d1ed6f7acf6b33aa12af1e20f56796578018b99a`: [`exclusive-capacity-caller-and-alloc-feature-d1ed6f7a.patch`](/tmp/bytes-nostd-alloc-exposure/exclusive-capacity-caller-and-alloc-feature-d1ed6f7a.patch), SHA-256 `eb945ef0c53dd124fc40f0b53e6ce76fd4806369577ec7351199786f6d10eb64`. `patch --dry-run -p1` passed on a copy of current branch files with no fuzz. Its caller source preserves existing `zeroed`, `clear`, and `append_owner` APIs and tests; resulting `exclusive.rs` SHA-256 is `893a8574edcbcd5d671e3fdf1868cc1b19b4fbad63a2390d0bd748c6ebe58705`.

The generic std patch is relative to `/workspace/bytes-proof-tools` and targets both the source checkout at `/workspace/bytes-proof-tools/creusot-source/creusot-std` and the registry source at `/workspace/bytes-proof-tools/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/creusot-std-0.13.0`. The caller rebase is relative to `/workspace/rust-crate-proofs`. The proof used only a private registry copy under `/tmp/bytes-nostd-alloc-exposure/cargo/registry/...`; no installed std patch was applied.

Original and proposed hashes for all eight modified std modules in both stock locations are recorded in [`std-origin-candidate-hashes.txt`](/tmp/bytes-nostd-alloc-exposure/msp-proof-final/std-origin-candidate-hashes.txt), SHA-256 `b3f0f349afecde27f00c227f9f97776f3be0f2bb9e1f06f999b73c5c386b2f6c`. The stock Vec source hash is `5ce87b16b5e6b633e77c32c7c98cf73e0584c0f0b23127fe4f5277c1d4f1a427`; source checkout and registry originals matched for the seven Rust source modules. Proposed source and registry outputs match for each module; their packaged `Cargo.toml` inputs had different original hashes.

The scratch bytes manifest has a local registry path override and the scratch-only `msp-width-audit` feature. Neither is in the caller patch. The msp width audit is solely a proof-input check.

## Contracts

The proposed opaque `capacity_model<T, A: Allocator>(vector: Vec<T, A>) -> Int` takes the actual generic Vec as its argument. It tracks capacity for that Vec value; it does not use sequence equality as allocation identity. The contracts add no pointer identity, injectivity, or allocation identity rule.

The generic Vec extern specs state:

- `capacity()` equals the observer and is at least the Vec length.
- `with_capacity(n)` returns an empty Vec whose observer is at least `n`.
- `reserve` and `reserve_exact` preserve the sequence, never reduce observed capacity, and leave enough capacity for the old length plus `additional`.
- `try_reserve` and `try_reserve_exact` preserve the sequence on both outcomes. On `Ok`, observed capacity is nondecreasing and at least old length plus `additional`; on `Err`, observed capacity is unchanged.

The fallible methods promise no allocation success or termination. Existing `#[check(terminates)]` on the infallible external methods remains an inherited std total-correctness assumption; this patch adds no termination attributes.

`ExclusiveBytes` exposes `with_capacity`, `capacity`, stronger reserve contracts, fallible reserve methods, and a small reserve-then-close caller. Native tests cover overflow errors preserving contents and capacity, zero and spare-capacity cases, and successful capacity lower bounds. The `try_reserve` return type is `alloc::collections::TryReserveError`.

The alloc exposure adds only `alloc` feature wiring and imports for existing Vec, Box, String, conversion, and slice contracts. The `std/convert.rs` Box/Vec/String specs and `std/slice.rs` slice-to-Vec and boxed-slice Clone specs retain their prior bodies and contracts. This exposes the already-written ownership relations in no_std+alloc mode. It does not add conversion relations or a new bytes protocol axiom.

The pinned Rust Vec and RawVec implementations were read for error framing and success bounds. On reserve errors, allocation metadata and contents remain unchanged; successful reservations guarantee the requested lower bound. No allocator success assumption was added.

## Build and proof evidence

Native checks passed for creusot-std core-only, alloc-only, default std, and all features; bytes host alloc+verified and std+verified; and bytes MSP native with `-Zbuild-std=core,alloc`. The external no_std macro consumer passed. Seven native `ExclusiveBytes` tests passed. Logs are preserved in `/tmp/bytes-nostd-alloc-exposure/` with `after-slice` suffixes.

The final MSP proof ran the full serialized workflow against target `msp430-none-elf` with features `alloc,verified,msp-width-audit` and `-Zbuild-std=core,alloc`. The scratch gate checks `target_pointer_width = 16` and `usize::BITS == 16`. The verbose target translation log records the actual `--target msp430-none-elf` compiler invocation. The `reserve_then_close` Coma uses `UInt16` and `MAX = 65535`. The integrated result was `Proved (226 files)`, exit 0. There are 227 `.coma` files in the capture: 226 proof units plus the extra file emitted for the scratch width audit. Full log, Why3 result cache, all Coma/proof JSON, and input snapshots are under [`msp-proof-final`](/tmp/bytes-nostd-alloc-exposure/msp-proof-final); the successful full-pipeline log SHA-256 is `b8e7629474b37cde14bf2fd5487e241e95193b2243fcd30688add39107dac024`.

The separate host proof used `alloc,verified` with no default features, target `x86_64-unknown-linux-gnu`, and pointer width 64. Its Coma uses `UInt64`; the integrated result was `Proved (226 files)`, exit 0. Full log, width cfg, Why3 cache, Coma/proof JSON, and input snapshots are under [`host-proof-final`](/tmp/bytes-nostd-alloc-exposure/host-proof-final); log SHA-256 is `2a209190becca4acae181db9e5541636044e4f5ddf57aca58eb8c99f54499011`.

The native feature trees show bytes `[alloc,verified]` (or `[alloc,verified,msp-width-audit]`) depending on `creusot-std [alloc]`. The effective proof trees explicitly include `creusot-std [alloc,creusot,creusot-deps,nightly]`, which Creusot injects during translation. None of these graphs includes `creusot-std/std` or `creusot-std/sc-drf`. The formatted graphs are `msp-proof-final/proof-feature-tree-inverted.txt` and `host-proof-final/proof-feature-tree-inverted.txt`; native graphs are saved as `feature-tree-inverted.txt` in each folder.

The capacity proofs use the private bytes 255 source copy under `/tmp/bytes-nostd-alloc-exposure/bytes/source`. The no-fuzz caller rebase was separately dry-run against current bytes HEAD `d1ed6f7a`; it preserves current `zeroed`, `clear`, and `append_owner` code. That rebase itself has not been integrated or proof-run against the current branch. The final branch integration should rerun the repository workflow after applying both patches.

MSP and host evidence manifests are `msp-proof-final/results.sha256` and `host-proof-final/results.sha256`.

An earlier proof-only invocation included an unsupported positional path and stopped on a stale aggregate Coma syntax error. It is retained in `msp-proof-final/proof.log` as a failed invocation; it is not counted as a proof result. The successful logs use the crate workflow: clean, target-specific translation, Creusot clean, then proof without a path argument. Before the conversion/slice exposure, an earlier integrated run found four missing conversion relations. The original failure and intermediate translation failure remain archived under `msp-proof-evidence` and `msp-proof-after-convert`.

## Canonical captures and review bundle

The unmodified repository `capture.py` was copied to the actual scratch bytes verification directory as `target-capture.py`; both SHA-256 values are `327991283b106a815ef178649c1a81cd055c7539ec0b668f28b912e6dc32605d`. Its positive run directories contain exactly the 226 selected proof units, not the additional MSP width-audit aggregate.

- MSP positive: `canonical-captures/positive/generic-vec-capacity-alloc-msp16/evidence.tar.gz`, SHA-256 `ce968117d1f346b4e1723689f7281b6ceab55dfc577d7687982519a476f844c4`; 226 Coma, 226 proof JSON, zero null leaves.
- Host positive: `canonical-captures/positive/generic-vec-capacity-alloc-host64/evidence.tar.gz`, SHA-256 `ac7c38767f1e25e95098e729d014b538581c06f1c0ba657defd5ef636a468890`; 226 Coma, 226 proof JSON, zero null leaves.
- The separate `msp-proof-final/verif-results/bytes_rlib.coma` is a width-audit aggregate outside the MSP capture run directory; it has no proof JSON and is supplemental only.
- Three canonical failure archives preserve source/log snapshots for the four-unproved run, convert-only frontend rejection, and unsupported positional proof-only invocation. Exact raw first-run Coma and original source snapshots are included separately in the outer bundle. The positional invocation is classified as a malformed proof command, not a semantic proof result.

The candidate review bundle is `canonical-candidate-bundle/candidate-evidence.tar.gz`, SHA-256 `14fed51c735909df817ed66d3b8128ae4d4255dfadb1bb7d09e16313003f0612`; its sidecar receipt and 5,834-member hash manifest verify the archive contents. It contains both eight-file std source and registry baseline/candidate sets, the actual private registry package resolved by Cargo, all patches and hash ledgers, exact bytes proof sources/Cargo inputs, full native logs, effective native/proof feature graphs, MSP target/feature audit, the two canonical positive archives, and raw/intermediate failure evidence. `configuration-review.json` explicitly records that the canonical script auto-includes installed stock Vec source (`5ce87b…`) as tool context; the proof actually compiled the private local Vec candidate (`f442bd…`).

No ENOSPC log was present in the capacity scratch or the bytes-proof-tools tree when searched. The bundle records that missing artifact and does not fabricate an ENOSPC run.
