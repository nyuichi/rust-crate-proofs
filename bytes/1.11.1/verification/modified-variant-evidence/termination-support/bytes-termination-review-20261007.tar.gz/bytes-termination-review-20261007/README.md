# Termination boundary probes — isolated bytes 1.11.1 copies

All candidates are scratch-only. Neither the production bytes crate nor the installed standard-library sources were changed. They use a local copy of stock Creusot 0.13.0 source at `/tmp/creusot-source-termination-probe-20261007` (source commit `318615be3b8bbc60d1f6d52469ba5c0bdebed4f1`).

## Generic callback and iterator interfaces: actual failure

`interface-failure/bytes-termination-interface-failure-20261007.tar.gz` preserves the actual HRTB `FnOnce(&[u8])` pre/post dispatch check and actual `ExclusiveBytes::from_iter` with `#[check(terminates)]`. Translation exits 1 before Coma generation with three exact missing-callee-termination diagnostics: `FnOnce::call_once`, `Vec::from_iter`, and `ExclusiveBytes::from_vec`. Stock FnOnce contains only normal pre/post contracts; stock Vec::from_iter has its IteratorSpec semantic contract but no termination marker. No totality premise was trusted or inferred.

## Closed-cursor finite computation

`cursor-colocated-positive/` contains the actual positive bounded experiment. Small leaves `ExclusiveBytes::{from_vec,len,get}` and `OwnedByteCursor::{new,remaining_len,next_byte}` have `#[check(terminates)]`. `read_first_and_return_cursor` performs one metadata read and one byte read, then returns its live cursor. Its body and postcondition prove; the cursor remains available to the caller. `read_first_and_close_normally` separately proves its ordinary close path and is intentionally not marked terminating.

The targeted proof command proved 9 Coma files: the three ExclusiveBytes leaves, four cursor methods (including ordinary close), and both client functions. All relevant proof JSON files are included. The translation and targeted proof both exited 0. This is a function/body proof for bounded sequential computation, not a claim about allocator cleanup or thread scheduling/join liveness.

Two failed scratch shapes are retained:

- `cursor-close-frontier/`: putting `#[check(terminates)]` on close itself produced exactly two missing-callee markers at `detach_bound_vec` and `deallocate_bound_vec`. The B3 allocator boundary is left outside the finite termination claim.
- `cursor-crossmodule-parser-failure/`: separate-module composition translated, but its targeted proof encountered a generated-Coma syntax error (`ERROR_UNBOUND_owner/index`) in a copied next_byte postcondition. The colocated source in the positive attempt avoids this frontend failure.

## Commands and scope

The configured target features were `verified,std`, with `--no-default-features`; Creusot used the local stock standard source copy and `/workspace/bytes-termination-target`. Translation and proofs were run serially through `/tmp/itoa-creusot-proof.lock`; proof execution used the elevated Why3 environment. Exact source snapshots, Coma, proof JSON, logs, and statuses accompany each attempt.
