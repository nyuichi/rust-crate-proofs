//! Bounded finite-cursor termination experiment; isolated under /tmp.
use super::{exclusive::ExclusiveBytes, iteration::OwnedByteCursor};
use creusot_std::prelude::*;

/// Reads one byte and the initial remaining length, returning the live cursor.
#[ensures(result.0@ == if owner@.len() == 0 { owner@ } else { owner@.subsequence(1, owner@.len()) })]
#[ensures(result.1 == if owner@.len() == 0 { None } else { Some(owner@[0]) })]
#[ensures(result.2@ == owner@.len())]
#[check(terminates)]
pub fn read_first_and_return_cursor(owner: ExclusiveBytes) -> (OwnedByteCursor, Option<u8>, usize) {
    let mut cursor = OwnedByteCursor::new(owner);
    let remaining = cursor.remaining_len();
    let first = cursor.next_byte();
    (cursor, first, remaining)
}

/// Positive normal-return cleanup caller, deliberately outside the termination claim.
#[ensures(result.0 == if owner@.len() == 0 { None } else { Some(owner@[0]) })]
#[ensures(result.1@ == owner@.len())]
pub fn read_first_and_close_normally(owner: ExclusiveBytes) -> (Option<u8>, usize) {
    let (cursor, first, remaining) = read_first_and_return_cursor(owner);
    cursor.close();
    (first, remaining)
}
