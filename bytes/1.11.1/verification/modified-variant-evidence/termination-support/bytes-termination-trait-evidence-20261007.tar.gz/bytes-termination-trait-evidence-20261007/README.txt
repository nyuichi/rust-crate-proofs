# Checked terminating callback trait probe

This is an isolated scratch experiment, not a production bytes source change.
It tests whether a program-defined callback trait can express a terminating
method boundary without FnGhost or a trusted termination law.

## Positive

`positive/src/lib.rs` declares `TerminatingCallback::call` with
`#[check(terminates)]`, marks generic `dispatch` as terminating, and supplies a
finite constant-result implementation. Its method implementation is also
marked `#[check(terminates)]`, as required by Creusot's trait refinement check.

Native `cargo check --lib` exited 0. The configured Creusot wrapper exited 0
and reported `Proved (3 files)`: generic dispatch, finite implementation, and
finite closed client. The corresponding generated Coma and proof JSON are kept
under `positive/verif/`.

## Negative

`negative/src/lib.rs` uses a callback implementation that recursively calls
itself forever. The recursive method has `#[check(terminates)]` and an
intentionally constant `#[variant(0)]` so the frontend emits the termination
obligation instead of rejecting a loop with no variant. Native
`cargo check --lib` exited 0 with Rust's unconditional-recursion warning.
The configured Creusot wrapper exited 1 with:

    Goal Coma.vc_call_DivergingCallback'0: \u2718
    Error: 1 unproved file

The generated method proof JSON records its functional VC as proved and its
variant-decrease VC as unproved (`null`). The generated Coma is preserved in
`negative/verif/`. The generic dispatch and closed client VCs prove, while the
concrete divergent implementation is rejected. This is an actual attempted
termination VC, not a native-only divergence observation.

A supplemental earlier loop-without-variant diagnostic is preserved under
`initial-frontend/`; it is not the basis of the negative result.

## Reproduction environment

- Rust: `nightly-2026-06-22`, rustc 1.98.0-nightly (91fe22da8, 2026-06-21)
- cargo-creusot 0.13.0; Why3 1.8.2; why3find 1.3.0+dev
- Creusot source: commit `318615be3b8bbc60d1f6d52469ba5c0bdebed4f1`
- Each candidate's `.cargo/config.toml` patches `creusot-std` to the local source
  at `/tmp/creusot-source-termination-probe-20261007/creusot-std`.
- Proof runs were serialized with `/tmp/itoa-creusot-proof.lock` and used
  `CARGO_NET_OFFLINE=true`, `CARGO_TARGET_DIR` in `/workspace`, and the candidate
  `.verified-proof-config`.

Commands for each candidate (after sourcing `/workspace/bytes-proof-tools/activate.sh`):

    CARGO_NET_OFFLINE=true CARGO_TARGET_DIR=<workspace-target> cargo check --lib
    CARGO_NET_OFFLINE=true CARGO_TARGET_DIR=<workspace-target> \
      XDG_CONFIG_HOME=<candidate>/.verified-proof-config \
      flock -x /tmp/itoa-creusot-proof.lock bash -c \
      'cargo creusot --why3find-arg=-j --why3find-arg=1'

This experiment establishes only that the changed trait boundary is expressible
and checks finite vs. divergent implementations. It says nothing about allocator
deallocation, panics, OS scheduling, thread spawn/join liveness, or arbitrary
`FnOnce`/`Iterator` totality.
