#![no_std]
#![allow(unexpected_cfgs)]

use creusot_std::prelude::*;

/// A callback whose implementation is checked for normal finite completion.
pub trait TerminatingCallback {
    /// Computes one result.
    #[check(terminates)]
    fn call(&self, input: usize) -> usize;
}

/// Dispatches through the checked method contract.
#[check(terminates)]
pub fn dispatch<C: TerminatingCallback>(callback: &C, input: usize) -> usize {
    callback.call(input)
}

/// A finite implementation used to validate the trait contract.
pub struct FiniteCallback;

impl TerminatingCallback for FiniteCallback {
    #[check(terminates)]
    fn call(&self, _input: usize) -> usize {
        0
    }
}

/// A closed client with no effects beyond the trait dispatch.
#[check(terminates)]
pub fn finite_client(input: usize) -> usize {
    dispatch(&FiniteCallback, input)
}
