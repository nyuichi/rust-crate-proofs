#![no_std]
#![allow(unexpected_cfgs)]

use creusot_std::prelude::*;

/// A callback whose implementation is checked for normal finite completion.
pub trait TerminatingCallback {
    /// Computes one result.
    #[check(terminates)]
    fn call(&self, input: usize) -> usize;
}

/// Dispatches through the checked method contract.
#[check(terminates)]
pub fn dispatch<C: TerminatingCallback>(callback: &C, input: usize) -> usize {
    callback.call(input)
}

/// A deliberately nonterminating implementation.
pub struct DivergingCallback;

impl TerminatingCallback for DivergingCallback {
    #[check(terminates)]
    #[variant(0)]
    fn call(&self, input: usize) -> usize {
        self.call(input)
    }
}

/// A closed client with no effects beyond the trait dispatch.
#[check(terminates)]
pub fn diverging_client(input: usize) -> usize {
    dispatch(&DivergingCallback, input)
}
