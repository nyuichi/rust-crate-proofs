#[cfg(creusot)] use creusot_std::prelude::*;
use alloc::vec::Vec;
use core::{ptr, slice};
use core::sync::atomic::AtomicPtr;
use crate::BytesMut;

pub struct Bytes {
    #[cfg(not(bytes_proof_frozen))]
    ptr: *const u8,
    #[cfg(bytes_proof_frozen)]
    pub(crate) ptr: crate::ownership_proof::raw_vec::BoundPtr,
    #[cfg(bytes_proof_frozen)]
    pub(crate) frozen: Option<crate::ownership_proof::frozen_region::FrozenReader>,
    #[cfg(not(bytes_proof_frozen))]
    len: usize,
    #[cfg(bytes_proof_frozen)]
    pub(crate) len: usize,
    // inlined "trait object"
    data: AtomicPtr<()>,
    vtable: &'static Vtable,
}

pub(crate) struct Vtable {
    /// Marks the two Vec-backed tables whose storage must be promoted before truncation.
    pub promotable: bool,
    /// fn(data, ptr, len, current_vtable)
    ///
    /// Pass the current table so callbacks that preserve the storage kind do
    /// not have to refer back to the table that contains the callback.
    pub clone: unsafe fn(&AtomicPtr<()>, *const u8, usize, &'static Vtable) -> Bytes,
    /// fn(data, ptr, len)
    ///
    /// `into_*` consumes the `Bytes`, returning the respective value.
    pub into_vec: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> Vec<u8>,
    pub into_mut: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> BytesMut,
    /// fn(data)
    pub is_unique: unsafe fn(&AtomicPtr<()>) -> bool,
    /// fn(data, ptr, len)
    pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),
}

impl Bytes {
        #[cfg_attr(creusot, ensures(result@ == self.len@))]
pub const fn len(&self) -> usize {
        self.len
    }
        #[cfg_attr(creusot, requires(!self.vtable.promotable))]
    #[cfg_attr(creusot, ensures((^self).len@ == (if len@ < self.len@ { len@ } else { self.len@ })))]
pub fn truncate(&mut self, len: usize) {
        if len < self.len {
            // The Vec "promotable" vtables do not store the capacity,
            // so we cannot truncate while using this repr. We *have* to
            // promote using `split_off` so the capacity can be stored.
            if self.vtable.promotable {
                drop(self.split_off(len));
            } else {
                self.len = len;
            }
        }
    }
        #[cfg_attr(creusot, requires(!self.vtable.promotable))]
    #[cfg_attr(creusot, ensures((^self).len@ == 0))]
pub fn clear(&mut self) {
        self.truncate(0);
    }
    #[cfg_attr(creusot, requires(false))]
    fn split_off(&mut self, _at: usize) -> Self { panic!("unreachable promotable branch in this conditional subset") }
}

#[cfg(creusot)]
#[requires(!bytes.vtable.promotable)]
#[ensures(result@ == (if requested@ < bytes.len@ { requested@ } else { bytes.len@ }))]
pub fn truncate_metadata_caller(mut bytes: Bytes, requested: usize) -> usize {
    bytes.truncate(requested);
    let len = bytes.len();
    core::mem::forget(bytes);
    len
}

#[cfg(creusot)]
#[requires(!bytes.vtable.promotable)]
#[ensures(result@ == 0)]
pub fn clear_metadata_caller(mut bytes: Bytes) -> usize {
    bytes.clear();
    let len = bytes.len();
    core::mem::forget(bytes);
    len
}

unsafe extern "Rust" {
    unsafe fn static_clone(
    _: &AtomicPtr<()>,
    ptr: *const u8,
    len: usize,
    vtable: &'static Vtable,
) -> Bytes;
}
unsafe extern "Rust" {
    unsafe fn static_to_vec(_: &AtomicPtr<()>, ptr: *const u8, len: usize) -> Vec<u8>;
}
unsafe extern "Rust" {
    unsafe fn static_to_mut(_: &AtomicPtr<()>, ptr: *const u8, len: usize) -> BytesMut;
}
unsafe extern "Rust" {
    fn static_is_unique(_: &AtomicPtr<()>) -> bool;
}
unsafe extern "Rust" {
    unsafe fn static_drop(_: &mut AtomicPtr<()>, _: *const u8, _: usize);
}
unsafe extern "Rust" {
    unsafe fn promotable_even_clone(
    data: &AtomicPtr<()>,
    ptr: *const u8,
    len: usize,
    _: &'static Vtable,
) -> Bytes;
}
unsafe extern "Rust" {
    unsafe fn promotable_even_to_vec(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> Vec<u8>;
}
unsafe extern "Rust" {
    unsafe fn promotable_even_to_mut(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> BytesMut;
}
unsafe extern "Rust" {
    unsafe fn promotable_even_drop(data: &mut AtomicPtr<()>, ptr: *const u8, len: usize);
}
unsafe extern "Rust" {
    fn promotable_is_unique(data: &AtomicPtr<()>) -> bool;
}
unsafe extern "Rust" {
    unsafe fn promotable_odd_clone(
    data: &AtomicPtr<()>,
    ptr: *const u8,
    len: usize,
    _: &'static Vtable,
) -> Bytes;
}
unsafe extern "Rust" {
    unsafe fn promotable_odd_to_vec(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> Vec<u8>;
}
unsafe extern "Rust" {
    unsafe fn promotable_odd_to_mut(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> BytesMut;
}
unsafe extern "Rust" {
    unsafe fn promotable_odd_drop(data: &mut AtomicPtr<()>, ptr: *const u8, len: usize);
}
