# `Bytes::truncate` and `Bytes::clear` under a non-promotable vtable precondition

This probe extracts the current `Bytes` layout, `Vtable`, exact `from_static`,
`len`, `truncate`, `clear`, `STATIC_VTABLE`, and both exact promotable table
initializers from `src/bytes.rs`. It attempts to prove `truncate` and `clear`
under an explicit precondition excluding both promotable vtable addresses.
`truncate`'s intended metadata postcondition is `min(old_len, requested_len)`;
`clear`'s is length zero. No Creusot proof is currently established: the
source-shaped address contract fails front-end translation at a `RawBorrow`,
and a retry using `core::ptr::addr_eq` fails at the same reference-to-pointer
conversion before any verification conditions are generated.

The source body still contains `drop(self.split_off(len))` for promotable
tables. The only probe adapter for that path is a `split_off` method with
`requires(false)` and a panic body. It has not been used in a proof: the
non-promotable precondition cannot currently be translated. No `split_off`,
ownership, clone, reference-count, callback, or `Drop` behavior is claimed.

Both vtable initializers are preserved exactly. Proof mode replaces callback
bodies with one signature-only external declaration per item solely so the
static tables typecheck; no callback is called or assigned a behavioral
contract. Native mode compiles the exact static callback bodies and local
panic stand-ins for the unselected promotable callbacks. The probe's opaque
`BytesMut` type exists only as the unobserved callback return type. Native
tests construct `Bytes::from_static`, exercise metadata operations on its
non-promotable vtable, and `forget` the handle; they do not read raw bytes or
test destruction. The native test passed 1/1. The two archived translation
logs record the failing address-expression attempts and do not establish a
proof result.

Run native tests with `cargo test --locked --offline`. Run the serialized pinned
Creusot gate with `bash run.sh`. Any success is bounded to the exact
`truncate`/`clear` bodies and the explicit pointer inequality precondition; it
does not establish that arbitrary real handles satisfy that precondition.
