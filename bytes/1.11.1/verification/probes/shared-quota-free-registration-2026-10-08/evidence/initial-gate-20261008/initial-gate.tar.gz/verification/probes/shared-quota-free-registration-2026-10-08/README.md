# Quota-free fractional registration prerequisite

This isolated experiment tests a generic registration step that borrows an
existing ticket and returns a fresh lifetime-fraction ticket without consuming
an external clone quota. It reuses the proved finite-map accounting source,
stock `LifetimeToken` splitting, and the generic operation-bound `EventAtomic`
interface. It does not edit the stable Shared lifecycle probe or production
sources.

The intended caller performs two registrations through the same id-0 source.
Each step inserts the current unbounded logical id, splits half the residual
token pool, keeps the source ticket valid, and ties the live-map count to the
checked native Relaxed increment. The wrapper retains the source overflow
abort condition. This is a registration-only prerequisite; release-sequence
preservation, physical retirement/recovery, thread transport and a public
Bytes::Clone proof remain outside its scope.

Proof claims and exact evidence will be added after the first gate.
