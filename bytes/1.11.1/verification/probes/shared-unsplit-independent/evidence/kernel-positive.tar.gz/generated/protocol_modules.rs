#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-unsplit-independent-92651b133720ef8d/out/scalable_tickets.rs"]
mod scalable_tickets;
