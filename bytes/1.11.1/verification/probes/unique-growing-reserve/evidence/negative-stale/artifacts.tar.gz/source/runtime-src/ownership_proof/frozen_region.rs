//! Read-only sharing of an existing physical region through lifetime fractions.
//! This adds no physical primitive: the final read uses the existing B4-read
//! bridge, and ending the full synthetic lifetime returns the original region.

use creusot_std::{
    ghost::{lifetime_logic::{FullBorrow, LifetimeToken}, GhostShared},
    prelude::*,
};
use super::raw_vec::{self, BoundPtr, PhysicalRegion};

pub(crate) type FrozenRegion = GhostShared<FullBorrow<PhysicalRegion>>;

/// Each independent token fraction supports an immutable borrow. The reference
/// lifetime is tied to both its descriptor and its own lifetime-token borrow.
#[requires(bound.invariant() && bound@ != None)]
#[requires(shared.val().cur().invariant())]
#[requires(shared.val().lft() == ticket.lft())]
#[requires(bound@.unwrap_logic().0 == shared.val().cur().namespace())]
#[requires(bound@.unwrap_logic().1 == shared.val().cur().capacity())]
#[requires(shared.val().cur().lo() <= bound@.unwrap_logic().2)]
#[requires(bound@.unwrap_logic().2 + len@ <= shared.val().cur().hi())]
#[requires(forall<offset: Int> 0 <= offset && offset < len@ ==>
    raw_vec::slot_known(shared.val().cur().slot(bound@.unwrap_logic().2 + offset)))]
#[ensures(result@.len() == len@)]
#[ensures(forall<offset: Int> 0 <= offset && offset < len@ ==>
    shared.val().cur().slot(bound@.unwrap_logic().2 + offset) == Some(Some(result@[offset])))]
pub(crate) fn borrow_frozen<'a>(
    bound: &'a BoundPtr,
    len: usize,
    shared: Ghost<FrozenRegion>,
    ticket: &'a LifetimeToken,
) -> &'a [u8] {
    let region: Ghost<&'a PhysicalRegion> = ghost! {
        let full: &'a FullBorrow<PhysicalRegion> = (*shared).to_ref();
        full.borrow(ticket)
    };
    unsafe { raw_vec::borrow_bound(bound, len, region) }
}

/// Affine read ticket carried by the extraction-only actual Bytes receiver.
/// The shared ghost view is copyable; the lifetime fraction is not.
pub(crate) struct FrozenReader {
    pub(crate) shared: Ghost<FrozenRegion>,
    pub(crate) ticket: LifetimeToken,
}

impl FrozenReader {
    #[logic(open, prophetic)]
    pub(crate) fn valid(self, bound: BoundPtr, len: usize) -> bool {
        pearlite! {
            bound.invariant() && bound@ != None &&
            self.shared.val().cur().invariant() &&
            self.shared.val().lft() == self.ticket.lft() &&
            bound@.unwrap_logic().0 == self.shared.val().cur().namespace() &&
            bound@.unwrap_logic().1 == self.shared.val().cur().capacity() &&
            self.shared.val().cur().lo() <= bound@.unwrap_logic().2 &&
            bound@.unwrap_logic().2 + len@ <= self.shared.val().cur().hi() &&
            forall<offset: Int> 0 <= offset && offset < len@ ==>
                raw_vec::slot_known(self.shared.val().cur().slot(bound@.unwrap_logic().2 + offset))
        }
    }
}
