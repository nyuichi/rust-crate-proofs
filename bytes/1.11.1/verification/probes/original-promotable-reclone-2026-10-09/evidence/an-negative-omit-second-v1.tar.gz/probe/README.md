# AN: promoted original-root re-clone and three normal automatic Drops

Development experiment after audited AM `ae7b7e5124c064d2e686ad1a9fb20d52e5c2b795`.
The complete original bytes 1.11.1 architecture remains **NOT ADMITTED**.
No AN proof result is claimed yet.

The native witness constructs a nonempty Box-backed Bytes, clones the original
once through Raw-to-Shared promotion, clones the same original again through
its existing Shared branch, drops the second then first child at lexical scope
exit, reads the original, saves the returned Vec, and drops the original on
normal return. Both native tag parities are included in the intended body proof;
the execution test is corroboration and does not establish allocator parity.

The distinguishing premise is AL's body-proved first-promotion transition plus
AM's exact terminal-Drop elaboration. The second clone must perform the actual
Acquire pointer load and guarded Relaxed refcount increment/registration. It
must allocate neither a new Shared control nor perform another promotion CAS.
The original retains its owned pointer history; a fresh child receives its own
read-only binding. No ghost value is materialized as a runtime expected pointer.
New bytes-specific protocol bodies must be proved under the existing documented
generic physical, synchronization, erasure, provenance and compiler TCB.

The immutable AL prefix and AM terminal adapters are reused, with new shared-
phase helpers and a three-owner client. The final gate requires all generated
Coma targets, no defect features or exclusions, actual Cargo compiled-record
inputs, exact source/native MIR/erasure correspondence, deliberate semantic and
typing controls, archived inputs/proofs, and independent archive audit.

Normal completion is the bounded scope. Concurrent CAS losers, escaping clones,
unwind, allocation failure, arbitrary clone/Drop contexts, other APIs and build
configurations remain open. A successful AN gate will not imply full-crate
verification. After each audited published increment, ask Astra
「次何するのがいい？」 and execute the next recommendation.

Run scripts use the pinned `/workspace/bytes-proof-tools` installation. Evidence
archives capture source, configuration and binary hashes; tool payloads remain
external. Why3 runs elevated, under the shared proof lock, with one concurrent
prover and a 1024 MiB limit; `sc-drf` is disabled.
