# Original BytesMut unique allocation/write experiment

Changed premise: the original four native fields remain in place. A cfg-only
optional sidecar connects them to the actual B1 allocation; None establishes no
authority. This gate extracts marked source verbatim, including the actual
with_capacity, no-growth reserve, spare access, memcpy call and advance_mut.
The advance_mut method is selected from its original trait impl into a local
inherent surface; this does not prove open BufMut laws. reserve_inner's interface
requires false: its body is outside scope, and the selected reserve precondition
must prove that branch unreachable. No alternative buffer representation.

Spec map: from_vec consumes the source Vec once via B1; sealed BoundPtr equals
the actual ptr (not merely its address); full Recovery/PhysicalRegion covers
[0,cap), native tag denotes Vec/off0; known prefix matches source bytes. Spare
access uses ordinary B4 with slot writeback, raw memcpy initializes only its
prefix, and advance_mut publishes only known slots. The public caller returns a
live original BytesMut. No Drop, freeze, Clone, growth, shared state, concurrency,
or whole-crate claim. B1/B4 and the local typed memcpy contract remain explicit
TCB, and proof cfg/native correspondence is a reviewed obligation.

Before run: generate extracts and hashes from current source. Preserve each
failed source/Coma/JSON/log before edits. Two equivalent failures require review;
a third requires structural change. No increased proof timeouts. Positive needs
completed engine output and all JSON leaves closed; zero generated goals is not
success. Native tests are bounded correspondence checks, not an ownership proof.
