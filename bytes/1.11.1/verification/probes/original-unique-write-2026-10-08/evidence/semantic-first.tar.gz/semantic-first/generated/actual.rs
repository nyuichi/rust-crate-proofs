use crate::TryGetError;
use core::{mem::{ManuallyDrop,MaybeUninit},ptr::{self,NonNull},cmp,slice};
use alloc::vec::Vec;
use core::sync::atomic::AtomicUsize;
// ORIGINAL_UNIQUE_BEGIN proof_imports
#[cfg(all(creusot, bytes_original_unique_gate))]
use creusot_std::prelude::*;
#[cfg(all(creusot, bytes_original_unique_gate))]
use crate::ownership_proof::raw_vec::{self, BoundPtr, Recovery, PhysicalRegion, slot_known};
// ORIGINAL_UNIQUE_END proof_imports
pub struct BytesMut {
    ptr: NonNull<u8>,
    len: usize,
    cap: usize,
    data: *mut Shared,
    // No authority is established for unselected constructors/representations.
    #[cfg(all(creusot, bytes_original_unique_gate))]
    unique_proof: Option<OriginalUniqueProof>,
}

// ORIGINAL_UNIQUE_BEGIN proof_model
#[cfg(all(creusot, bytes_original_unique_gate))]
struct OriginalUniqueProof {
    base: BoundPtr,
    capabilities: Ghost<(Recovery, PhysicalRegion)>,
}
#[cfg(all(creusot, bytes_original_unique_gate))]
impl BytesMut {
    #[logic(open(self), prophetic)]
    fn unique_valid(self) -> bool {
        pearlite! {
            match self.unique_proof {
                None => false,
                Some(proof) => {
                    let caps = proof.capabilities.inner_logic();
                    proof.base.invariant() && caps.0.invariant() && caps.1.invariant() &&
                    proof.base@ == Some((caps.0.namespace(), self.cap@, 0int)) &&
                    self.ptr@ == proof.base.raw_pointer() &&
                    caps.0.capacity() == self.cap@ && caps.1.capacity() == self.cap@ &&
                    caps.1.namespace() == caps.0.namespace() &&
                    caps.1.resource_id() == caps.0.namespace() &&
                    caps.1.lo() == 0 && caps.1.hi() == self.cap@ &&
                    self.len <= self.cap &&
                    self.data.addr_logic()@ < 32 && self.data.addr_logic()@ % 4 == 1 &&
                    (forall<i:Int> 0 <= i && i < self.len@ ==> slot_known(caps.1.slot(i)))
                }
            }
        }
    }
    #[logic(open(self))]
    fn unique_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! { self.unique_proof.unwrap_logic().capabilities.inner_logic().1.slot(index) }
    }
    #[logic(open(self))]
    fn unique_bytes(self) -> Seq<u8> {
        pearlite! { Seq::create(self.len@, |i:Int| self.unique_slot(i).unwrap_logic().unwrap_logic()) }
    }
}
// ORIGINAL_UNIQUE_END proof_model

struct Shared {
    vec: Vec<u8>,
    original_capacity_repr: usize,
    ref_count: AtomicUsize,
}
const KIND_ARC: usize = 0b0;
const KIND_VEC: usize = 0b1;
const KIND_MASK: usize = 0b1;
const MAX_ORIGINAL_CAPACITY_WIDTH: usize = 17;
const MIN_ORIGINAL_CAPACITY_WIDTH: usize = 10;
const ORIGINAL_CAPACITY_MASK: usize = 0b11100;
const ORIGINAL_CAPACITY_OFFSET: usize = 2;
const VEC_POS_OFFSET: usize = 5;
const MAX_VEC_POS: usize = usize::MAX >> VEC_POS_OFFSET;
const NOT_VEC_POS_MASK: usize = 0b11111;
#[cfg(target_pointer_width = "64")]
const PTR_WIDTH: usize = 64;
#[cfg(target_pointer_width = "32")]
const PTR_WIDTH: usize = 32;
impl BytesMut {
// ORIGINAL_UNIQUE_BEGIN with_capacity
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.len == 0usize))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(capacity <= result.cap))]
    #[inline]
    pub fn with_capacity(capacity: usize) -> BytesMut {
        BytesMut::from_vec(Vec::with_capacity(capacity))
    }
// ORIGINAL_UNIQUE_END with_capacity
// ORIGINAL_UNIQUE_BEGIN len
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result == self.len))]
    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }
// ORIGINAL_UNIQUE_END len
// ORIGINAL_UNIQUE_BEGIN capacity
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result == self.cap))]
    #[inline]
    pub fn capacity(&self) -> usize {
        self.cap
    }
// ORIGINAL_UNIQUE_END capacity
// ORIGINAL_UNIQUE_BEGIN reserve
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(additional@ <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(^self == *self))]
    #[inline]
    pub fn reserve(&mut self, additional: usize) {
        let len = self.len();
        let rem = self.capacity() - len;

        if additional <= rem {
            // The handle can already store at least `additional` more bytes, so
            // there is no further work needed to be done.
            return;
        }

        // will always succeed
        let _ = self.reserve_inner(additional, true);
    }
// ORIGINAL_UNIQUE_END reserve
// ORIGINAL_UNIQUE_BEGIN extend
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(extend@.len() <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).len@ == self.len@ + extend@.len()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < self.len@ ==> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < extend@.len() ==> (^self).unique_slot(self.len@ + i) == Some(Some(extend@[i]))))]
    #[inline]
    pub fn extend_from_slice(&mut self, extend: &[u8]) {
        let cnt = extend.len();
        self.reserve(cnt);

        unsafe {
            let dst = self.spare_capacity_mut();
            // Reserved above
            debug_assert!(dst.len() >= cnt);

            crate::storage_ops::copy_to_uninit_prefix_raw(dst, extend);
        }

        unsafe {
            self.advance_mut(cnt);
        }
    }
// ORIGINAL_UNIQUE_END extend
// ORIGINAL_UNIQUE_BEGIN from_vec
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.len@ == vec@.len()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.cap@ == creusot_std::std::vec::capacity_model(vec)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < vec@.len() ==> result.unique_slot(i) == Some(Some(vec@[i]))))]
    #[inline]
    pub(crate) fn from_vec(vec: Vec<u8>) -> BytesMut {
        #[cfg(not(all(creusot, bytes_original_unique_gate)))]
        let (ptr, len, cap) = {
            let mut vec = ManuallyDrop::new(vec);
            (vptr(vec.as_mut_ptr()), vec.len(), vec.capacity())
        };
        #[cfg(all(creusot, bytes_original_unique_gate))]
        let (ptr, len, cap, unique_proof) = {
            // B1 consumes precisely the Vec hidden by native ManuallyDrop.
            let (raw, len, capabilities) = raw_vec::detach_vec(vec);
            let (base, cap) = raw.into_bound_ptr_at_zero();
            let ptr = base.as_non_null();
            (ptr, len, cap, Some(OriginalUniqueProof { base, capabilities }))
        };

        let original_capacity_repr = original_capacity_to_repr(cap);
        let data = (original_capacity_repr << ORIGINAL_CAPACITY_OFFSET) | KIND_VEC;

        BytesMut {
            ptr,
            len,
            cap,
            data: invalid_ptr(data),
            #[cfg(all(creusot, bytes_original_unique_gate))]
            unique_proof,
        }
    }
// ORIGINAL_UNIQUE_END from_vec
// ORIGINAL_UNIQUE_BEGIN spare
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result@.len() == self.cap@ - self.len@ && (^result)@.len() == self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data && (^self).len == self.len))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < self.len@ ==> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> self.len@ <= i && i < self.cap@ ==> self.unique_slot(i) == Some(result@[i-self.len@]@)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> self.len@ <= i && i < self.cap@ ==> (^self).unique_slot(i) == Some((^result)@[i-self.len@]@)))]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<u8>] {
        #[cfg(all(creusot, bytes_original_unique_gate))]
        {
            let proof = self.unique_proof.as_mut().unwrap();
            unsafe { raw_vec::borrow_spare_preserving_prefix(
                proof.base, self.len, self.cap, ghost! { &mut proof.capabilities.1 }
            ) }
        }
        #[cfg(not(all(creusot, bytes_original_unique_gate)))]
        unsafe {
            let ptr = self.ptr.as_ptr().add(self.len);
            let len = self.cap - self.len;

            slice::from_raw_parts_mut(ptr.cast(), len)
        }
    }
// ORIGINAL_UNIQUE_END spare
// ORIGINAL_UNIQUE_BEGIN advance_mut
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(cnt@ <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(forall<i:Int> self.len@ <= i && i < self.len@ + cnt@ ==> slot_known(self.unique_slot(i))))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).len@ == self.len@ + cnt@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[inline]
    unsafe fn advance_mut(&mut self, cnt: usize) {
        let remaining = self.cap - self.len();
        if cnt > remaining {
            super::panic_advance(&TryGetError {
                requested: cnt,
                available: remaining,
            });
        }
        // Addition won't overflow since it is at most `self.cap`.
        self.len = self.len() + cnt;
    }
// ORIGINAL_UNIQUE_END advance_mut
#[cfg_attr(creusot, requires(false))]
fn reserve_inner(&mut self,_additional:usize,_allocate:bool)->bool { panic!("excluded growth") }
}
// ORIGINAL_UNIQUE_BEGIN capacity_repr
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result <= 7usize))]
#[inline]
fn original_capacity_to_repr(cap: usize) -> usize {
    let width = PTR_WIDTH - ((cap >> MIN_ORIGINAL_CAPACITY_WIDTH).leading_zeros() as usize);
    cmp::min(
        width,
        MAX_ORIGINAL_CAPACITY_WIDTH - MIN_ORIGINAL_CAPACITY_WIDTH,
    )
}
// ORIGINAL_UNIQUE_END capacity_repr
// ORIGINAL_UNIQUE_BEGIN invalid_ptr
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.addr_logic() == addr))]
#[inline]
fn invalid_ptr<T>(addr: usize) -> *mut T {
    let ptr = core::ptr::null_mut::<u8>().wrapping_add(addr);
    debug_assert_eq!(crate::provenance_specs::pointer_addr(ptr), addr);
    ptr.cast::<T>()
}
// ORIGINAL_UNIQUE_END invalid_ptr
fn vptr(ptr: *mut u8) -> NonNull<u8> {
    if cfg!(debug_assertions) {
        NonNull::new(ptr).expect("Vec pointer should be non-null")
    } else {
        unsafe { NonNull::new_unchecked(ptr) }
    }
}

#[cfg(creusot)]
#[ensures(result.unique_valid())]
#[ensures(result.len@ == input@.len())]
#[ensures(forall<i:Int> 0 <= i && i < input@.len() ==> result.unique_slot(i) == Some(Some(input@[i])))]
pub fn allocate_and_append(input:&[u8]) -> BytesMut {
 let mut value=BytesMut::with_capacity(input.len());
 value.extend_from_slice(input);
 value
}
#[cfg(all(test,not(creusot)))]
mod tests { use super::*;
#[test] fn exact_native_empty_and_nonempty() {
 for input in [&b""[..],&b"abc"[..],&b"longer contents"[..]] {
 let mut value=BytesMut::with_capacity(input.len()+8); value.extend_from_slice(input);
 assert_eq!(value.len,input.len());
 unsafe { assert_eq!(slice::from_raw_parts(value.ptr.as_ptr(),value.len),input);
 drop(Vec::from_raw_parts(value.ptr.as_ptr(),value.len,value.cap)); }
 }
}
}
