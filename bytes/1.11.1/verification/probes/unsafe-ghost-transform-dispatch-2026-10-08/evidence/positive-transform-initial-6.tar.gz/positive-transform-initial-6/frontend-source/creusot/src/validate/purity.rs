use crate::{
    backend::is_trusted_item,
    contracts_items::{
        Intrinsic, is_check_ghost, is_check_terminates, is_erasure, is_logic, is_prophetic,
        is_snapshot_closure, is_spec, is_trusted_ghost, is_trusted_terminates,
    },
    ctx::{HasTyCtxt, TranslationCtx},
    resolution::TraitResolved,
    translation::specification::ProgramPurity,
};
use rustc_hir::def_id::{DefId, LocalDefId};
use rustc_infer::infer::TyCtxtInferExt;
use rustc_middle::{
    thir::{self, ClosureExpr, ExprId, ExprKind, Thir, visit::Visitor},
    ty::{FnDef, TyCtxt, TypingEnv},
};
use rustc_span::sym;
use rustc_trait_selection::infer::InferCtxtExt;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Purity {
    /// The context of ghost blocks.
    /// Similar to `Program { purity: Ghost }`, but can also call the few
    /// ghost-only functions (e.g. `Ghost::new`).
    Ghost,
    Program {
        purity: ProgramPurity,
    },
    Logic {
        prophetic: bool,
    },
}

// Purity of the function being checked
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum LocalPurity {
    Purity(Purity),
    TrustedTerminates,
    TrustedGhost,
}

impl LocalPurity {
    pub(crate) fn of_def_id<'tcx>(ctx: &TranslationCtx<'tcx>, def_id: DefId) -> Self {
        use self::Purity::*;
        use LocalPurity::*;
        if is_logic(ctx.tcx, def_id) {
            Self::logic(is_prophetic(ctx.tcx, def_id))
        } else if is_spec(ctx.tcx, def_id) {
            Self::logic(!is_snapshot_closure(ctx.tcx, def_id))
        } else if is_trusted_ghost(ctx.tcx, def_id)
            || is_check_ghost(ctx.tcx, def_id) && is_trusted_item(ctx.tcx, def_id)
        {
            TrustedGhost
        } else if is_trusted_terminates(ctx.tcx, def_id)
            || is_check_terminates(ctx.tcx, def_id) && is_trusted_item(ctx.tcx, def_id)
        {
            TrustedTerminates
        } else {
            Purity(Program { purity: ctx.sig(def_id).contract.purity })
        }
    }

    fn can_call(self, other: Purity) -> bool {
        use self::Purity::*;
        use LocalPurity::*;
        match (self, other) {
            (Purity(Logic { prophetic }), Logic { prophetic: prophetic2 }) => {
                prophetic || !prophetic2
            }
            (Purity(Program { purity }), Program { purity: purity2 }) => purity <= purity2,
            (Purity(Ghost), Ghost | Program { purity: ProgramPurity::Ghost }) => true,
            (TrustedTerminates, Program { .. }) => true,
            (TrustedGhost, Ghost | Program { .. }) => true,
            (_, _) => false,
        }
    }

    fn logic(prophetic: bool) -> Self {
        LocalPurity::Purity(Purity::Logic { prophetic })
    }

    fn ghost() -> Self {
        LocalPurity::Purity(Purity::Ghost)
    }

    fn is_logic(self) -> bool {
        matches!(self, LocalPurity::Purity(Purity::Logic { .. }))
    }

    fn is_program(self) -> bool {
        use LocalPurity::*;
        matches!(self, Purity(self::Purity::Program { .. }) | TrustedTerminates | TrustedGhost)
    }

    fn as_str(self) -> &'static str {
        use LocalPurity::*;
        match self {
            Purity(purity) => purity.as_str(),
            TrustedTerminates => "program (terminates)",
            TrustedGhost => "program (ghost)",
        }
    }
}

impl Purity {
    fn as_str(&self) -> &'static str {
        use Purity::*;
        match self {
            Ghost => "ghost",
            Program { purity } => match purity {
                ProgramPurity::Ghost => "program (ghost)",
                ProgramPurity::Terminates => "program (terminates)",
                ProgramPurity::Impure => "program",
            },
            Logic { prophetic: false } => "logic",
            Logic { prophetic: true } => "prophetic logic",
        }
    }
}

pub(crate) fn validate_purity<'tcx>(
    ctx: &TranslationCtx<'tcx>,
    def_id: DefId,
    (thir, expr): (&Thir<'tcx>, ExprId),
) {
    // Only start traversing from top-level definitions. Closures will be visited during the traversal
    // of their parents so that they can inherit the context from their parent.
    if ctx.tcx.is_closure_like(def_id) {
        return;
    }
    let is_trusted_ghost = is_trusted_ghost(ctx.tcx, def_id);
    let is_trusted_terminates = is_trusted_ghost || is_trusted_terminates(ctx.tcx, def_id);
    if is_trusted_terminates && (is_logic(ctx.tcx, def_id) || is_spec(ctx.tcx, def_id)) {
        ctx.error(
            ctx.def_span(def_id),
            if is_trusted_ghost {
                "Logic functions can't be `#[trusted(ghost)]`"
            } else {
                "Logic functions can't be `#[trusted(terminates)]`"
            },
        )
        .emit();
        return;
    }
    let typing_env = ctx.typing_env(def_id);
    PurityVisitor { ctx, thir, context: LocalPurity::of_def_id(ctx, def_id), typing_env }
        .visit_expr(&thir[expr]);
}

struct PurityVisitor<'a, 'tcx> {
    ctx: &'a TranslationCtx<'tcx>,
    thir: &'a Thir<'tcx>,
    context: LocalPurity,
    /// Typing environment of the caller function
    typing_env: TypingEnv<'tcx>,
}

enum ClosureKind {
    Spec(LocalDefId),
    Erasure,
}

impl PurityVisitor<'_, '_> {
    fn purity(&self, func_did: DefId, args: &[ExprId]) -> Purity {
        if is_logic(self.ctx.tcx, func_did) {
            Purity::Logic { prophetic: is_prophetic(self.ctx.tcx, func_did) }
        } else if let Intrinsic::GhostIntoInner
        | Intrinsic::GhostNew
        | Intrinsic::GhostDeref
        | Intrinsic::GhostDerefMut = self.ctx.intrinsic(func_did)
        {
            Purity::Ghost
        } else {
            let purity = if self.implements_fn_ghost(func_did, args) {
                ProgramPurity::Ghost
            } else {
                self.ctx.sig(func_did).contract.purity
            };
            Purity::Program { purity }
        }
    }

    /// Returns `true` if `func_did` is one of `call`, `call_mut` or `call_once`, and
    /// the closure being called implements `FnGhost`.
    fn implements_fn_ghost(&self, func_did: DefId, args: &[ExprId]) -> bool {
        let Some(trait_did) = self.ctx.trait_of_assoc(func_did) else { return false };
        if !self.ctx.is_fn_trait(trait_did) {
            return false;
        };
        let ty = self.thir[args[0]].ty.peel_refs();
        let (infcx, param_env) = self.ctx.infer_ctxt().build_with_typing_env(self.typing_env);
        infcx
            .type_implements_trait(Intrinsic::FnGhost.get(self.ctx), [ty], param_env)
            .must_apply_considering_regions()
    }

    /// If the expression is a closure with attribute `creusot::spec`, return `Some` of its `LocalDefId`, otherwise `None`.
    fn get_spec_closure(&self, mut expr: ExprId) -> Option<ClosureKind> {
        loop {
            match self.thir[expr].kind {
                ExprKind::Scope { value, .. } => expr = value,
                ExprKind::Block { block } => {
                    let block = &self.thir[block];
                    if !block.stmts.is_empty() {
                        return None;
                    }
                    expr = block.expr?;
                }
                ExprKind::Closure(box ClosureExpr { closure_id, .. }) => {
                    if is_spec(self.ctx.tcx, closure_id.to_def_id()) {
                        return Some(ClosureKind::Spec(closure_id));
                    } else if is_erasure(self.ctx.tcx, closure_id.to_def_id()) {
                        return Some(ClosureKind::Erasure);
                    }
                    return None;
                }
                _ => return None,
            }
        }
    }

    /// Validate the body of a spec closure.
    fn validate_spec_purity(&mut self, closure_id: LocalDefId, prophetic: bool) {
        let (thir, expr) = self.ctx.thir_body(closure_id);
        let thir = &thir.borrow();
        PurityVisitor { thir, context: LocalPurity::logic(prophetic), ..*self }
            .visit_expr(&thir[expr]);
    }

    /// Return `false` if this is not a `creusot::spec` or `creusot::erasure` closure.
    fn try_visit_spec_stmt(&mut self, stmt: &thir::Stmt) -> bool {
        let thir::StmtKind::Let { ref pattern, initializer: Some(init), else_block, span, .. } =
            stmt.kind
        else {
            return false;
        };
        match self.get_spec_closure(init) {
            Some(ClosureKind::Spec(closure_id)) => {
                // If the statement is a spec statement, visit it.
                let thir::PatKind::Wild = pattern.kind else {
                    self.ctx
                        .dcx()
                        .span_fatal(pattern.span, "expected a wildcard pattern in spec statement")
                };
                if else_block.is_some() {
                    self.ctx.dcx().span_fatal(span, "expected no else block in spec statement")
                };
                self.validate_spec_purity(closure_id, true);
                true
            }
            Some(ClosureKind::Erasure) => true,
            None => false,
        }
    }
}

impl<'a, 'tcx> Visitor<'a, 'tcx> for PurityVisitor<'a, 'tcx> {
    fn thir(&self) -> &'a Thir<'tcx> {
        self.thir
    }

    fn visit_expr(&mut self, expr: &'a thir::Expr<'tcx>) {
        match expr.kind {
            ExprKind::Call { fun, ref args, .. } => {
                if let &FnDef(func_did, subst) = self.thir[fun].ty.kind() {
                    // try to specialize the called function if it is a trait method.
                    let subst = self.ctx.erase_and_anonymize_regions(subst);
                    let (func_did, _) =
                        TraitResolved::resolve_item(self.ctx.tcx, self.typing_env, func_did, subst)
                            .to_opt(func_did, subst)
                            .unwrap();

                    let fn_purity = self.purity(func_did, args);
                    if self.context.is_logic()
                        && (
                            // These methods are allowed to cheat the purity restrictions
                            self.ctx.is_diagnostic_item(sym::box_new, func_did)
                                || matches!(
                                    self.ctx.intrinsic(func_did),
                                    Intrinsic::GhostDeref | Intrinsic::GhostDerefMut
                                )
                        )
                    {
                    } else if !self.context.can_call(fn_purity) {
                        // Emit a nicer error specifically for calls of ghost functions.
                        if fn_purity == Purity::Ghost && self.context.is_program() {
                            match self.ctx.intrinsic(func_did) {
                                Intrinsic::GhostIntoInner => self
                                    .error(expr.span, "trying to access the contents of a ghost variable in program context").emit(),
                                Intrinsic::GhostDeref | Intrinsic::GhostDerefMut => self
                                    .error(expr.span, "dereference of a ghost variable in program context").emit(),
                                Intrinsic::GhostNew => self
                                    .error(
                                        expr.span,
                                        "cannot create a ghost variable in program context",
                                    )
                                    .with_span_suggestion(
                                        expr.span,
                                        "try wrapping this expression in `ghost!` instead",
                                        format!(
                                            "ghost!({})",
                                            self.ctx
                                                .sess
                                                .source_map()
                                                .span_to_snippet(self.thir.exprs[args[0]].span)
                                                .unwrap()
                                        ),
                                        rustc_errors::Applicability::MachineApplicable,
                                    )
                                    .emit(),
                                _ => unreachable!(),
                            };
                        } else {
                            let (caller, callee) = match (self.context, fn_purity) {
                                (
                                    LocalPurity::Purity(Purity::Program { .. } | Purity::Ghost),
                                    Purity::Logic { .. },
                                ) => ("program", "logic"),
                                (LocalPurity::Purity(Purity::Ghost), Purity::Program { .. }) => {
                                    ("ghost", "non-ghost")
                                }
                                (
                                    LocalPurity::Purity(Purity::Logic { .. }),
                                    Purity::Program { .. } | Purity::Ghost,
                                ) => ("logic", "program"),
                                _ => (self.context.as_str(), fn_purity.as_str()),
                            };
                            let msg = format!(
                                "called {callee} function `{}` in {caller} context",
                                self.ctx.def_path_str(func_did),
                            );

                            self.ctx.dcx().span_err(self.thir[fun].span, msg);
                        }
                    }
                    if Intrinsic::SnapshotFromFn.is(self.ctx, func_did) {
                        assert!(args.len() == 1);
                        let Some(ClosureKind::Spec(closure_id)) = self.get_spec_closure(args[0])
                        else {
                            self.ctx.dcx().span_fatal(
                                expr.span,
                                "expected a spec closure as argument to `snapshot_from_fn`",
                            );
                        };
                        self.validate_spec_purity(closure_id, false);
                        return;
                    }
                } else if self.context.is_logic() {
                    // TODO Add a "code" back in
                    self.ctx.dcx().span_fatal(expr.span, "non function call in logical context")
                }
            }
            ExprKind::Closure(box ClosureExpr { closure_id, .. }) => {
                if is_spec(self.ctx.tcx, closure_id.into()) {
                    self.ctx.dcx().span_fatal(
                        expr.span,
                        format!("unexpected spec closure {}", self.ctx.def_path_str(closure_id)),
                    );
                }
                let (thir, expr) = self.ctx.thir_body(closure_id);
                let thir = &thir.borrow();
                PurityVisitor { thir, ..*self }.visit_expr(&thir[expr]);
            }
            ExprKind::Scope { region_scope: _, hir_id, value: _ } => {
                if super::is_ghost_block(self.ctx.tcx, hir_id) {
                    let old_context = std::mem::replace(&mut self.context, LocalPurity::ghost());
                    thir::visit::walk_expr(self, expr);
                    self.context = old_context;
                    return;
                }
            }
            _ => {}
        }
        thir::visit::walk_expr(self, expr)
    }

    fn visit_stmt(&mut self, stmt: &'a thir::Stmt<'tcx>) {
        if !self.try_visit_spec_stmt(stmt) {
            thir::visit::walk_stmt(self, stmt)
        }
    }
}

impl<'a, 'tcx> HasTyCtxt<'tcx> for PurityVisitor<'a, 'tcx> {
    fn tcx(&self) -> TyCtxt<'tcx> {
        self.ctx.tcx
    }
}
