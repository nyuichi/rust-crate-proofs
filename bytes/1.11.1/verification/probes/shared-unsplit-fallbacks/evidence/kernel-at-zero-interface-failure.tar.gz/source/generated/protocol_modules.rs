#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-unsplit-fallbacks-d5f5fdebeb25aed6/out/scalable_tickets.rs"]
mod scalable_tickets;
