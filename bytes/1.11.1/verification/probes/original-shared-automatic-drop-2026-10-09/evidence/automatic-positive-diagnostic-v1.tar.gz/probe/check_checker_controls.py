#!/usr/bin/env python3
"""No-solver adversarial mutations for the automatic-Drop source checker."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import pathlib
import sys
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures" / "checker-controls.json"
CHECKER_PATH = ROOT / "check_correspondence.py"


def replace_once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise RuntimeError(f"mutation anchor must occur exactly once: {old!r}")
    return source.replace(old, new, 1)


def load_checker():
    spec = importlib.util.spec_from_file_location("automatic_drop_correspondence", CHECKER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load automatic-Drop correspondence checker")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.AI = module.load_ai_checker()
    return module


def source_mutations(native: str) -> dict[str, str]:
    return {
        "native_explicit_drop_call": replace_once(
            native, "    observed\n}", "    core::mem::drop(second);\n    observed\n}"),
        "native_extra_clone": replace_once(
            native, "    let observed = AsRef::<[u8]>::as_ref(&second).to_vec();",
            "    let third = second.clone();\n    let observed = AsRef::<[u8]>::as_ref(&second).to_vec();"),
        "native_wrong_drop_order_source": replace_once(
            native, "    let second = first.clone();", "    let first = first.clone();"),
    }


def shadow_mutations(active: str, helper: str, client: str) -> dict[str, tuple[str, str, str]]:
    changed: dict[str, tuple[str, str, str]] = {}
    second = "    bytes_terminal_drop(second,cursor.borrow_mut(),second_receipt.borrow_mut());\n"
    first = "    bytes_terminal_drop(first,cursor.borrow_mut(),first_receipt.borrow_mut());\n"
    changed["omit_second_terminal_drop"] = (active, helper, replace_once(client, second, ""))
    changed["omit_first_terminal_drop"] = (active, helper, replace_once(client, first, ""))
    changed["duplicate_second_terminal_drop"] = (active, helper, replace_once(client, second, second + second))
    changed["swap_terminal_drop_places"] = (
        active, helper,
        replace_once(replace_once(client, second, "    bytes_terminal_drop(first,cursor.borrow_mut(),second_receipt.borrow_mut());\n"),
                     first, "    bytes_terminal_drop(second,cursor.borrow_mut(),first_receipt.borrow_mut());\n"))
    changed["wrong_terminal_drop_place"] = (
        active, helper,
        replace_once(client, second, "    bytes_terminal_drop(first,cursor.borrow_mut(),second_receipt.borrow_mut());\n"))
    changed["early_terminal_drop_before_last_read"] = (
        active, helper,
        replace_once(client,
            "    let observed=borrowed.to_vec();\n",
            "    let mut second_receipt=ghost! {None::<Completion>};\n" + second +
            "    let observed=borrowed.to_vec();\n"))
    changed["return_saved_after_drop"] = (
        active, helper,
        replace_once(client,
            "    let saved_return=observed;\n",
            "") .replace(first, first + "    let saved_return=observed;\n", 1))
    changed["wrong_terminal_cursor"] = (
        active, helper,
        replace_once(client, second, "    bytes_terminal_drop(second,wrong_cursor.borrow_mut(),second_receipt.borrow_mut());\n"))
    changed["wrong_receipt_output"] = (
        active, helper,
        replace_once(client, second, "    bytes_terminal_drop(second,cursor.borrow_mut(),first_receipt.borrow_mut());\n"))
    changed["terminal_helper_wrong_callback"] = (
        active,
        replace_once(helper, "original_shared_cleanup(value,cursor,output)",
                     "unknown_native_callback(value,cursor,output)"),
        client)
    changed["terminal_helper_observes_bytes_address"] = (
        active,
        replace_once(helper, "    original_shared_cleanup(value,cursor,output)",
                     "    observe_address(&value as *const Bytes);\n"
                     "    original_shared_cleanup(value,cursor,output)"),
        client)
    changed["terminal_helper_escapes_data_address"] = (
        active,
        replace_once(helper, "    original_shared_cleanup(value,cursor,output)",
                     "    let address=core::ptr::addr_of!(value.data);\n"
                     "    unknown_sink(address);\n"
                     "    original_shared_cleanup(value,cursor,output)"),
        client)
    changed["terminal_helper_false_trusted_summary"] = (
        active,
        replace_once(helper, "fn bytes_terminal_drop(",
                     "#[trusted]\n#[ensures(false)]\nfn bytes_terminal_drop("),
        client)
    changed["terminal_shadow_hidden_drop_impl"] = (
        active + "\nimpl Drop for Bytes { fn drop(&mut self) { unknown_native_drop(self) } }\n",
        helper, client)
    changed["terminal_shadow_hidden_native_call"] = (
        active, helper,
        replace_once(client, "    let second=original_shared_clone(&first,cursor.borrow_mut());",
                     "    let second=original_shared_clone(&first,cursor.borrow_mut());\n"
                     "    unknown_native_callback(&second);"))
    changed["terminal_shadow_false_precondition"] = (
        active, helper,
        replace_once(client,
            "#[requires(input@.len() < creusot_std::std::vec::capacity_model(input))]",
            "#[requires(false)]"))
    changed["terminal_shadow_move_or_dropflag"] = (
        active, helper,
        replace_once(client, "    let saved_return=observed;",
                     "    let saved_return=observed;\n    if true { drop(first); }"))
    return changed


def mir_mutations(sources: dict[str, str], names: dict[str, str]) -> dict[str, dict[str, str]]:
    scope = names["scope"]
    bytes_drop = names["bytes_drop"]
    closure = names["shared_drop_closure"]
    changed: dict[str, dict[str, str]] = {}

    def with_change(key: str, filename: str, old: str, new: str) -> None:
        updated = dict(sources)
        updated[filename] = replace_once(updated[filename], old, new)
        changed[key] = updated

    with_change("mir_changed_terminal_edge", scope,
                "drop(_4) -> [return: bb6, unwind: bb10];",
                "drop(_4) -> [return: bb7, unwind: bb10];")
    with_change("mir_omitted_terminal_drop", scope,
                "StorageDead(_6);\n        drop(_4) -> [return: bb6, unwind: bb10];",
                "StorageDead(_6);\n        goto -> bb6;")
    with_change("mir_swapped_terminal_drop_places", scope,
                "drop(_4) -> [return: bb6, unwind: bb10];",
                "drop(_2) -> [return: bb6, unwind: bb10];")
    with_change("mir_changed_drop_unwind_successor", scope,
                "drop(_2) -> [return: bb7, unwind: bb12];",
                "drop(_2) -> [return: bb7, unwind: bb10];")
    with_change("mir_added_branch_dropflag", scope,
                "_0 = move _6;\n        goto -> bb5;",
                "_0 = move _6;\n        switchInt(const true) -> [0: bb5, otherwise: bb6];")
    with_change("mir_wrong_bytes_vtable_slot", bytes_drop,
                "(*_7).4: for<'a> unsafe fn", "(*_7).3: for<'a> unsafe fn")
    with_change("mir_wrong_bytes_drop_argument", bytes_drop,
                "_5 = copy ((*_1).0: *const u8);", "_5 = copy ((*_1).1: usize);")
    with_change("mir_shared_closure_wrong_target", closure,
                "bytes::release_shared(move _4)", "bytes::free_shared(move _4)")
    with_change("mir_shared_closure_observes_data_address", closure,
                "_5 = copy (*_2);", "_5 = copy _2;")
    return changed


def production_mutations(ai: Any, bytes_source: str, refcount: str,
                         shared_record: str, bytes_record: str, vtable_record: str,
                         loom: str) -> dict[str, tuple[str, str, str, str, str, str]]:
    changed: dict[str, tuple[str, str, str, str, str, str]] = {}

    def row(k: str, bs: str = bytes_source, sr: str = shared_record,
            br: str = bytes_record, vr: str = vtable_record, ls: str = loom) -> None:
        changed[k] = (bs, refcount, sr, br, vr, ls)

    row("production_bytes_drop_wrong_vtable_field", replace_once(
        bytes_source, "(self.vtable.drop)(&mut self.data, self.ptr, self.len)",
        "(self.vtable.clone)(&self.data, self.ptr, self.len)"))
    row("production_bytes_drop_observes_self_address", replace_once(
        bytes_source, "fn drop(&mut self) {", "fn drop(&mut self) { let _address=self as *mut Bytes;"))
    row("production_vtable_field_order_changed", vr=replace_once(
        vtable_record,
        "pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),",
        "pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),\n    pub hidden: unsafe fn(),"))
    row("production_native_vtable_drop_target_changed", bs=replace_once(
        bytes_source, "drop: shared_drop,", "drop: shared_clone,"))
    row("production_bytes_added_field_glue", bytes_record,
        bytes_record=replace_once(bytes_record, "    vtable: &'static Vtable,",
                                  "    vtable: &'static Vtable,\n    hidden: alloc::boxed::Box<u8>,"))
    row("production_shared_added_field_glue", shared_record,
        shared_record=replace_once(shared_record, "    pub(crate) ref_cnt: AtomicUsize,",
                                   "    pub(crate) ref_cnt: AtomicUsize,\n    hidden: alloc::vec::Vec<u8>,"))
    row("production_loom_callback_sees_atomic_address", loom,
        ls=replace_once(loom, "f(self.get_mut())", "f(&mut *self.get_mut())"))
    row("production_shared_callback_extra_effect", replace_once(
        bytes_source, "release_shared(shared.cast());", "release_shared(shared.cast());\n        release_shared(shared.cast());"))
    return changed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=pathlib.Path,
                        default=ROOT / "fixtures" / "checker-control-results.json")
    args = parser.parse_args()
    checker = load_checker()
    spec = json.loads(FIXTURES.read_text())
    native = checker.NATIVE_SOURCE.read_text()
    mir_sources = {name: (checker.MIR_DIR / name).read_text()
                   for name in checker.MIR_FILENAMES.values()}
    active = checker.ACTIVE_SHADOW.read_text()
    helper = (checker.GENERATED / "terminal-helper.rs").read_text()
    client = (checker.GENERATED / "elaborated-client.rs").read_text()
    mapping_path = checker.MAP_DEFAULT
    mapping = json.loads(mapping_path.read_text())
    bytes_source = (checker.CRATE_ROOT / "src/bytes.rs").read_text()
    refcount = (checker.CRATE_ROOT / "src/ref_count_ops.rs").read_text()
    shared_record = (checker.CRATE_ROOT / "src/bytes/shared_record.rs").read_text()
    bytes_record = (checker.CRATE_ROOT / "src/bytes/bytes_record.rs").read_text()
    vtable_record = (checker.CRATE_ROOT / "src/bytes/vtable_record.rs").read_text()
    loom = (checker.CRATE_ROOT / "src/loom.rs").read_text()

    try:
        positive = checker.audit_all(native_source=native, mir_dir=checker.MIR_DIR,
                                     active_source=active, terminal_helper=helper,
                                     elaborated_client=client, mapping_path=mapping_path)
    except Exception as exc:
        print(json.dumps({"status": "controls_failed", "error": f"positive rejected: {exc}"}, indent=2))
        return 2
    native_controls = source_mutations(native)
    shadow_controls = shadow_mutations(active, helper, client)
    mir_controls = mir_mutations(mir_sources, checker.MIR_FILENAMES)
    prod_controls = production_mutations(checker.AI, bytes_source, refcount,
                                         shared_record, bytes_record, vtable_record, loom)
    control_names = {**native_controls, **shadow_controls, **mir_controls, **prod_controls}
    expected_names = {row["name"] for row in spec["controls"]}
    if set(control_names) != expected_names:
        print(json.dumps({"status": "controls_failed", "error": {
            "unmatched_fixture_names": sorted(expected_names - set(control_names)),
            "unmatched_mutation_names": sorted(set(control_names) - expected_names)}}, indent=2))
        return 2

    mir_facts = positive["native_mir"]
    shadow_facts = positive["proof_shadow"]
    base_source = (checker.AI_PROBE / "src/public_shared.rs").read_text()
    rows = []
    for row in spec["controls"]:
        name = row["name"]
        try:
            if name in native_controls:
                checker.audit_native_source(native_controls[name])
            elif name in shadow_controls:
                a, h, c = shadow_controls[name]
                checker.audit_shadow(a, h, c, checker.AI)
            elif name in mir_controls:
                checker.audit_mir_sources(mir_controls[name])
            else:
                bs, rc, sr, br, vr, ls = prod_controls[name]
                checker.audit_production_drop_sources(checker.AI, bs, rc, sr, br, vr, ls)
        except Exception as exc:
            rows.append({"name": name, "class": row["class"], "rejected": True, "reason": str(exc)})
        else:
            rows.append({"name": name, "class": row["class"], "rejected": False,
                         "reason": "mutation passed correspondence check"})
    result = {
        "status": "controls_pass" if all(r["rejected"] for r in rows) else "controls_failed",
        "checker_sha256": hashlib.sha256(checker.CHECKER_PATH.read_bytes()).hexdigest()
        if hasattr(checker, "CHECKER_PATH") else hashlib.sha256((ROOT / "check_correspondence.py").read_bytes()).hexdigest(),
        "native_source_sha256": hashlib.sha256(native.encode()).hexdigest(),
        "active_source_sha256": hashlib.sha256(active.encode()).hexdigest(),
        "mapping_sha256": hashlib.sha256(mapping_path.read_bytes()).hexdigest(),
        "controls": rows,
        "control_count": len(rows),
        "all_controls_rejected": all(r["rejected"] for r in rows),
        "prover_invoked": False,
        "positive_status": positive["status"],
        "boundary": spec["boundary"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "controls_pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
