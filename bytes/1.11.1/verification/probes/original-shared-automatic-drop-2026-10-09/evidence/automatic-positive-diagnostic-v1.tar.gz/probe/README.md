# Actual Shared Bytes terminal automatic Drop

AJ applies AG's external normal-edge elaboration to AI's actual Shared lifecycle.
The native source has no explicit cleanup or `mem::drop`: construct first, clone
second, copy the AsRef view into an owned Vec, then return it. The selected native
MIR evaluates/moves the return value before dropping second and then first.
Native source/API/destructor are unchanged. The client alone assumes input
length is less than capacity; AE's unrestricted constructor proof is unchanged.

The proof-only artifact retains AI's exact mathematical source, removes implicit
Bytes Drop by retaining the existing no-Drop shadow record, and appends an
ordinary consuming `bytes_terminal_drop` helper and the elaborated caller.
The helper forwards the body-proved checked cleanup and preserves its contract;
it is not trusted. Each terminal call consumes the actual sidecar ticket and
threads the separate affine cursor and completion channel. The caller saves the
return value, checks second's KeptAlive receipt and exact ticket removal (first
still live), then first's Reclaimed receipt pair and empty map. There is no
postcondition restoring a live `&mut Bytes` invariant after freeing storage.

A consuming shadow is only admitted with the extra generic terminal-place
correspondence premise: the selected destructor/target closure neither observes
nor escapes the Bytes handle/data-field address. Stored pointer/length/vtable
values are preserved, and `AtomicMut::with_mut`/`get_mut` returns only a copy of
the stored pointer. Heap buffer/control pointers remain relevant to recovery
and free; the ban concerns the handle's own location. Independent native field
drop glue must be absent. Exact Bytes/Shared field profiles, Shared Drop body,
AtomicUsize no-drop guard, core native alias, actual Drop/callback/closure/native
MIR and release/free chain are checked. This does not establish equivalence for
arbitrary destructors or moves.

Generic compiler/MIR/source-checker/ghost-erasure interpretation remains tool
TCB, alongside AI's reviewed callback/field/physical primitives. Bytes-specific
issuance, release, final Acquire, recovery, deallocation receipt composition and
terminal helper/caller consequences are body proved. A future native destructor-
effect lowering can replace the external terminal-place interface without
changing the lifecycle proof contracts. No bytes-specific Drop summary is trusted.

`generate-native-mir.sh` uses the pinned nightly, disables incremental query
reuse and cleans only the selected packages to obtain fresh MIR dumps. It runs
the exact native source against production Bytes with real Drop on five inputs.
The capture records the selected after-ElaborateDrops client/destructor/target
MIR, versions, source identities and commands. Unwind successors and cleanup
blocks are retained but excluded from the normal-return theorem.
`elaborate.py` generates active source and mapping; the mapping is a receipt,
not proof. The independent checker rederives place/target/order/count/successors,
last-read and saved-return ordering, selected closure non-address observation and
field-glue/source conditions. Unsupported branches/flags/escapes/effects are not
silently admitted.

Run native generation, structural controls, and then `run-proof.sh` elevated.
Why3 uses the shared lock, one prover, 1024 MiB and no sc-drf. Every generated
Coma target is included; diagnostic skips are explicitly marked and cannot be
canonical. `evidence.py` archives exact sources, all target/results, external
source inputs/private Std/Cargo patch/configuration, native results and proof log.
The complete bytes target remains NOT ADMITTED: unwind, other representations,
arbitrary concurrent closure and remaining APIs/configurations are still open.
Final counts, controls and independent audit are recorded after canonical replay.
