#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-adjacent-unsplit-eb74a49aaf73d217/out/scalable_tickets.rs"]
mod scalable_tickets;
