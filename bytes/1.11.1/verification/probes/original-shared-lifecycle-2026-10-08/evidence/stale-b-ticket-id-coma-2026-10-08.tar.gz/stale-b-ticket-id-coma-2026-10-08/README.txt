Preserved frontend artifact from the original-shared probe before refreshing
its path dependency Coma after the B Ticket::id public logic accessor change.
The generated terms contain `ERROR_UNBOUND_id` in initialize/prepare/clone
contracts; Why3 consequently reports a syntax error. This is stale dependency
metadata, not a positive proof result. The archive is retained to diagnose the
refresh sequence; it must not be counted as passing lifecycle evidence.
