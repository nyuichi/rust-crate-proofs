# Targeted no-Acquire negative control

The proof-only feature removes the actual Acquire call and its callback from the last-owner path while preserving the `Pending::recover` call. Native builds retain Acquire, and the feature-mutated code was not executed natively.

The translated source tree contains 44 Coma files. The targeted `release_one_observed` proof reports 29/30 goals discharged, with one unresolved nested recovery guard obligation. Its proof JSON has exactly one recursively audited null leaf at the path recorded in `result.json`. This is a negative control, not a positive lifecycle result.

`inputs/` contains the exact probe, production helper, and bounded-protocol source inputs. `outputs/verif/` contains all translated Coma files and only the freshly produced proof JSON for the selected target; sibling proof JSON files from an interrupted whole-crate attempt are intentionally excluded. The log and launcher metadata record the completed serialized execution.
