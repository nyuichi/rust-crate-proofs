# Source lifecycle driver positive evidence

The default-feature Creusot/Why3 run proves all 44 generated files. The snapshot includes 44 Coma modules and their matching 44 proof JSON files; recursive JSON inspection finds no null leaves. The source map pins the selected bytes.rs/loom.rs branches, the production helper files, and all bounded-protocol dependency sources.

The native test log records 2/2 passing tests. Both driver directions select the original or clone as the live reader, and the suite checks the complete returned byte sequence for empty and nonempty inputs with spare capacity. The negative borrow log records E0505 when cleanup consumes a handle with a borrowed slice still in use.

The no-Acquire mutant is a separate targeted negative control. Its archive hash and print-only acquired-view guard diagnostic are included under `controls/`; the mutant was never executed natively. Public vtable selection, indirect callback dispatch, arbitrary-count/full public `Clone`, and automatic `Drop` remain outside the proved scope.
