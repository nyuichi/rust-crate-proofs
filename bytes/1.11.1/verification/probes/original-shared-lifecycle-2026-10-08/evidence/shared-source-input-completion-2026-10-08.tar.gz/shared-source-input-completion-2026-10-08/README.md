# Shared source input completion

This supplement contains the production files imported by path from the bounded physical-lifecycle crate but not included in the probe-local source directories: `src/provenance_specs.rs` and `src/ownership_proof/bound_ptr.rs`. Its `completion.json` ties these exact file hashes to the immutable positive and no-Acquire evidence archive hashes.
