# Integrated original Shared proof snapshot (diagnostic)

This archive freezes the exact selected source inputs, translation (`.coma`) and proof JSON tree, environment configuration, and serialized run log for the clean replay dated 2026-10-08. The translation succeeded; the full proof exited 1 with unresolved VCs, so this is not a positive verification result. See `manifest.json` for counts, exact recursive null locations, and file hashes.

The adapter models `Bytes.vtable` as an opaque input and does not prove `SHARED_VTABLE`, indirect dispatch, or automatic public `Drop`. The bounded lifecycle dependency admits one constructor owner plus one clone. Generic atomic-field and typed-allocation contracts remain TCB.
