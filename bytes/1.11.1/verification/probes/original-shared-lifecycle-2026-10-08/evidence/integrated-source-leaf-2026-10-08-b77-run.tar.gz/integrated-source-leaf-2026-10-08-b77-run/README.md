# Original Shared lifecycle candidate (B77 diagnostic)

This archive freezes the exact source and clean translated/proof tree after B's checked token-lifetime observations were added. Translation succeeded; proof exited 1 with only four unresolved VC leaves: two in the `len < cap` constructor and two in explicit `release_shared` cleanup. All other targets in the clean generated tree prove. See `manifest.json` for recursive null locations, counts, and hashes. This is not a positive full lifecycle proof.

The adapter uses the actual source-shaped native `Bytes` and `Shared` fields. It selects cleanup pointer from `Bytes.data.get_mut()` matching production `AtomicMut::with_mut`. `Vtable` is an opaque input; public dispatch and automatic `Drop` remain open. B is bounded to one clone. Generic actual-field synchronization/pointer access and exact typed-box allocation/deallocation boundaries remain TCB; no bytes-specific ownership/refcount/finalizer theorem is trusted.
