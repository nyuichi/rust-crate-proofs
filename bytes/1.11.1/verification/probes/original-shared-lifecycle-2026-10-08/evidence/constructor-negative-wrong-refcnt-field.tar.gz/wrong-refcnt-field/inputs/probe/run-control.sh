#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source /workspace/bytes-proof-tools/activate.sh
export CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR=/workspace/bytes-proof-tools/targets/bytes-field-control-wrong-refcnt-field
export XDG_CONFIG_HOME="$PWD/.proof-config"
exec 9>"${BYTES_PROOF_LOCK:-/tmp/itoa-creusot-proof.lock}"
flock 9
cargo creusot clean --force
rm -rf verif
cargo creusot --only=coma -- --locked
cargo creusot clean --force
cargo creusot --only=prove --why3find-arg=-j --why3find-arg=1
