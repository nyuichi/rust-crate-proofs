# Original Shared source leaf: current authoring evidence

This archive contains the exact source snapshot and prover outputs for the corrected non-consuming clone leaf at this point in the integration. It is diagnostic, not a positive proof of the complete lifecycle. The native tests pass, and the negative same-handle release test fails compilation with E0505 as expected.

The single Why3 run translated successfully and then exited 1 with five unproved top-level source-adapter VCs: constructor, clone, release, borrowed contents, and peer-release read. The generated tree has the counts recorded in `manifest.json`. In particular, `borrow_across_peer_release` is 6/7, with the one remaining child at the `!peer_last` assertion. Some nested VCs in `release_one` and `from_vec_spare_capacity` also remain null.

This is the source-shaped default `Bytes` fields plus actual three-field `Shared` leaf for the selected `len < cap` path. The supplied `Vtable` is opaque: static vtable identity, callback dispatch, and automatic `Drop` are not proved. The fixed B protocol covers the initial owner and one clone only. Generic atomic operations use the actual borrowed core fields. This snapshot makes no claim of successful end-to-end verification.
