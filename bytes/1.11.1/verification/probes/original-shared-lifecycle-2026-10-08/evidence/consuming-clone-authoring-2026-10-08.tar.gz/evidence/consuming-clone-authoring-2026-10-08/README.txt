Authoring diagnostic snapshot only; not a positive lifecycle proof.

Captured 2026-10-08 from the draft whose source_adapter::shallow_clone_arc consumed
self and returned (old_handle, new_handle). The proof run was interrupted on root's
instruction after the source correspondence review found that this does not match
the original Clone(&self) source leaf. It also still used debug_assert for the
source overflow-abort branch and release_one did not publish Receipt.valid in its
postcondition. The generated Coma/JSON and copied adapter sources are retained only
to inspect the first semantic VC frontier. Do not cite this snapshot as evidence
for original Clone or a completed source lifecycle.
