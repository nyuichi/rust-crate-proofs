# Integrated original Shared proof replay (diagnostic)

This archive freezes the second clean serialized run after deleting only this probe’s ignored `verif/` tree. Translation completed without dangling generated artifacts. The proof still exits 1 with 15 unresolved nodes across four targets. See `manifest.json` for exact source hashes, output counts, and null paths. It is diagnostic evidence, not a positive lifecycle proof.

The leaf models the production four-field `Bytes` and three-field `Shared` records. `Vtable` remains an opaque input; public dynamic dispatch and automatic `Drop` are out of scope. The bounded protocol covers initial count one plus one clone. Generic actual-field atomic and typed deallocation contracts remain TCB.
