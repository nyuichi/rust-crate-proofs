#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-actual-shared-try-reclaim-6bb3d60484856831/out/scalable_tickets.rs"]
mod scalable_tickets;
