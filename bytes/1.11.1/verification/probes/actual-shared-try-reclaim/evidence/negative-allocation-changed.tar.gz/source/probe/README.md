# Bounded public Shared `try_reclaim`

This probe extracts the actual `BytesMut::try_reclaim` method with
`bytes_proof_shared_reclaim`. The method receives a matching exclusive external
coordinator and requires initialized registered storage and
`offset + len + additional <= isize::MAX`.

The ordinary sufficient-capacity fast path is unchanged. The cfg slow path
returns false for a live sibling or when the singleton allocation cannot fit
the request under the native movement policy. Otherwise it uses the existing
singleton lease, B6 offset bridge, reuse/movement helper, and reactivation.
The capacity guard excludes the helper's reallocation branch.

Contracts specify the exact success condition, unchanged visible bytes and
length, sufficient capacity on success, unchanged handle on failure, unchanged
allocation identity and physical capacity, unchanged registration count, and
preserved unrelated registrations. The strengthened `reserve_lease` contract
exposes preservation of its original Recovery authority for fitting requests;
its body is checked without adding trust.

The native matrix covers 512 prefix/suffix, capacity, request, and sibling-count
cases. It checks both output bytes and the native success condition. The proof
caller explicitly retires every surviving owner. Saved evidence records the
proof result and exact generated source separately from native execution.

```sh
bash verify.bash
cargo test --locked
bash verify.bash --features negative_allocation_changed
```

The negative requests an impossible changed allocation identity after the
nonallocating operation. Ordinary automatic Drop, concurrent native ownership,
and requests outside the stated arithmetic bound remain outside this gate.
