#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-actual-shared-try-reclaim-ebfd7952c36b1743/out/scalable_tickets.rs"]
mod scalable_tickets;
