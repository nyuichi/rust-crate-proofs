#!/usr/bin/env python3
"""Run source mutations against the closed-client checker without a prover."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
CHECKER_PATH = ROOT / "check_closed_scope.py"
FIXTURE_PATH = ROOT / "fixtures" / "checker-controls.json"
RESULT_PATH = ROOT / "fixtures" / "checker-control-results.json"
SOURCE_PATH = ROOT / "src" / "driver.rs"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


spec = importlib.util.spec_from_file_location("closed_scope_checker", CHECKER_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("could not load check_closed_scope.py")
checker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checker
spec.loader.exec_module(checker)


def once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise AssertionError(f"mutation anchor must occur exactly once: {old!r}")
    return source.replace(old, new, 1)


def mutate(case_id: str, source: str) -> str:
    line_one = "    let (_, second) = registry.register(first.borrow(), cursor.borrow_mut());\n"
    line_two = "    let (_, third) = registry.register(first.borrow(), cursor.borrow_mut());\n"
    if case_id == "escaped_clone":
        return once(source, line_one, line_one + "    let escaped = second.clone();\n")
    if case_id == "unfinished_callback":
        callback = "    let unfinished = || { registry.register(first.borrow(), cursor.borrow_mut()); };\n"
        return once(source, line_one, line_one + callback)
    if case_id == "forgotten_live":
        return once(source, line_one, line_one + "    core::mem::forget(second);\n")
    if case_id == "thread_escape":
        return once(source, line_one,
                    line_one + "    std::thread::spawn(move || { let _ = second; });\n")
    if case_id == "raw_alias":
        anchor = "    let (registry, first, mut cursor) = Registry::new(\n"
        return once(source, anchor,
                    anchor + "    let raw = &mut cursor as *mut _;\n")
    if case_id == "untracked_event":
        return once(source, line_two,
                    "    let (_, third) = registry.register(first.borrow());\n")
    if case_id == "fakecomment":
        return once(source, line_two,
                    "    // registry.register(first.borrow(), cursor.borrow_mut());\n")
    if case_id == "fakestring":
        return once(source, line_two,
                    '    let marker = "registry.register(first.borrow(), cursor.borrow_mut());";\n')
    if case_id == "wrong_target":
        return once(source, line_two,
                    "    let (_, third) = registry.register(second.borrow(), cursor.borrow_mut());\n")
    if case_id == "wrong_order":
        third = (
            "    let (third_last, third_recovery) = registry.retire(third, cursor.borrow_mut());\n"
            "    proof_assert!(!third_last && third_recovery.inner_logic() == None);\n"
        )
        first = (
            "    let (first_last, first_recovery) = registry.retire(first, cursor.borrow_mut());\n"
            "    proof_assert!(!first_last && first_recovery.inner_logic() == None);\n"
        )
        return once(source, third + first, first + third)
    if case_id == "duplicate":
        return once(source, line_one,
                    line_one + "    let (_, duplicate) = registry.register(first.borrow(), cursor.borrow_mut());\n")
    if case_id == "omitted":
        return once(source, line_two, "")
    raise AssertionError(f"unknown checker-control mutation: {case_id}")


def main() -> int:
    fixture = json.loads(FIXTURE_PATH.read_text())
    source_bytes = SOURCE_PATH.read_bytes()
    source = source_bytes.decode()
    cases = []
    for row in fixture["controls"]:
        mutated = mutate(row["id"], source)
        try:
            checker.audit_source(mutated, source_name=f"<mutation:{row['id']}>")
            actual = "correspondence_pass"
            error = None
        except checker.CoverageError as exc:
            actual = "coverage_failure"
            error = str(exc)
        cases.append({
            "id": row["id"],
            "expected": row["expected"],
            "actual": actual,
            "pass": actual == row["expected"],
            "error": error,
            "prover_invoked": False,
        })
    report = {
        "schema_version": 1,
        "status": "controls_pass" if all(x["pass"] for x in cases) else "controls_failed",
        "checker_sha256": sha(CHECKER_PATH.read_bytes()),
        "fixture_sha256": sha(FIXTURE_PATH.read_bytes()),
        "source_sha256": sha(source_bytes),
        "controls": cases,
        "prover_invoked": False,
        "semantic_boundary": fixture["semantic_boundary"],
    }
    RESULT_PATH.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        "status": report["status"],
        "controls": len(cases),
        "failures": [x for x in cases if not x["pass"]],
        "report": RESULT_PATH.as_posix(),
    }, indent=2))
    return 0 if report["status"] == "controls_pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
