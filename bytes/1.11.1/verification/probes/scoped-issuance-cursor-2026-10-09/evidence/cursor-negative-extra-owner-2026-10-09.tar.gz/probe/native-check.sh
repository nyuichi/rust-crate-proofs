#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source /workspace/bytes-proof-tools/activate.sh
export CARGO_NET_OFFLINE=true
# Same package/source, with all ghost channels erased by the ordinary compiler.
cargo build --locked
rustc_path="$(rustup which rustc)"
rlib=$(find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -name 'libbytes_scoped_issuance_cursor-*.rlib' -print -quit)
[[ -n "$rlib" ]]
mkdir -p generated
cat > generated/native-main.rs <<'RS'
extern crate bytes_scoped_issuance_cursor;
fn main() {
    assert!(bytes_scoped_issuance_cursor::closed_sparse_lifecycle());
}
RS
"$rustc_path" generated/native-main.rs --edition 2021 -L dependency="$CARGO_TARGET_DIR/debug/deps" \
    --extern "bytes_scoped_issuance_cursor=$rlib" -o generated/native-client
./generated/native-client
printf 'native closed scoped client: passed\n'
