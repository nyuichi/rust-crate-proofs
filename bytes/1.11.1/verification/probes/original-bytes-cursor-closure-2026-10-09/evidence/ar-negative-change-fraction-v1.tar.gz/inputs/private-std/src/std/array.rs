#[cfg(creusot)]
use crate::resolve::structural_resolve;
use crate::{invariant::*, logic::ops::IndexLogic, prelude::*, std::iter::ExactSizeIteratorSpec};
use core::array::*;

impl<T, const N: usize> Invariant for [T; N] {
    #[logic(open, prophetic)]
    fn invariant(self) -> bool {
        pearlite! { inv(self@) && self@.len() == N@ }
    }
}

impl<T, const N: usize> View for [T; N] {
    type ViewTy = Seq<T>;

    #[logic]
    #[cfg_attr(target_pointer_width = "16", builtin("creusot.slice.Slice16$BW$.view"))]
    #[cfg_attr(target_pointer_width = "32", builtin("creusot.slice.Slice32$BW$.view"))]
    #[cfg_attr(target_pointer_width = "64", builtin("creusot.slice.Slice64$BW$.view"))]
    fn view(self) -> Self::ViewTy {
        dead
    }
}

impl<T: DeepModel, const N: usize> DeepModel for [T; N] {
    type DeepModelTy = Seq<T::DeepModelTy>;

    #[trusted]
    #[logic(opaque)]
    #[ensures(self.view().len() == result.len())]
    #[ensures(forall<i> 0 <= i && i < result.len() ==> result[i] == self[i].deep_model())]
    fn deep_model(self) -> Self::DeepModelTy {
        dead
    }
}

impl<T, const N: usize> Resolve for [T; N] {
    #[logic(open, prophetic, inline)]
    #[creusot::trusted_trivial_if_param_trivial]
    fn resolve(self) -> bool {
        pearlite! { forall<i: Int> 0 <= i && i < N@ ==> resolve(self@[i]) }
    }

    #[trusted]
    #[logic(prophetic)]
    #[requires(structural_resolve(self))]
    #[ensures(self.resolve())]
    fn resolve_coherence(self) {}
}

impl<T, const N: usize> IndexLogic<Int> for [T; N] {
    type Item = T;

    #[logic(open, inline)]
    fn index_logic(self, ix: Int) -> Self::Item {
        pearlite! { self@[ix] }
    }
}

impl<T, const N: usize> IndexLogic<usize> for [T; N] {
    type Item = T;

    #[logic(open, inline)]
    fn index_logic(self, ix: usize) -> Self::Item {
        pearlite! { self@[ix@] }
    }
}

impl<T, const N: usize> View for IntoIter<T, N> {
    type ViewTy = Seq<T>;

    #[logic(opaque)]
    fn view(self) -> Self::ViewTy {
        dead
    }
}

impl<T, const N: usize> IteratorSpec for IntoIter<T, N> {
    #[logic(open, prophetic)]
    fn produces(self, visited: Seq<T>, o: Self) -> bool {
        pearlite! { self@ == visited.concat(o@) }
    }

    #[logic(open, prophetic)]
    fn completed(&mut self) -> bool {
        pearlite! { resolve(self) && self@ == Seq::empty() }
    }

    #[logic(law)]
    #[ensures(self.produces(Seq::empty(), self))]
    fn produces_refl(self) {
        let _ = Seq::<T>::concat_empty;
    }

    #[logic(law)]
    #[requires(a.produces(ab, b))]
    #[requires(b.produces(bc, c))]
    #[ensures(a.produces(ab.concat(bc), c))]
    fn produces_trans(a: Self, ab: Seq<T>, b: Self, bc: Seq<T>, c: Self) {
        let _ = ab.reverse_concat(bc);
        let _ = Seq::<T>::concat_assoc;
    }
}

extern_spec! {
    impl<T, const N: usize> Iterator for IntoIter<T, N> {
        #[ensures(result.0@ == self@.len())]
        #[ensures(result.1 == Some(result.0))]
        fn size_hint(&self) -> (usize, Option<usize>);
    }
}

impl<T, const N: usize> ExactSizeIteratorSpec for IntoIter<T, N> {
    #[logic(law)]
    #[requires(Self::size_hint.postcondition((self,), r))]
    #[ensures(r.1 == Some(r.0))]
    #[allow(unused_variables)]
    fn size_hint_exact(&self, r: (usize, Option<usize>)) {}
}

impl<T, const N: usize> DoubleEndedIteratorSpec for IntoIter<T, N> {
    #[logic(open)]
    fn produces_back(self, visited: Seq<T>, o: Self) -> bool {
        pearlite! {
            self@ == o@.concat(visited.reverse())
        }
    }

    #[logic(open, prophetic)]
    fn completed_back(&mut self) -> bool {
        self.completed()
    }

    #[logic(law)]
    #[ensures(self.produces_back(Seq::empty(), self))]
    fn produces_back_refl(self) {
        let _ = Seq::<T>::reverse_empty();
        let _ = Seq::<T>::concat_empty;
    }

    #[logic(law)]
    #[requires(a.produces_back(ab, b))]
    #[requires(b.produces_back(bc, c))]
    #[ensures(a.produces_back(ab.concat(bc), c))]
    fn produces_back_trans(a: Self, ab: Seq<T>, b: Self, bc: Seq<T>, c: Self) {
        let _ = ab.reverse_concat(bc);
        let _ = Seq::<T>::concat_assoc;
    }

    #[logic(law)]
    #[requires(Self::size_hint.postcondition((self,), r))]
    #[ensures(forall<s: Seq<Self::Item>, i: &mut Self>
        self.produces_back(s, *i) && i.completed_back() ==> r.0@ <= s.len())]
    #[ensures(match r.1 {
        Some(r) => {
            forall<s: Seq<Self::Item>, i: Self> self.produces_back(s, i) ==> s.len() <= r@
        }
        None => true
    })]
    fn size_hint_back_spec(&self, r: (usize, Option<usize>)) {}
}

extern_spec! {
    impl<T, const N: usize> IntoIterator for [T; N] {
        #[check(ghost)]
        #[ensures(self@ == result@)]
        fn into_iter(self) -> core::array::IntoIter<T, N>;
    }

    impl<T: Clone, const N: usize> Clone for [T; N] {
        #[ensures(forall<i> 0 <= i && i < self@.len() ==>
            T::clone.postcondition((&self@[i],), result@[i]))]
        fn clone(&self) -> [T; N];
    }

    impl<T, const N: usize> [T; N] {
        #[check(ghost)]
        #[ensures(result@ == self@)]
        fn as_slice(&self) -> &[T] {
            self
        }

        #[check(ghost)]
        #[ensures(result@ == self@)]
        #[ensures((^self)@.len() == (*self)@.len())]
        #[ensures((^result)@ == (^self)@)]
        fn as_mut_slice(&mut self) -> &mut [T] {
            self
        }
    }
}
