use crate::{
    ghost::{FnGhost, Perm, perm::PermTarget},
    prelude::*,
    std::sync::committer::Committer,
};
pub mod ordering {
    pub struct SeqCst;
    pub use crate::std::sync::atomic::ordering::None;
}
use core::sync::atomic::Ordering as OrderingTy;

macro_rules! impl_atomic {
    ($( ($type:ty, $atomic_type:ident $(< $T:ident >)?) ),+) => { $(

        /// Creusot wrapper around [`std::sync::atomic::$atomic_type`]
        #[doc = concat!("Creusot wrapper around [`std::sync::atomic::", stringify!($atomic_type), "`].")]
        pub struct $atomic_type $(< $T >)?(::core::sync::atomic::$atomic_type $(< $T >)?);

        impl $(< $T >)? PermTarget for $atomic_type $(< $T >)? {
            type Value<'a> = $type where Self: 'a;
            type PermPayload = ();
        }

        impl $(< $T >)? $atomic_type $(< $T >)? {
            #[ensures(result.1.val() == val)]
            #[ensures(*result.1.ward() == result.0)]
            #[inline(always)]
            #[trusted]
            #[check(terminates)]
            pub fn new(val: $type) -> (Self, Ghost<Perm<$atomic_type $(< $T >)?>>) {
                (Self(::core::sync::atomic::$atomic_type::new(val)), Ghost::conjure())
            }

            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::into_inner`].")]
            #[requires(self == *own.ward())]
            #[ensures(result == own.val())]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn into_inner(self, own: Ghost<Perm<$atomic_type $(< $T >)?>>) -> $type {
                self.0.into_inner()
            }

            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::compare_exchange`].")]
            #[doc = ""]
            #[doc = "The load and the store are always sequentially consistent."]
            #[requires(forall<c: &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>>
                !c.shot_store() ==> c.ward() == *self ==>
                c.val_load().deep_model() == current.deep_model() ==>
                c.val_store() == new ==>
                f.precondition((Ok(c),)) && (f.postcondition_once((Ok(c),), ()) ==> (^c).shot_store())
            )]
            #[requires(forall<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                !c.shot_store() ==> c.ward() == *self ==>
                // NOTE: This following line is not present for `weak`
                c.val_load().deep_model() != current.deep_model() ==>
                f.precondition((Err(c),))
            )]
            #[ensures(
                match result {
                    Ok(result) => {
                        exists<c: &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>>
                            !c.shot_store() && c.ward() == *self &&
                            c.val_load().deep_model() == current.deep_model() &&
                            c.val_store() == new &&
                            result == c.val_load() &&
                            f.postcondition_once((Ok(c),), ())
                    },
                    Err(result) => {
                       exists<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                            !c.shot_store() && c.ward() == *self &&
                            // NOTE: This following line is not present for `weak`
                            c.val_load().deep_model() != current.deep_model() &&
                            result == c.val_load() &&
                            f.postcondition_once((Err(c),), ())
                    }
                }
            )]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn compare_exchange<F>(&self, current: $type, new: $type, f: Ghost<F>) -> Result<$type, $type>
            where
                F: FnGhost + FnOnce(Result<
                    &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>,
                    &Committer<Self, $type, ordering::SeqCst, ordering::None>
                >,
            )
            {
                self.0.compare_exchange(current, new, OrderingTy::SeqCst, OrderingTy::SeqCst)
            }

            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::compare_exchange_weak`].")]
            #[doc = ""]
            #[doc = "The load and the store are always sequentially consistent."]
            #[requires(forall<c: &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>>
                !c.shot_store() ==> c.ward() == *self ==>
                c.val_load().deep_model() == current.deep_model() ==>
                c.val_store() == new ==>
                f.precondition((Ok(c),)) && (f.postcondition_once((Ok(c),), ()) ==> (^c).shot_store())
            )]
            #[requires(forall<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                !c.shot_store() ==> c.ward() == *self ==>
                f.precondition((Err(c),))
            )]
            #[ensures(
                match result {
                    Ok(result) => {
                        exists<c: &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>>
                            !c.shot_store() && c.ward() == *self &&
                            c.val_load().deep_model() == current.deep_model() &&
                            c.val_store() == new &&
                            result == c.val_load() &&
                            f.postcondition_once((Ok(c),), ())
                    },
                    Err(result) => {
                       exists<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                            !c.shot_store() && c.ward() == *self &&
                            result == c.val_load() &&
                            f.postcondition_once((Err(c),), ())
                    }
                }
            )]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn compare_exchange_weak<F>(&self, current: $type, new: $type, f: Ghost<F>) -> Result<$type, $type>
            where
                F: FnGhost + FnOnce(Result<
                    &mut Committer<Self, $type, ordering::SeqCst, ordering::SeqCst>,
                    &Committer<Self, $type, ordering::SeqCst, ordering::None>
                >,
            )
            {
                self.0.compare_exchange_weak(current, new, OrderingTy::SeqCst, OrderingTy::SeqCst)
            }

            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::load`].")]
            #[doc = ""]
            #[doc = "The load is always sequentially consistent."]
            #[requires(forall<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                !c.shot_store() ==> c.ward() == *self ==> f.precondition((c,))
            )]
            #[ensures(exists<c: &Committer<Self, $type, ordering::SeqCst, ordering::None>>
                !c.shot_store() && c.ward() == *self && c.val_load() == result && f.postcondition_once((c,), ())
            )]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn load<F>(&self, f: Ghost<F>) -> $type
            where
                F: FnGhost + FnOnce(&Committer<Self, $type, ordering::SeqCst, ordering::None>),
            {
                self.0.load(OrderingTy::SeqCst)
            }

            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::store`].")]
            #[doc = ""]
            #[doc = "The store is always sequentially consistent."]
            #[requires(forall<c: &mut Committer<Self, $type, ordering::None, ordering::SeqCst>>
                !c.shot_store() ==> c.ward() == *self ==> c.val_store() == val ==>
                f.precondition((c,)) && (f.postcondition_once((c,), ()) ==> (^c).shot_store())
            )]
            #[ensures(exists<c: &mut Committer<Self, $type, ordering::None, ordering::SeqCst>>
                !c.shot_store() && c.ward() == *self && c.val_store() == val &&
                f.postcondition_once((c,), ())
            )]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn store<F>(&self, val: $type, f: Ghost<F>)
            where
                F: FnGhost + FnOnce(&mut Committer<Self, $type, ordering::None, ordering::SeqCst>),
            {
                self.0.store(val, OrderingTy::SeqCst)
            }
        }

    )* };
}

macro_rules! impl_atomic_int {
    ($( ($int_type:ty, $atomic_type:ident) ),+) => { $(

        impl_atomic!(($int_type, $atomic_type));

        impl $atomic_type {
            #[doc = concat!("Wrapper for [`std::sync::atomic::", stringify!($atomic_type), "::fetch_add`].")]
            #[doc = ""]
            #[doc = "The load and the store are always sequentially consistent."]
            #[requires(forall<c: &mut Committer<Self, $int_type, ordering::SeqCst, ordering::SeqCst>>
                !c.shot_store() ==> c.ward() == *self ==> c.val_store() == val + c.val_load() ==>
                f.precondition((c,)) && (f.postcondition_once((c,), ()) ==> (^c).shot_store())
            )]
            #[ensures(exists<c: &mut Committer<Self, $int_type, ordering::SeqCst, ordering::SeqCst>>
                !c.shot_store() && c.ward() == *self && c.val_store() == val + c.val_load() &&
                c.val_load() == result && f.postcondition_once((c,), ())
            )]
            #[inline(always)]
            #[trusted]
            #[allow(unused_variables)]
            pub fn fetch_add<F>(&self, val: $int_type, f: Ghost<F>) -> $int_type
            where
                F: FnGhost + FnOnce(&mut Committer<Self, $int_type, ordering::SeqCst, ordering::SeqCst>),
            {
                self.0.fetch_add(val, OrderingTy::SeqCst)
            }
        }

    )* };
}

impl_atomic! {
    (bool, AtomicBool),
    (*mut T, AtomicPtr<T>)
}

impl_atomic_int! {
    (i8, AtomicI8),
    (u8, AtomicU8),
    (i16, AtomicI16),
    (u16, AtomicU16),
    (i32, AtomicI32),
    (u32, AtomicU32),
    (i64, AtomicI64),
    (u64, AtomicU64),
    (isize, AtomicIsize),
    (usize, AtomicUsize)
}
