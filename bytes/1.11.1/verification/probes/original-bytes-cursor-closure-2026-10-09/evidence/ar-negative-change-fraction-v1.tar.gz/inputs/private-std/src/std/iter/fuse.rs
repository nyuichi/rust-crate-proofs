use crate::{
    prelude::*,
    std::iter::{ExactSizeIteratorSpec, Fuse},
};
use core::iter::FusedIterator;

impl<I: Iterator> View for Fuse<I> {
    type ViewTy = Option<I>;

    #[logic(opaque)]
    fn view(self) -> Option<I> {
        dead
    }
}

impl<I: Iterator> Invariant for Fuse<I> {
    #[logic(prophetic, open, inline)]
    fn invariant(self) -> bool {
        inv(self.view())
    }
}

impl<I: IteratorSpec> IteratorSpec for Fuse<I> {
    #[logic(open, prophetic)]
    fn completed(&mut self) -> bool {
        pearlite! {
            (self@ == None || exists<it:&mut I> it.completed() && self@ == Some(*it)) &&
            (^self)@ == None
        }
    }

    #[logic(open, prophetic)]
    fn produces(self, prod: Seq<Self::Item>, other: Self) -> bool {
        pearlite! {
            match self@ {
                None => prod == Seq::empty() && other@ == self@,
                Some(i) => match other@ {
                    Some(i2) => i.produces(prod, i2),
                    None => false,
                },
            }
        }
    }

    #[logic(law)]
    #[ensures(self.produces(Seq::empty(), self))]
    fn produces_refl(self) {}

    #[logic(law)]
    #[requires(a.produces(ab, b))]
    #[requires(b.produces(bc, c))]
    #[ensures(a.produces(ab.concat(bc), c))]
    fn produces_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}
}

pub trait FusedIteratorSpec: FusedIterator + IteratorSpec {
    #[logic(law)]
    #[requires(self.completed())]
    #[requires((^self).produces(steps, next))]
    #[ensures(steps == Seq::empty())]
    fn is_fused(&mut self, steps: Seq<Self::Item>, next: Self);
}

impl<I: IteratorSpec> FusedIteratorSpec for Fuse<I> {
    #[logic(law)]
    #[requires(self.completed())]
    #[requires((^self).produces(steps, next))]
    #[ensures(steps == Seq::empty())]
    fn is_fused(&mut self, steps: Seq<Self::Item>, next: Self) {}
}

extern_spec! {
    impl<I: Iterator> Iterator for Fuse<I> {
        #[ensures(match self@ {
            Some(s) => I::size_hint.postcondition((&s,), result),
            None => result == (0usize, Some(0usize))
        })]
        fn size_hint(&self) -> (usize, Option<usize>);
    }
}

impl<I: ExactSizeIteratorSpec> ExactSizeIteratorSpec for Fuse<I> {
    #[logic(law)]
    #[requires(Self::size_hint.postcondition((self,), r))]
    #[ensures(r.1 == Some(r.0))]
    #[allow(unused_variables)]
    fn size_hint_exact(&self, r: (usize, Option<usize>)) {
        let _ = I::size_hint_exact;
    }
}
