use crate::{prelude::*, std::iter::ExactSizeIteratorSpec};
#[cfg(feature = "nightly")]
use core::iter::Step;
use core::ops::{Range, RangeInclusive};

#[cfg(feature = "nightly")]
impl<Idx: DeepModel<DeepModelTy = Int> + Step> IteratorSpec for Range<Idx> {
    #[logic(open, prophetic)]
    fn completed(&mut self) -> bool {
        pearlite! {
            resolve(self) && self.start.deep_model() >= self.end.deep_model()
        }
    }

    #[logic(open)]
    fn produces(self, visited: Seq<Self::Item>, o: Self) -> bool {
        pearlite! {
            self.end == o.end && self.start.deep_model() <= o.start.deep_model()
            && (visited.len() > 0 ==> o.start.deep_model() <= o.end.deep_model())
            && visited.len() == o.start.deep_model() - self.start.deep_model()
            && forall<i> 0 <= i && i < visited.len() ==>
                visited[i].deep_model() == self.start.deep_model() + i
        }
    }

    #[logic(law)]
    #[ensures(self.produces(Seq::empty(), self))]
    fn produces_refl(self) {}

    #[logic(law)]
    #[requires(a.produces(ab, b))]
    #[requires(b.produces(bc, c))]
    #[ensures(a.produces(ab.concat(bc), c))]
    fn produces_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}
}

extern_spec! {
    impl<Idx: DeepModel<DeepModelTy = Int> + Step> Iterator for Range<Idx> {
        #[ensures(self.start.deep_model() >= self.end.deep_model() ==>
            result == (0usize, Some(0usize)))]
        #[ensures({
            let s = self.end.deep_model() - self.start.deep_model();
            s >= 0 && s <= usize::MAX@ ==>
            result.0@ == s && result.1 == Some(result.0)
        })]
        #[ensures(self.end.deep_model() - self.start.deep_model() > usize::MAX@ ==>
            result == (usize::MAX, None))]
        fn size_hint(&self) -> (usize, Option<usize>);
    }
}

macro_rules! impl_exact_size_range {
    ($($t:ty)*) => ($(
        impl ExactSizeIteratorSpec for Range<$t> {
            #[logic(law)]
            #[requires(Self::size_hint.postcondition((self,), r))]
            #[ensures(r.1 == Some(r.0))]
            #[allow(unused_variables)]
            fn size_hint_exact(&self, r: (usize, Option<usize>)) {}
        }
    )*)
}

impl_exact_size_range! { i8 u8 i16 u16 isize usize }

// Apparently, `ExactSizeIterator` is not implemented for `Range<i64>` and `Range<u64>` even
// on 64-bit platforms.
#[cfg(any(target_pointer_width = "32", target_pointer_width = "64"))]
impl_exact_size_range! { i32 u32 }

#[cfg(feature = "nightly")]
impl<Idx: DeepModel<DeepModelTy = Int> + Step> DoubleEndedIteratorSpec for Range<Idx> {
    #[logic(open)]
    fn produces_back(self, visited: Seq<Self::Item>, o: Self) -> bool {
        pearlite! {
            self.start == o.start && self.end.deep_model() >= o.end.deep_model()
            && (visited.len() > 0 ==> o.end.deep_model() >= o.start.deep_model())
            && visited.len() == self.end.deep_model() - o.end.deep_model()
            && forall<i> 0 <= i && i < visited.len() ==>
                visited[i].deep_model() == self.end.deep_model() - i - 1
        }
    }

    #[logic(open, prophetic)]
    fn completed_back(&mut self) -> bool {
        self.completed()
    }

    #[logic(law)]
    #[ensures(self.produces_back(Seq::empty(), self))]
    fn produces_back_refl(self) {}

    #[logic(law)]
    #[requires(a.produces_back(ab, b))]
    #[requires(b.produces_back(bc, c))]
    #[ensures(a.produces_back(ab.concat(bc), c))]
    fn produces_back_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}

    #[logic(law)]
    #[requires(Self::size_hint.postcondition((self,), r))]
    #[ensures(forall<s: Seq<Self::Item>, i: &mut Self>
        self.produces_back(s, *i) && i.completed_back() ==> r.0@ <= s.len())]
    #[ensures(match r.1 {
        Some(r) => {
            forall<s: Seq<Self::Item>, i: Self> self.produces_back(s, i) ==> s.len() <= r@
        }
        None => true
    })]
    fn size_hint_back_spec(&self, r: (usize, Option<usize>)) {}
}

#[logic(open)]
#[ensures(r.is_empty_log() == (result == 0))]
pub fn range_inclusive_len<Idx: DeepModel<DeepModelTy = Int>>(r: RangeInclusive<Idx>) -> Int {
    if r.is_empty_log() { 0 } else { r.end_log().deep_model() - r.start_log().deep_model() + 1 }
}

#[cfg(feature = "nightly")]
impl<Idx: DeepModel<DeepModelTy = Int> + Step> IteratorSpec for RangeInclusive<Idx> {
    #[logic(open, prophetic)]
    fn completed(&mut self) -> bool {
        pearlite! {
            self.is_empty_log() && (^self).is_empty_log()
        }
    }

    #[logic(open)]
    fn produces(self, visited: Seq<Self::Item>, o: Self) -> bool {
        pearlite! {
            visited.len() == range_inclusive_len(self) - range_inclusive_len(o) &&
            (self.is_empty_log() ==> o.is_empty_log()) &&
            (o.is_empty_log() || self.end_log() == o.end_log()) &&
            forall<i> 0 <= i && i < visited.len() ==>
                visited[i].deep_model() == self.start_log().deep_model() + i
        }
    }

    #[logic(law)]
    #[ensures(self.produces(Seq::empty(), self))]
    fn produces_refl(self) {}

    #[logic(law)]
    #[requires(a.produces(ab, b))]
    #[requires(b.produces(bc, c))]
    #[ensures(a.produces(ab.concat(bc), c))]
    fn produces_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}
}

extern_spec! {
    impl<Idx: DeepModel<DeepModelTy = Int> + Step> Iterator for RangeInclusive<Idx> {
        #[ensures({
            let s = range_inclusive_len(*self);
            s <= usize::MAX@ ==> result.0@ == s && result.1 == Some(result.0)
        })]
        #[ensures(range_inclusive_len(*self) > usize::MAX@ ==>
            result == (usize::MAX, None))]
        fn size_hint(&self) -> (usize, Option<usize>);
    }
}

macro_rules! impl_exact_size_range_inclusive {
    ($($t:ty)*) => ($(
        impl ExactSizeIteratorSpec for RangeInclusive<$t> {
            #[logic(law)]
            #[requires(Self::size_hint.postcondition((self,), r))]
            #[ensures(r.1 == Some(r.0))]
            #[allow(unused_variables)]
            fn size_hint_exact(&self, r: (usize, Option<usize>)) {}
        }
    )*)
}

impl_exact_size_range_inclusive! { i8 u8 }

#[cfg(any(target_pointer_width = "32", target_pointer_width = "64"))]
impl_exact_size_range_inclusive! { i16 u16 }

#[cfg(feature = "nightly")]
impl<Idx: DeepModel<DeepModelTy = Int> + Step> DoubleEndedIteratorSpec for RangeInclusive<Idx> {
    #[logic(open)]
    fn produces_back(self, visited: Seq<Self::Item>, o: Self) -> bool {
        pearlite! {
            visited.len() == range_inclusive_len(self) - range_inclusive_len(o) &&
            (self.is_empty_log() ==> o.is_empty_log()) &&
            (o.is_empty_log() || self.start_log() == o.start_log()) &&
            forall<i> 0 <= i && i < visited.len() ==>
                visited[i].deep_model() == self.end_log().deep_model() - i
        }
    }

    #[logic(open, prophetic)]
    fn completed_back(&mut self) -> bool {
        self.completed()
    }

    #[logic(law)]
    #[ensures(self.produces_back(Seq::empty(), self))]
    fn produces_back_refl(self) {}

    #[logic(law)]
    #[requires(a.produces_back(ab, b))]
    #[requires(b.produces_back(bc, c))]
    #[ensures(a.produces_back(ab.concat(bc), c))]
    fn produces_back_trans(a: Self, ab: Seq<Self::Item>, b: Self, bc: Seq<Self::Item>, c: Self) {}

    #[logic(law)]
    #[requires(Self::size_hint.postcondition((self,), r))]
    #[ensures(forall<s: Seq<Self::Item>, i: &mut Self>
        self.produces_back(s, *i) && i.completed_back() ==> r.0@ <= s.len())]
    #[ensures(match r.1 {
        Some(r) => {
            forall<s: Seq<Self::Item>, i: Self> self.produces_back(s, i) ==> s.len() <= r@
        }
        None => true
    })]
    fn size_hint_back_spec(&self, r: (usize, Option<usize>)) {}
}

/// Dummy impls that don't use the unstable trait Step
#[cfg(not(feature = "nightly"))]
macro_rules! impl_range {
    ( $( $ty:tt ),+ ) => {
        $(
            impl IteratorSpec for Range<$ty> {}
            impl IteratorSpec for RangeInclusive<$ty> {}
            impl DoubleEndedIteratorSpec for Range<$ty> {}
            impl DoubleEndedIteratorSpec for RangeInclusive<$ty> {}
        )+
    };
}

#[cfg(not(feature = "nightly"))]
impl_range! { char, i8, i16, i32, i64, i128, isize, u8, u16, u32, u64, u128, usize }
