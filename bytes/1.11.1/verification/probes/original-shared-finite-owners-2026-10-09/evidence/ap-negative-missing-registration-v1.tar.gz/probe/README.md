# AP: runtime-variable finite owners in actual Vec loops

Development after audited AO commit 48cf2a0e365dd00b20bf88b93bec8d75a7dde5ca.
The original bytes 1.11.1 full architecture remains **NOT ADMITTED**.

The caller supplies a runtime count. After the original Box-backed owner
retires, the surviving child uses actual Shared-vtable Clone in a Vec push
loop. A pop loop lexically retires each peer; the survivor reads, saves its
return and finally retires. The Vec destructor executes with zero elements;
its own container storage remains distinct from Bytes payload/control receipts.

The new proof premise is an inductive exact inventory over the actual Vec and
affine cursor, not fixed-count unrolling or a quota. The real guarded refcount
abort remains native. Only normal completion is claimed; success for every
count, allocation failure, unwind, concurrency and arbitrary escaping owners
remain open. Source/MIR loop and destructor correspondence remains an explicit
generic compiler/erasure boundary pending replacement by verified lowering.

This file records the intended experiment, not a passing gate. Publication
requires all translated targets, feature-free source/native/compiled-input
correspondence, decisive semantic/frontend/structural controls and independent
immutable archive reconstruction. Earlier source/proof evidence is unchanged.
After an audited published increment, ask Astra 「次何するのがいい？」 and
execute the next recommendation until full original verification is complete.
