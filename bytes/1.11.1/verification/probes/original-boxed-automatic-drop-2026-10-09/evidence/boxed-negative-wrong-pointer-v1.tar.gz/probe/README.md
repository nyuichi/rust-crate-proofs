# Unrestricted boxed construction/read/normal automatic Drop — 2026-10-09

D2026-10-09-AK, directed by Astra after independently audited AJ. Native witness
has no nonempty/parity precondition. Target: Static empty and both unpromoted
PromotableRaw pointer-tag branches, exact read and one terminal automatic Drop.
Clone/promotion, unwind, Shared automatic Drop generalization and whole-crate
admission remain outside this increment. Development in progress; no admission.
