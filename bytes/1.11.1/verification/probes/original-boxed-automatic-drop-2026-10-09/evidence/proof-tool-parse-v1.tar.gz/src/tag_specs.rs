//! Generic exact provenance-preserving low-bit tag roundtrip and equal-pointer distance.
//! Tag clearing is production ptr_map(ptr, |a| a & !1), which preserves provenance.
//! Eq-pointer offset_from is zero without inventing allocation ownership.
//! Std analogue: raw pointer map_addr/offset_from interpretation; removal path is
//! supported exact-pointer contracts. Numerical address equality is insufficient.
use creusot_std::prelude::*;
use crate::raw_vec::BoundPtr;
#[logic(opaque)] pub fn tagged_data(pointer:*mut u8)->*mut () {dead}
#[trusted]
#[requires(base.inner_logic().raw_pointer().addr_logic() & 1usize == 0usize)]
#[requires(tagged == tagged_data(base.inner_logic().raw_pointer()))]
#[ensures(result == base.inner_logic().raw_pointer())]
pub fn clear_low_bit(tagged:*mut (),base:Ghost<&BoundPtr>)->*mut u8 {
    #[cfg(creusot)] {unreachable!("generic exact-provenance tag roundtrip")}
    #[cfg(not(creusot))] { tagged.cast::<u8>().map_addr(|a|a & !1) }
}
#[trusted]
#[requires(pointer == base as *const u8)]
#[ensures(result == 0isize)]
pub unsafe fn equal_pointer_distance(pointer:*const u8,base:*mut u8)->isize {
    unsafe { pointer.offset_from(base) }
}
