#[ensures(result@ == input@)]
pub(crate) fn boxed_read_then_drop(input:Box<[u8]>)->Vec<u8> {
    let bytes=original_bytes_from_box(input);
    let metadata=snapshot!(bytes.boxed_metadata());
    let borrowed=original_bytes_as_slice(&bytes);
    let mut completion=ghost! {None::<BoxedCompletion>};
    bytes_terminal_drop(bytes,completion.borrow_mut());
    let observed=borrowed.to_vec();
    let saved_return=observed;
    proof_assert!(completion.inner_logic() != None && completion.inner_logic().unwrap_logic().valid(*metadata));
    saved_return
}
