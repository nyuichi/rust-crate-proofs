#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-unsplit-mixed-cb6949de922be38d/out/scalable_tickets.rs"]
mod scalable_tickets;
