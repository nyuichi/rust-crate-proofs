use alloc::{vec::Vec,boxed::Box};
use core::mem::{self,ManuallyDrop,MaybeUninit};
use core::ptr::{self,NonNull};
use core::cmp;
use core::sync::atomic::{AtomicUsize,Ordering};
use creusot_std::prelude::*;
use crate::capacity_ops::{original_capacity_to_repr,MAX_VEC_POS};
// BEGIN EXACT RELEASE_UNIQUE_STORAGE
// SAFETY: ptr is a handle into the original global byte allocation, offset
// is its exact displacement, and full allocation ownership is transferred.
#[cfg_attr(creusot, requires(ptr.invariant()))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().0.invariant() && capabilities.inner_logic().1.invariant()))]
#[cfg_attr(creusot, requires(ptr@ == Some((capabilities.inner_logic().0.namespace(), capacity@ + offset@, offset@))))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().0.capacity() == capacity@ + offset@))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().1.capacity() == capacity@ + offset@))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().1.namespace() == capabilities.inner_logic().0.namespace()))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().1.resource_id() == capabilities.inner_logic().0.namespace()))]
#[cfg_attr(creusot, requires(capabilities.inner_logic().1.lo() == 0 && capabilities.inner_logic().1.hi() == capacity@ + offset@))]
unsafe fn release_unique_storage(
    #[cfg(not(any(creusot, bytes_proof_probe)))] ptr: NonNull<u8>,
    #[cfg(any(creusot, bytes_proof_probe))] ptr: crate::ownership_proof::raw_vec::BoundPtr,
    capacity: usize, offset: usize,
    #[cfg(any(creusot, bytes_proof_probe))] capabilities: Ghost<(crate::ownership_proof::raw_vec::Recovery, crate::ownership_proof::raw_vec::PhysicalRegion)>,
) {
    let original_capacity = capacity + offset;
    #[cfg(not(any(creusot, bytes_proof_probe)))]
    unsafe { crate::allocation_ops::deallocate_u8(ptr.as_ptr().sub(offset), original_capacity); }
    #[cfg(any(creusot, bytes_proof_probe))]
    {
        let base = ptr.retreat_within(offset);
        unsafe { crate::ownership_proof::raw_vec::deallocate_bound_vec(base, original_capacity, capabilities); }
    }
}
pub struct BytesMut {
    #[cfg(not(any(creusot, bytes_proof_probe)))]
    ptr: NonNull<u8>,
    #[cfg(any(creusot, bytes_proof_probe))]
    ptr: crate::ownership_proof::raw_vec::BoundPtr,
    len: usize,
    cap: usize,
    data: *mut Shared,
    // Present only in proof builds. Other construction paths remain outside
    // the offset-zero unique ownership gate until their protocols are proved.
    #[cfg(any(creusot, bytes_proof_probe))]
    unique_at_zero: Ghost<Option<(
        crate::ownership_proof::raw_vec::Recovery,
        crate::ownership_proof::raw_vec::PhysicalRegion,
    )>>,
    #[cfg(any(creusot, bytes_proof_probe))]
    pending_control: Ghost<Option<sequential_shared_control::PendingControl>>,
    #[cfg(any(creusot, bytes_proof_probe))]
    shared_registration: Ghost<Option<sequential_shared_control::HandleRegistration>>,
    #[cfg(any(creusot, bytes_proof_probe))]
    shared_context: Ghost<Option<sequential_shared_control::ControlContext>>,
}
struct Shared {
    buffer: SharedBuffer,
    original_capacity_repr: usize,
    #[cfg(not(any(creusot, bytes_proof_probe)))]
    ref_count: AtomicUsize,
    #[cfg(any(creusot, bytes_proof_probe))]
    ref_count: crate::ownership_proof::sequential_counter::SequentialCounter,
}
struct SharedBuffer {
    #[cfg(not(any(creusot, bytes_proof_probe)))]
    base: NonNull<u8>,
    #[cfg(any(creusot, bytes_proof_probe))]
    base: crate::ownership_proof::raw_vec::BoundPtr,
    capacity: usize,
}
// BEGIN EXACT RELEASE_SHARED
#[cfg_attr(bytes_proof_repeated_split, requires(registration.inner_logic().control == control && registration.inner_logic().matches(*context.inner_logic())))]
#[cfg_attr(bytes_proof_repeated_split, ensures((^context.inner_logic()).valid(control)))]
#[cfg_attr(bytes_proof_repeated_split, ensures(result == !(^context.inner_logic()).active()))]
#[cfg_attr(bytes_proof_repeated_split, ensures(result == ((*context.inner_logic().status.pending).len() == 1)))]
#[cfg_attr(bytes_proof_repeated_split, ensures(result == (* (^context.inner_logic()).status.pending).is_empty()))]
#[cfg_attr(bytes_proof_repeated_split, ensures((^context.inner_logic()).status.capacity == context.inner_logic().status.capacity &&
    (^context.inner_logic()).status.allocation == context.inner_logic().status.allocation &&
    (^context.inner_logic()).status.registration == context.inner_logic().status.registration))]
#[cfg_attr(bytes_proof_repeated_split, ensures(* (^context.inner_logic()).status.pending ==
    (*context.inner_logic().status.pending).remove(registration.inner_logic().packet.0.logical_id())))]
#[cfg_attr(bytes_proof_repeated_split, ensures((* (^context.inner_logic()).status.pending).len() + 1 == (*context.inner_logic().status.pending).len()))]
#[cfg_attr(bytes_proof_repeated_split, ensures(forall<other: sequential_shared_control::HandleRegistration> other.matches(*context.inner_logic()) &&
    other.packet.0.logical_id() != registration.inner_logic().packet.0.logical_id() ==> other.matches(^context.inner_logic())))]
#[cfg_attr(bytes_proof_repeated_split, requires(control.pointer == ptr))]
unsafe fn release_shared(ptr: *mut Shared,
    #[cfg(bytes_proof_repeated_split)] control: sequential_shared_control::ControlPtr,
    #[cfg(bytes_proof_repeated_split)] mut context: Ghost<&mut sequential_shared_control::ControlContext>,
    #[cfg(bytes_proof_repeated_split)] registration: Ghost<sequential_shared_control::HandleRegistration>,
) -> bool {
    #[cfg(bytes_proof_repeated_split)]
    { ghost! { crate::ownership_proof::scalable_tickets::pending_cardinality(snapshot!(*context.status.pending)); }; }
    #[cfg(not(bytes_proof_repeated_split))]
    let old = (*ptr).ref_count.fetch_sub(1, Ordering::Release);
    #[cfg(bytes_proof_repeated_split)]
    let old = {
        let (permission, counter) = ghost! {
            let context = &mut **context;
            (&**context.owner.as_ref().unwrap(), context.counter.as_mut().unwrap())
        }.split();
        let shared = unsafe { creusot_std::ghost::perm::Perm::as_ref(ptr, permission) };
        shared.ref_count.fetch_sub_release(1, counter)
    };
    #[cfg(bytes_proof_repeated_split)]
    {
        crate::ownership_proof::scalable_tickets::retire(ghost! { context.registry.as_mut().unwrap() }, ghost! { registration.into_inner().packet });
        ghost! { context.status = snapshot!(context.registry.unwrap_logic().public()); };
    }
    if old != 1 { return false; }
    // Only the final owner proceeds to acquire and full-allocation cleanup.
    // The proof adapter is exclusive/sequential: it does not prove cross-thread
    // visibility or release-sequence synchronization from this load alone.
    #[cfg(not(bytes_proof_repeated_split))]
    (*ptr).ref_count.load(Ordering::Acquire);
    #[cfg(bytes_proof_repeated_split)]
    {
        ghost! { crate::ownership_proof::scalable_tickets::pending_cardinality(snapshot!(*context.status.pending)); };
        let permission = ghost! { &**context.owner.as_ref().unwrap() };
        let shared = unsafe { creusot_std::ghost::perm::Perm::as_ref(ptr, permission) };
        let observed = shared.ref_count.load_acquire(ghost! { context.counter.as_ref().unwrap() });
        assert!(observed == 0);
    }
    #[cfg(bytes_proof_repeated_split)]
    let full = crate::ownership_proof::scalable_tickets::finish(ghost! { context.registry.take().unwrap() });
    let (base, capacity) = {
        #[cfg(not(bytes_proof_repeated_split))]
        let shared = &mut *ptr;
        #[cfg(bytes_proof_repeated_split)]
        let shared = unsafe { creusot_std::ghost::perm::Perm::as_mut(ptr, ghost! { &mut **context.owner.as_mut().unwrap() }) };
        let base = shared.buffer.base;
        let capacity = shared.buffer.capacity;
        // Disarm before freeing the buffer; subsequent control destruction has
        // no buffer allocation left to release through its automatic Drop.
        #[cfg(not(bytes_proof_repeated_split))]
        { shared.buffer.base = shared_buffer_unbound(NonNull::dangling()); }
        #[cfg(bytes_proof_repeated_split)]
        { shared.buffer.base = crate::ownership_proof::raw_vec::BoundPtr::unbound(NonNull::dangling()); }
        shared.buffer.capacity = 0;
        (base, capacity)
    };
    #[cfg(not(bytes_proof_repeated_split))]
    unsafe { crate::allocation_ops::deallocate_u8(base.as_ptr(), capacity); }
    #[cfg(bytes_proof_repeated_split)]
    unsafe { crate::ownership_proof::raw_vec::deallocate_bound_vec(base, capacity, full); }
    #[cfg(not(bytes_proof_repeated_split))]
    drop(Box::from_raw(ptr));
    #[cfg(bytes_proof_repeated_split)]
    {
        let owner = ghost! { let _counter = context.counter.take().unwrap(); context.owner.take().unwrap() };
        unsafe { creusot_std::ghost::perm::Perm::drop(ptr, owner); }
    }
    true
}
#[inline]
#[cfg_attr(creusot, ensures(result.addr_logic() == addr))]
fn invalid_ptr<T>(addr: usize) -> *mut T {
    // This null-derived pointer stores integer metadata only. It carries no
    // allocation permission and must not be used as a dereferenceable pointer.
    let ptr = crate::provenance_specs::metadata_pointer(addr);
    debug_assert_eq!(crate::provenance_specs::pointer_addr(ptr), addr);
    ptr.cast::<T>()
}
// BEGIN EXACT INCREMENT_SHARED
#[cfg_attr(all(creusot, bytes_proof_repeated_split), requires(ptr == control.pointer))]
#[cfg_attr(all(creusot, bytes_proof_repeated_split), requires(context.inner_logic().valid(control) && context.inner_logic().active()))]
#[cfg_attr(all(creusot, bytes_proof_repeated_split), requires((*context.inner_logic().status.pending).len() < isize::MAX@))]
#[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^context.inner_logic()).valid_count(control, 1) && (^context.inner_logic()).active()))]
#[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^context.inner_logic()).status == context.inner_logic().status))]
unsafe fn increment_shared(ptr: *mut Shared,
    #[cfg(bytes_proof_repeated_split)] control: sequential_shared_control::ControlPtr,
    #[cfg(bytes_proof_repeated_split)] context: Ghost<&mut sequential_shared_control::ControlContext>,
) {
    #[cfg(not(bytes_proof_repeated_split))]
    let old_size = (*ptr).ref_count.fetch_add(1, Ordering::Relaxed);
    #[cfg(bytes_proof_repeated_split)]
    let old_size = sequential_shared_control::increment(control, context);
    if old_size > isize::MAX as usize {
        crate::abort();
    }
}
const KIND_VEC: usize = 0b1;
const KIND_ARC: usize = 0b0;
const KIND_MASK: usize = 0b1;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/carrier_protocol.rs"]
pub(crate) mod sequential_shared_control;
impl BytesMut {
    // BEGIN EXACT GET_VEC_POS
    #[inline]
    #[cfg_attr(creusot, requires(self.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(creusot, ensures(result == self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET))]
    unsafe fn get_vec_pos(&self) -> usize {
        debug_assert_eq!(self.kind(), KIND_VEC);

        crate::capacity_ops::vec_pos_from_data(
            crate::provenance_specs::pointer_addr(self.data),
        )
    }
    // BEGIN EXACT SET_VEC_POS
    #[inline]
    #[cfg_attr(creusot, requires(self.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(creusot, requires(pos <= crate::capacity_ops::MAX_VEC_POS))]
    #[cfg_attr(creusot, ensures((^self).data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == pos))]
    #[cfg_attr(creusot, ensures((^self).data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(creusot, ensures((^self).data.addr_logic() & crate::capacity_ops::NOT_VEC_POS_MASK == self.data.addr_logic() & crate::capacity_ops::NOT_VEC_POS_MASK))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero == self.unique_at_zero && (^self).pending_control == self.pending_control && (^self).shared_registration == self.shared_registration && (^self).shared_context == self.shared_context))]
    unsafe fn set_vec_pos(&mut self, pos: usize) {
        debug_assert_eq!(self.kind(), KIND_VEC);
        debug_assert!(pos <= MAX_VEC_POS);

        self.data = invalid_ptr(crate::capacity_ops::set_vec_pos_in_data(
            crate::provenance_specs::pointer_addr(self.data),
            pos,
        ));
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    pub(crate) fn proof_unique_at_zero_owned(self) -> bool {
        pearlite! {
            self.data.addr_logic() & KIND_MASK == KIND_VEC &&
            self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == 0usize &&
            self.pending_control.inner_logic() == None &&
            self.shared_registration.inner_logic() == None &&
            self.shared_context.inner_logic() == None &&
            match self.unique_at_zero.inner_logic() {
                None => false,
                Some((recovery, region)) =>
                    self.ptr.invariant() &&
                    self.ptr@ == Some((recovery.namespace(), self.cap@, 0int)) &&
                    recovery.invariant() && region.invariant() &&
                    recovery.capacity() == self.cap@ &&
                    region.capacity() == self.cap@ &&
                    region.namespace() == recovery.namespace() &&
                    region.resource_id() == recovery.namespace() &&
                    region.lo() == 0 && region.hi() == self.cap@ &&
                    self.len@ <= self.cap@
            }
        }
    }
    // BEGIN EXACT AS_SLICE
    #[inline]
    #[cfg_attr(creusot, requires(self.proof_initialized()))]
    #[cfg_attr(creusot, ensures(result@.len() == self.len@))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < self.len@ ==>
        self.proof_view_slot(index) == Some(Some(result@[index]))))]
    #[cfg_attr(creusot, check(ghost))]
    fn as_slice(&self) -> &[u8] {
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        { unsafe { slice::from_raw_parts(self.ptr.as_ptr(), self.len) } }
        #[cfg(any(creusot, bytes_proof_probe))]
        {
            #[cfg(bytes_proof_valid_handle)]
            if self.len == 0 {
                return unsafe { crate::ownership_proof::raw_vec::borrow_empty_bound(&self.ptr) };
            }
            if self.kind() == KIND_VEC {
                return unsafe { crate::ownership_proof::raw_vec::borrow_bound(
                    &self.ptr, self.len, ghost! { &self.unique_at_zero.as_ref().unwrap().1 }) };
            }
            let (packet, status, left) = ghost! {
                let registration = self.shared_registration.as_ref().unwrap();
                (&registration.packet, registration.status, registration.left)
            }.split();
            unsafe { crate::ownership_proof::shared_protocol::borrow_packet(&self.ptr, self.len, packet, status, left) }
        }
    }
    // BEGIN EXACT AS_SLICE_MUT
    #[inline]
    #[cfg_attr(creusot, requires(self.proof_initialized()))]
    #[cfg_attr(creusot, ensures(result@.len() == self.len@ && (^result)@.len() == self.len@))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < self.len@ ==>
        self.proof_view_slot(index) == Some(Some(result@[index]))))]
    #[cfg_attr(creusot, ensures((^self).proof_owned_valid()))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < (^self).len@ ==>
        crate::ownership_proof::raw_vec::slot_known((^self).proof_view_slot(index))))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures(((^self).unique_at_zero.inner_logic() == None) == (self.unique_at_zero.inner_logic() == None)))]
    #[cfg_attr(creusot, ensures(self.unique_at_zero.inner_logic() != None ==> (^self).unique_at_zero.inner_logic().unwrap_logic().0 == self.unique_at_zero.inner_logic().unwrap_logic().0))]
    #[cfg_attr(creusot, ensures(((^self).shared_registration.inner_logic() == None) == (self.shared_registration.inner_logic() == None)))]
    #[cfg_attr(creusot, ensures((^self).pending_control == self.pending_control && (^self).shared_context == self.shared_context))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().control == self.shared_registration.inner_logic().unwrap_logic().control))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().status == self.shared_registration.inner_logic().unwrap_logic().status))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().left == self.shared_registration.inner_logic().unwrap_logic().left))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < self.len@ ==>
        (^self).proof_view_slot(index) == Some(Some((^result)@[index]))))]
    #[cfg_attr(creusot, ensures(forall<index: Int> !(0 <= index && index < self.len@) ==>
        (^self).proof_view_slot(index) == self.proof_view_slot(index)))]
    #[cfg_attr(creusot, ensures(forall<index: Int>
        !(self.ptr@.unwrap_logic().2 <= index && index < self.ptr@.unwrap_logic().2 + self.len@) ==>
            (^self).proof_owned_slot(index) == self.proof_owned_slot(index)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(self.shared_registration.inner_logic() != None ==>
        (^self).shared_registration.inner_logic().unwrap_logic().packet.0 == self.shared_registration.inner_logic().unwrap_logic().packet.0 &&
        (^self).shared_registration.inner_logic().unwrap_logic().packet.1.lo() == self.shared_registration.inner_logic().unwrap_logic().packet.1.lo() &&
        (^self).shared_registration.inner_logic().unwrap_logic().packet.1.hi() == self.shared_registration.inner_logic().unwrap_logic().packet.1.hi()))]
    fn as_slice_mut(&mut self) -> &mut [u8] {
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        { unsafe { slice::from_raw_parts_mut(self.ptr.as_ptr(), self.len) } }
        #[cfg(any(creusot, bytes_proof_probe))]
        {
            #[cfg(bytes_proof_valid_handle)]
            if self.len == 0 {
                return unsafe { crate::ownership_proof::raw_vec::borrow_empty_bound_mut(&self.ptr) };
            }
            if self.kind() == KIND_VEC {
                return unsafe { crate::ownership_proof::raw_vec::borrow_bound_mut(
                    &self.ptr, self.len, ghost! { &mut self.unique_at_zero.as_mut().unwrap().1 }) };
            }
            let (packet, status, left) = ghost! {
                let registration = self.shared_registration.as_mut().unwrap();
                (&mut registration.packet, registration.status, registration.left)
            }.split();
            unsafe { crate::ownership_proof::shared_protocol::borrow_packet_mut(&self.ptr, self.len, packet, status, left) }
        }
    }
    #[inline]
    #[cfg_attr(creusot, ensures(result.proof_unique_at_zero_valid()))]
    #[cfg_attr(creusot, ensures(result.len@ == vec@.len()))]
    #[cfg_attr(creusot, ensures(result.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(creusot, ensures(result.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == 0usize))]
    #[cfg_attr(creusot, ensures(
        ((result.data.addr_logic() & crate::capacity_ops::ORIGINAL_CAPACITY_MASK)
            >> crate::capacity_ops::ORIGINAL_CAPACITY_OFFSET)@
            == crate::capacity_ops::original_capacity_class_logic(result.cap)
    ))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < vec@.len() ==>
        result.proof_unique_slot(index) == Some(Some(vec@[index]))))]
    #[cfg_attr(creusot, ensures(forall<index: Int> vec@.len() <= index && index < result.cap@ ==>
        result.proof_unique_slot(index) == Some(None)))]
    pub(crate) fn from_vec(vec: Vec<u8>) -> BytesMut {
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        let (ptr, len, cap) = {
            let mut vec = ManuallyDrop::new(vec);
            (vptr(vec.as_mut_ptr()), vec.len(), vec.capacity())
        };
        #[cfg(any(creusot, bytes_proof_probe))]
        let (ptr, len, cap, capabilities) =
            crate::ownership_proof::bound_ptr::detach_bound_vec(vec);

        let original_capacity_repr = original_capacity_to_repr(cap);
        let data = crate::capacity_ops::pack_vec_metadata(original_capacity_repr);

        BytesMut {
            ptr,
            len,
            cap,
            data: invalid_ptr(data),
            #[cfg(any(creusot, bytes_proof_probe))]
            unique_at_zero: ghost! { Some(capabilities.into_inner()) },
            #[cfg(any(creusot, bytes_proof_probe))]
            pending_control: ghost! { None },
            #[cfg(any(creusot, bytes_proof_probe))]
            shared_registration: ghost! { None },
            #[cfg(any(creusot, bytes_proof_probe))]
            shared_context: ghost! { None },
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    pub(crate) fn proof_unique_at_zero_valid(self) -> bool {
        pearlite! {
            self.proof_unique_at_zero_owned() &&
            forall<index: Int> 0 <= index && index < self.len@ ==>
                crate::ownership_proof::raw_vec::slot_known(self.proof_unique_slot(index))
        }
    }
    #[cfg(creusot)]
    #[logic]
    pub(crate) fn proof_unique_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! {
            match self.unique_at_zero.inner_logic() {
                None => None,
                Some((_, region)) => region.slot(index),
            }
        }
    }
    #[inline]
    #[cfg_attr(creusot, ensures(result == self.len))]
    pub fn len(&self) -> usize {
        self.len
    }
    #[inline]
    #[cfg_attr(creusot, ensures(result == self.cap))]
    pub fn capacity(&self) -> usize {
        self.cap
    }
    #[inline]
    #[cfg_attr(creusot, ensures(result == (self.data.addr_logic() & KIND_MASK)))]
    #[cfg_attr(creusot, check(ghost))]
    fn kind(&self) -> usize {
        crate::provenance_specs::pointer_addr(self.data) & KIND_MASK
    }
    // BEGIN EXACT RESERVE
    #[cfg_attr(creusot, requires(self.proof_initialized()))]
    #[cfg_attr(all(creusot, not(bytes_proof_unique_growth), not(bytes_proof_shared_reserve)), requires(additional@ <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, not(bytes_proof_unique_growth), not(bytes_proof_shared_reserve)), ensures(^self == *self))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth, not(bytes_proof_unique_reserve)), requires(additional@ <= self.cap@ - self.len@ ||
        (self.proof_unique_owned() && additional@ <= isize::MAX@ - self.ptr@.unwrap_logic().2 - self.len@ &&
         (additional@ > self.cap@ - self.len@ + self.ptr@.unwrap_logic().2 || self.ptr@.unwrap_logic().2 < self.len@))))]
    #[cfg_attr(all(creusot, bytes_proof_unique_reserve), requires(additional@ <= self.cap@ - self.len@ ||
        (self.proof_unique_owned() && additional@ <= isize::MAX@ - self.ptr@.unwrap_logic().2 - self.len@)))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth), ensures(additional@ <= self.cap@ - self.len@ ==> ^self == *self))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth), ensures((^self).proof_initialized() && (^self).len == self.len && (^self).cap >= self.cap))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth), ensures(additional@ <= (^self).cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth), ensures(self.proof_unique_owned() ==> (^self).proof_unique_owned()))]
    #[cfg_attr(all(creusot, bytes_proof_unique_growth), ensures(forall<index: Int> 0 <= index && index < self.len@ ==>
        (^self).proof_view_slot(index) == self.proof_view_slot(index)))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), requires(self.proof_registered_valid() && self.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), requires(*coordinator.inner_logic() != None && self.shared_registration.inner_logic().unwrap_logic().matches(coordinator.inner_logic().unwrap_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), requires(self.ptr@.unwrap_logic().2 + self.len@ + additional@ <= isize::MAX@))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((^self).proof_initialized() && (^self).len == self.len && (^self).cap@ >= self.len@ + additional@))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures(forall<i: Int> 0 <= i && i < self.len@ ==> (^self).proof_view_slot(i) == self.proof_view_slot(i)))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((^coordinator.inner_logic()) != None))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((^coordinator.inner_logic()).unwrap_logic().valid(self.shared_registration.inner_logic().unwrap_logic().control) && (^coordinator.inner_logic()).unwrap_logic().active()))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((^self).shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().matches((^coordinator.inner_logic()).unwrap_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((*coordinator.inner_logic().unwrap_logic().status.pending).len() >= 2 && additional@ > self.cap@ - self.len@ ==> (^self).proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((^self).shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((*coordinator.inner_logic().unwrap_logic().status.pending).len() == 1 ==>
        (^self).proof_registered_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures((*(^coordinator.inner_logic()).unwrap_logic().status.pending).len() ==
        (*coordinator.inner_logic().unwrap_logic().status.pending).len() -
        (if (*coordinator.inner_logic().unwrap_logic().status.pending).len() >= 2 && additional@ > self.cap@ - self.len@ { 1int } else { 0int })))]
    #[cfg_attr(all(creusot, bytes_proof_shared_reserve), ensures(forall<other: sequential_shared_control::HandleRegistration>
        other.matches(coordinator.inner_logic().unwrap_logic()) && other.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
        other.matches((^coordinator.inner_logic()).unwrap_logic())))]
    pub fn reserve(&mut self, additional: usize,
        #[cfg(bytes_proof_shared_reserve)] mut coordinator: Ghost<&mut Option<sequential_shared_control::ControlContext>>,
    ) {
        let len = self.len();
        let rem = self.capacity() - len;

        if additional <= rem {
            // The handle can already store at least `additional` more bytes, so
            // there is no further work needed to be done.
            return;
        }

        // Restricted proof configuration carries the external affine coordinator
        // explicitly. The ordinary runtime below retains its native API.
        #[cfg(bytes_proof_shared_reserve)]
        {
            let original = snapshot!(*self);
            let identity = ghost! { self.shared_registration.as_ref().unwrap().control.identity.into_inner() };
            let control = sequential_shared_control::ControlPtr { pointer: self.data, identity };
            if shared_reclaim::is_unique(control, ghost! { coordinator.as_ref().unwrap() }) {
                ghost! { sequential_shared_control::HandleRegistration::singleton_is_sole(
                    snapshot!(coordinator.inner_logic().unwrap_logic()),
                    snapshot!(self.shared_registration.inner_logic().unwrap_logic())); };
                let base = {
                    let shared = unsafe { creusot_std::ghost::perm::Perm::as_ref(self.data,
                        ghost! { &**coordinator.as_ref().unwrap().owner.as_ref().unwrap() }) };
                    shared.buffer.base
                };
                let offset = self.ptr.offset_from_bound_base(base);
                let registration = ghost! { self.shared_registration.take().unwrap() };
                let context = ghost! { coordinator.take().unwrap() };
                let lease = shared_reclaim::acquire(control, context, registration);
                let (pointer, capacity, lease) = shared_reserve::reserve_lease(control, lease, self.ptr, offset, self.len, additional);
                let end = snapshot!(pointer@.unwrap_logic().2 + capacity@);
                let (context, registration) = shared_reserve::reactivate_view(control, lease, end).split();
                self.ptr = pointer;
                self.cap = capacity;
                self.shared_registration = ghost! { Some(registration.into_inner()) };
                ghost! { **coordinator = Some(context.into_inner()); };
                proof_assert!(forall<i: Int> 0 <= i && i < self.len@ ==>
                    self.proof_view_slot(i) == original.proof_view_slot(i));
                proof_assert!(self.proof_initialized());
            } else {
                ghost! { crate::ownership_proof::scalable_tickets::pending_cardinality(
                    snapshot!(*coordinator.inner_logic().unwrap_logic().status.pending)); };
                proof_assert!((*coordinator.inner_logic().unwrap_logic().status.pending).len() >= 2);
                let empty = Self::from_vec(Vec::new());
                let old = mem::replace(self, empty);
                let grown = shared_copy::reserve_copy(old, additional, ghost! { coordinator.as_mut().unwrap() });
                let mut empty = mem::replace(self, grown);
                let pointer = empty.ptr;
                let capacity = empty.cap;
                let caps = ghost! { empty.unique_at_zero.take().unwrap() };
                mem::forget(empty);
                unsafe { release_unique_storage(pointer, capacity, 0, caps); }
            }
            return;
        }

        // The proof gate covers only the native fast path above.
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        { let _ = self.reserve_inner(additional, true); }
        #[cfg(all(any(creusot, bytes_proof_probe), bytes_proof_unique_growth))]
        {
            #[cfg(bytes_proof_unique_reserve)]
            {
                let off = unsafe { self.get_vec_pos() };
                if self.cap - self.len + off >= additional && off >= self.len {
                    self.reclaim_unique();
                    return;
                }
            }
            self.reserve_unique_growing(additional);
        }
        #[cfg(all(any(creusot, bytes_proof_probe), not(bytes_proof_unique_growth), not(bytes_proof_shared_reserve)))]
        panic!("growing reserve is outside the in-capacity proof gate");
    }
    // BEGIN EXACT SPARE_CAPACITY_MUT
    #[inline]
    #[cfg_attr(creusot, requires(self.proof_initialized()))]
    #[cfg_attr(creusot, ensures(result@.len() == self.cap@ - self.len@ && (^result)@.len() == self.cap@ - self.len@))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < result@.len() ==>
        self.proof_view_slot(self.len@ + index) == Some(result@[index]@)))]
    // Absolute visible indices let publication and frame clients use the same
    // slot term without reconstructing the spare slice's relative index.
    #[cfg_attr(creusot, ensures(forall<index: Int> self.len@ <= index && index < self.cap@ ==>
        self.proof_view_slot(index) == Some(result@[index - self.len@]@)))]
    #[cfg_attr(creusot, ensures(forall<index: Int> self.len@ <= index && index < self.cap@ ==>
        (^self).proof_view_slot(index) == Some((^result)@[index - self.len@]@)))]
    #[cfg_attr(creusot, ensures((^self).proof_owned_valid()))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < (^self).len@ ==>
        crate::ownership_proof::raw_vec::slot_known((^self).proof_view_slot(index))))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures(((^self).unique_at_zero.inner_logic() == None) == (self.unique_at_zero.inner_logic() == None)))]
    #[cfg_attr(creusot, ensures(self.unique_at_zero.inner_logic() != None ==> (^self).unique_at_zero.inner_logic().unwrap_logic().0 == self.unique_at_zero.inner_logic().unwrap_logic().0))]
    #[cfg_attr(creusot, ensures(((^self).shared_registration.inner_logic() == None) == (self.shared_registration.inner_logic() == None)))]
    #[cfg_attr(creusot, ensures((^self).pending_control == self.pending_control && (^self).shared_context == self.shared_context))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().control == self.shared_registration.inner_logic().unwrap_logic().control))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().status == self.shared_registration.inner_logic().unwrap_logic().status))]
    #[cfg_attr(creusot, ensures(self.shared_registration.inner_logic() != None ==> (^self).shared_registration.inner_logic().unwrap_logic().left == self.shared_registration.inner_logic().unwrap_logic().left))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < (^result)@.len() ==>
        (^self).proof_view_slot(self.len@ + index) == Some((^result)@[index]@)))]
    #[cfg_attr(creusot, ensures(forall<index: Int> !(self.len@ <= index && index < self.cap@) ==>
        (^self).proof_view_slot(index) == self.proof_view_slot(index)))]
    #[cfg_attr(creusot, ensures(forall<index: Int>
        !(self.ptr@.unwrap_logic().2 + self.len@ <= index && index < self.ptr@.unwrap_logic().2 + self.cap@) ==>
            (^self).proof_owned_slot(index) == self.proof_owned_slot(index)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(self.shared_registration.inner_logic() != None ==>
        (^self).shared_registration.inner_logic().unwrap_logic().packet.0 == self.shared_registration.inner_logic().unwrap_logic().packet.0 &&
        (^self).shared_registration.inner_logic().unwrap_logic().packet.1.lo() == self.shared_registration.inner_logic().unwrap_logic().packet.1.lo() &&
        (^self).shared_registration.inner_logic().unwrap_logic().packet.1.hi() == self.shared_registration.inner_logic().unwrap_logic().packet.1.hi()))]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<u8>] {
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        unsafe {
            let ptr = self.ptr.as_ptr().add(self.len);
            let len = self.cap - self.len;
            slice::from_raw_parts_mut(ptr.cast(), len)
        }
        #[cfg(any(creusot, bytes_proof_probe))]
        {
            #[cfg(bytes_proof_valid_handle)]
            if self.cap == 0 {
                return unsafe { crate::ownership_proof::raw_vec::borrow_empty_bound_uninit_mut(&self.ptr) };
            }
            if self.kind() == KIND_VEC {
                return unsafe { crate::ownership_proof::raw_vec::borrow_spare_preserving_prefix(
                    self.ptr, self.len, self.cap,
                    ghost! { &mut self.unique_at_zero.as_mut().unwrap().1 }) };
            }
            let (packet, status, left) = ghost! {
                let registration = self.shared_registration.as_mut().unwrap();
                (&mut registration.packet, registration.status, registration.left)
            }.split();
            unsafe { crate::ownership_proof::shared_protocol::borrow_packet_uninit_mut(self.ptr, self.len, self.cap, packet, status, left) }
        }
    }
    // BEGIN EXACT TRUNCATE
    #[cfg_attr(creusot, requires(self.proof_initialized()))]
    #[cfg_attr(creusot, ensures((^self).len@ == if len <= self.len { len@ } else { self.len@ }))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero == self.unique_at_zero && (^self).pending_control == self.pending_control && (^self).shared_registration == self.shared_registration && (^self).shared_context == self.shared_context))]
    #[cfg_attr(creusot, ensures((^self).proof_initialized()))]
    pub fn truncate(&mut self, len: usize) {
        if len <= self.len() {
            // SAFETY: Shrinking the buffer cannot expose uninitialized bytes.
            unsafe { self.set_len(len) };
        }
    }
    // BEGIN EXACT SET_LEN
    #[cfg_attr(creusot, requires(self.proof_owned_valid()))]
    #[cfg_attr(creusot, requires(len <= self.cap))]
    #[cfg_attr(creusot, requires(forall<index: Int> 0 <= index && index < len@ ==>
        crate::ownership_proof::raw_vec::slot_known(self.proof_view_slot(index))))]
    #[cfg_attr(creusot, ensures((^self).len == len))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero == self.unique_at_zero && (^self).pending_control == self.pending_control && (^self).shared_registration == self.shared_registration && (^self).shared_context == self.shared_context))]
    #[cfg_attr(creusot, ensures((^self).proof_initialized()))]
    pub unsafe fn set_len(&mut self, len: usize) {
        debug_assert!(len <= self.cap, "set_len out of bounds");
        self.len = len;
    }
    // BEGIN EXACT SPLIT_TO
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == 0usize))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(at <= self.len))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).proof_split_pair_valid(result)))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(result.ptr@ == self.ptr@))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).ptr@ == Some((self.ptr@.unwrap_logic().0, self.ptr@.unwrap_logic().1, at@))))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(result.len == at && (^self).len@ == self.len@ - at@))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(result.cap == at && (^self).cap@ == self.cap@ - at@))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).proof_initialized() && result.proof_initialized()))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(forall<index: Int> 0 <= index && index < at@ ==>
        result.proof_view_slot(index) == self.proof_unique_slot(index)))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(forall<index: Int> 0 <= index && index < self.len@ - at@ ==>
        (^self).proof_view_slot(index) == self.proof_unique_slot(index + at@)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), requires(self.proof_carrier_ready() && at <= self.len))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).shared_registration.inner_logic().unwrap_logic().packet.1.lo() == self.ptr@.unwrap_logic().2 + at@))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(result.shared_registration.inner_logic().unwrap_logic().packet.1.lo() ==
        if self.shared_registration.inner_logic() == None { 0int } else { self.shared_registration.inner_logic().unwrap_logic().packet.1.lo() }))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).proof_carrier_pair(result)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(result.ptr@ == self.ptr@ && (^self).ptr@ == Some((self.ptr@.unwrap_logic().0, self.ptr@.unwrap_logic().1, self.ptr@.unwrap_logic().2 + at@))))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(result.len == at && (^self).len@ == self.len@ - at@ && result.cap == at && (^self).cap@ == self.cap@ - at@))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).proof_initialized() && result.proof_initialized()))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<index: Int> 0 <= index && index < at@ ==> result.proof_view_slot(index) == self.proof_view_slot(index)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<index: Int> 0 <= index && index < self.len@ - at@ ==> (^self).proof_view_slot(index) == self.proof_view_slot(index + at@)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.matches(self.shared_context.inner_logic().unwrap_logic()) &&
        registration.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            registration.matches((^self).shared_context.inner_logic().unwrap_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((* (^self).shared_context.inner_logic().unwrap_logic().status.pending).len() ==
        if self.shared_context.inner_logic() == None { 2int } else { (*self.shared_context.inner_logic().unwrap_logic().status.pending).len() + 1 }))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.matches(self.shared_context.inner_logic().unwrap_logic()) ==>
            registration.packet.0.logical_id() != (^self).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
            registration.packet.0.logical_id() != result.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).proof_carrier_initialized() && result.proof_carrier_initialized()))]
    #[must_use = "consider BytesMut::advance if you don't need the other half"]
    pub fn split_to(&mut self, at: usize) -> BytesMut {
        assert!(
            at <= self.len(),
            "split_to out of bounds: {:?} <= {:?}",
            at,
            self.len(),
        );

        unsafe {
            let mut other = self.shallow_clone();
            #[cfg(all(any(creusot, bytes_proof_probe), not(bytes_proof_repeated_split)))]
            self.proof_register_split(&mut other, at);
            #[cfg(bytes_proof_repeated_split)]
            { self.proof_finish_carrier_split(other, at) }
            #[cfg(not(bytes_proof_repeated_split))]
            {
                // SAFETY: We've checked that `at` <= `self.len()` and we know that `self.len()` <=
                // `self.capacity()`.
                self.advance_unchecked(at);
                other.cap = at;
                other.len = at;
                other
            }
        }
    }
    // BEGIN EXACT ADVANCE_UNCHECKED
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), requires(self.proof_empty_valid() || (self.ptr.invariant() && self.ptr@ != None)))]
    #[cfg_attr(all(creusot, not(bytes_proof_valid_handle)), requires(self.ptr.invariant() && self.ptr@ != None))]
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), requires(self.proof_empty_valid() ||
        self.ptr@.unwrap_logic().2 + self.cap@ <= self.ptr@.unwrap_logic().1))]
    #[cfg_attr(all(creusot, not(bytes_proof_valid_handle)), requires(
        self.ptr@.unwrap_logic().2 + self.cap@ <= self.ptr@.unwrap_logic().1))]
    #[cfg_attr(creusot, requires(count <= self.cap && self.len <= self.cap))]
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), requires(self.proof_empty_valid() ==> count@ == 0int))]
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), requires(self.proof_empty_valid() ||
        (self.data.addr_logic() & KIND_MASK == KIND_ARC && self.proof_shared_allocation_registered()) ||
        (self.proof_unique_owned() && self.ptr@.unwrap_logic().2 + count@ <= crate::capacity_ops::MAX_VEC_POS@)))]
    #[cfg_attr(all(creusot, not(bytes_proof_valid_handle)), requires(
        (self.data.addr_logic() & KIND_MASK == KIND_ARC && self.proof_shared_allocation_registered()) ||
        (self.proof_unique_owned() && self.ptr@.unwrap_logic().2 + count@ <= crate::capacity_ops::MAX_VEC_POS@)))]
    #[cfg_attr(creusot, ensures((^self).ptr.invariant()))]
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), ensures(self.proof_empty_valid() ||
        (^self).ptr@ == Some((self.ptr@.unwrap_logic().0, self.ptr@.unwrap_logic().1, self.ptr@.unwrap_logic().2 + count@))))]
    #[cfg_attr(all(creusot, not(bytes_proof_valid_handle)), ensures(
        (^self).ptr@ == Some((self.ptr@.unwrap_logic().0, self.ptr@.unwrap_logic().1, self.ptr@.unwrap_logic().2 + count@))))]
    #[cfg_attr(all(creusot, bytes_proof_valid_handle), ensures(self.proof_empty_valid() ==> (^self).proof_empty_valid()))]
    #[cfg_attr(creusot, ensures((^self).len@ == (if count <= self.len { self.len@ - count@ } else { 0int }) && (^self).cap@ == self.cap@ - count@))]
    #[cfg_attr(creusot, ensures(self.data.addr_logic() & KIND_MASK == KIND_ARC ==> (^self).data == self.data))]
    #[cfg_attr(creusot, ensures(self.proof_unique_owned() ==> (^self).proof_unique_owned()))]
    #[cfg_attr(creusot, ensures((^self).data.addr_logic() & crate::capacity_ops::NOT_VEC_POS_MASK == self.data.addr_logic() & crate::capacity_ops::NOT_VEC_POS_MASK))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero == self.unique_at_zero && (^self).pending_control == self.pending_control && (^self).shared_registration == self.shared_registration && (^self).shared_context == self.shared_context))]
    #[cfg_attr(creusot, ensures(forall<index: Int> (^self).proof_owned_slot(index) == self.proof_owned_slot(index)))]
    #[cfg_attr(creusot, ensures(self.proof_registered_valid() ==> (^self).proof_registered_valid()))]
    #[cfg_attr(creusot, ensures(self.proof_initialized() ==> (^self).proof_initialized()))]
    #[cfg_attr(creusot, ensures(forall<index: Int>
        (^self).proof_view_slot(index) == self.proof_view_slot(index + count@)))]
    pub(crate) unsafe fn advance_unchecked(&mut self, count: usize) {
        // Setting the start to 0 is a no-op, so return early if this is the
        // case.
        if count == 0 {
            return;
        }

        debug_assert!(count <= self.cap, "internal: set_start out of bounds");

        let kind = self.kind();

        #[cfg(all(creusot, bytes_proof_valid_handle))]
        if kind == KIND_VEC {
            let empty = BytesMut {
                ptr: crate::ownership_proof::raw_vec::BoundPtr::unbound(NonNull::dangling()),
                len: 0,
                cap: 0,
                data: invalid_ptr(KIND_VEC),
                unique_at_zero: ghost! { None },
                pending_control: ghost! { None },
                shared_registration: ghost! { None },
                shared_context: ghost! { None },
            };
            let old = mem::replace(self, empty);
            let raw = RawTransition::from_valid(old);
            let updated = raw.advance_to_valid(count);
            // The result is already valid. Do not let BytesMut::drop inspect
            // the resource-free placeholder returned by this replacement.
            let placeholder = mem::replace(self, updated);
            mem::forget(placeholder);
            return;
        }

        #[cfg(not(all(creusot, bytes_proof_valid_handle)))]
        if kind == KIND_VEC {
            // Setting the start when in vec representation is a little more
            // complicated. First, we have to track how far ahead the
            // "start" of the byte buffer from the beginning of the vec. We
            // also have to ensure that we don't exceed the maximum shift.
            let pos = self.get_vec_pos() + count;

            if pos <= MAX_VEC_POS {
                self.set_vec_pos(pos);
            } else {
                // The repr must be upgraded to ARC. This will never happen
                // on 64 bit systems and will only happen on 32 bit systems
                // when shifting past 134,217,727 bytes. As such, we don't
                // worry too much about performance here.
                #[cfg(not(any(creusot, bytes_proof_probe)))]
                self.promote_to_shared(/*ref_count = */ 1);
                #[cfg(any(creusot, bytes_proof_probe))]
                panic!("unique offset overflow promotion is outside this proof gate");
            }
        }

        // Updating the start of the view is setting `ptr` to point to the
        // new start and updating the `len` field to reflect the new length
        // of the view.
        #[cfg(not(any(creusot, bytes_proof_probe)))]
        { self.ptr = vptr(self.ptr.as_ptr().add(count)); }
        #[cfg(any(creusot, bytes_proof_probe))]
        { self.ptr = self.ptr.advance_within(count); }
        self.len = self.len.saturating_sub(count);
        self.cap -= count;
    }
    // BEGIN EXACT PROMOTE_TO_SHARED
    #[cfg_attr(creusot, requires(self.proof_unique_at_zero_valid()))]
    #[cfg_attr(creusot, requires(self.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(creusot, requires(self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == 0usize))]
    #[cfg_attr(creusot, requires(ref_cnt == 2usize))]
    #[cfg_attr(creusot, ensures((^self).proof_pending_valid()))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap))]
    #[cfg_attr(creusot, ensures((^self).pending_control.inner_logic().unwrap_logic().caps == self.unique_at_zero.inner_logic().unwrap_logic()))]
    unsafe fn promote_to_shared(&mut self, ref_cnt: usize) {
        debug_assert_eq!(self.kind(), KIND_VEC);
        debug_assert!(ref_cnt == 1 || ref_cnt == 2);

        let original_capacity_repr =
            crate::capacity_ops::original_capacity_repr_from_data(
                crate::provenance_specs::pointer_addr(self.data),
            );

        // The vec offset cannot be concurrently mutated, so there
        // should be no danger reading it.
        let off = crate::capacity_ops::vec_pos_from_data(
            crate::provenance_specs::pointer_addr(self.data),
        );

        // First, allocate a new `Shared` instance containing the
        // `Vec` fields. It's important to note that `ptr`, `len`,
        // and `cap` cannot be mutated without having `&mut self`.
        // This means that these fields will not be concurrently
        // updated and since the buffer hasn't been promoted to an
        // `Arc`, those three fields still are the components of the
        // vector.
        #[cfg(any(creusot, bytes_proof_probe))]
        let (ref_count, counter_own) = crate::ownership_proof::sequential_counter::SequentialCounter::new(ref_cnt);
        let shared = Box::new(Shared {
            #[cfg(not(any(creusot, bytes_proof_probe)))]
            buffer: SharedBuffer::from_handle(self.ptr.as_ptr(), self.cap, off),
            #[cfg(any(creusot, bytes_proof_probe))]
            buffer: SharedBuffer { base: self.ptr, capacity: self.cap },
            original_capacity_repr,
            #[cfg(not(any(creusot, bytes_proof_probe)))]
            ref_count: AtomicUsize::new(ref_cnt),
            #[cfg(any(creusot, bytes_proof_probe))]
            ref_count,
        });

        #[cfg(not(any(creusot, bytes_proof_probe)))]
        let shared = Box::into_raw(shared);
        #[cfg(any(creusot, bytes_proof_probe))]
        let (shared, owner) = crate::ownership_proof::boxed_alignment::into_raw_aligned(shared);

        #[cfg(any(creusot, bytes_proof_probe))]
        crate::ownership_proof::boxed_alignment::aligned_address_has_clear_low_bit(
            crate::provenance_specs::pointer_addr(shared), core::mem::align_of::<Shared>(),
        );

        // The pointer should be aligned, so this assert should
        // always succeed.
        debug_assert_eq!(
            crate::provenance_specs::pointer_addr(shared) & KIND_MASK,
            KIND_ARC
        );

        self.data = shared;
        #[cfg(any(creusot, bytes_proof_probe))]
        {
            self.pending_control = ghost! {
                let caps = self.unique_at_zero.take().unwrap();
                Some(sequential_shared_control::PendingControl { counter: counter_own.into_inner(), owner: owner.into_inner(), caps })
            };
        }
    }
    // BEGIN EXACT SHALLOW_CLONE
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.data.addr_logic() & KIND_MASK == KIND_VEC))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), requires(self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET == 0usize))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).proof_pending_valid()))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(result.ptr == (^self).ptr && result.len == (^self).len && result.cap == (^self).cap && result.data == (^self).data))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures(result.unique_at_zero.inner_logic() == None && result.pending_control.inner_logic() == None && result.shared_registration.inner_logic() == None && result.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, not(bytes_proof_repeated_split)), ensures((^self).pending_control.inner_logic().unwrap_logic().caps == self.unique_at_zero.inner_logic().unwrap_logic()))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), requires(self.proof_carrier_ready()))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).proof_carrier_pending()))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(((^self).shared_context.inner_logic() == None) == (self.shared_context.inner_logic() == None)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(self.shared_context.inner_logic() == None ==> (^self).pending_control.inner_logic() != None))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(result.ptr == (^self).ptr && result.len == (^self).len && result.cap == (^self).cap && result.data == (^self).data))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(result.unique_at_zero.inner_logic() == None && result.pending_control.inner_logic() == None && result.shared_registration.inner_logic() == None && result.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<index: Int> (^self).proof_carrier_slot(index) == self.proof_owned_slot(index)))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(forall<index: Int> self.ptr@.unwrap_logic().2 <= index && index < self.ptr@.unwrap_logic().2 + self.len@ ==>
        crate::ownership_proof::raw_vec::slot_known((^self).proof_carrier_slot(index))))]
    #[cfg_attr(all(creusot, bytes_proof_repeated_split), ensures(self.shared_context.inner_logic() != None ==> (^self).shared_registration == self.shared_registration &&
        (^self).shared_context.inner_logic().unwrap_logic().status == self.shared_context.inner_logic().unwrap_logic().status))]
    #[inline]
    unsafe fn shallow_clone(&mut self) -> BytesMut {
        if self.kind() == KIND_ARC {
            #[cfg(not(any(creusot, bytes_proof_probe)))]
            increment_shared(self.data);
            #[cfg(all(any(creusot, bytes_proof_probe), not(bytes_proof_repeated_split)))]
            panic!("ARC clone is outside the first sequential split gate");
            #[cfg(bytes_proof_repeated_split)]
            {
                let identity = ghost! { self.shared_registration.as_ref().unwrap().control.identity.into_inner() };
                let control = sequential_shared_control::ControlPtr { pointer: self.data, identity };
                increment_shared(self.data, control, ghost! { self.shared_context.as_mut().unwrap() });
            }
            #[cfg(not(any(creusot, bytes_proof_probe)))]
            { ptr::read(self) }
            #[cfg(any(creusot, bytes_proof_probe))]
            { self.pending_descriptor_copy() }
        } else {
            self.promote_to_shared(/*ref_count = */ 2);
            #[cfg(not(any(creusot, bytes_proof_probe)))]
            { ptr::read(self) }
            #[cfg(any(creusot, bytes_proof_probe))]
            { self.pending_descriptor_copy() }
        }
    }
    // Copies metadata only. The completed split protocol must distribute
    // regions before this pending descriptor can become a verified handle.
    #[cfg_attr(creusot, ensures(result.ptr == self.ptr && result.len == self.len && result.cap == self.cap && result.data == self.data))]
    #[cfg_attr(creusot, ensures(result.unique_at_zero.inner_logic() == None && result.pending_control.inner_logic() == None && result.shared_registration.inner_logic() == None && result.shared_context.inner_logic() == None))]
    #[cfg(any(creusot, bytes_proof_probe))]
    fn pending_descriptor_copy(&self) -> BytesMut {
        BytesMut {
            ptr: self.ptr, len: self.len, cap: self.cap, data: self.data,
            unique_at_zero: ghost! { None },
            #[cfg(any(creusot, bytes_proof_probe))]
            pending_control: ghost! { None },
            #[cfg(any(creusot, bytes_proof_probe))]
            shared_registration: ghost! { None },
            #[cfg(any(creusot, bytes_proof_probe))]
            shared_context: ghost! { None },
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_unique_owned(self) -> bool {
        pearlite! {
            self.data.addr_logic() & KIND_MASK == KIND_VEC &&
            self.pending_control.inner_logic() == None &&
            self.shared_registration.inner_logic() == None &&
            self.shared_context.inner_logic() == None &&
            match self.unique_at_zero.inner_logic() {
                None => false,
                Some((recovery, region)) =>
                    self.ptr.invariant() && self.ptr@ != None &&
                    self.ptr@.unwrap_logic().0 == recovery.namespace() &&
                    self.ptr@.unwrap_logic().1 == recovery.capacity() &&
                    self.ptr@.unwrap_logic().2 == (self.data.addr_logic() >> crate::capacity_ops::VEC_POS_OFFSET)@ &&
                    self.ptr@.unwrap_logic().2 + self.cap@ == recovery.capacity() &&
                    recovery.invariant() && region.invariant() &&
                    region.capacity() == recovery.capacity() &&
                    region.namespace() == recovery.namespace() &&
                    region.resource_id() == recovery.namespace() &&
                    region.lo() == 0 && region.hi() == recovery.capacity() &&
                    self.len <= self.cap
            }
        }
    }
    #[cfg(creusot)]
    #[logic]
    pub(crate) fn proof_view_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! {
            match self.unique_at_zero.inner_logic() {
                Some((_, region)) => region.slot(self.ptr@.unwrap_logic().2 + index),
                None => match self.shared_registration.inner_logic() {
                    None => None,
                    Some(registration) => registration.packet.1.slot(self.ptr@.unwrap_logic().2 + index),
                },
            }
        }
    }
    #[cfg(creusot)]
    #[logic]
    pub(crate) fn proof_owned_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! {
            match self.unique_at_zero.inner_logic() {
                Some((_, region)) => region.slot(index),
                None => match self.shared_registration.inner_logic() {
                    None => None,
                    Some(registration) => registration.packet.1.slot(index),
                },
            }
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_initialized(self) -> bool {
        pearlite! {
            self.proof_owned_valid() &&
            forall<index: Int> 0 <= index && index < self.len@ ==>
                crate::ownership_proof::raw_vec::slot_known(self.proof_view_slot(index))
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_pending_valid(self) -> bool {
        pearlite! {
            self.unique_at_zero.inner_logic() == None &&
            self.shared_registration.inner_logic() == None && self.shared_context.inner_logic() == None &&
            self.len <= self.cap && self.data.addr_logic() & KIND_MASK == KIND_ARC &&
            match self.pending_control.inner_logic() {
                Some(pending) => pending.valid(self.data, self.ptr, self.cap), None => false,
            }
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_shared_allocation_registered(self) -> bool {
        pearlite! {
            self.data.addr_logic() & KIND_MASK == KIND_ARC && self.ptr@ != None &&
            match self.shared_registration.inner_logic() {
                None => false,
                Some(registration) => registration.valid() &&
                    registration.control.pointer == self.data &&
                    self.ptr@.unwrap_logic().0 == registration.status.allocation &&
                    self.ptr@.unwrap_logic().1 == registration.status.capacity,
            }
        }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_registered_valid(self) -> bool {
        pearlite! {
            self.unique_at_zero.inner_logic() == None && self.pending_control.inner_logic() == None &&
            self.len <= self.cap && self.ptr.invariant() &&
            self.data.addr_logic() & KIND_MASK == KIND_ARC &&
            match self.shared_registration.inner_logic() {
                None => false,
                Some(registration) => registration.valid() && registration.control.pointer == self.data &&
                    self.ptr@ != None &&
                    self.ptr@.unwrap_logic().0 == registration.status.allocation &&
                    self.ptr@.unwrap_logic().1 == registration.status.capacity &&
                    self.ptr@.unwrap_logic().2 + self.cap@ <= registration.status.capacity &&
                    registration.view_lo() <= self.ptr@.unwrap_logic().2 &&
                    self.ptr@.unwrap_logic().2 + self.cap@ ==
                        registration.view_hi(),
            }
        }
    }
    #[cfg(all(creusot, not(bytes_proof_valid_handle)))]
    #[logic(prophetic)]
    fn proof_owned_valid(self) -> bool {
        pearlite! { self.proof_unique_owned() || self.proof_registered_valid() }
    }
    #[cfg(any(creusot, bytes_proof_probe))]
    #[cfg_attr(creusot, requires(self.shared_context.inner_logic() != None))]
    #[cfg_attr(creusot, ensures(result.inner_logic() == self.shared_context.inner_logic().unwrap_logic()))]
    #[cfg_attr(creusot, ensures((^self).shared_context.inner_logic() == None))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero == self.unique_at_zero && (^self).pending_control == self.pending_control && (^self).shared_registration == self.shared_registration))]
    fn proof_take_coordinator(&mut self) -> Ghost<sequential_shared_control::ControlContext> {
        ghost! { self.shared_context.take().unwrap() }
    }
    #[cfg(creusot)]
    #[logic(prophetic)]
    fn proof_empty_valid(self) -> bool {
        pearlite! {
            self.len == 0usize && self.cap == 0usize &&
            self.data.addr_logic() == KIND_VEC && self.ptr.invariant() && self.ptr@ == None &&
            self.unique_at_zero.inner_logic() == None && self.pending_control.inner_logic() == None &&
            self.shared_registration.inner_logic() == None && self.shared_context.inner_logic() == None
        }
    }
    // BEGIN EXACT SHARED UNSPLIT
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.proof_initialized() && other.proof_initialized()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_context.inner_logic() == None && other.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_registration.inner_logic() != None && other.shared_registration.inner_logic() != None))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(other.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_registration.inner_logic().unwrap_logic().control == other.shared_registration.inner_logic().unwrap_logic().control))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() != other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.len == self.cap))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(self.shared_registration.inner_logic().unwrap_logic().packet.1.hi() == other.shared_registration.inner_logic().unwrap_logic().packet.1.lo()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), requires(other.ptr@.unwrap_logic().2 == other.shared_registration.inner_logic().unwrap_logic().packet.1.lo()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((^self).proof_initialized() && (^self).shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((^self).shared_registration.inner_logic().unwrap_logic().matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((^self).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==
        self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((^self).ptr == self.ptr && (^self).data == self.data))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((^self).len@ == self.len@ + other.len@ && (^self).cap@ == self.cap@ + other.cap@))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures((* (^context.inner_logic()).status.pending).len() + 1 == (*context.inner_logic().status.pending).len()))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures(forall<index: Int> 0 <= index && index < (^self).len@ ==>
        (^self).proof_view_slot(index) == if index < self.len@ { self.proof_view_slot(index) }
            else { other.proof_view_slot(index - self.len@) }))]
    #[cfg_attr(all(creusot, bytes_proof_adjacent_unsplit), ensures(forall<remaining: sequential_shared_control::HandleRegistration> remaining.matches(*context.inner_logic()) &&
        remaining.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
        remaining.packet.0.logical_id() != other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            remaining.matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.proof_initialized() && other.proof_initialized()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.shared_context.inner_logic() == None && other.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.shared_registration.inner_logic() != None && other.shared_registration.inner_logic() != None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(other.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.shared_registration.inner_logic().unwrap_logic().control == other.shared_registration.inner_logic().unwrap_logic().control))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() != other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.len == 0usize || other.cap == 0usize || self.ptr@.unwrap_logic().2 + self.len@ != other.ptr@.unwrap_logic().2))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), requires(self.len@ + other.len@ <= isize::MAX@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures((^self).proof_initialized() && (^self).shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(self.len == 0usize ==> ^self == other))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(self.len != 0usize && other.cap == 0usize ==> ^self == *self))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(self.len == 0usize || other.cap == 0usize ==> (^self).shared_registration.inner_logic().unwrap_logic().matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(self.len != 0usize && other.cap != 0usize ==> (^self).proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures((^self).len@ == self.len@ + other.len@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures((* (^context.inner_logic()).status.pending).len() + if self.len == 0usize || other.cap == 0usize { 1 } else { 2 } == (*context.inner_logic().status.pending).len()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(forall<index: Int> 0 <= index && index < (^self).len@ ==>
        (^self).proof_view_slot(index) == if index < self.len@ { self.proof_view_slot(index) } else { other.proof_view_slot(index - self.len@) }))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_fallbacks), ensures(forall<remaining: sequential_shared_control::HandleRegistration> remaining.matches(*context.inner_logic()) &&
        remaining.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
        remaining.packet.0.logical_id() != other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            remaining.matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.proof_initialized() && other.proof_initialized()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.shared_context.inner_logic() == None && other.shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.shared_registration.inner_logic() != None && other.shared_registration.inner_logic() != None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(other.shared_registration.inner_logic().unwrap_logic().matches(*other_context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.data != other.data))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires((*context.inner_logic().status.pending).len() >= 1))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), requires(self.len@ + other.len@ <= isize::MAX@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((^self).proof_initialized() && (^self).shared_context.inner_logic() == None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((^context.inner_logic()).valid(self.shared_registration.inner_logic().unwrap_logic().control)))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((^other_context.inner_logic()).valid(other.shared_registration.inner_logic().unwrap_logic().control)))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(self.len == 0usize ==> ^self == other))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(self.len != 0usize && other.cap == 0usize ==> ^self == *self))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(self.len == 0usize ==> (^self).shared_registration.inner_logic().unwrap_logic().matches(^other_context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(self.len != 0usize && other.cap == 0usize ==> (^self).shared_registration.inner_logic().unwrap_logic().matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(self.len != 0usize && other.cap != 0usize ==> (^self).proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((^self).len@ == self.len@ + other.len@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((* (^context.inner_logic()).status.pending).len() + if self.len == 0usize || other.cap != 0usize { 1 } else { 0 } == (*context.inner_logic().status.pending).len()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures((* (^other_context.inner_logic()).status.pending).len() + if self.len == 0usize { 0 } else { 1 } == (*other_context.inner_logic().status.pending).len()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(forall<index: Int> 0 <= index && index < (^self).len@ ==>
        (^self).proof_view_slot(index) == if index < self.len@ { self.proof_view_slot(index) } else { other.proof_view_slot(index - self.len@) }))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(forall<remaining: sequential_shared_control::HandleRegistration> remaining.matches(*context.inner_logic()) &&
        remaining.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==> remaining.matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_independent), ensures(forall<remaining: sequential_shared_control::HandleRegistration> remaining.matches(*other_context.inner_logic()) &&
        remaining.packet.0.logical_id() != other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==> remaining.matches(^other_context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires((self.proof_initialized() || self.proof_empty_valid()) && (other.proof_initialized() || other.proof_empty_valid())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires(((self.proof_unique_owned() || self.proof_empty_valid()) && other.proof_registered_valid()) || (self.proof_registered_valid() && (other.proof_unique_owned() || other.proof_empty_valid()))))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires(self.shared_context.inner_logic()==None && other.shared_context.inner_logic()==None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires(self.shared_registration.inner_logic()!=None ==> self.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires(other.shared_registration.inner_logic()!=None ==> other.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires((*context.inner_logic().status.pending).len()>=1))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), requires(self.len@+other.len@<=isize::MAX@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^self).proof_initialized() || (^self).proof_empty_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^self).shared_registration.inner_logic()!=None ==> (^self).shared_registration.inner_logic().unwrap_logic().matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^self).shared_context.inner_logic()==None))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures(self.len==0usize ==> ^self==other))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures(self.len!=0usize && other.cap==0usize ==> ^self==*self))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures(self.len!=0usize && other.cap!=0usize ==> (^self).proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^self).len@==self.len@+other.len@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures(forall<i:Int> 0<=i && i<(^self).len@ ==> (^self).proof_view_slot(i)==if i<self.len@{self.proof_view_slot(i)}else{other.proof_view_slot(i-self.len@)}))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^context.inner_logic()).valid(if self.shared_registration.inner_logic()!=None{self.shared_registration.inner_logic().unwrap_logic().control}else{other.shared_registration.inner_logic().unwrap_logic().control})))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((* (^context.inner_logic()).status.pending).len()+(if ((self.len==0usize && self.shared_registration.inner_logic()!=None) || (self.len!=0usize && (other.cap!=0usize || other.shared_registration.inner_logic()!=None))){1}else{0})==(*context.inner_logic().status.pending).len()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures((^context.inner_logic()).active()==if ((self.len==0usize && self.shared_registration.inner_logic()!=None) || (self.len!=0usize && (other.cap!=0usize || other.shared_registration.inner_logic()!=None))){(*context.inner_logic().status.pending).len()>=2}else{context.inner_logic().active()}))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_mixed), ensures(forall<remaining:sequential_shared_control::HandleRegistration> remaining.matches(*context.inner_logic()) &&
        remaining.packet.0.logical_id()!=(if self.shared_registration.inner_logic()!=None{self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()}else{other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()}) ==> remaining.matches(^context.inner_logic())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), requires(((self.proof_unique_owned() && self.proof_initialized()) || self.proof_empty_valid()) && ((other.proof_unique_owned() && other.proof_initialized()) || other.proof_empty_valid())))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), requires(self.len@+other.len@<=isize::MAX@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures(((^self).proof_unique_owned() && (^self).proof_initialized()) || (^self).proof_empty_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures(self.len==0usize ==> ^self==other))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures(self.len!=0usize && other.cap==0usize ==> ^self==*self))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures(self.len!=0usize && other.cap!=0usize ==> (^self).proof_unique_at_zero_valid()))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures((^self).len@==self.len@+other.len@))]
    #[cfg_attr(all(creusot, bytes_proof_unsplit_unique), ensures(forall<i:Int> 0<=i && i<(^self).len@ ==> (^self).proof_view_slot(i)==if i<self.len@{self.proof_view_slot(i)}else{other.proof_view_slot(i-self.len@)}))]
    pub fn unsplit(&mut self, other: BytesMut,
        #[cfg(any(bytes_proof_adjacent_unsplit, bytes_proof_unsplit_fallbacks, bytes_proof_unsplit_independent, bytes_proof_unsplit_mixed))] context: Ghost<&mut sequential_shared_control::ControlContext>,
        #[cfg(bytes_proof_unsplit_independent)] other_context: Ghost<&mut sequential_shared_control::ControlContext>,
    ) {
        #[cfg(bytes_proof_adjacent_unsplit)]
        {
            shared_unsplit::merge_into(self, other, context);
        }
        #[cfg(bytes_proof_unsplit_fallbacks)]
        {
            if self.len == 0 {
                shared_unsplit_fallbacks::empty_adopt(self, other, context);
            } else if other.cap == 0 {
                shared_unsplit_fallbacks::empty_other(self, other, context);
            } else {
                // Move the old owner out without running Drop on an unarmed placeholder.
                let empty = BytesMut {
                    ptr: crate::ownership_proof::raw_vec::BoundPtr::unbound(NonNull::dangling()),
                    len: 0, cap: 0, data: invalid_ptr(KIND_VEC),
                    unique_at_zero: ghost! { None }, pending_control: ghost! { None },
                    shared_registration: ghost! { None }, shared_context: ghost! { None },
                };
                let old = mem::replace(self, empty);
                let output = shared_unsplit_fallbacks::copy_concat(old, other, context);
                mem::forget(mem::replace(self, output));
            }
        }
        #[cfg(bytes_proof_unsplit_independent)]
        {
            if self.len == 0 {
                let previous = mem::replace(self, other);
                let _ = previous.proof_carrier_release(context);
            } else if other.cap == 0 {
                let _ = other.proof_carrier_release(other_context);
            } else {
                let empty = BytesMut {
                    ptr: crate::ownership_proof::raw_vec::BoundPtr::unbound(NonNull::dangling()),
                    len: 0, cap: 0, data: invalid_ptr(KIND_VEC),
                    unique_at_zero: ghost! { None }, pending_control: ghost! { None },
                    shared_registration: ghost! { None }, shared_context: ghost! { None },
                };
                let previous = mem::replace(self, empty);
                let output = shared_unsplit_independent::independent_concat(previous, other, context, other_context);
                mem::forget(mem::replace(self, output));
            }
        }
        #[cfg(bytes_proof_unsplit_mixed)]
        {
            ghost!{shared_unsplit_mixed::empty_metadata_bits();};
            if self.len == 0 {
                let previous = mem::replace(self, other);
                if previous.kind() == KIND_VEC { shared_unsplit_mixed::retire_unique(previous); }
                else { let _ = previous.proof_carrier_release(context); }
            } else if other.cap == 0 {
                if other.kind() == KIND_VEC { shared_unsplit_mixed::retire_unique(other); }
                else { let _ = other.proof_carrier_release(context); }
            } else {
                let output = shared_unsplit_mixed::copy_pair(self, &other);
                let previous = mem::replace(self, output);
                shared_unsplit_mixed::retire_pair(previous, other, context);
            }
        }
        #[cfg(bytes_proof_unsplit_unique)]
        {
            if self.len == 0 {
                shared_unsplit_mixed::retire_unique(mem::replace(self, other));
            } else if other.cap == 0 {
                shared_unsplit_mixed::retire_unique(other);
            } else {
                let output = shared_unsplit_mixed::copy_pair(self, &other);
                shared_unsplit_mixed::retire_unique(mem::replace(self, output));
                shared_unsplit_mixed::retire_unique(other);
            }
        }
        #[cfg(not(any(bytes_proof_adjacent_unsplit, bytes_proof_unsplit_fallbacks, bytes_proof_unsplit_independent, bytes_proof_unsplit_mixed, bytes_proof_unsplit_unique)))]
        {
        if self.is_empty() {
            *self = other;
            return;
        }

        if let Err(other) = self.try_unsplit(other) {
            self.extend_from_slice(other.as_ref());
        }
        }
    }
    // BEGIN EXACT CARRIER SPLIT METHODS
    #[cfg(all(creusot, bytes_proof_repeated_split))]
    #[logic(prophetic)]
    fn proof_carrier_initialized(self) -> bool {
        pearlite! { self.proof_owned_valid() &&
            forall<index: Int> self.ptr@.unwrap_logic().2 <= index &&
                index < self.ptr@.unwrap_logic().2 + self.len@ ==>
                crate::ownership_proof::raw_vec::slot_known(self.proof_owned_slot(index)) }
    }

    /// A change of coordinates, with the same physical slots and ownership.
    #[cfg(all(any(creusot, bytes_proof_probe), bytes_proof_repeated_split))]
    #[cfg_attr(creusot, check(ghost))]
    #[cfg_attr(creusot, ensures((*handle).proof_initialized() == (*handle).proof_carrier_initialized()))]
    fn proof_initialization_coordinates(handle: Snapshot<Self>) {
        proof_assert!(forall<index: Int> (*handle).proof_view_slot(index) ==
            (*handle).proof_owned_slot(handle.ptr@.unwrap_logic().2 + index));
        proof_assert!(forall<index: Int> (*handle).proof_owned_slot(index) ==
            (*handle).proof_view_slot(index - handle.ptr@.unwrap_logic().2));
    }


    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().packet.1.lo() == self.ptr@.unwrap_logic().2 + at@))]
    #[cfg_attr(creusot, ensures(result.shared_registration.inner_logic().unwrap_logic().packet.1.lo() ==
        if self.pending_control.inner_logic() != None { 0int } else { self.shared_registration.inner_logic().unwrap_logic().packet.1.lo() }))]
    #[cfg(all(any(creusot, bytes_proof_probe), bytes_proof_repeated_split))]
    #[cfg_attr(creusot, requires(self.proof_carrier_pending() && at <= self.len))]
    #[cfg_attr(creusot, ensures((^self).proof_carrier_pair(result)))]
    #[cfg_attr(creusot, ensures(result.ptr@ == self.ptr@ && (^self).ptr@ == Some((self.ptr@.unwrap_logic().0, self.ptr@.unwrap_logic().1, self.ptr@.unwrap_logic().2 + at@))))]
    #[cfg_attr(creusot, ensures(result.len == at && (^self).len@ == self.len@ - at@ && result.cap == at && (^self).cap@ == self.cap@ - at@))]
    #[cfg_attr(creusot, ensures((^self).proof_initialized() && result.proof_initialized()))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < at@ ==> result.proof_view_slot(index) == self.proof_carrier_slot(self.ptr@.unwrap_logic().2 + index)))]
    #[cfg_attr(creusot, ensures(forall<index: Int> 0 <= index && index < self.len@ - at@ ==> (^self).proof_view_slot(index) == self.proof_carrier_slot(self.ptr@.unwrap_logic().2 + index + at@)))]
    #[cfg_attr(creusot, ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.valid() && registration.control == self.shared_registration.inner_logic().unwrap_logic().control &&
        crate::ownership_proof::scalable_tickets::packet_matches(registration.packet, *self.shared_context.inner_logic().unwrap_logic().status) &&
        registration.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            registration.matches((^self).shared_context.inner_logic().unwrap_logic())))]
    #[cfg_attr(creusot, ensures((* (^self).shared_context.inner_logic().unwrap_logic().status.pending).len() ==
        if self.pending_control.inner_logic() != None { 2int } else { (*self.shared_context.inner_logic().unwrap_logic().status.pending).len() + 1 }))]
    #[cfg_attr(creusot, ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.valid() && registration.control == self.shared_registration.inner_logic().unwrap_logic().control &&
        crate::ownership_proof::scalable_tickets::packet_matches(registration.packet, *self.shared_context.inner_logic().unwrap_logic().status) ==>
            registration.packet.0.logical_id() != (^self).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
            registration.packet.0.logical_id() != result.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(creusot, requires(other.ptr == self.ptr && other.len == self.len && other.cap == self.cap && other.data == self.data))]
    #[cfg_attr(creusot, requires(other.unique_at_zero.inner_logic() == None && other.pending_control.inner_logic() == None && other.shared_registration.inner_logic() == None && other.shared_context.inner_logic() == None))]
    #[cfg_attr(creusot, requires(forall<index: Int> self.ptr@.unwrap_logic().2 <= index && index < self.ptr@.unwrap_logic().2 + self.len@ ==>
        crate::ownership_proof::raw_vec::slot_known(self.proof_carrier_slot(index))))]
    #[cfg_attr(creusot, ensures((^self).proof_carrier_initialized() && result.proof_carrier_initialized()))]
    fn proof_finish_carrier_split(&mut self, mut other: Self, at: usize) -> Self {
        self.proof_register_carrier_split(&mut other, at);
        unsafe { self.advance_unchecked(at); }
        other.cap = at;
        other.len = at;
        ghost! { Self::proof_initialization_coordinates(snapshot!(*self)); };
        ghost! { Self::proof_initialization_coordinates(snapshot!(other)); };
        other
    }


    #[cfg(all(creusot, bytes_proof_repeated_split))]
    #[logic(prophetic)]
    fn proof_carrier_ready(self) -> bool {
        pearlite! {
            self.proof_carrier_initialized() && (self.proof_unique_at_zero_valid() ||
                match (self.shared_registration.inner_logic(), self.shared_context.inner_logic()) {
                    (Some(registration), Some(context)) => registration.matches(context) &&
                        (*context.status.pending).len() < isize::MAX@,
                    _ => false,
                })
        }
    }

    #[cfg(all(creusot, bytes_proof_repeated_split))]
    #[logic(prophetic)]
    fn proof_carrier_pending(self) -> bool {
        pearlite! {
            self.proof_pending_valid() || (self.proof_registered_valid() &&
                match (self.shared_registration.inner_logic(), self.shared_context.inner_logic()) {
                    (Some(registration), Some(context)) => registration.matches_incremented(context),
                    _ => false,
                })
        }
    }

    #[cfg(all(creusot, bytes_proof_repeated_split))]
    #[logic]
    fn proof_carrier_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! {
            match self.pending_control.inner_logic() {
                Some(pending) => pending.caps.1.slot(index),
                None => self.proof_owned_slot(index),
            }
        }
    }

    #[cfg(all(creusot, bytes_proof_repeated_split))]
    #[logic(prophetic)]
    fn proof_carrier_pair(self, other: Self) -> bool {
        pearlite! {
            self.proof_registered_valid() && other.proof_registered_valid() &&
            other.shared_context.inner_logic() == None &&
            self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() !=
                other.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
            match self.shared_context.inner_logic() {
                Some(context) => self.shared_registration.inner_logic().unwrap_logic().matches(context) &&
                    other.shared_registration.inner_logic().unwrap_logic().matches(context),
                None => false,
            }
        }
    }

    #[cfg_attr(creusot, ensures((^other).shared_registration.inner_logic().unwrap_logic().packet.1.lo() ==
        if self.pending_control.inner_logic() != None { 0int } else { self.shared_registration.inner_logic().unwrap_logic().packet.1.lo() }))]
    #[cfg(all(any(creusot, bytes_proof_probe), bytes_proof_repeated_split))]
    #[cfg_attr(creusot, requires(self.proof_carrier_pending() && at <= self.cap))]
    #[cfg_attr(creusot, requires(other.ptr == self.ptr && other.len == self.len && other.cap == self.cap && other.data == self.data))]
    #[cfg_attr(creusot, requires(other.unique_at_zero.inner_logic() == None && other.pending_control.inner_logic() == None && other.shared_registration.inner_logic() == None && other.shared_context.inner_logic() == None))]
    #[cfg_attr(creusot, ensures((^self).ptr == self.ptr && (^self).len == self.len && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(creusot, ensures((^other).ptr == other.ptr && (^other).len == other.len && (^other).cap == other.cap && (^other).data == other.data))]
    #[cfg_attr(creusot, ensures((^self).unique_at_zero.inner_logic() == None && (^self).pending_control.inner_logic() == None))]
    #[cfg_attr(creusot, ensures((^other).unique_at_zero.inner_logic() == None && (^other).pending_control.inner_logic() == None && (^other).shared_context.inner_logic() == None))]
    #[cfg_attr(creusot, ensures((^self).shared_context.inner_logic() != None && (^self).shared_registration.inner_logic() != None && (^other).shared_registration.inner_logic() != None))]
    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().matches((^self).shared_context.inner_logic().unwrap_logic()) &&
        (^other).shared_registration.inner_logic().unwrap_logic().matches((^self).shared_context.inner_logic().unwrap_logic())))]
    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().control.pointer == self.data &&
        (^other).shared_registration.inner_logic().unwrap_logic().control.pointer == self.data))]
    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().status.allocation == self.ptr@.unwrap_logic().0 &&
        (^self).shared_registration.inner_logic().unwrap_logic().status.capacity == self.ptr@.unwrap_logic().1 &&
        (^other).shared_registration.inner_logic().unwrap_logic().status.allocation == self.ptr@.unwrap_logic().0 &&
        (^other).shared_registration.inner_logic().unwrap_logic().status.capacity == self.ptr@.unwrap_logic().1))]
    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().packet.1.lo() == self.ptr@.unwrap_logic().2 + at@ &&
        (^self).shared_registration.inner_logic().unwrap_logic().packet.1.hi() == self.ptr@.unwrap_logic().2 + self.cap@))]
    #[cfg_attr(creusot, ensures((^other).shared_registration.inner_logic().unwrap_logic().packet.1.lo() <= self.ptr@.unwrap_logic().2 &&
        (^other).shared_registration.inner_logic().unwrap_logic().packet.1.hi() == self.ptr@.unwrap_logic().2 + at@))]
    #[cfg_attr(creusot, ensures((^self).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() !=
        (^other).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    #[cfg_attr(creusot, ensures(forall<index: Int> self.ptr@.unwrap_logic().2 <= index && index < self.ptr@.unwrap_logic().2 + at@ ==>
        (^other).proof_owned_slot(index) == self.proof_carrier_slot(index)))]
    #[cfg_attr(creusot, ensures(forall<index: Int> self.ptr@.unwrap_logic().2 + at@ <= index && index < self.ptr@.unwrap_logic().2 + self.cap@ ==>
        (^self).proof_owned_slot(index) == self.proof_carrier_slot(index)))]
    #[cfg_attr(creusot, ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.valid() &&
        registration.control == self.shared_registration.inner_logic().unwrap_logic().control &&
        crate::ownership_proof::scalable_tickets::packet_matches(registration.packet, *self.shared_context.inner_logic().unwrap_logic().status) &&
        registration.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            registration.matches((^self).shared_context.inner_logic().unwrap_logic())))]
    #[cfg_attr(creusot, ensures((* (^self).shared_context.inner_logic().unwrap_logic().status.pending).len() ==
        if self.pending_control.inner_logic() != None { 2int } else { (*self.shared_context.inner_logic().unwrap_logic().status.pending).len() + 1 }))]
    #[cfg_attr(creusot, ensures(forall<registration: sequential_shared_control::HandleRegistration>
        self.shared_context.inner_logic() != None && registration.valid() &&
        crate::ownership_proof::scalable_tickets::packet_matches(registration.packet, *self.shared_context.inner_logic().unwrap_logic().status) ==>
            registration.packet.0.logical_id() != (^self).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() &&
            registration.packet.0.logical_id() != (^other).shared_registration.inner_logic().unwrap_logic().packet.0.logical_id()))]
    fn proof_register_carrier_split(&mut self, other: &mut Self, at: usize) {
        let pointer = self.data;
        let base = self.ptr;
        let capacity = self.cap;
        let cut = snapshot!(self.ptr@.unwrap_logic().2 + at@);
        let assigned = ghost! {
            if let Some(pending) = self.pending_control.take() {
                sequential_shared_control::activate(pointer, base, capacity, cut, Ghost::new(pending)).into_inner()
            } else {
                let parent = self.shared_registration.take().unwrap();
                let mut context = self.shared_context.take().unwrap();
                let children = sequential_shared_control::split_more(Ghost::new(&mut context), Ghost::new(parent), cut);
                let (left, right) = children.into_inner();
                (context, left, right)
            }
        };
        let (context, left, right) = assigned.split();
        self.shared_context = ghost! { Some(context.into_inner()) };
        other.shared_registration = ghost! { Some(left.into_inner()) };
        self.shared_registration = ghost! { Some(right.into_inner()) };
    }


    #[cfg(all(any(creusot, bytes_proof_probe), bytes_proof_repeated_split))]
    #[cfg_attr(creusot, requires(self.proof_registered_valid() && self.shared_context.inner_logic() == None))]
    #[cfg_attr(creusot, requires(self.shared_registration.inner_logic().unwrap_logic().matches(*context.inner_logic())))]
    #[cfg_attr(creusot, ensures((^context.inner_logic()).valid(self.shared_registration.inner_logic().unwrap_logic().control)))]
    #[cfg_attr(creusot, ensures(result == !(^context.inner_logic()).active()))]
    #[cfg_attr(creusot, ensures((* (^context.inner_logic()).status.pending).len() + 1 == (*context.inner_logic().status.pending).len()))]
    #[cfg_attr(creusot, ensures(forall<registration: sequential_shared_control::HandleRegistration>
        registration.matches(*context.inner_logic()) &&
        registration.packet.0.logical_id() != self.shared_registration.inner_logic().unwrap_logic().packet.0.logical_id() ==>
            registration.matches(^context.inner_logic())))]
    #[cfg_attr(creusot, ensures(result == ((*context.inner_logic().status.pending).len() == 1)))]
    fn proof_carrier_release(mut self, context: Ghost<&mut sequential_shared_control::ControlContext>) -> bool {
        let registration = ghost! { self.shared_registration.take().unwrap() };
        let identity = ghost! { registration.control.identity.into_inner() };
        let control = sequential_shared_control::ControlPtr { pointer: self.data, identity };
        // Suppress automatic cleanup before entering the consuming release.
        // From here the protocol alone owns cleanup, even if it unwinds.
        mem::forget(self);
        sequential_shared_control::release(control, context, registration)
    }

}
#[cfg(not(creusot))]
impl Drop for SharedBuffer {
    fn drop(&mut self) {
        // u8 has no destructor; deallocation does not require initialized bytes.
        unsafe { crate::allocation_ops::deallocate_u8(self.base.as_ptr(), self.capacity); }
    }
}#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_reclaim.rs"]
pub(crate) mod shared_reclaim;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_copy.rs"]
pub(crate) mod shared_copy;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_reserve.rs"]
pub(crate) mod shared_reserve;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_unsplit_fallbacks.rs"]
pub(crate) mod shared_unsplit_fallbacks;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_unsplit_independent.rs"]
pub(crate) mod shared_unsplit_independent;
#[path = "/workspace/rust-crate-proofs/bytes/1.11.1/src/ownership_proof/shared_unsplit_mixed.rs"]
pub(crate) mod shared_unsplit_mixed;
use shared_unsplit_mixed::{retire_unique,initial_coordinates};
#[ensures((result.proof_initialized() && result.proof_unique_owned()) || result.proof_empty_valid())]
#[ensures(result.len@<=input@.len())]
fn prepare_unique(input:Vec<u8>,advance:usize,canonical:bool)->BytesMut{
 let mut unique=BytesMut::from_vec(input);
 ghost!{initial_coordinates(snapshot!(unique));};
 let count=cmp::min(advance,cmp::min(unique.cap,MAX_VEC_POS));
 unsafe{unique.advance_unchecked(count);}
 if canonical {
  let empty=BytesMut{ptr:crate::ownership_proof::raw_vec::BoundPtr::unbound(NonNull::dangling()),len:0,cap:0,data:invalid_ptr(KIND_VEC),
   unique_at_zero:ghost!{None},pending_control:ghost!{None},shared_registration:ghost!{None},shared_context:ghost!{None}};
  retire_unique(mem::replace(&mut unique,empty));
 }
 unique
}
#[cfg(not(feature="unique_pair"))]
#[requires(a@.len()+b@.len()<=isize::MAX@)]
pub(crate) fn mixed_caller(a:Vec<u8>,b:Vec<u8>,unique_left:bool,advance:usize,canonical:bool){
 let unique=prepare_unique(a,advance,canonical);let mut shared=BytesMut::from_vec(b);
 ghost!{initial_coordinates(snapshot!(shared));};
 let empty=shared.split_to(0);let mut context=shared.proof_take_coordinator();
 assert!(!empty.proof_carrier_release(context.borrow_mut()));
 let (mut left,right)=if unique_left{(unique,shared)}else{(shared,unique)};
 #[cfg(not(creusot))]
 let expected={let mut v=if left.len==0{Vec::new()}else{left.as_slice().to_vec()};if right.len>0{v.extend_from_slice(right.as_slice());}v};
 left.unsplit(right,context.borrow_mut());
 let output=left;
 #[cfg(not(creusot))]
 if output.len==0 {assert!(expected.is_empty());}else{assert_eq!(output.as_slice(),expected.as_slice());}
 if output.kind()==KIND_VEC {retire_unique(output);proof_assert!(!context.active());}
 else {assert!(output.proof_carrier_release(context.borrow_mut()));}
}
#[cfg(feature="unique_pair")]
#[requires(a@.len()+b@.len()<=isize::MAX@)]
pub(crate) fn unique_caller(a:Vec<u8>,b:Vec<u8>,advance:usize,left_empty:bool,right_empty:bool){
 let mut left=prepare_unique(a,advance,left_empty);let right=prepare_unique(b,advance,right_empty);
 #[cfg(not(creusot))]
 let expected={let mut v=if left.len==0{Vec::new()}else{left.as_slice().to_vec()};if right.len>0{v.extend_from_slice(right.as_slice());}v};
 left.unsplit(right);
 let output=left;
 #[cfg(not(creusot))]
 if output.len==0 {assert!(expected.is_empty());}else{assert_eq!(output.as_slice(),expected.as_slice());}
 retire_unique(output);
}
