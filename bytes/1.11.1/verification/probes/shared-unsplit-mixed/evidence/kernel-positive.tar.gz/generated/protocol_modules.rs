#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-unsplit-mixed-c3f131173c0cc13e/out/scalable_tickets.rs"]
mod scalable_tickets;
