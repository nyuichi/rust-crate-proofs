# AO: original owner retires before its surviving promoted child

Development increment after audited AN `5f3d20a3005b727ace827685d0601d791d180f78`.
The complete original bytes 1.11.1 architecture remains **NOT ADMITTED**.

The native witness constructs a nonempty Box-backed Bytes, clones it once,
drops the original at inner scope exit, reads the surviving child, saves the
returned Vec, and drops the child on normal return. The proof includes both
native tag parities. Native execution tests corroborate the client behavior;
they do not establish allocator parity or prove the Rust memory model.

The distinguishing transition consumes the complete original PromotionScope,
including its owned pointer history and root resources. It returns only a
DetachedScope containing an affine observation cursor. The existing proved
State::on_release body seals the actual root recovery authority into private
state. The last child's release and final Acquire recover that authority and
perform both physical frees. No recovery capability, root core, pointer
permission, or private state is hidden inside the surviving scope. Its logical
observations do not extract resources. The nonfinal helper is stated for an
actual ledger length greater than one; the client derives its two actual owners.

The first diagnostic positive run passes 125 targets / 983 prover leaves /
0 null and 0 structural leaves. It deliberately skips the correspondence gate
and is not canonical admission. Deliberate controls, exact source/native
correspondence and an independently audited feature-free archive are required
before publication of the completed increment. See evidence and TCB.md.

The inherited AN prefix and support sources remain byte-pinned. Generic
physical, synchronization, provenance, callback erasure and normal Drop
compiler boundaries are explicit. Root retirement and surviving-child ownership,
lastness and reclamation laws are proved bodies, not new trusted contracts.

Concurrency, CAS losers, unwind, allocation failure, arbitrary escaping clients,
other original APIs and build configurations remain open. A successful AO gate
does not imply full-crate verification. After each audited published increment,
ask Astra 「次何するのがいい？」 and execute the next recommendation.

The pinned tools live outside evidence archives. Captures include source,
configuration, tool hashes, private Std, native MIR and actual Cargo compiled
inputs. Why3 executes under the common lock, one prover and 1024 MiB, with
sc-drf disabled. Archive replay of location-bound Cargo OUT_DIR is documented
rather than represented as a portable standalone toolchain.
