# Tokenless sharing distinguishing experiment

Baseline 8bed373b. Plan recorded before source: stock GhostShared is a changed
premise versus frozen mutable ticket splitting through a shared receiver.
Consume an actual Vec with existing B1; irreversibly share its actual sealed
Recovery/PhysicalRegion; copy the immutable witness through &self; prove two B4
reads observe the input bytes. Retain the allocation without a competing Vec
owner or deallocation. No alternative production buffer/API or bytes protocol.

Negative: attempt moving capabilities out of `*shared.to_ref()` to invoke B3.
This tests extraction from a remaining local shared value, NOT proven lastness:
GhostShared is Copy and has no last-handle tracking. Expected Rust rejection.

Stock GhostShared and B1/B4 are existing generic TCB. No project trusted function
is added. Positive is immutable observation only; resource registration,
actual refcount updates, reclaim, Send/Sync and original Bytes Clone are outside
its claim. Source audit covers other existing stock candidates separately.
One interface review for a failed shape; stop rather than changing timeouts.
