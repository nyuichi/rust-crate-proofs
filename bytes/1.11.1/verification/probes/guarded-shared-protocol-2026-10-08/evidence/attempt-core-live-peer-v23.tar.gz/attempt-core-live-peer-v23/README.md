# Guarded shared protocol core

This probe combines quota-free logical ticket registration with arbitrary-order
Release retirement and typed payload recovery. Logical ticket IDs are monotonic
and sparse: registration inserts the next ID, while retirement removes the ID
carried by its affine ticket. The protocol keeps the atomic count equal to the
live-map cardinality and bounds it by `MAX_REF_COUNT + 1`.

The generic event adapter commits one state transition only for a successful
guarded Relaxed RMW. A refused overflow observation makes no store and runs no
callback. The registration callback uses the returned successful old value;
the shared Release RMW carries predecessor publication without acquiring it;
only the last Release followed by an Acquire can synchronize the `AtView`
payload and recover the full `LifetimeToken`. The native guard implementation
is shared with `src/ref_count_limit.rs` and is audited separately from this
Creusot protocol.

The default target is the strong generic lifecycle core. `Registry::new`
guarantees the initial ID is zero, its public metadata equals the payload
metadata, and the initial ticket's two lifetime fractions sum to one. The
default proof gate is `./run-proof.sh`; it serializes Why3 through
`/tmp/itoa-creusot-proof.lock`, uses one prover with a 1024 MiB limit, and
keeps `sc-drf` disabled.

`evidence/attempt-combined-core-v22-canonical-36-proof-capture.tar.gz`
is the canonical captured proof artifact for the current default-core source.
It contains all 36 generated `.coma` files and all 36 `proof.json` files,
source and external inputs, configuration, run log, and SHA-256 manifest. Its
adjacent `.sha256` file verifies the archive. The v16 and v20 archives are
retained as historical evidence for preceding core revisions.

The `driver` feature is default-off. Its multi-clone sparse-hole scenario is
retained as a separate proof challenge, not counted as passed coverage. The
current `Registry::retire` API only reports whether its atomic event observed
the last reference and returns typed recovery conditionally; it does not carry
a completeness receipt showing that a particular client owns every live
ticket. Accordingly, the driver does not claim a final last retirement until a
body-proved completeness capability is available.

The `negative_core_lost_insert`, `negative_core_lost_removal`,
`negative_core_missing_acquire`, and `negative_core_duplicate_ticket` features
are proof-failure controls. Each is run as a separate attempt; a failure is
useful only when its captured translation and proof diagnostics identify the
omitted protocol obligation rather than a parser or build error.
