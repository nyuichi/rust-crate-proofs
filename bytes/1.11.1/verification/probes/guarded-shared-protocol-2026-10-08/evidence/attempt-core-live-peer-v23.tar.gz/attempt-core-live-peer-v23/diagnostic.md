# Live-peer proof attempt v23

Compilation and translation pass. The default full proof gate reached the new
`State::on_release_with_live_peer` callback composition and proved 28 of 29
leaves. Exact null task 19,4 is the helper's promised SyncView monotonicity
`current <= ^current`. The delegated `on_release` contract did not yet export
the monotonic-view postcondition already established by the Release RMW body.
This is a missing callback contract, not a lifecycle-state or live-peer
failure. Preserve this attempt; the next source revision adds that callback
postcondition and reruns the full gate.
