# Guarded shared lifecycle proof, v24

This frozen run contains the exact current source and external modules for the
default generic protocol proof. Compilation and translation passed, then all 37
generated proof files passed with one prover, a 1024 MiB limit, and `sc-drf`
disabled. The default gate excludes the separate `driver` and negative-control
features.

The source uses the generic successful guarded Relaxed RMW, quota-free sparse
logical IDs, release publication carry, and last Acquire/AtView recovery. The
new `State::on_release_with_live_peer` callback consumes one real retirement
receipt and a separately borrowed valid peer ticket. It proves fragment
identity separates the IDs, the retirement removes exactly its own map key,
and the peer remains live, so no recovery can be returned for that event. It
makes no exact counter assertion. The composed callback postconditions expose
the map removal, pending-implies-empty fact, and SyncView monotonicity required
for client proofs.

`input-SHA256SUMS` pins all proof inputs before the run; `SHA256SUMS` covers
this full capture, including generated COMA and proof JSON. The source archive
and outer tar archive each have adjacent SHA-256 receipts.
