Exact Why3 tasks emitted from attempt-combined-driver-v12's failed Coma tree.
Branches for `vc_three_clones_sparse_hole_mixed_retirement`:
9, 10, 11, 13, 16, 18, 20, 22, 24, 27, 31,0.
The output task printer source and effective task config are included.
