# Private standard-library source receipt

This sidecar pins the external `creusot-std` 0.13.0 package used by the v24
proof. The complete package source archive and its 110-file SHA-256 manifest
are stored as sibling evidence files named in `receipt.json`. This compact
sidecar records their hashes, the exact Cargo metadata package path, feature
tree, and timing relation to the proof run. All source mtimes predate the
proof-run log creation timestamp.
