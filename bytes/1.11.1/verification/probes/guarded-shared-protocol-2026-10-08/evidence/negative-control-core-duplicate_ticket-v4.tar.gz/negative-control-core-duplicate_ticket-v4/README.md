# Duplicate-ticket negative control

This is an immutable feature run of `negative_core_duplicate_ticket` against
its captured source snapshot. Compilation and Creusot translation passed; the
proof failed at the intended duplicate-issuance precondition.

The exact null task is generated from
`generated/bytes_guarded_shared_protocol_rlib/lifecycle/negative_duplicate_ticket.coma`
with `vc_negative_duplicate_ticket_T` path `6,1`. It shows the authority map
contains `ticket.id` after the fragment lemma, while the attempted `issue`
requires that key to be absent. Thus the deliberate duplicate insertion is
rejected by the body-proved issuance contract.

`full-run.log`, `runner-status.txt`, source snapshot, external proof modules,
Why3 configuration, generated COMA and proof JSON, exact-task printer and its
invocation output are preserved. `input-SHA256SUMS` records proof inputs;
`capture-SHA256SUMS` records the complete capture contents other than itself.
The adjacent archive checksum verifies the transport archive.
