//! Bounded original-shaped lifecycle: one source ticket and one affine clone quota.
//! No bytes-specific trusted functions. Native atomic events live in event.rs.
use super::*;
use creusot_std::{ghost::{invariant::Protocol,resource::{Resource,Authority,Fragment}},
    logic::{Id,FMap,real::Real,ra::{RA,excl::Excl,agree::Ag,auth::CancelLocalUpdateUnit}},
    std::sync::view::ReleaseSyncView};
use crate::fraction_map::{self as fm,LiveFractions};

pub trait RecoveryPayload {
    type Metadata;
    #[logic] fn metadata(self)->Self::Metadata;
    #[logic(prophetic)] fn wellformed(self)->bool;
}
pub struct Ticket<T:RecoveryPayload> {
    pub token:LifetimeToken, pub(crate) id:Int, pub(crate) fragment:Fragment<LiveFractions>, pub(crate) recovery:Option<T>,
}
pub struct CloneQuota {resource:Resource<Option<Excl<()>>>}
pub struct Receipt {fragment:Fragment<Option<Ag<bool>>>,left:bool}
impl Receipt {#[logic] pub fn left(self)->bool {self.left}}
type Publication<T>=Option<Ag<(Int,AtView<Option<T>>)>>;
pub struct State<T:RecoveryPayload> {
    own:Perm<ModelAtomic>,first:Int,latest:Int,
    alive:Authority<LiveFractions>, next:Int,
    quota:Resource<Option<Excl<()>>>,
    lifetime:Lifetime, pool:Option<LifetimeToken>,
    expected:Snapshot<T::Metadata>,
    recovery:Option<AtView<Option<T>>>, withdrawn:bool,
    publication:Authority<Publication<T>>,
    left_done:Authority<Option<Ag<bool>>>,right_done:Authority<Option<Ag<bool>>>,
}
impl<T:RecoveryPayload> Protocol for State<T> {
    type Public=(ModelAtomic,Id,Id,Lifetime,T::Metadata,Id,Id,Id);
    #[logic] fn public(self)->Self::Public {(*self.own.ward(),self.alive.id(),self.quota.id(),self.lifetime,*self.expected,self.publication.id(),self.left_done.id(),self.right_done.id())}
    #[logic(prophetic)] fn protocol(self)->bool {pearlite! {
        1<=self.next && self.next<=2 && fm::ids_bounded(self.alive@,self.next) &&
        self.alive@.len()<=self.next &&
        self.own.val().get(self.latest)!=None &&
        self.own.val()[self.latest].0@==self.alive@.len() &&
        self.first<=self.latest &&
        (forall<t:Int> self.own.val().get(t)!=None == (self.first<=t && t<=self.latest)) &&
        (self.quota@ == if self.next==1 {None}else{Some(Excl(()))}) &&
        (self.withdrawn == (self.alive@.len()==0)) &&
        ((self.pool==None)==self.withdrawn) &&
        (self.pool!=None ==> self.pool.unwrap_logic().lft()==self.lifetime &&
            self.pool.unwrap_logic().frac().to_real()+fm::sum_prefix(self.alive@,self.next)==Real::from_int(1)) &&
        ((self.left_done@==None)==self.alive@.contains(0)) &&
        ((self.right_done@==None)==(self.next==1 || self.alive@.contains(1))) &&
        (match (self.left_done@,self.right_done@) {
            (Some(l),Some(r))=>l.0!=r.0,
            (Some(l),None)=>l.0==(self.next==1),
            (None,Some(r))=>!r.0,
            (None,None)=>true
        }) &&
        (if self.withdrawn {self.recovery==None} else {
            ((self.recovery==None)==self.alive@.contains(0)) &&
            (self.recovery!=None ==> self.recovery.unwrap_logic().val()!=None &&
                self.recovery.unwrap_logic().val().unwrap_logic().wellformed() &&
                self.recovery.unwrap_logic().val().unwrap_logic().metadata()==*self.expected &&
                self.recovery.unwrap_logic().view()<=self.own.val()[self.latest].1)
        }) &&
        ((self.publication@!=None)==self.withdrawn) &&
        (self.publication@!=None ==> self.publication@.unwrap_logic().0.0==self.latest &&
            self.publication@.unwrap_logic().0.1.view()==self.own.val()[self.latest].1)
    }}
}
impl<T:RecoveryPayload> EventProtocol for State<T> {
    #[logic] fn atomic(self)->ModelAtomic {*self.own.ward()}
}
impl<T:RecoveryPayload> Ticket<T> {
    #[logic(open(crate),prophetic)] pub fn valid(self,public:<State<T> as Protocol>::Public)->bool {pearlite! {
        0<=self.id && self.id<2 && self.fragment.id()==public.1 &&
        self.fragment@==FMap::singleton(self.id,Excl(self.token.frac())) && self.token.lft()==public.3 &&
        (if self.id==0 {self.recovery!=None && self.recovery.unwrap_logic().wellformed() &&
            self.recovery.unwrap_logic().metadata()==public.4} else {self.recovery==None})
    }}
}
impl CloneQuota {
    #[logic] fn valid(self,id:Id)->bool {pearlite! {self.resource.id()==id && self.resource@==Some(Excl(()))}}
}
#[check(ghost)]
#[requires(!auth@.contains(*id))]
#[ensures((^auth)@==auth@.insert(*id,Excl(*fraction)))]
#[ensures(result@==FMap::singleton(*id,Excl(*fraction)))]
#[ensures(result.id()==auth.id() && (^auth).id()==auth.id())]
fn issue(auth:&mut Authority<LiveFractions>,id:Snapshot<Int>,fraction:Snapshot<PositiveReal>)->Fragment<LiveFractions> {
    let before=snapshot!(auth@);
    let one=snapshot!(FMap::singleton(*id,Excl(*fraction)));
    proof_assert!(forall<k:Int> (*before).get(k).op((*one).get(k))!=None);
    let result=auth.add_fragment(one);
    proof_assert!(auth@.ext_eq((*before).insert(*id,Excl(*fraction))));
    result
}
#[check(ghost)]
#[requires(fragment.id()==auth.id() && fragment@==FMap::singleton(*id,Excl(*fraction)))]
#[ensures((^auth)@==auth@.remove(*id))]
#[ensures(auth@.get(*id)==Some(Excl(*fraction)))]
#[ensures((^auth).id()==auth.id())]
fn remove(auth:&mut Authority<LiveFractions>,mut fragment:Fragment<LiveFractions>,id:Snapshot<Int>,fraction:Snapshot<PositiveReal>) {
    auth.frag_lemma(&fragment);
    let before=snapshot!(auth@);
    proof_assert!({fm::singleton_ticket_factor(*before,*id,*fraction); true});
    auth.update(&mut fragment,CancelLocalUpdateUnit);
}

pub struct Registry<T:RecoveryPayload> {atomic:EventAtomic<State<T>>}
impl<T:RecoveryPayload> Registry<T> {
    #[logic] pub fn public(self)-><State<T> as Protocol>::Public {self.atomic.public()}
    #[logic] fn valid(self)->bool {self.public().0==self.atomic.model()}
    #[logic] fn receipt(self,r:Receipt,last:bool)->bool {pearlite! {
        r.fragment.id()==if r.left {self.public().6}else{self.public().7} && r.fragment@==Some(Ag(last))
    }}
    #[requires(payload.wellformed())]
    #[requires(full.frac()==PositiveReal::from_int(1))]
    #[ensures(result.0.valid())]
    #[ensures(result.0.public().3==full.lft() && result.0.public().4==payload.metadata())]
    #[ensures(result.1.inner_logic().valid(result.0.public()))]
    #[ensures(result.2.inner_logic().valid(result.0.public().2))]
    pub fn new(payload:Ghost<T>,full:Ghost<LifetimeToken>)->(Self,Ghost<Ticket<T>>,Ghost<CloneQuota>) {
        let mut current=ghost! {SyncView::new().into_inner()};
        let (raw,own)=RawAtomic::new(1,current.borrow_mut());
        let setup=ghost! {
            let (first,pool)=full.into_inner().split();
            let mut alive=Authority::alloc().into_inner();
            let fragment=issue(&mut alive,snapshot!(0),snapshot!(first.frac()));
            let all=Resource::alloc(snapshot!(Some(Excl(())))).into_inner();
            let (quota,empty)=all.split(snapshot!(Some(Excl(()))),snapshot!(None));
            let expected=snapshot!(payload.metadata());
            let latest:Snapshot<Int>=snapshot!(raw.model().get_timestamp(*current));
            let lifetime:Snapshot<Lifetime>=snapshot!(pool.lft());
            let ticket=Ticket{id:0int,fragment,token:first,recovery:Some(payload.into_inner())};
            let state=State{own:own.into_inner(),first:latest.into_ghost().into_inner(),latest:latest.into_ghost().into_inner(),
                alive,next:1int,quota:empty,lifetime:lifetime.into_ghost().into_inner(),pool:Some(pool),expected,
                recovery:None,withdrawn:false,publication:Authority::alloc().into_inner(),
                left_done:Authority::alloc().into_inner(),right_done:Authority::alloc().into_inner()};
            (state,(ticket,CloneQuota{resource:quota}))
        };
        let (state,rest)=setup.split();let (first,quota)=rest.split();
        (Self{atomic:EventAtomic::bind(raw,state)},first,quota)
    }

    #[requires(self.valid() && source.valid(self.public()) && quota.valid(self.public().2))]
    #[ensures(result.0==1usize && result.1.inner_logic().valid(self.public()))]
    #[ensures(result.1.inner_logic().id==1 && source.id==0)]
    pub fn clone_bounded(&self,source:Ghost<&Ticket<T>>,quota:Ghost<CloneQuota>)->(usize,Ghost<Ticket<T>>) {
        let mut current=ghost! {SyncView::new().into_inner()};
        let release=ghost! {ReleaseSyncView::new().into_inner()};
        let mut output=ghost! {None::<Ticket<T>>};
        let old=self.atomic.increment(ghost! {|s:&mut State<T>,c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>| {
            s.quota.join_in(quota.into_inner().resource);
            proof_assert!(s.next==1);
            s.alive.frag_lemma(&source.fragment);
            proof_assert!(source.id==0 && s.alive@.len()==1);
            let before=snapshot!(s.alive@);
            let token=s.pool.as_mut().unwrap().split_off();
            let fraction=snapshot!(token.frac());
            let fragment=issue(&mut s.alive,snapshot!(1),fraction);
            proof_assert!({fm::insert_fresh(*before,1,*fraction);true});
            proof_assert!({fm::insert_fresh_preserves_bound(*before,1,*fraction);true});
            c.shoot_load(&s.own,&mut current);
            c.shoot_store(&mut s.own,&mut current,release.into_inner());
            proof_assert!(c.timestamp()==s.latest && c.val_load()==1usize);
            let latest:Snapshot<Int>=snapshot!(c.timestamp()+1);
            s.latest=latest.into_ghost().into_inner();s.next=2int;
            *output=Some(Ticket{id:1int,fragment,token,recovery:None});
        }});
        (old,ghost! {output.into_inner().unwrap()})
    }

    #[requires(self.valid() && ticket.valid(self.public()))]
    #[ensures(result.0==(result.1.inner_logic()!=None))]
    #[ensures(result.0 ==> result.1.inner_logic().unwrap_logic().0.wellformed() &&
        result.1.inner_logic().unwrap_logic().0.metadata()==self.public().4 &&
        result.1.inner_logic().unwrap_logic().1.lft()==self.public().3 &&
        result.1.inner_logic().unwrap_logic().1.frac()==PositiveReal::from_int(1))]
    #[ensures(self.receipt(result.2.inner_logic(),result.0))]
    #[ensures(result.2.inner_logic().left()==(ticket.id==0))]
    pub fn retire(&self,ticket:Ghost<Ticket<T>>)->(bool,Ghost<Option<(T,LifetimeToken)>>,Ghost<Receipt>) {
        let (rest,payload)=ghost! {
            let t=ticket.into_inner();((t.id,(t.token,t.fragment)),t.recovery)
        }.split();
        let (mut current,sealed)=AtView::new(payload).split();
        let mut collected=ghost! {None::<(AtView<Option<T>>,LifetimeToken,Fragment<Publication<T>>)>};
        let mut receipt=ghost! {None::<Receipt>};
        let old=self.atomic.decrement(ghost! {|s:&mut State<T>,c:&mut Committer<ModelAtomic,usize,Relaxed,Release>| {
            let (id,(token,fragment))=rest.into_inner();
            let before=snapshot!(s.alive@);let fraction=snapshot!(token.frac());let identity=snapshot!(id);
            remove(&mut s.alive,fragment,identity,fraction);
            proof_assert!(0<=id && id<s.next && (*before).len()>0);
            proof_assert!({fm::remove_known(*before,id,*fraction,s.next);true});
            s.pool.as_mut().unwrap().join_in(token);
            c.shoot_load(&s.own,&mut current);
            let published=release::release_rmw(c,&mut s.own,&mut current);
            proof_assert!(c.timestamp()==s.latest && c.val_load()@==(*before).len());
            let latest:Snapshot<Int>=snapshot!(c.timestamp()+1);s.latest=latest.into_ghost().into_inner();
            if id==0int {s.recovery=Some(sealed.into_inner());}
            let last:Snapshot<bool>=snapshot!(c.val_load()==1usize);
            let fragment=if id==0int {s.left_done.add_fragment(snapshot!(Some(Ag(*last))))}
                else {s.right_done.add_fragment(snapshot!(Some(Ag(*last))))};
            *receipt=Some(Receipt{fragment,left:id==0int});
            if last.into_ghost().into_inner() {
                proof_assert!(s.alive@.ext_eq(LiveFractions::empty()));
                proof_assert!({fm::empty_prefix(s.next);true});
                let full=s.pool.take().unwrap();
                proof_assert!(full.frac().ext_eq(PositiveReal::from_int(1)));
                let mut recovery=s.recovery.take().unwrap();recovery.weaken(published);
                let stamp=snapshot!(Some(Ag((s.latest,recovery))));
                let receipt=s.publication.add_fragment(stamp);
                *collected=Some((recovery,full,receipt));s.withdrawn=true;
            }
        }});
        if old==1 {
            #[cfg(not(feature="negative_no_acquire"))]
            self.atomic.acquire(ghost! {|s:&mut State<T>,c:&Committer<ModelAtomic,usize,Acquire,NoStore>| {
                s.publication.frag_lemma(&collected.as_ref().unwrap().2);
                c.shoot_load(&s.own,&mut current);
                proof_assert!(c.timestamp()==s.latest);
            }});
            (true,ghost! {let (sealed,full,_receipt)=collected.into_inner().unwrap();Some((sealed.sync(*current).unwrap(),full))},
                ghost! {receipt.into_inner().unwrap()})
        } else {(false,ghost! {None},ghost! {receipt.into_inner().unwrap()})}
    }
    #[requires(self.valid() && self.receipt(a.inner_logic(),a_last) && self.receipt(b.inner_logic(),b_last))]
    #[requires(a.left()!=b.left())]
    #[ensures(a_last!=b_last)]
    pub fn finish(&self,a_last:bool,a:Ghost<Receipt>,b_last:bool,b:Ghost<Receipt>) {
        self.atomic.acquire(ghost! {|s:&mut State<T>,_:&Committer<ModelAtomic,usize,Acquire,NoStore>| {
            let a=a.into_inner();let b=b.into_inner();
            if a.left {s.left_done.frag_lemma(&a.fragment);s.right_done.frag_lemma(&b.fragment);}
            else {s.right_done.frag_lemma(&a.fragment);s.left_done.frag_lemma(&b.fragment);}
            proof_assert!(a_last!=b_last);
        }});
    }
}
