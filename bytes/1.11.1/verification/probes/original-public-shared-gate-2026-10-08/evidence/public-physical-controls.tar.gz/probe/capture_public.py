#!/usr/bin/env python3
"""Immutable complete local/public-gate diagnostic snapshot; no success inference."""
import argparse,hashlib,json,pathlib,tarfile
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('log');a=p.parse_args()
r=pathlib.Path(__file__).resolve().parent;c=r.parents[2];out=r/'evidence'/(a.label+'.tar.gz');assert not out.exists()
files={}
def addtree(base,prefix,exclude=()):
 for f in base.rglob('*'):
  if f.is_file() and not any(x in f.relative_to(base).parts for x in exclude):files[prefix+'/'+str(f.relative_to(base))]=f
addtree(r,'probe',('target','evidence','.proof-config','.git'))
addtree(c/'src','inputs/production/src')
for name in ['guarded-shared-protocol-2026-10-08','shared-physical-lifecycle-2026-10-08','original-shared-lifecycle-2026-10-08']:
 addtree(r.parent/name/'src','inputs/'+name+'/src')
addtree(pathlib.Path('/workspace/bytes-proof-tools/bytes-proof-std/src'),'inputs/bytes-proof-std/src')
rows=[]
with tarfile.open(out,'w:gz') as t:
 for name,f in sorted(files.items()):
  t.add(f,arcname=name);rows.append({'path':name,'source':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
d={'archive':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'log':a.log,'members':rows}
(r/'evidence'/(a.label+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(d['archive'],d['sha256'],len(rows))
