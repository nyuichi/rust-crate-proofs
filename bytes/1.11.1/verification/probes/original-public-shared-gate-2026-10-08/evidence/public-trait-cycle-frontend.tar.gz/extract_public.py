import os,pathlib,hashlib,json
root=pathlib.Path(__file__).resolve().parents[3]; out=pathlib.Path(os.environ['OUT_DIR']); gen=pathlib.Path('generated');gen.mkdir(exist_ok=True)
s=(root/'src/bytes.rs').read_text(); rows={}
def span(name):
 a=s.index('// ORIGINAL_SHARED_BEGIN '+name);b=s.index('// ORIGINAL_SHARED_END '+name,a)+len('// ORIGINAL_SHARED_END '+name)
 t=s[a:b];rows[name]={'sha256':hashlib.sha256(t.encode()).hexdigest(),'line':s[:a].count('\n')+1};return t
records=''
for name in ['bytes_record.rs','vtable_record.rs']:
 p=root/'src/bytes'/name;t=p.read_text();rows[name]={'sha256':hashlib.sha256(t.encode()).hexdigest()};records+=t+'\n'
# BytesMut's unselected return type preserves the source's concrete fields;
# its operations/representation invariants are outside this selected branch.
m=(root/'src/bytes_mut.rs').read_text();a=m.index('pub struct BytesMut {');b=m.index('\n}',a)+2
record=m[a:b];record=record.replace('NonNull<u8>','core::ptr::NonNull<u8>');records+=record+'\n'
impls=span('bytes_clone_impl')+'\n'+span('bytes_from_vec_impl')+'\n'
for name,t in [('public_records.rs',records),('public_traits.rs',impls)]:
 (out/name).write_text(t);(gen/name).write_text(t);rows['generated/'+name]={'sha256':hashlib.sha256(t.encode()).hexdigest()}
for name in ['shared_clone','shallow_clone_arc','shared_drop','release_shared','free_shared']:span(name)
(gen/'source-map.json').write_text(json.dumps(rows,indent=2)+'\n')
