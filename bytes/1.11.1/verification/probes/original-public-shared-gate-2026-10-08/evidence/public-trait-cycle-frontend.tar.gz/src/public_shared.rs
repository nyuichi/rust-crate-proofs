//! Selected actual public Bytes fields and Clone/From trait integration.
use alloc::{alloc::{dealloc,Layout},boxed::Box,vec::Vec};
use core::sync::atomic::{AtomicPtr,AtomicUsize};
use creusot_std::{prelude::*,ghost::{GhostShared,perm::Perm,
    lifetime_logic::{EndBorrow,FullBorrow,Lifetime,LifetimeToken}},
    logic::{Id,Int,real::PositiveReal},std::{ops::FnExt,sync::{
        atomic::{AtomicUsize as ModelAtomic,ordering::{Relaxed,Release,Acquire,None as NoStore}},
        committer::Committer,view::{ReleaseSyncView,SyncView}}}};
use crate::{boxed_alignment,field_event,pointer_event,physical_projection,raw_vec,lifecycle,erased_call};
use lifecycle::RecoveryPayload as _;
include!("../../../../src/bytes/shared_record.rs");
impl field_event::AtomicField for Shared {
    #[cfg_attr(creusot, ensures(field_event::atomic_model(result) == self.field_model()))]
    fn atomic_field(&self)->&AtomicUsize {&self.ref_cnt}
    #[cfg(creusot)] #[logic(open(crate))]
    fn field_model(&self)->ModelAtomic {field_event::atomic_model(&self.ref_cnt)}
}
// Exact native declarations are extracted from production by build.rs.
include!(concat!(env!("OUT_DIR"),"/public_records.rs"));
pub(crate) struct Payload {
    recovery: raw_vec::Recovery,
    physical_end: EndBorrow<raw_vec::PhysicalRegion>,
    control_end: EndBorrow<field_event::OwnedControl<Shared>>,
    physical: Ghost<GhostShared<FullBorrow<raw_vec::PhysicalRegion>>>,
    control: Ghost<GhostShared<FullBorrow<field_event::OwnedControl<Shared>>>>,
    base: raw_vec::BoundPtr,
    capacity: usize,
    len: usize,
    expected: Snapshot<Seq<u8>>,
}

impl lifecycle::RecoveryPayload for Payload {
    type Metadata = (Lifetime, Id, Int, Seq<u8>, Int, *const Shared, *mut u8);

    #[logic]
    fn metadata(self) -> Self::Metadata {
        (
            self.control.val().lft(),
            self.recovery.namespace(),
            self.recovery.capacity(),
            *self.expected,
            pearlite! { self.control.val().cur().pointer().addr_logic()@ },
            self.control.val().cur().pointer(),
            self.base.raw_pointer(),
        )
    }

    #[logic(prophetic)]
    fn wellformed(self) -> bool {
        pearlite! {
            self.recovery.invariant() && self.base.invariant() &&
            self.base@ == Some((self.recovery.namespace(), self.recovery.capacity(), 0int)) &&
            self.capacity@ == self.recovery.capacity() && self.len@ == (*self.expected).len() &&
            self.capacity@ > 0 &&
            self.len@ <= self.capacity@ &&
            self.physical_end.lft() == self.physical.val().lft() &&
            self.physical.val().lft() == self.control.val().lft() &&
            ^self.physical_end == self.physical.val().cur() &&
            self.physical.val().cur().invariant() &&
            self.physical.val().cur().namespace() == self.recovery.namespace() &&
            self.physical.val().cur().capacity() == self.recovery.capacity() &&
            self.physical.val().cur().resource_id() == self.recovery.namespace() &&
            self.physical.val().cur().lo() == 0 &&
            self.physical.val().cur().hi() == self.recovery.capacity() &&
            self.control_end.lft() == self.control.val().lft() &&
            ^self.control_end == self.control.val().cur() &&
            self.control.val().cur().wellformed() &&
            self.control.val().cur().owner.val().buf == self.base.raw_pointer() &&
            self.control.val().cur().owner.val().cap@ == self.recovery.capacity() &&
            self.control.val().cur().model() ==
                field_event::atomic_model(&self.control.val().cur().owner.val().ref_cnt) &&
            (forall<i: Int> 0 <= i && i < self.len@ ==>
                self.physical.val().cur().slot(i) == Some(Some((*self.expected)[i])))
        }
    }
}


pub(crate) type CloneSpec<'a> = fn(&'a AtomicPtr<()>,*const u8,usize,Ghost<&'a OriginalSharedProof>)->Bytes;
pub(crate) struct OriginalSharedProof {
    shared:*mut Shared,
    bound:raw_vec::BoundPtr,
    capacity:usize,
    control:Ghost<GhostShared<FullBorrow<field_event::OwnedControl<Shared>>>>,
    physical:Ghost<GhostShared<FullBorrow<raw_vec::PhysicalRegion>>>,
    invariant:Ghost<GhostShared<field_event::FieldInvariant<lifecycle::State<Payload>>>>,
    ticket:Ghost<lifecycle::Ticket<Payload>>,
    data_binding:Ghost<pointer_event::ReadOnlyPointer>,
    spec:Ghost<for<'a> fn(&'a AtomicPtr<()>,*const u8,usize,Ghost<&'a OriginalSharedProof>)->Bytes>,
}
impl OriginalSharedProof {
    #[logic(prophetic)]
    pub(crate) fn valid_for(self,ptr:*const u8,len:usize,data:creusot_std::std::sync::atomic::AtomicPtr<()>)->bool {
        let p = self;
        pearlite! {
            p.bound.invariant() &&
            p.bound@ == Some((p.invariant.inner_logic().val().public().3.1,
                p.capacity@, 0int)) &&
            p.capacity@ == p.invariant.inner_logic().val().public().3.2 &&
            len@ == p.invariant.inner_logic().val().public().3.3.len() &&
            p.capacity@ > 0 &&
            len@ <= p.capacity@ &&
            ptr == p.bound.raw_pointer() as *const u8 &&
            p.bound.current_address() == ptr.addr_logic()@ &&
            p.data_binding.inner_logic().model() ==
                data &&
            p.data_binding.inner_logic().value() == p.shared as *mut () &&
            p.shared as *const Shared == p.control.inner_logic().val().cur().pointer() &&
            p.invariant.inner_logic().val().public().3.5 == p.shared as *const Shared &&
            p.invariant.inner_logic().val().public().3.6 == p.bound.raw_pointer() &&
            p.invariant.inner_logic().val().public().3.0 ==
                p.invariant.inner_logic().val().public().2 &&
            p.control.inner_logic().val().lft() == p.invariant.inner_logic().val().public().2 &&
            p.physical.inner_logic().val().lft() == p.invariant.inner_logic().val().public().2 &&
            p.control.inner_logic().val().cur().wellformed() &&
            p.control.inner_logic().val().cur().model() == p.invariant.inner_logic().val().model() &&
            p.control.inner_logic().val().cur().owner.val().buf == p.bound.raw_pointer() &&
            p.control.inner_logic().val().cur().owner.val().cap@ == p.capacity@ &&
            p.physical.inner_logic().val().cur().invariant() &&
            p.physical.inner_logic().val().cur().namespace() == p.bound@.unwrap_logic().0 &&
            p.physical.inner_logic().val().cur().capacity() == p.capacity@ &&
            p.physical.inner_logic().val().cur().resource_id() == p.bound@.unwrap_logic().0 &&
            p.physical.inner_logic().val().cur().lo() == 0 &&
            p.physical.inner_logic().val().cur().hi() == p.capacity@ &&
            (forall<i: Int> 0 <= i && i < len@ ==>
                p.physical.inner_logic().val().cur().slot(i) ==
                    Some(Some(p.invariant.inner_logic().val().public().3.3[i]))) &&
            p.ticket.inner_logic().token.lft() == p.invariant.inner_logic().val().public().2 &&
            p.ticket.inner_logic().valid(p.invariant.inner_logic().val().public())
        }
    }

}

impl Bytes {
    #[logic(prophetic)]
    pub(crate) fn original_shared_valid(self)->bool {
        pearlite! {self.original_shared.inner_logic().valid_for(self.ptr,self.len,pointer_event::pointer_model(&self.data)) &&
            erased_call::registered3(self.vtable.clone,self.original_shared.inner_logic().spec.inner_logic()) &&
            spec_matches(self.original_shared.inner_logic().spec.inner_logic())}
    }
    #[logic]
    pub(crate) fn original_shared_bytes(self)->Seq<u8> {
        self.original_shared.inner_logic().invariant.inner_logic().val().public().3.3
    }
}

#[logic(open(crate))]
fn spec_matches(spec:for<'a> fn(&'a AtomicPtr<()>,*const u8,usize,Ghost<&'a OriginalSharedProof>)->Bytes)->bool {
    pearlite! {
        (forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<&OriginalSharedProof>>
            spec.precondition((data,ptr,len,input)) == shared_clone_checked.precondition((data,ptr,len,input))) &&
        (forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<&OriginalSharedProof>,output:Bytes>
            spec.postcondition((data,ptr,len,input),output) == shared_clone_checked.postcondition((data,ptr,len,input),output))
    }
}

#[trusted]
#[ensures(erased_call::registered3(result.0.clone,result.1.inner_logic()))]
#[ensures(spec_matches(result.1.inner_logic()))]
#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<&OriginalSharedProof>>
    result.1.inner_logic().precondition((data,ptr,len,input)) == shared_clone_checked.precondition((data,ptr,len,input)))]
#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<&OriginalSharedProof>,output:Bytes>
    result.1.inner_logic().postcondition((data,ptr,len,input),output) == shared_clone_checked.postcondition((data,ptr,len,input),output))]
fn shared_registration()->(&'static Vtable,Ghost<for<'a> fn(&'a AtomicPtr<()>,*const u8,usize,Ghost<&'a OriginalSharedProof>)->Bytes>) {
    unreachable!("closed original SHARED_VTABLE.clone / checked erasure reification")
}

#[requires(source.original_shared_valid())]
#[ensures(result.original_shared_valid())]
#[ensures(result.original_shared_bytes() == source.original_shared_bytes())]
#[ensures(result.ptr == source.ptr && result.len == source.len)]
fn original_shared_clone(source:&Bytes)->Bytes {
    let native = source.vtable.clone;
    let spec = ghost! {source.original_shared.spec.into_inner()};
    erased_call::invoke3(native,(&source.data,source.ptr,source.len),
        ghost! {&*source.original_shared},spec)
}

#[requires(input.valid_for(ptr,len,pointer_event::pointer_model(data)))]
#[ensures(result.original_shared_valid())]
#[ensures(result.original_shared_bytes() == input.invariant.inner_logic().val().public().3.3)]
#[ensures(result.ptr == ptr && result.len == len)]
fn shared_clone_checked(data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<&OriginalSharedProof>)->Bytes {
    let shared_word=pointer_event::load_relaxed(data,ghost! {&*input.data_binding});
    let mut current=ghost! {SyncView::new().into_inner()};
    let release=ghost! {ReleaseSyncView::new().into_inner()};
    let mut ticket=ghost! {None::<lifecycle::Ticket<Payload>>};
    let old=field_event::increment_owned::<Shared,lifecycle::State<Payload>,_>(
        shared_word.cast::<Shared>(),ghost! {(*input.control).to_ref()},
        ghost! {&input.ticket.token},ghost! {(*input.invariant).to_ref()},
        ghost! {|state:&mut lifecycle::State<Payload>,c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>| {
            *ticket=Some(lifecycle::State::on_register(Ghost::new(state),Ghost::new(c),
                ghost! {&*input.ticket},current.borrow_mut(),release).into_inner());
        }});
    let mut pointer_view=ghost! {SyncView::new().into_inner()};
    let (data,permission)=pointer_event::new_pointer(shared_word,pointer_view.borrow_mut());
    let binding=pointer_event::bind_read_only(&data,shared_word,permission);
    let (vtable,spec)=shared_registration();
    Bytes {ptr,len,data,vtable,original_shared:ghost! {
        OriginalSharedProof {shared:input.shared,bound:input.bound,capacity:input.capacity,
            control:input.control,physical:input.physical,invariant:input.invariant,
            ticket:Ghost::new(ticket.into_inner().unwrap()),data_binding:binding,spec}
    }}
}

// Temporary diagnostic body: no constructor proof/completion is claimed from
// a diverging placeholder. It permits the actual trait precondition/refinement
// experiment before investing in physical constructor integration.
#[requires(input@.len() < creusot_std::std::vec::capacity_model(input))]
#[ensures(result.original_shared_valid())]
#[ensures(result.original_shared_bytes() == input@)]
fn original_shared_from_vec(input:Vec<u8>)->Bytes {panic!("trait refinement diagnostic only")}

include!(concat!(env!("OUT_DIR"),"/public_traits.rs"));
