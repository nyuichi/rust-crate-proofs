# First promotable Clone and closed cleanup lifecycle — 2026-10-09

D2026-10-09-AL, directed by Astra after audited/published AK. Client-only nonempty
Box premise, both parities, closed single-threaded first CAS, explicit cleanup.
PromotionScope directly receives constructor-owned raw physical resources and
unconsumed root AtomicPtr permission; no logical resource getter, readonly
history after mutation, guessed issuance, trusted promotion success or count1
plus fictional increment. First prove owned-pointer CAS and initialize_pair,
then actual native client. No promotion autoDrop/concurrent loser/full admission.
Development in progress; no new admission.

Development prerequisites (not lifecycle admission):

- Actual count-2 pair initializer: 76 targets / 450 prover leaves / 0 nulls.
  `pair-positive-diagnostic-v3` archive SHA-256
  `09387c3550e92ad212f13d5b8277d64fe4f4d1cc76b5fff54befd75b72e2f3e5`.
  Two real affine tokens issue IDs 0/1 and fractions 1/2, 1/4, with pool 1/4.
  Independent archive/source audit: `PAIR_PREREQUISITE_AUDIT.md`.
- Owned-pointer first strong CAS: 79 targets / 482 prover leaves / 0 nulls.
  `cas-positive-diagnostic-v1` archive SHA-256
  `30586cdeab09d8d12158a9ac899c227ed13acaf1399a60cd43ece266827fef98`.
  The success follows from the body proof over the owned initial history and
  the strong failure deep-model inequality. The updated permission retains
  both old/new history; it is not converted to a read-only binding.

Both captures deliberately skip the not-yet-implemented client correspondence
checker, with structured `not_run` and diagnostic status 2. Neither establishes
the actual Box-to-Shared ownership transfer or admits a clone lifecycle. The
initial pair body failure and exact tasks are archived. The intervening frontend
type-error log is preserved as `evidence/pair-frontend-v2.log`; it is a log-only
diagnostic, not an immutable full input/proof capture.

Post-store owned-pointer prerequisites pass diagnostic 83/507/0 in
`cas-positive-diagnostic-v2`, SHA-256
`38dcaba847d610db040509177f0bea39764bd9a9def9d316c6ca86d45035f5b0`.
The terminal get_mut bridge returns a pure maximal-history timestamp only; it
consumes the permission and supplies no SyncView or implicit Acquire. Root
AsRef must retain its actual native shape (no invented atomic load).

Isolated generic pointer semantic controls (all complete mini-crate targets):

| Defect | Files / prover / null | Archive SHA-256 | Actual failed goal |
|---|---|---|---|
| Wrong CAS expected | 8 / 67 / 1 | a5ac22d79ac061a03f9a52e857a64795a9067ffc0df94e4d7790bec97645b98a | initial owned singleton must equal wrong expected singleton |
| Success callback omits store | 8 / 77 / 1 | 7f471e9a6468fd6b41aecc4fe65e1c4a017981049aaf99903248c04d1fe4165f | success Committer final shot_store |
| Re-seal updated history as old read-only value | 8 / 69 / 1 | 367ac1d07d4246cc90962bcfc5a4cecf26a1b8f8c2ce054d3b11f9c4f3a1eed1 | every updated history entry must still equal initial |

Inputs, every translated mini target, proof trees and logs are immutable under
`evidence/cas-control-*.tar.gz`; printed null tasks are saved alongside. These
exercise generic boundary prerequisites and are not native Bytes lifecycle
negative controls. A first mini launch lacked its local why3find configuration;
the infrastructure-failure log is retained separately and counted as no solver
rejection. The fixed invocation reused the exact pinned configuration. Mini
working `verif/` is removed after archival to prevent stale negative results
being confused with the later canonical integrated gate.

Mini archive replay layout: restore `inputs/repository/` at a fresh repository
root, copy archive `probe/` to
`bytes/1.11.1/verification/probes/original-promotable-first-clone-2026-10-09/`
inside that root, and restore the pinned tools/Std installation under the paths
recorded in the activation/configuration. The mini path attributes then resolve
to the captured `owned_pointer.rs` and `pointer_event.rs`. Captured backend
`.why3find` caches are hashed diagnostic data, not replay inputs; remove them
and `verif/` before invoking the mini `run-control.sh` to obtain an uncached
replay. The archived script removed `verif/` only. The current script also removes
`.why3find`, and future captures exclude backend caches. The old archives
remain untouched; this improvement has not been counted as an uncached replay.
