//! Owned pointer permission / Committer boundary: development in progress.
