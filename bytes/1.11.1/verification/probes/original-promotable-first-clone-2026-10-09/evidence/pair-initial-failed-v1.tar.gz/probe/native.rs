use bytes::Bytes;

pub fn first_promotion_scope(input:Box<[u8]>)->Vec<u8> {
    let original=Bytes::from(input);
    let child=original.clone();
    child.cleanup();
    let observed=AsRef::<[u8]>::as_ref(&original).to_vec();
    original.cleanup();
    observed
}
