//! Generic actual-core AtomicPtr / owned-Perm event correspondence.
//!
//! The two trusted operations are counterparts of private Std 0.13's
//! `std/sync/atomic.rs` load and strong compare_exchange contracts. They use
//! the SAME pointer_model as pointer_event::new_pointer, and preserve native
//! Acquire / (AcqRel, Acquire) orderings. No SC permission extraction, pointer
//! dereference, allocation transfer, successful-CAS or Bytes law is assumed.
//! Callbacks capture actual affine permissions and use Std Committer operations.
//! Exact core-field/model identity and erased callback invocation remain TCB;
//! replacement is a supported core AtomicPtr adapter with these contracts.
//!
//! load_known / exchange_known / first_strong_cas below are body proved. Their
//! all-history-equals premise is temporary: exchange_known exports the actual
//! old/new history and does NOT recreate an immutable pointer binding.
use core::sync::atomic::{AtomicPtr as CoreAtomicPtr, Ordering};
use creusot_std::{
    ghost::{FnGhost, Perm},
    prelude::*,
    std::sync::{
        atomic::{AtomicPtr as ModelAtomicPtr, ordering::{Acquire, Release, None as NoStore}},
        committer::Committer,
        view::SyncView,
    },
};
use crate::pointer_event::pointer_model;

/// One actual Acquire load and its operation-bound ghost callback.
#[trusted]
#[requires(forall<c: &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>>
    !c.shot_store() && c.ward() == pointer_model(field) ==>
    f.precondition((c,)))]
#[ensures(exists<c: &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>>
    !c.shot_store() && c.ward() == pointer_model(field) &&
    result == c.val_load() && f.postcondition_once((c,), ()))]
pub(crate) fn load_acquire<F>(field: &CoreAtomicPtr<()>, f: Ghost<F>) -> *mut ()
where F: FnGhost + FnOnce(&Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>) {
    field.load(Ordering::Acquire)
}

/// Native STRONG CAS. Unlike weak CAS, failure entails unequal deep models.
/// The success callback must shoot exactly one store; failure cannot store.
#[trusted]
#[requires(forall<c: &mut Committer<ModelAtomicPtr<()>, *mut (), Acquire, Release>>
    !c.shot_store() && c.ward() == pointer_model(field) &&
    c.val_load().deep_model() == expected.deep_model() && c.val_store() == new ==>
    f.precondition((Ok(c),)) &&
    (f.postcondition_once((Ok(c),), ()) ==> (^c).shot_store()))]
#[requires(forall<c: &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>>
    !c.shot_store() && c.ward() == pointer_model(field) &&
    c.val_load().deep_model() != expected.deep_model() ==>
    f.precondition((Err(c),)))]
#[ensures(match result {
    Ok(old) => exists<c: &mut Committer<ModelAtomicPtr<()>, *mut (), Acquire, Release>>
        !c.shot_store() && c.ward() == pointer_model(field) &&
        c.val_load().deep_model() == expected.deep_model() && c.val_store() == new &&
        old == c.val_load() && f.postcondition_once((Ok(c),), ()),
    Err(old) => exists<c: &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>>
        !c.shot_store() && c.ward() == pointer_model(field) &&
        c.val_load().deep_model() != expected.deep_model() &&
        old == c.val_load() && f.postcondition_once((Err(c),), ())
})]
pub(crate) fn compare_exchange<F>(
    field: &CoreAtomicPtr<()>, expected: *mut (), new: *mut (), f: Ghost<F>,
) -> Result<*mut (), *mut ()>
where F: FnGhost + FnOnce(Result<
    &mut Committer<ModelAtomicPtr<()>, *mut (), Acquire, Release>,
    &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>,
>) {
    field.compare_exchange(expected, new, Ordering::AcqRel, Ordering::Acquire)
}

/// Body-proved load from a still-unmodified owned history. The owner is borrowed
/// and remains available for the later CAS; native allocation may occur between.
#[requires(*own.ward() == pointer_model(field))]
#[requires(forall<t: Int> own.val().get(t) != None ==>
    own.val().get(t).unwrap_logic().0 == expected)]
#[ensures(result == expected)]
#[ensures(**current <= ^current)]
pub(crate) fn load_known(
    field: &CoreAtomicPtr<()>, expected: *mut (), own: Ghost<&Perm<ModelAtomicPtr<()>>>,
    mut current: Ghost<&mut SyncView>,
) -> *mut () {
    load_acquire(field, ghost! {
        |c: &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>| {
            c.shoot_load(&**own, &mut **current);
        }
    })
}

/// Body-proved first strong CAS: the full permission excludes an untracked
/// competing write. Success follows from the captured history and the strong
/// failure inequality, not from a trusted successful-promotion assertion.
#[requires(*own.ward() == pointer_model(field))]
#[requires(forall<t: Int> own.val().get(t) != None ==>
    own.val().get(t).unwrap_logic().0 == expected)]
#[ensures(result == Ok(expected))]
#[ensures((^own).ward() == own.ward())]
#[ensures(**current <= ^current)]
#[ensures(exists<t: Int>
    own.val().get(t) != None && own.val().get(t + 1) == None &&
    (^own).val() == own.val().insert(t + 1, (new, ^current)))]
pub(crate) fn exchange_known(
    field: &CoreAtomicPtr<()>, expected: *mut (), new: *mut (),
    mut own: Ghost<&mut Perm<ModelAtomicPtr<()>>>, mut current: Ghost<&mut SyncView>,
) -> Result<*mut (), *mut ()> {
    compare_exchange(field, expected, new, ghost! {
        |event: Result<
            &mut Committer<ModelAtomicPtr<()>, *mut (), Acquire, Release>,
            &Committer<ModelAtomicPtr<()>, *mut (), Acquire, NoStore>,
        >| {
            match event {
                Ok(c) => {
                    c.shoot_load(&**own, &mut **current);
                    c.shoot_store(&mut **own, &mut **current);
                }
                Err(c) => {
                    c.shoot_load(&**own, &mut **current);
                }
            }
        }
    })
}

/// Closed generic witness: fresh singleton history, real Acquire, strong CAS.
/// Arbitrary pointer values are only copied, compared and stored, never used
/// as allocation authority or dereferenced.
#[ensures(result)]
pub fn first_strong_cas(initial: *mut (), new: *mut ()) -> bool {
    let mut current = ghost! { SyncView::new().into_inner() };
    let (field, mut own) = crate::pointer_event::new_pointer(initial, current.borrow_mut());
    let observed = load_known(&field, initial, own.borrow(), current.borrow_mut());
    match exchange_known(&field, observed, new, own.borrow_mut(), current.borrow_mut()) {
        Ok(old) => old == initial,
        Err(_) => false,
    }
}
