# First promotable Clone and closed cleanup lifecycle — 2026-10-09

D2026-10-09-AL, directed by Astra after audited/published AK. Client-only nonempty
Box premise, both parities, closed single-threaded first CAS, explicit cleanup.
PromotionScope directly receives constructor-owned raw physical resources and
unconsumed root AtomicPtr permission; no logical resource getter, readonly
history after mutation, guessed issuance, trusted promotion success or count1
plus fictional increment. First prove owned-pointer CAS and initialize_pair,
then actual native client. No promotion autoDrop/concurrent loser/full admission.
Development in progress; no new admission.

Development prerequisites (not lifecycle admission):

- Actual count-2 pair initializer: 76 targets / 450 prover leaves / 0 nulls.
  `pair-positive-diagnostic-v3` archive SHA-256
  `09387c3550e92ad212f13d5b8277d64fe4f4d1cc76b5fff54befd75b72e2f3e5`.
  Two real affine tokens issue IDs 0/1 and fractions 1/2, 1/4, with pool 1/4.
  Independent archive/source audit: `PAIR_PREREQUISITE_AUDIT.md`.
- Owned-pointer first strong CAS: 79 targets / 482 prover leaves / 0 nulls.
  `cas-positive-diagnostic-v1` archive SHA-256
  `30586cdeab09d8d12158a9ac899c227ed13acaf1399a60cd43ece266827fef98`.
  The success follows from the body proof over the owned initial history and
  the strong failure deep-model inequality. The updated permission retains
  both old/new history; it is not converted to a read-only binding.

Both captures deliberately skip the not-yet-implemented client correspondence
checker, with structured `not_run` and diagnostic status 2. Neither establishes
the actual Box-to-Shared ownership transfer or admits a clone lifecycle. The
initial pair body failure and exact tasks are archived. The intervening frontend
type-error log is preserved as `evidence/pair-frontend-v2.log`; it is a log-only
diagnostic, not an immutable full input/proof capture.
