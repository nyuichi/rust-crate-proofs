#!/usr/bin/env python3
"""Independent source correspondence gate for the AL first-promotion proof.

The gate binds the selected shadow to the bounded native Box/clone/read/drop
witness, checks the affine proof state and its source-level event wiring, and
then runs the frozen native source/MIR checker. It does not prove compiler MIR
adequacy or discharge the generic AtomicPtr, allocator, pointer provenance,
callback-erasure, or physical-resource TCB.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import re
import sys
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parent
CRATE_ROOT = ROOT.parents[2]
AI_PATH = ROOT.parent / "original-shared-scoped-client-2026-10-09" / "check_correspondence.py"
NATIVE_PATH = ROOT / "check_native.py"


class CheckError(RuntimeError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise CheckError(message)


def load_module(name: str, path: pathlib.Path):
    require(path.is_file(), f"missing checker dependency: {path}")
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


AI = load_module("al_promotion_source_parser", AI_PATH)
NATIVE = load_module("al_promotion_native_audit", NATIVE_PATH)


def tokens(text: str) -> list[str]:
    return AI.rust_tokens(text)


def token_count(haystack: list[str], needle: list[str]) -> int:
    if not needle:
        return 0
    return sum(haystack[i:i + len(needle)] == needle
               for i in range(len(haystack) - len(needle) + 1))


def has(haystack: list[str], snippet: str, label: str, count: int | None = None) -> None:
    wanted = tokens(snippet)
    actual = token_count(haystack, wanted)
    if count is None:
        require(actual > 0, f"{label}: missing `{snippet}`")
    else:
        require(actual == count, f"{label}: expected {count} occurrence(s) of `{snippet}`, found {actual}")


def ordered(haystack: list[str], snippets: list[str], label: str) -> None:
    cursor = 0
    for snippet in snippets:
        wanted = tokens(snippet)
        found = next((i for i in range(cursor, len(haystack) - len(wanted) + 1)
                      if haystack[i:i + len(wanted)] == wanted), None)
        require(found is not None, f"{label}: required operation order breaks at `{snippet}`")
        cursor = found + len(wanted)


def body(source: str, name: str) -> list[str]:
    try:
        return AI.find_function(source, name)[0]
    except Exception as exc:
        raise CheckError(f"cannot uniquely extract function `{name}`: {exc}") from exc


def attrs(source: str, name: str) -> list[list[str]]:
    try:
        result = AI.function_outer_attributes(source, name)
        if result:
            return result
        # The frozen parser intentionally recognizes only plain visibility
        # decorations before `fn`. Normalize one code-position `unsafe` token
        # so the same contiguous #[...] parser can inspect unsafe adapters.
        code = AI.mask_noncode(source)
        matches = list(re.finditer(r"\bunsafe\s+fn\s+" + re.escape(name) + r"\b", code))
        if len(matches) == 1:
            start = matches[0].start()
            normalized = source[:start] + " " * len("unsafe ") + source[start + len("unsafe "):]
            result = AI.function_outer_attributes(normalized, name)
        return result
    except Exception as exc:
        raise CheckError(f"cannot extract attributes for `{name}`: {exc}") from exc


def exact_attrs(source: str, name: str, expected: list[str]) -> None:
    got = attrs(source, name)
    want = [tokens(x) for x in expected]
    require(got == want, f"`{name}` attributes/contracts differ from the reviewed registration surface")


def attrs_have(source: str, name: str, snippet: str, label: str | None = None) -> None:
    flattened = [tok for attr in attrs(source, name) for tok in attr]
    require(token_count(flattened, tokens(snippet)) > 0,
            f"{label or name}: attribute/contracts lost `{snippet}`")


def exact_body(source: str, name: str, expected: str, label: str | None = None) -> None:
    require(body(source, name) == tokens(expected),
            f"{label or name}: executable body differs from the reviewed bounded adapter")


def type_item(source: str, prefix: str, label: str) -> list[str]:
    try:
        return NATIVE.extract_item_tokens(source, prefix, label)
    except Exception as exc:
        raise CheckError(f"cannot extract type `{label}`: {exc}") from exc


def comma_parts(items: list[str]) -> list[list[str]]:
    """Split token sequence at commas outside (), [], {}, and generic angles."""
    out: list[list[str]] = []
    start = 0
    round_depth = square_depth = brace_depth = angle_depth = 0
    for i, tok in enumerate(items):
        if tok == "(": round_depth += 1
        elif tok == ")": round_depth -= 1
        elif tok == "[": square_depth += 1
        elif tok == "]": square_depth -= 1
        elif tok == "{": brace_depth += 1
        elif tok == "}": brace_depth -= 1
        elif tok == "<": angle_depth += 1
        elif tok == ">" and angle_depth: angle_depth -= 1
        elif tok == "," and (round_depth, square_depth, brace_depth, angle_depth) == (0, 0, 0, 0):
            if start < i:
                out.append(items[start:i])
            start = i + 1
    if start < len(items):
        out.append(items[start:])
    return out


def struct_fields(source: str, name: str) -> list[str]:
    prefix = f"struct {name} {{"
    item = type_item(source, prefix, name)
    opening = item.index("{")
    closing = len(item) - 1
    fields = comma_parts(item[opening + 1:closing])
    names = []
    for field in fields:
        require(len(field) > 1 and field[1] == ":", f"`{name}` contains a non-field or malformed field")
        names.append(field[0])
    return names


def assert_routes(lib: str, shadow: str) -> dict[str, Any]:
    """Pin the actual module source paths and selected promotion route."""
    expected_paths = {
        "relaxed": "../../original-public-shared-gate-2026-10-08/src/relaxed.rs",
        "ref_count_limit": "../../../../src/ref_count_limit.rs",
        "fraction_map": "../../shared-physical-lifecycle-2026-10-08/src/fraction_map.rs",
        "release": "../../shared-physical-lifecycle-2026-10-08/src/release.rs",
        "owned_region": "../../../../src/ownership_proof/owned_region.rs",
        "raw_vec": "../../../../src/ownership_proof/raw_vec.rs",
        "boxed_alignment": "../../../../src/ownership_proof/boxed_alignment.rs",
        "pointer_event": "../../original-shared-lifecycle-2026-10-08/src/pointer_event.rs",
        "promotion_tags": "../../original-boxed-automatic-drop-2026-10-09/src/tag_specs.rs",
    }
    for module, expected in expected_paths.items():
        actual = AI.rust_path_for_module(lib, module)
        require(actual == expected, f"`{module}` path changed: {actual!r}")
        resolved = (ROOT / "src" / actual).resolve()
        require(resolved.is_file(), f"`{module}` route resolves to no source: {resolved}")

    lib_tokens = tokens(lib)
    masked = AI.mask_noncode(lib)
    for declaration in (
        "mod event;", "mod lifecycle;", "mod field_event;", "mod physical_projection;",
        "mod free_effect;", "mod erased_call;", "#[cfg(creusot)] mod owned_pointer;",
        "#[cfg(creusot)] mod promotion;",
    ):
        require(token_count(lib_tokens, tokens(declaration)) == 1,
                f"probe module wiring must contain exactly one `{declaration}`")
    for module in ("event", "lifecycle", "field_event", "physical_projection", "free_effect", "erased_call"):
        require(len(re.findall(r"#\s*\[\s*path\s*=.*?\]\s*mod\s+" + re.escape(module) + r"\b", masked, re.S)) == 0,
                f"default module `{module}` gained an alternate #[path] source")
        require((ROOT / "src" / f"{module}.rs").is_file(), f"default module `{module}` source is missing")
    require(len(re.findall(r"\bmod\s+promotion\b", masked)) == 1,
            "promotion module has an alternate or duplicate source declaration")
    require(len(re.findall(r"\bmod\s+owned_pointer\b", masked)) == 1,
            "owned_pointer module has an alternate or duplicate source declaration")
    require(len(re.findall(r"#\s*\[\s*path\s*=\s*\"[^\"]*\"\s*\]\s*mod\s+promotion\b", masked)) == 0,
            "promotion cannot use an alternate #[path] route")

    shadow_tokens = tokens(shadow)
    for item in (
        'include!("../../../../src/bytes/shared_record.rs");',
        'include!(concat!(env!("OUT_DIR"),"/public_records.rs"));',
    ):
        require(token_count(shadow_tokens, tokens(item)) == 1,
                f"selected proof shadow must include exact `{item}`")
    return {
        "selected_shadow": "src/promotion.rs",
        "module_cfg": "#[cfg(creusot)] mod promotion;",
        "promotion_alternate_path": False,
        "support_paths": expected_paths,
        "production_shared_record_included": True,
        "generated_production_record_included": True,
    }


PROMOTION_FN_NAMES = [
    "atomic_field", "field_model", "metadata", "wellformed", "reclaimed", "valid", "valid_for",
    "word", "table", "valid", "matches", "valid", "valid", "is_raw", "is_shared", "valid",
    "root_valid", "observation", "cursor_model", "cursor_public", "root_id", "root_fraction",
    "root_metadata", "same_root", "same_pointer_owner", "child_valid", "is_child", "child_id",
    "child_fraction", "child_content", "child_public", "child_accepts", "even_table", "odd_table",
    "shared_table", "even_table_reification", "odd_table_reification", "shared_table_reification",
    "tag_pointer", "from_box_scoped", "shallow_clone_vec_checked", "valid", "content", "public",
    "accepts", "clone_result", "even_clone_checked", "even_clone_registration", "odd_clone_checked",
    "odd_clone_registration", "clone_root", "release_core", "free_recovered", "child_drop_checked",
    "child_drop_registration", "cleanup_child", "root_drop_checked", "even_root_drop_registration",
    "odd_root_drop_registration", "cleanup_root", "read_root", "first_promotion_client",
]


def assert_closed_function_surface(source: str) -> None:
    code = AI.mask_noncode(source)
    names = re.findall(r"\bfn\s+([A-Za-z_][A-Za-z0-9_]*)\b", code)
    require(sorted(names) == sorted(PROMOTION_FN_NAMES),
            "promotion.rs function surface changed; unreviewed/removed logic or executable helper")


def assert_proof_state_types(source: str) -> dict[str, Any]:
    expected_fields = {
        "Payload": ["recovery", "physical_end", "control_end", "physical", "control", "base", "capacity", "len", "expected"],
        "SharedCore": ["shared", "bound", "capacity", "control", "physical", "invariant", "ticket"],
        "RootDescriptor": ["base", "capacity", "expected", "model"],
        "ChildProof": ["core", "binding"],
        "RawPhase": ["recovery", "physical", "own", "current"],
        "SharedPhase": ["root", "cursor", "own", "current"],
        "PromotionScope": ["descriptor", "phase"],
    }
    for name, wanted in expected_fields.items():
        got = struct_fields(source, name)
        require(got == wanted, f"`{name}` fields changed: {got}")
    descriptor = type_item(source, "struct RootDescriptor {", "RootDescriptor")
    for forbidden in ("Perm", "Cursor", "Recovery", "Ticket", "LifetimeToken", "PhysicalRegion"):
        require(forbidden not in descriptor, f"RootDescriptor gained affine resource `{forbidden}`")
    require(token_count(tokens(source), tokens("type Cursor=crate::event::ScopeCursor<lifecycle::State<Payload>>;")) == 1,
            "there must be one exact erased lifecycle cursor alias")

    for alias in (
        "type CloneInput<'a>=(&'a RootDescriptor,&'a mut PromotionScope);",
        "type CloneSpec<'a>=fn(&'a AtomicPtr<()>,*const u8,usize,Ghost<CloneInput<'a>>)->Bytes;",
        "type ChildDropInput<'a>=(ChildProof,&'a mut Cursor,&'a mut Option<Completion>);",
        "type ChildDropSpec<'a>=fn(&'a mut AtomicPtr<()>,*const u8,usize,Ghost<ChildDropInput<'a>>);",
        "type RootDropInput<'a>=(RootDescriptor,&'a mut PromotionScope,&'a mut Option<Completion>);",
        "type RootDropSpec<'a>=fn(&'a mut AtomicPtr<()>,*const u8,usize,Ghost<RootDropInput<'a>>);",
    ):
        require(token_count(tokens(source), tokens(alias)) == 1, f"proof callback ABI alias changed: `{alias}`")
    for enum_name, variants in {
        "Completion": ["KeptAlive", "Reclaimed", "physical_projection::FreeReceipt", "free_effect::TypedFreeReceipt<Shared>"],
        "OriginalSharedProof": ["Root", "RootDescriptor", "Child", "ChildProof"],
        "Phase": ["Raw", "RawPhase", "Shared", "SharedPhase"],
    }.items():
        item = type_item(source, f"enum {enum_name} {{", enum_name)
        for variant in variants:
            require(token_count(item, tokens(variant)) > 0, f"`{enum_name}` lost `{variant}`")
    require(token_count(type_item(source, "struct RawPhase {", "RawPhase"), tokens("Perm<ModelAtomicPtr<()>>")) > 0,
            "raw phase no longer owns the pointer history permission")
    require(token_count(type_item(source, "struct SharedPhase {", "SharedPhase"), tokens("Perm<ModelAtomicPtr<()>>")) > 0,
            "shared phase no longer retains the pointer history permission")
    require(struct_fields(source, "SharedPhase").count("cursor") == 1,
            "shared phase lost its unique lifecycle cursor field")
    require(token_count(type_item(source, "struct ChildProof {", "ChildProof"), tokens("pointer_event::ReadOnlyPointer")) > 0,
            "child proof no longer carries the affine read-only pointer binding")
    require(token_count(type_item(source, "struct ChildProof {", "ChildProof"), tokens("Ghost<Perm<ModelAtomicPtr<()>>>")) == 0,
            "child proof illegally owns/rebinds the root pointer permission")
    return {"affine_scope_external_to_Bytes": True,
            "root_descriptor_copyable_metadata_only": True,
            "child_pointer_binding_read_only": True,
            "single_scope_cursor_type": "event::ScopeCursor<State<Payload>>",
            "completion_contains_both_free_receipts": True}


def assert_support_adapters(lib: str, shadow: str, native_bundle: dict[str, Any]) -> dict[str, Any]:
    """Check the exact generic adapters used by the selected proof path."""
    owned = (ROOT / "src/owned_pointer.rs").read_text()
    pointer_path = (ROOT / "src" / AI.rust_path_for_module(lib, "pointer_event")).resolve()
    pointer = pointer_path.read_text()
    field = (ROOT / "src/field_event.rs").read_text()
    projection = (ROOT / "src/physical_projection.rs").read_text()
    free = (ROOT / "src/free_effect.rs").read_text()
    erased = (ROOT / "src/erased_call.rs").read_text()
    rawvec_path = (ROOT / "src" / AI.rust_path_for_module(lib, "raw_vec")).resolve()
    rawvec = rawvec_path.read_text()
    align_path = (ROOT / "src" / AI.rust_path_for_module(lib, "boxed_alignment")).resolve()
    alignment = align_path.read_text()
    tags_path = (ROOT / "src" / AI.rust_path_for_module(lib, "promotion_tags")).resolve()
    tags = tags_path.read_text()

    # The model adapters are checked as actual executable wrappers, not as a
    # claim that native std atomics or their Rust memory-model interpretation
    # have been derived by Creusot.
    exact_body(owned, "load_acquire", "field.load(Ordering::Acquire)", "owned_pointer::load_acquire")
    exact_body(owned, "compare_exchange",
               "field.compare_exchange(expected,new,Ordering::AcqRel,Ordering::Acquire)",
               "owned_pointer::compare_exchange")
    exact_body(owned, "exchange_known", r"""compare_exchange(field,expected,new,ghost! {
        |event:Result<&mut Committer<ModelAtomicPtr<()>,*mut (),Acquire,Release>,&Committer<ModelAtomicPtr<()>,*mut (),Acquire,NoStore>,>| {
            match event {
                Ok(c)=>{c.shoot_load(&**own,&mut **current);c.shoot_store(&mut **own,&mut **current);}
                Err(c)=>{c.shoot_load(&**own,&mut **current);}
            }
        }
    })""", "owned_pointer::exchange_known")
    exact_body(owned, "exchange_singleton",
               "exchange_known(field,expected,new,own,current)", "owned_pointer::exchange_singleton")
    exact_body(owned, "get_mut_finish",
               "#[cfg(creusot)]{unreachable!(\"generic terminal owned-history interpretation\")}#[cfg(not(creusot))]{(*field.get_mut(),snapshot!(0))}",
               "owned_pointer::get_mut_finish")
    attrs_have(owned, "compare_exchange", "Committer<ModelAtomicPtr<()>,*mut (),Acquire,Release>")
    attrs_have(owned, "compare_exchange", "Committer<ModelAtomicPtr<()>,*mut (),Acquire,NoStore>")
    attrs_have(owned, "compare_exchange", "old==c.val_load()")
    attrs_have(owned, "get_mut_finish", "forall<t:Int>")
    attrs_have(owned, "get_mut_finish", "t<=*result.1")
    attrs_have(owned, "get_mut_finish", "^field==*field")
    require("finish_latest" not in body(shadow, "root_drop_checked"),
            "root terminal route must use the consuming get_mut_finish operation directly")

    exact_body(pointer, "new_pointer", "(CoreAtomicPtr::new(value),Ghost::conjure())", "pointer_event::new_pointer")
    exact_body(pointer, "bind_read_only", "Ghost::conjure()", "pointer_event::bind_read_only")
    exact_body(pointer, "get_mut", "*field.get_mut()", "pointer_event::get_mut")
    attrs_have(pointer, "new_pointer", "pointer_model(&result.0)")
    attrs_have(pointer, "bind_read_only", "permission.inner_logic().val().get(t).unwrap_logic().0==value")
    attrs_have(pointer, "bind_read_only", "result.value()==value")
    attrs_have(pointer, "get_mut", "result==binding.inner_logic().value()")
    attrs_have(pointer, "get_mut", "^field==*field")

    exact_body(field, "new", "(CoreAtomicUsize::new(value),Ghost::conjure())", "field_event::new")
    exact_body(field, "bind", "Ghost::conjure()", "ScopedFieldInvariant::bind")
    exact_body(field, "decrement_owned",
               "unsafe{&*pointer}.atomic_field().fetch_sub(1,Ordering::Release)",
               "field_event::decrement_owned")
    exact_body(field, "acquire_owned",
               "unsafe{&*pointer}.atomic_field().load(Ordering::Acquire)",
               "field_event::acquire_owned")
    attrs_have(field, "new", "atomic_model(&result.0)")
    attrs_have(field, "bind", "state.atomic()==atomic_model(atomic)")
    attrs_have(field, "bind", "result.inner_logic().1.observation()==state.observe()")
    attrs_have(field, "decrement_owned", "cursor.inner_logic().model()==invariant.inner_logic().model()")
    exact_body(shadow, "atomic_field", "&self.ref_cnt", "Shared::atomic_field")
    exact_body(shadow, "field_model", "field_event::atomic_model(&self.ref_cnt)", "Shared::field_model")

    exact_body(projection, "borrow", "unsafe{core::slice::from_raw_parts(pointer,len)}",
               "physical_projection::borrow")
    exact_body(projection, "deallocate",
               "unsafe{alloc::alloc::dealloc(pointer,alloc::alloc::Layout::from_size_align(capacity,1).unwrap())}Ghost::conjure()",
               "physical_projection::deallocate")
    attrs_have(projection, "borrow", "pointer==bound.inner_logic().raw_pointer() as *const u8")
    attrs_have(projection, "borrow", "bound.inner_logic()@.unwrap_logic().2+len@<=region.inner_logic().hi()")
    attrs_have(projection, "deallocate", "result.inner_logic().pointer()==pointer")
    attrs_have(projection, "deallocate", "result.inner_logic().size()==capacity@")
    attrs_have(projection, "deallocate", "result.inner_logic().align()==1")

    exact_body(free, "deallocate_typed_box",
               "if core::mem::size_of::<T>()!=0{unsafe{dealloc(pointer.cast(),Layout::new::<T>())}}Ghost::conjure()",
               "free_effect::deallocate_typed_box")
    attrs_have(free, "deallocate_typed_box", "*owner.inner_logic().ward()==pointer as *const T")
    attrs_have(free, "deallocate_typed_box", "result.inner_logic().consumed(owner.inner_logic())")
    attrs_have(free, "deallocate_typed_box", "result.inner_logic().allocated()")

    exact_body(erased, "registered3", "dead", "erased_call::registered3")
    exact_attrs(erased, "registered3", ["#[trusted]", "#[logic(opaque)]"])
    exact_body(erased, "invoke3",
               "#[cfg(not(creusot))]{unsafe{native(args.0,args.1,args.2)}}#[cfg(creusot)]{unreachable!(\"generic registered erased call\")}",
               "erased_call::invoke3")
    attrs_have(erased, "invoke3", "registered3(native,spec.inner_logic())")
    attrs_have(erased, "invoke3", "spec.inner_logic().precondition((args.0,args.1,args.2,input))")
    attrs_have(erased, "invoke3", "spec.inner_logic().postcondition((args.0,args.1,args.2,input),result)")

    detach = body(rawvec, "detach_boxed_slice")
    has(detach, "Box::into_raw(input)", "raw_vec::detach_boxed_slice", count=1)
    has(detach, "Resource::alloc(allocation_value)", "raw_vec::detach_boxed_slice")
    has(detach, "Recovery{resource:recovery_resource", "raw_vec::detach_boxed_slice")
    has(detach, "PhysicalRegion{ledger", "raw_vec::detach_boxed_slice")
    attrs_have(rawvec, "detach_boxed_slice", "result.0.capacity()==input@.len()")
    attrs_have(rawvec, "detach_boxed_slice", "result.2.inner_logic().1.slot(index)")

    exact_body(alignment, "into_raw_aligned", "Perm::from_box(value)", "boxed_alignment::into_raw_aligned")
    attrs_have(alignment, "into_raw_aligned", "result.inner_logic().1.pointer()==result.inner_logic().0")
    exact_body(tags, "equal_pointer_distance", "unsafe{pointer.offset_from(base)}", "tag_specs::equal_pointer_distance")
    attrs_have(tags, "equal_pointer_distance", "pointer==base as *const u8")
    attrs_have(tags, "equal_pointer_distance", "result==0isize")

    # Native selected vtable records bind the actual source callback names
    # consumed by the native MIR audit. Table identity remains part of the
    # explicit trusted reification/registration TCB in promotion.rs.
    production = native_bundle["production_source"]
    expected_vtables = {
        "PROMOTABLE_EVEN_VTABLE": ("promotable_even_clone", "promotable_even_drop"),
        "PROMOTABLE_ODD_VTABLE": ("promotable_odd_clone", "promotable_odd_drop"),
        "SHARED_VTABLE": ("shared_clone", "shared_drop"),
    }
    for table, (clone_fn, drop_fn) in expected_vtables.items():
        item = NATIVE.extract_item_tokens(production, f"static {table}: Vtable", table)
        require(token_count(item, tokens(f"clone:{clone_fn}")) == 1 and
                token_count(item, tokens(f"drop:{drop_fn}")) == 1,
                f"native {table} no longer points to the selected clone/drop callbacks")

    return {
        "owned_pointer_acquire_strong_cas_and_terminal_body_checked": True,
        "pointer_event_new_immutable_binding_and_get_mut_checked": True,
        "field_event_real_atomic_projection_release_acquire_checked": True,
        "physical_read_buffer_free_and_typed_control_free_checked": True,
        "rawvec_box_detach_and_box_alignment_adapter_source_checked": True,
        "tag_distance_and_native_vtable_targets_checked": True,
        "erased_call_abi_body_checked": True,
        "native_pointer_model_and_erasure_interpretation": "generic TCB, contracts/source-bound; not proved from Rust std"
    }


def assert_trust_boundary(source: str) -> dict[str, Any]:
    allowed = {
        "even_table_reification", "odd_table_reification", "shared_table_reification",
        "tag_pointer", "even_clone_registration", "odd_clone_registration",
        "child_drop_registration", "even_root_drop_registration", "odd_root_drop_registration",
    }
    masked = AI.mask_noncode(source)
    matches = list(re.finditer(r"#\s*\[\s*trusted\s*\]", masked))
    names = []
    for hit in matches:
        tail = masked[hit.end():]
        fn = re.search(r"\bfn\s+([A-Za-z_][A-Za-z0-9_]*)\b", tail)
        require(fn is not None, "unattached or non-function trusted attribute in promotion module")
        names.append(fn.group(1))
    require(set(names) == allowed and len(names) == len(allowed),
            f"promotion trusted allowlist changed: {sorted(names)}")

    for name in ("from_box_scoped", "shallow_clone_vec_checked", "even_clone_checked", "odd_clone_checked",
                 "clone_root", "release_core", "free_recovered", "child_drop_checked", "cleanup_child",
                 "root_drop_checked", "cleanup_root", "read_root", "first_promotion_client"):
        a = attrs(source, name)
        require(not any("trusted" in x or "assume" in x or "axiom" in x or "extern_spec" in x for x in a),
                f"proof-bearing operation `{name}` acquired a trust/vacuity attribute")
    require(len(attrs(source, "first_promotion_client")) == 2,
            "client requires/ensures surface changed; re-review for vacuity")
    first_attrs = attrs(source, "first_promotion_client")
    require(first_attrs == [tokens("#[requires(input@.len()>0)]"), tokens("#[ensures(result@==input@)]")],
            "client nonempty/content contract changed")

    registration_contracts = {
        "even_clone_registration": [
            "#[trusted]", "#[ensures(result.0==even_table())]",
            "#[ensures(erased_call::registered3(result.0.clone,result.1.inner_logic()))]",
            "#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<CloneInput>> result.1.inner_logic().precondition((data,ptr,len,input))==even_clone_checked.precondition((data,ptr,len,input)))]",
            "#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<CloneInput>,output:Bytes> result.1.inner_logic().postcondition((data,ptr,len,input),output)==even_clone_checked.postcondition((data,ptr,len,input),output))]",
        ],
        "odd_clone_registration": [
            "#[trusted]", "#[ensures(result.0==odd_table())]",
            "#[ensures(erased_call::registered3(result.0.clone,result.1.inner_logic()))]",
            "#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<CloneInput>> result.1.inner_logic().precondition((data,ptr,len,input))==odd_clone_checked.precondition((data,ptr,len,input)))]",
            "#[ensures(forall<data:&AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<CloneInput>,output:Bytes> result.1.inner_logic().postcondition((data,ptr,len,input),output)==odd_clone_checked.postcondition((data,ptr,len,input),output))]",
        ],
        "child_drop_registration": [
            "#[trusted]", "#[ensures(result.0==shared_table())]",
            "#[ensures(erased_call::registered3(result.0.drop,result.1.inner_logic()))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<ChildDropInput>> result.1.inner_logic().precondition((data,ptr,len,input))==child_drop_checked.precondition((data,ptr,len,input)))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<ChildDropInput>> result.1.inner_logic().postcondition((data,ptr,len,input),())==child_drop_checked.postcondition((data,ptr,len,input),()))]",
        ],
        "even_root_drop_registration": [
            "#[trusted]", "#[ensures(result.0==even_table())]",
            "#[ensures(erased_call::registered3(result.0.drop,result.1.inner_logic()))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<RootDropInput>> result.1.inner_logic().precondition((data,ptr,len,input))==root_drop_checked.precondition((data,ptr,len,input)))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<RootDropInput>> result.1.inner_logic().postcondition((data,ptr,len,input),())==root_drop_checked.postcondition((data,ptr,len,input),()))]",
        ],
        "odd_root_drop_registration": [
            "#[trusted]", "#[ensures(result.0==odd_table())]",
            "#[ensures(erased_call::registered3(result.0.drop,result.1.inner_logic()))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<RootDropInput>> result.1.inner_logic().precondition((data,ptr,len,input))==root_drop_checked.precondition((data,ptr,len,input)))]",
            "#[ensures(forall<data:&mut AtomicPtr<()>,ptr:*const u8,len:usize,input:Ghost<RootDropInput>> result.1.inner_logic().postcondition((data,ptr,len,input),())==root_drop_checked.postcondition((data,ptr,len,input),()))]",
        ],
    }
    for name, wanted in registration_contracts.items():
        exact_attrs(source, name, wanted)
        require(body(source, name) == tokens("unreachable!(\"checked closed table/clone erasure\")" if name in ("even_clone_registration", "odd_clone_registration") else
                                              "unreachable!(\"closed native shared-child drop erasure\")" if name == "child_drop_registration" else
                                              "unreachable!(\"closed native promotable ARC-drop erasure\")"),
                f"`{name}` body changed; checked callback shim must remain source-only and closed")

    exact_attrs(source, "even_table_reification", ["#[trusted]", "#[ensures(result==even_table())]"])
    exact_attrs(source, "odd_table_reification", ["#[trusted]", "#[ensures(result==odd_table())]"])
    exact_attrs(source, "shared_table_reification", ["#[trusted]", "#[ensures(result==shared_table())]"])
    exact_attrs(source, "tag_pointer", [
        "#[trusted]", "#[requires(ptr.addr_logic() & 1usize==0usize)]",
        "#[ensures(result==tag_specs::tagged_data(ptr))]",
        "#[ensures(result.addr_logic()==(ptr.addr_logic() | 1usize))]",
    ])
    tag_body = body(source, "tag_pointer")
    ordered(tag_body, ["#[cfg(creusot)]", "unreachable!(\"generic native exposed-provenance forward tag\")",
                       "#[cfg(not(creusot))]", "((ptr as usize)|1) as *mut ()"], "tag_pointer")
    return {"trusted_functions": sorted(allowed),
            "registration_contracts_exact": True,
            "native_callback_erasure": "only trusted registrations; all other proof operations body-checked"}


def assert_operation_mapping(source: str, native_result: dict[str, Any], native_bundle: dict[str, Any]) -> dict[str, Any]:
    # Box constructor: the proof scope starts from a real Box detach adapter,
    # records the same base/length, classifies the actual pointer parity, and
    # constructs exactly one pointer field plus external RawPhase authority.
    ctor = body(source, "from_box_scoped")
    ordered(ctor, ["raw_vec::detach_boxed_slice(input)", "raw.into_bound_ptr_at_zero()",
                   "provenance_specs::pointer_addr(ptr)", "if address & 1usize==0usize",
                   "pointer_event::new_pointer(word,current.borrow_mut())", "RootDescriptor",
                   "PromotionScope", "RawPhase", "OriginalSharedProof::Root"], "from_box_scoped")
    for snippet in ("if input.len()==0", "tag_pointer(ptr)", "even_table_reification()",
                    "odd_table_reification()", "snapshot!(input@)"):
        has(ctor, snippet, "from_box_scoped")
    require(token_count(ctor, tokens("raw_vec::detach_boxed_slice(input)")) == 1,
            "Box ownership must be detached once")
    raw_vec = (CRATE_ROOT / "src/ownership_proof/raw_vec.rs").read_text()
    detach = body(raw_vec, "detach_boxed_slice")
    has(detach, "Box::into_raw(input)", "RawVec Box adapter")
    has(detach, "Recovery", "RawVec Box adapter")
    has(detach, "PhysicalRegion", "RawVec Box adapter")

    # The exact native MIR/source audit has already pinned From<Box> and its
    # parity vtables. This shadow checks the selected branch is nonempty-only
    # and reaches the checked proof-facing constructor.
    native_audit = native_result["native_mir"]
    require(native_audit.get("selected_definition_headers_unique") is True and
            native_audit.get("selected_production_mir_count") == 18,
            "native checker did not admit the unique selected constructor/callback MIR set")

    # Clone route: saved vtable callback, parity-specific exact registration,
    # three unchanged runtime arguments, one Ghost bundle, and checked shim.
    clone_root = body(source, "clone_root")
    ordered(clone_root, ["source.vtable.clone", "if address & 1usize==0usize",
                         "even_clone_registration()", "erased_call::invoke3",
                         "odd_clone_registration()", "erased_call::invoke3"], "clone_root")
    has(clone_root, "(&source.data,source.ptr,source.len)", "clone_root runtime ABI")
    has(clone_root, "ghost!{(*descriptor,&mut **scope)}", "clone_root affine proof argument")

    # Both parity helpers perform the actual Acquire adapter, expose only the
    # existing tagged pointer kind, and route to the single strong-CAS helper.
    for name in ("even_clone_checked", "odd_clone_checked"):
        helper = body(source, name)
        ordered(helper, ["owned_pointer::load_acquire", "Committer<ModelAtomicPtr<()>,*mut (),Acquire,NoStore>",
                         "provenance_specs::pointer_addr(stored)&1usize",
                         "unreachable!(\"first clone raw phase excludes existing ARC branch\")",
                         "shallow_clone_vec_checked"], name)
        has(helper, "c.shoot_load(&raw.own,&mut raw.current)", name)
        require(token_count(helper, tokens("shallow_clone_vec_checked(")) == 1,
                f"{name} must perform one checked vector promotion")
    shallow = body(source, "shallow_clone_vec_checked")
    ordered(shallow, ["field_event::new(2,control_view.borrow_mut())", "Shared{buf,cap,ref_cnt}",
                      "boxed_alignment::into_raw_aligned(boxed)",
                      "owned_pointer::exchange_singleton(data,expected,shared.cast(),own_borrow,current_borrow)",
                      "lifecycle::State::initialize_pair(count_permission,count_view,payload,lifetime)",
                      "field_event::ScopedFieldInvariant::bind(&shared_ref.ref_cnt,state)",
                      "pointer_event::new_pointer(shared.cast()",
                      "pointer_event::bind_read_only(&child_data,shared.cast(),child_permission)",
                      "Phase::Shared(SharedPhase",
                      "OriginalSharedProof::Child"], "shallow_clone_vec_checked")
    has(shallow, "Err(_actual)", "singleton strong-CAS failure exclusion")
    has(shallow, "unreachable!", "singleton strong-CAS failure exclusion")
    require(token_count(shallow, tokens("owned_pointer::exchange_singleton(")) == 1,
            "promotion must use one checked strong CAS")
    require(token_count(shallow, tokens("field_event::new(2")) == 1,
            "Shared initial count must be two exactly once")
    require(token_count(shallow, tokens("State::initialize_pair(")) == 1,
            "promotion must issue the real initial root/child ticket pair once")
    require(token_count(shallow, tokens("ScopedFieldInvariant::bind(")) == 1,
            "the single control field must receive one scoped cursor binding")

    # Count-two initialization produces the root's external affine authority
    # and child's read-only pointer view. Audit actual source body/contracts.
    lifecycle = (ROOT / "src/lifecycle.rs").read_text()
    pair = body(lifecycle, "initialize_pair")
    pair_attrs = attrs(lifecycle, "initialize_pair")
    require(any(tokens("#[requires(payload.wellformed() && full.frac() == PositiveReal::from_int(1))]") == x
                for x in pair_attrs), "initialize_pair lost full-lifetime premise")
    require(any(tokens("#[requires(own.val() == FMap::singleton((*own.ward()).get_timestamp(*current), (2usize, *current)))]") == x
                for x in pair_attrs), "initialize_pair lost real count-two singleton premise")
    ordered(pair, ["full.split()", "pool.split()", "issue(&mut alive,zero,root_fraction)",
                   "issue(&mut alive,one,child_fraction)", "recovery:Some(payload)",
                   "recovery:None", "next:Int::new(2)", "(state,root,child)"], "initialize_pair")
    for snippet in ("root_token.frac()", "child_token.frac()", "alive", "Authority::<LiveFractions>::alloc()",
                    "root_token", "child_token", "pool"):
        has(pair, snippet, "initialize_pair")
    for forbidden in ("compare_exchange", "fetch_add", "fetch_sub", "on_register", "relaxed_rmw"):
        require(forbidden not in pair, f"initialize_pair unexpectedly performs a native event `{forbidden}`")

    # Child teardown is routed through the saved child's actual drop vtable
    # and immutable binding, while root teardown consumes its one latest owner.
    child_cleanup = body(source, "cleanup_child")
    ordered(child_cleanup, ["value.vtable.drop", "Child(p)", "child_drop_registration()",
                            "proof_assert!(value.vtable==table)", "erased_call::invoke3"], "cleanup_child")
    has(child_cleanup, "(&mut value.data,value.ptr,value.len)", "child cleanup ABI")
    has(child_cleanup, "&mut shared.cursor", "child cleanup cursor")
    child_shim = body(source, "child_drop_checked")
    ordered(child_shim, ["pointer_event::get_mut(data", "release_core(shared", "cursor", "output"],
            "child_drop_checked")
    has(child_shim, "&*proof.binding", "child readonly binding")
    require("bind_read_only" not in child_shim and "new_pointer" not in child_shim,
            "child cleanup may not mint or rebind pointer authority")

    root_cleanup = body(source, "cleanup_root")
    ordered(root_cleanup, ["value.vtable.drop", "OriginalSharedProof::Root", "if address & 1usize==0usize",
                           "even_root_drop_registration()", "erased_call::invoke3",
                           "odd_root_drop_registration()", "erased_call::invoke3"], "cleanup_root")
    has(root_cleanup, "(&mut value.data,value.ptr,value.len)", "root cleanup ABI")
    root_shim = body(source, "root_drop_checked")
    ordered(root_shim, ["scope.phase.take()", "owned_pointer::get_mut_finish(data,own)",
                        "provenance_specs::pointer_addr(word)&1usize", "release_core(word.cast(),root,cursor.borrow_mut(),output)",
                        "(*cursor.observation()).0.len()==0"], "root_drop_checked")
    require("bind_read_only" not in root_shim and "new_pointer" not in root_shim,
            "terminal root cleanup may not create/rebind a pointer permission")
    require(token_count(root_shim, tokens("owned_pointer::get_mut_finish(")) == 1,
            "root cleanup must consume its unique latest pointer owner once")

    # One release path updates the same cursor with decrement and, at zero,
    # Acquire/recovery plus both distinct allocation free receipts.
    release = body(source, "release_core")
    ordered(release, ["field_event::decrement_owned", "State::on_release", "if old==1",
                      "field_event::acquire_owned", "State::on_acquire", "Pending::recover",
                      "free_recovered", "Completion::Reclaimed", "Completion::KeptAlive"], "release_core")
    has(release, "&mut **cursor", "release cursor threading", count=2)
    require(token_count(release, tokens("field_event::decrement_owned")) == 1,
            "release path must have one decrement")
    require(token_count(release, tokens("field_event::acquire_owned")) == 1,
            "last-owner branch must have one Acquire")
    free = body(source, "free_recovered")
    for call in ("physical_projection::deallocate(shared.buf,shared.cap,bound,capabilities)",
                 "free_effect::deallocate_typed_box(pointer,owner)"):
        has(free, call, "paired free receipts")
    has(free, "FreeReceipt", "buffer free receipt")
    has(free, "TypedFreeReceipt<Shared>", "typed control free receipt")
    require(token_count(free, tokens("physical_projection::deallocate(")) == 1 and
            token_count(free, tokens("free_effect::deallocate_typed_box(")) == 1,
            "last-owner path must discharge exactly one buffer and one typed control allocation")

    # Read correspondence is an actual physical borrow with the root's range;
    # the proof performs no extra AtomicPtr read at observation time.
    read = body(source, "read_root")
    ordered(read, ["Phase::Shared(s)", "full.borrow(&root.ticket.token)",
                   "physical_projection::borrow(value.ptr,value.len,ghost!{&root.bound},region)"], "read_root")
    for forbidden in ("load_acquire", "load_relaxed", "pointer_event::get_mut", "data.load"):
        require(forbidden not in read, f"root read introduces an unreviewed pointer observation `{forbidden}`")

    # Closed proof client mirrors native.rs source operation sequence, adds
    # only Ghost scope/completion channels, and observes while the root lives.
    driver = body(source, "first_promotion_client")
    ordered(driver, ["from_box_scoped(input)", "clone_root(&original,scope.borrow_mut())",
                     "cleanup_child(child,scope.borrow_mut(),child_completion.borrow_mut())",
                     "read_root(&original,scope.borrow()).to_vec()",
                     "cleanup_root(original,scope.borrow_mut(),root_completion.borrow_mut())",
                     "root_completion.inner_logic().unwrap_logic().reclaimed()", "observed"],
            "first_promotion_client")
    has(driver, "!child_completion.inner_logic().unwrap_logic().reclaimed()", "child KeptAlive result")
    has(driver, "(*scope.observation()).0.len()==1", "one live root ticket after child retirement")
    has(driver, "scope.phase==None", "scope consumed after root retirement")
    require(token_count(driver, tokens("read_root(")) == 1,
            "closed client must read exactly once between child and root cleanup")

    # Generic erased invocation body is source matched, but correspondence of
    # native ABI/function-pointer meaning remains a disclosed generic TCB.
    erased = (ROOT / "src/erased_call.rs").read_text()
    invoke = body(erased, "invoke3")
    require(token_count(invoke, tokens("native(args.0,args.1,args.2)")) == 1,
            "invoke3 must call the registered native callback once with exactly three runtime arguments")
    require(token_count(tokens(erased), tokens("Ghost<G>")) > 0 and
            token_count(tokens(erased), tokens("registered3(native,spec.inner_logic())")) > 0,
            "erased call registration lost its proof-only argument mapping")

    return {
        "native_constructor_to_shadow": "production From<Box<[u8]>> and captured MIR audited; shadow consumes Box through raw_vec::detach_boxed_slice and branches on same pointer parity",
        "native_clone_to_shadow": "production Clone and callback MIR audited; shadow dispatches saved clone pointer through exact three-runtime-argument invoke3 registrations to Acquire/strong-CAS checked shim",
        "native_read_to_shadow": "production AsRef/as_slice audited; shadow root read uses physical_projection::borrow over original ptr/len and no additional atomic load",
        "native_child_drop_to_shadow": "production cleanup/Shared callback path audited; shadow callback uses child ReadOnlyPointer and same cursor",
        "native_root_drop_to_shadow": "production cleanup/promotable drop path audited; shadow consumes latest owned pointer permission then releases root ticket and proves cursor empty",
        "count_two_pair": "real lifecycle::State::initialize_pair body and count-two premise checked; root+child tickets, fresh IDs, map, fractions and pool are in the proof contracts/body",
        "allocation_free_result": "buffer FreeReceipt and typed Shared FreeReceipt both returned by the same last-owner path",
        "native_audit_status": native_result.get("status"),
        "remaining_tcb": [
            "generic RawVec Box detach physical-authority interpretation and generic PhysicalRegion slice/free adapter contracts",
            "generic pointer AtomicPtr field/model identity, strong-CAS history, and terminal get_mut interpretation",
            "trusted vtable table reification, proof/native callback registration and three-argument Ghost erasure correspondence",
            "Rust compiler MIR adequacy, allocator behavior, and pointer provenance/tag exposure",
            "native execution tests corroborate returned bytes but are not a mathematical proof",
        ],
    }


def audit(shadow_path: pathlib.Path) -> dict[str, Any]:
    shadow_resolved = shadow_path.resolve()
    expected_shadow = (ROOT / "src/promotion.rs").resolve()
    require(shadow_resolved == expected_shadow,
            f"selected shadow must be the live checked-in src/promotion.rs, got {shadow_resolved}")
    lib_path = ROOT / "src/lib.rs"
    shadow = shadow_resolved.read_text()
    lib = lib_path.read_text()
    # The generated extraction is checked against actual marker spans; the
    # selected proof include route is separately pinned above.
    bundle = NATIVE.load_bundle()
    native_result = NATIVE.audit_bundle(bundle)
    routes = assert_routes(lib, shadow)
    assert_closed_function_surface(shadow)
    state = assert_proof_state_types(shadow)
    trust = assert_trust_boundary(shadow)
    adapters = assert_support_adapters(lib, shadow, bundle)
    mapping = assert_operation_mapping(shadow, native_result, bundle)
    extracted = AI.audit_generated_extractions(
        bundle["production_source"], ROOT / "generated",
        (CRATE_ROOT / "src/bytes/bytes_record.rs").read_text(),
        (CRATE_ROOT / "src/bytes/vtable_record.rs").read_text(),
        (CRATE_ROOT / "src/bytes_mut.rs").read_text(),
    )
    return {
        "status": "pass",
        "checker_scope": "selected AL promotion shadow to bounded native source/MIR correspondence, with independent lifecycle/affine wiring checks",
        "native_audit": native_result,
        "proof_routes": routes,
        "proof_state": state,
        "trusted_boundary": trust,
        "support_adapters": adapters,
        "operation_mapping": mapping,
        "production_extraction": extracted,
        "limitations": [
            "this correspondence gate does not prove Creusot/Why3 obligations; the admitted proof run must do so",
            "native MIR evidence is source/compiler output correspondence, not a proof of compiler adequacy",
            "generic standard-library, AtomicPtr, raw allocation, provenance, field projection and erased callback boundaries remain the stated TCB",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shadow", type=pathlib.Path, default=ROOT / "src/promotion.rs")
    parser.add_argument("--mapping", type=pathlib.Path,
                        help="deprecated; any supplied mapping is rejected because correspondence is derived from source")
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args()
    try:
        require(args.mapping is None, "mapping files are not accepted; checks derive from live source and native MIR")
        result = audit(args.shadow)
    except (CheckError, NATIVE.AuditError, AI.CorrespondenceError, OSError, ValueError, KeyError, TypeError) as exc:
        result = {"status": "reject", "checker_scope": "AL native/source proof correspondence", "reason": str(exc)}
        rendered = json.dumps(result, indent=2) + "\n"
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(rendered)
        print(rendered, end="")
        return 1
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
