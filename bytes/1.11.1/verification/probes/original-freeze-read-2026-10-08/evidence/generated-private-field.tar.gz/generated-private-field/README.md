# Original offset-zero freeze and read experiment

Plan recorded before this gate's source edits. Extend original-unique-write's
actual BytesMut sidecar with the retained B1 RawAllocation. Select the original
Vec/off0 freeze branch and the original Bytes::from(Vec) len<cap Shared branch.
Interpret their raw reconstruction/detachment boundaries with existing B2/B1;
prove original control flow, constructor fields, and immutable read connected to
actual byte allocation capabilities. Native four-field representations remain.
No replacement buffer and no trusted public freeze/constructor contract.

The Shared Box is actually allocated with original buf/cap/AtomicUsize fields.
A cfg-only Box Perm records its native pointer and fields. The ordinary native
atomic constructors and static Vtable reference may use local true-only
translation leaves; they establish no atomic value, data pointer contents,
refcount, ordering, vtable identity or callback behavior. These remain explicit
open obligations. Read validity comes from retained actual B1 capabilities and
B4, not atomics or a fictitious ghost refcount. Return live Bytes; no Drop claim.

Strict len<cap excludes boxed/promotable/static paths; original KIND_ARC freeze
is excluded. Calls to omitted branches have false-precondition interfaces in the
probe and must be unreachable. Preserve exact source and generated span hashes.
Two equivalent failures require interface review; third requires restructuring.
No timeout increase. Positive requires complete nonempty proof tree/engine exit0.
Native tests use the actual main crate, not proof-only vtable callback stubs.
