use core::{mem::{self,ManuallyDrop,MaybeUninit},ptr::{self,NonNull},cmp,slice};
use alloc::{vec::Vec,boxed::Box};
use crate::{Bytes,TryGetError};
use core::sync::atomic::AtomicUsize;
// ORIGINAL_UNIQUE_BEGIN proof_imports
#[cfg(all(creusot, bytes_original_unique_gate))]
use creusot_std::prelude::*;
#[cfg(all(creusot, bytes_original_unique_gate))]
use crate::ownership_proof::raw_vec::{self, BoundPtr, RawAllocation, Recovery, PhysicalRegion, slot_known};
// ORIGINAL_UNIQUE_END proof_imports
pub struct BytesMut {
    ptr: NonNull<u8>,
    len: usize,
    cap: usize,
    data: *mut Shared,
    // No authority is established for unselected constructors/representations.
    #[cfg(all(creusot, bytes_original_unique_gate))]
    unique_proof: Option<OriginalUniqueProof>,
}
// ORIGINAL_UNIQUE_BEGIN proof_model
#[cfg(all(creusot, bytes_original_unique_gate))]
struct OriginalUniqueProof {
    base: BoundPtr,
    raw: RawAllocation,
    capabilities: Ghost<(Recovery, PhysicalRegion)>,
}
#[cfg(all(creusot, bytes_original_unique_gate))]
impl BytesMut {
    #[logic(open(self), prophetic)]
    pub(crate) fn unique_valid(self) -> bool {
        pearlite! {
            match self.unique_proof {
                None => false,
                Some(proof) => {
                    let caps = proof.capabilities.inner_logic();
                    proof.base.invariant() && proof.raw.invariant() &&
                    proof.raw.namespace() == caps.0.namespace() && proof.raw.capacity() == self.cap@ &&
                    proof.raw.raw_pointer() == proof.base.raw_pointer() && caps.0.invariant() && caps.1.invariant() &&
                    proof.base@ == Some((caps.0.namespace(), self.cap@, 0int)) &&
                    self.ptr@ == proof.base.raw_pointer() &&
                    caps.0.capacity() == self.cap@ && caps.1.capacity() == self.cap@ &&
                    caps.1.namespace() == caps.0.namespace() &&
                    caps.1.resource_id() == caps.0.namespace() &&
                    caps.1.lo() == 0 && caps.1.hi() == self.cap@ &&
                    self.len <= self.cap &&
                    self.data.addr_logic()@ < 32 && self.data.addr_logic()@ % 4 == 1 &&
                    (forall<i:Int> 0 <= i && i < self.len@ ==> slot_known(caps.1.slot(i)))
                }
            }
        }
    }
    #[logic(open(self))]
    pub(crate) fn unique_slot(self, index: Int) -> Option<Option<u8>> {
        pearlite! { self.unique_proof.unwrap_logic().capabilities.inner_logic().1.slot(index) }
    }
    #[logic(open(self))]
    pub(crate) fn unique_bytes(self) -> Seq<u8> {
        pearlite! { Seq::create(self.len@, |i:Int| self.unique_slot(i).unwrap_logic().unwrap_logic()) }
    }
}
#[cfg(all(creusot, bytes_original_unique_gate))]
#[check(ghost)]
#[bitwise_proof]
#[requires(repr <= 7usize)]
#[ensures(((repr << 2usize) | 1usize)@ < 32)]
#[ensures(((repr << 2usize) | 1usize)@ % 4 == 1)]
fn original_unique_metadata_bits(repr: usize) {}
#[cfg(all(creusot, bytes_original_unique_gate))]
#[check(ghost)]
#[bitwise_proof]
#[requires(addr@ < 32 && addr@ % 4 == 1)]
#[ensures(addr & 1usize == 1usize)]
#[ensures(addr >> 5usize == 0usize)]
fn original_unique_decode_bits(addr: usize) {}
// ORIGINAL_UNIQUE_END proof_model
struct Shared {
    vec: Vec<u8>,
    original_capacity_repr: usize,
    ref_count: AtomicUsize,
}
const KIND_ARC: usize = 0b0;
const KIND_VEC: usize = 0b1;
const KIND_MASK: usize = 0b1;
const MAX_ORIGINAL_CAPACITY_WIDTH: usize = 17;
const MIN_ORIGINAL_CAPACITY_WIDTH: usize = 10;
const ORIGINAL_CAPACITY_MASK: usize = 0b11100;
const ORIGINAL_CAPACITY_OFFSET: usize = 2;
const VEC_POS_OFFSET: usize = 5;
const MAX_VEC_POS: usize = usize::MAX >> VEC_POS_OFFSET;
const NOT_VEC_POS_MASK: usize = 0b11111;
#[cfg(target_pointer_width = "64")]
const PTR_WIDTH: usize = 64;
#[cfg(target_pointer_width = "32")]
const PTR_WIDTH: usize = 32;
impl BytesMut {
// ORIGINAL_UNIQUE_BEGIN with_capacity
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.len == 0usize))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_bytes() == Seq::empty()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(capacity <= result.cap))]
    #[inline]
    pub fn with_capacity(capacity: usize) -> BytesMut {
        BytesMut::from_vec(Vec::with_capacity(capacity))
    }
// ORIGINAL_UNIQUE_END with_capacity
// ORIGINAL_UNIQUE_BEGIN len
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result == self.len))]
    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }
// ORIGINAL_UNIQUE_END len
// ORIGINAL_UNIQUE_BEGIN capacity
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result == self.cap))]
    #[inline]
    pub fn capacity(&self) -> usize {
        self.cap
    }
// ORIGINAL_UNIQUE_END capacity
// ORIGINAL_UNIQUE_BEGIN reserve
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(additional@ <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(^self == *self))]
    #[inline]
    pub fn reserve(&mut self, additional: usize) {
        let len = self.len();
        let rem = self.capacity() - len;

        if additional <= rem {
            // The handle can already store at least `additional` more bytes, so
            // there is no further work needed to be done.
            return;
        }

        // will always succeed
        let _ = self.reserve_inner(additional, true);
    }
// ORIGINAL_UNIQUE_END reserve
// ORIGINAL_UNIQUE_BEGIN extend
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(extend@.len() <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).len@ == self.len@ + extend@.len()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_bytes() == self.unique_bytes().concat(extend@)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < self.len@ ==> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < extend@.len() ==> (^self).unique_slot(self.len@ + i) == Some(Some(extend@[i]))))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> self.len@ + extend@.len() <= i && i < self.cap@ ==> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[inline]
    pub fn extend_from_slice(&mut self, extend: &[u8]) {
        let cnt = extend.len();
        self.reserve(cnt);

        unsafe {
            let dst = self.spare_capacity_mut();
            // Reserved above
            debug_assert!(dst.len() >= cnt);

            crate::storage_ops::copy_to_uninit_prefix_raw(dst, extend);
        }

        unsafe {
            self.advance_mut(cnt);
        }
    }
// ORIGINAL_UNIQUE_END extend
// ORIGINAL_UNIQUE_BEGIN from_vec
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.len@ == vec@.len()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.unique_bytes() == vec@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.cap@ == creusot_std::std::vec::capacity_model(vec)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> result.len@ <= i && i < result.cap@ ==> result.unique_slot(i) == Some(None)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < vec@.len() ==> result.unique_slot(i) == Some(Some(vec@[i]))))]
    #[inline]
    pub(crate) fn from_vec(vec: Vec<u8>) -> BytesMut {
        #[cfg(not(all(creusot, bytes_original_unique_gate)))]
        let (ptr, len, cap) = {
            let mut vec = ManuallyDrop::new(vec);
            (vptr(vec.as_mut_ptr()), vec.len(), vec.capacity())
        };
        #[cfg(all(creusot, bytes_original_unique_gate))]
        let (ptr, len, cap, unique_proof) = {
            // B1 consumes precisely the Vec hidden by native ManuallyDrop.
            let (raw, len, capabilities) = raw_vec::detach_vec(vec);
            let (base, cap) = raw.bound_ptr_at_zero();
            let ptr = base.as_non_null();
            (ptr, len, cap, Some(OriginalUniqueProof { base, raw, capabilities }))
        };

        let original_capacity_repr = original_capacity_to_repr(cap);
        let data = (original_capacity_repr << ORIGINAL_CAPACITY_OFFSET) | KIND_VEC;
        #[cfg(all(creusot, bytes_original_unique_gate))]
        ghost! { original_unique_metadata_bits(original_capacity_repr) };

        BytesMut {
            ptr,
            len,
            cap,
            data: invalid_ptr(data),
            #[cfg(all(creusot, bytes_original_unique_gate))]
            unique_proof,
        }
    }
// ORIGINAL_UNIQUE_END from_vec
// ORIGINAL_UNIQUE_BEGIN spare
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result@.len() == self.cap@ - self.len@ && (^result)@.len() == self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data && (^self).len == self.len))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> 0 <= i && i < self.len@ ==> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> self.len@ <= i && i < self.cap@ ==> self.unique_slot(i) == Some(result@[i-self.len@]@)))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> self.len@ <= i && i < self.cap@ ==> (^self).unique_slot(i) == Some((^result)@[i-self.len@]@)))]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<u8>] {
        #[cfg(all(creusot, bytes_original_unique_gate))]
        {
            let proof = self.unique_proof.as_mut().unwrap();
            unsafe { raw_vec::borrow_spare_preserving_prefix(
                proof.base, self.len, self.cap, ghost! { &mut proof.capabilities.1 }
            ) }
        }
        #[cfg(not(all(creusot, bytes_original_unique_gate)))]
        unsafe {
            let ptr = self.ptr.as_ptr().add(self.len);
            let len = self.cap - self.len;

            slice::from_raw_parts_mut(ptr.cast(), len)
        }
    }
// ORIGINAL_UNIQUE_END spare
// ORIGINAL_UNIQUE_BEGIN advance_mut
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(cnt@ <= self.cap@ - self.len@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), requires(forall<i:Int> self.len@ <= i && i < self.len@ + cnt@ ==> slot_known(self.unique_slot(i))))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).len@ == self.len@ + cnt@))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures((^self).ptr == self.ptr && (^self).cap == self.cap && (^self).data == self.data))]
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(forall<i:Int> (^self).unique_slot(i) == self.unique_slot(i)))]
    #[inline]
    unsafe fn advance_mut(&mut self, cnt: usize) {
        let remaining = self.cap - self.len();
        if cnt > remaining {
            super::panic_advance(&TryGetError {
                requested: cnt,
                available: remaining,
            });
        }
        // Addition won't overflow since it is at most `self.cap`.
        self.len = self.len() + cnt;
    }
// ORIGINAL_UNIQUE_END advance_mut
// ORIGINAL_FREEZE_BEGIN kind
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result == KIND_VEC))]
    #[inline]
    fn kind(&self) -> usize {
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        {
            let addr = crate::provenance_specs::pointer_addr(self.data);
            ghost! { original_unique_decode_bits(addr) };
            addr & KIND_MASK
        }
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        { self.data as usize & KIND_MASK }
    }
// ORIGINAL_FREEZE_END kind
// ORIGINAL_FREEZE_BEGIN get_vec_pos
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result == 0usize))]
    #[inline]
    unsafe fn get_vec_pos(&self) -> usize {
        debug_assert_eq!(self.kind(), KIND_VEC);

        #[cfg(all(creusot, bytes_original_freeze_gate))]
        {
            let addr = crate::provenance_specs::pointer_addr(self.data);
            ghost! { original_unique_decode_bits(addr) };
            addr >> VEC_POS_OFFSET
        }
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        { self.data as usize >> VEC_POS_OFFSET }
    }
// ORIGINAL_FREEZE_END get_vec_pos
// ORIGINAL_FREEZE_BEGIN freeze
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.unique_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.len < self.cap))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_bytes() == self.unique_bytes()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_pointer() == self.ptr@ as *const u8))]
    #[inline]
    pub fn freeze(self) -> Bytes {
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        let bytes = ManuallyDrop::new(self);
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        let mut bytes = self;
        if bytes.kind() == KIND_VEC {
            // Just re-use `Bytes` internal Vec vtable
            unsafe {
                let off = bytes.get_vec_pos();
                #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
                let vec = rebuild_vec(bytes.ptr.as_ptr(), bytes.len, bytes.cap, off);
                #[cfg(all(creusot, bytes_original_freeze_gate))]
                let vec = original_rebuild_unique(bytes.ptr.as_ptr(), bytes.len, bytes.cap, off,
                    bytes.unique_proof.take().unwrap());
                #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
                let mut b: Bytes = vec.into();
                #[cfg(all(creusot, bytes_original_freeze_gate))]
                let mut b: Bytes = Bytes::from(vec);
                b.advance(off);
                b
            }
        } else {
            debug_assert_eq!(bytes.kind(), KIND_ARC);

            #[cfg(all(creusot, bytes_original_freeze_gate))]
            { unreachable!("selected Vec/off0 path"); }
            #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
            {
                let ptr = bytes.ptr.as_ptr();
                let len = bytes.len;
                let data = AtomicPtr::new(bytes.data.cast());
                unsafe { Bytes::with_vtable(ptr, len, data, &SHARED_VTABLE) }
            }
        }
    }
// ORIGINAL_FREEZE_END freeze
#[requires(false)] fn reserve_inner(&mut self,_n:usize,_a:bool)->bool {panic!("excluded growth")}
}
// ORIGINAL_UNIQUE_BEGIN capacity_repr
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result <= 7usize))]
#[inline]
fn original_capacity_to_repr(cap: usize) -> usize {
    let width = PTR_WIDTH - ((cap >> MIN_ORIGINAL_CAPACITY_WIDTH).leading_zeros() as usize);
    cmp::min(
        width,
        MAX_ORIGINAL_CAPACITY_WIDTH - MIN_ORIGINAL_CAPACITY_WIDTH,
    )
}
// ORIGINAL_UNIQUE_END capacity_repr
// ORIGINAL_UNIQUE_BEGIN invalid_ptr
    #[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result.addr_logic() == addr))]
#[inline]
fn invalid_ptr<T>(addr: usize) -> *mut T {
    let ptr = core::ptr::null_mut::<u8>().wrapping_add(addr);
    debug_assert_eq!(crate::provenance_specs::pointer_addr(ptr), addr);
    ptr.cast::<T>()
}
// ORIGINAL_UNIQUE_END invalid_ptr
// ORIGINAL_UNIQUE_BEGIN vptr
#[cfg_attr(all(creusot, bytes_original_unique_gate), requires(!ptr.is_null_logic()))]
#[cfg_attr(all(creusot, bytes_original_unique_gate), ensures(result@ == ptr))]
#[inline]
fn vptr(ptr: *mut u8) -> NonNull<u8> {
    if cfg!(debug_assertions) {
        NonNull::new(ptr).expect("Vec pointer should be non-null")
    } else {
        unsafe { NonNull::new_unchecked(ptr) }
    }
}
// ORIGINAL_UNIQUE_END vptr
// ORIGINAL_FREEZE_BEGIN rebuild_vec
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(off == 0usize))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.raw.invariant()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(ptr == proof.raw.raw_pointer() && cap@ == proof.raw.capacity()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().0.invariant() && proof.capabilities.inner_logic().1.invariant()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().0.namespace() == proof.raw.namespace()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().1.namespace() == proof.raw.namespace()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().1.resource_id() == proof.raw.namespace()))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().0.capacity() == cap@ && proof.capabilities.inner_logic().1.capacity() == cap@))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(proof.capabilities.inner_logic().1.lo() == 0 && proof.capabilities.inner_logic().1.hi() == cap@))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(len <= cap))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(forall<i:Int> 0 <= i && i < len@ ==> slot_known(proof.capabilities.inner_logic().1.slot(i))))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result@.len() == len@))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(creusot_std::std::vec::capacity_model(result) == cap@))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(creusot_std::std::vec::pointer_model(result) == ptr))]
#[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(forall<i:Int> 0 <= i && i < len@ ==> proof.capabilities.inner_logic().1.slot(i) == Some(Some(result@[i]))))]
#[cfg(all(creusot, bytes_original_freeze_gate))]
unsafe fn original_rebuild_unique(ptr: *mut u8, len: usize, cap: usize, off: usize,
    proof: OriginalUniqueProof,
) -> Vec<u8> {
    unsafe { raw_vec::resume_vec(proof.raw, len, proof.capabilities) }
}
// ORIGINAL_FREEZE_END rebuild_vec
