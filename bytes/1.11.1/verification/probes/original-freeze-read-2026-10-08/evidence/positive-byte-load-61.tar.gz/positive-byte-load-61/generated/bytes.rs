use core::{mem::{self,ManuallyDrop},ptr,slice};
use alloc::{vec::Vec,boxed::Box};
use core::sync::atomic::{AtomicPtr,AtomicUsize};
use crate::BytesMut;
// ORIGINAL_FREEZE_BEGIN bytes_imports
#[cfg(all(creusot, bytes_original_freeze_gate))]
use creusot_std::{prelude::*, ghost::perm::Perm};
#[cfg(all(creusot, bytes_original_freeze_gate))]
use crate::ownership_proof::{raw_vec::{self, BoundPtr, Recovery, PhysicalRegion, slot_known}, boxed_alignment};
// ORIGINAL_FREEZE_END bytes_imports
pub struct Bytes {
    ptr: *const u8,
    len: usize,
    // inlined "trait object"
    data: AtomicPtr<()>,
    vtable: &'static Vtable,
    #[cfg(all(creusot, bytes_original_freeze_gate))]
    original_frozen: Option<OriginalFrozenProof>,
}
pub(crate) struct Vtable {
    /// fn(data, ptr, len)
    pub clone: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> Bytes,
    /// fn(data, ptr, len)
    ///
    /// `into_*` consumes the `Bytes`, returning the respective value.
    pub into_vec: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> Vec<u8>,
    pub into_mut: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> BytesMut,
    /// fn(data)
    pub is_unique: unsafe fn(&AtomicPtr<()>) -> bool,
    /// fn(data, ptr, len)
    pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),
}
struct Shared {
    // Holds arguments to dealloc upon Drop, but otherwise doesn't use them
    buf: *mut u8,
    cap: usize,
    ref_cnt: AtomicUsize,
}
// ORIGINAL_FREEZE_BEGIN frozen_model
#[cfg(all(creusot, bytes_original_freeze_gate))]
struct OriginalFrozenProof {
    base: BoundPtr,
    capabilities: Ghost<(Recovery, PhysicalRegion)>,
    shared: *mut Shared,
    shared_owner: Ghost<Box<Perm<*const Shared>>>,
}
#[cfg(all(creusot, bytes_original_freeze_gate))]
impl Bytes {
    #[logic(open(self), prophetic)]
    pub(crate) fn original_frozen_valid(self) -> bool {
        pearlite! {
            match self.original_frozen {
                None => false,
                Some(proof) => {
                    let caps = proof.capabilities.inner_logic();
                    proof.base.invariant() && caps.0.invariant() && caps.1.invariant() &&
                    proof.base@ == Some((caps.0.namespace(), caps.0.capacity(), 0int)) &&
                    self.ptr == proof.base.raw_pointer() as *const u8 &&
                    caps.1.capacity() == caps.0.capacity() &&
                    caps.1.namespace() == caps.0.namespace() &&
                    caps.1.resource_id() == caps.0.namespace() &&
                    caps.1.lo() == 0 && caps.1.hi() == caps.0.capacity() &&
                    self.len@ < caps.0.capacity() &&
                    *proof.shared_owner.ward() == proof.shared as *const Shared &&
                    proof.shared_owner.val().buf == proof.base.raw_pointer() &&
                    proof.shared_owner.val().cap@ == caps.0.capacity() &&
                    (forall<i:Int> 0 <= i && i < self.len@ ==> slot_known(caps.1.slot(i)))
                }
            }
        }
    }
    #[logic(open(self))]
    pub(crate) fn original_frozen_bytes(self) -> Seq<u8> {
        pearlite! { Seq::create(self.len@, |i:Int|
            self.original_frozen.unwrap_logic().capabilities.inner_logic().1.slot(i).unwrap_logic().unwrap_logic()) }
    }
    #[logic(open(self))]
    pub(crate) fn original_frozen_pointer(self) -> *const u8 { self.ptr }
}
// Temporary ordinary translation leaves. No atomic value/state, refcount,
// vtable identity or callback law is assumed. Native branches below still use
// the exact original core/loom constructors and SHARED_VTABLE reference.
#[cfg(all(creusot, bytes_original_freeze_gate))]
#[trusted]
#[ensures(true)]
fn original_atomic_usize_new(_value: usize) -> AtomicUsize { unimplemented!() }
#[cfg(all(creusot, bytes_original_freeze_gate))]
#[trusted]
#[ensures(true)]
fn original_atomic_ptr_new<T>(_value: *mut T) -> AtomicPtr<T> { unimplemented!() }
#[cfg(all(creusot, bytes_original_freeze_gate))]
#[trusted]
#[ensures(true)]
fn original_shared_vtable() -> &'static Vtable { unimplemented!() }
// ORIGINAL_FREEZE_END frozen_model
const KIND_MASK:usize=0b1;
impl Bytes {
// ORIGINAL_FREEZE_BEGIN bytes_len
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result == self.len))]
    #[inline]
    pub const fn len(&self) -> usize {
        self.len
    }
// ORIGINAL_FREEZE_END bytes_len
// ORIGINAL_FREEZE_BEGIN bytes_as_slice
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.original_frozen_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result@ == self.original_frozen_bytes()))]
    #[inline]
    fn as_slice(&self) -> &[u8] {
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        {
            let proof = self.original_frozen.as_ref().unwrap();
            unsafe { raw_vec::borrow_bound(&proof.base, self.len, ghost! { &proof.capabilities.1 }) }
        }
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        unsafe { slice::from_raw_parts(self.ptr, self.len) }
    }
// ORIGINAL_FREEZE_END bytes_as_slice
// ORIGINAL_FREEZE_BEGIN bytes_inc_start
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.original_frozen_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(by == 0usize))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(^self == *self))]
    #[inline]
    unsafe fn inc_start(&mut self, by: usize) {
        // should already be asserted, but debug assert for tests
        debug_assert!(self.len >= by, "internal: inc_start out of bounds");
        self.len -= by;
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        { self.ptr = self.ptr.add(by); }
        // Selected by == 0: exact same pointer, no new raw access boundary.
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        { proof_assert!(by == 0usize); }
    }
// ORIGINAL_FREEZE_END bytes_inc_start
// ORIGINAL_FREEZE_BEGIN bytes_advance
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(self.original_frozen_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(cnt == 0usize))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(^self == *self))]
    #[inline]
    pub(crate) fn advance(&mut self, cnt: usize) {
        assert!(
            cnt <= self.len(),
            "cannot advance past `remaining`: {:?} <= {:?}",
            cnt,
            self.len(),
        );

        unsafe {
            self.inc_start(cnt);
        }
    }
// ORIGINAL_FREEZE_END bytes_advance
// ORIGINAL_FREEZE_BEGIN bytes_from_vec
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), requires(vec@.len() < creusot_std::std::vec::capacity_model(vec)))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_valid()))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_bytes() == vec@))]
    #[cfg_attr(all(creusot, bytes_original_freeze_gate), ensures(result.original_frozen_pointer() == creusot_std::std::vec::pointer_model(vec) as *const u8))]
    pub(crate) fn from(vec: Vec<u8>) -> Bytes {
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        let mut vec = ManuallyDrop::new(vec);
        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        let (ptr, len, cap) = (vec.as_mut_ptr(), vec.len(), vec.capacity());
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        let (ptr, len, cap, base, capabilities) = {
            let (raw, len, capabilities) = raw_vec::detach_vec(vec);
            let (base, cap) = raw.into_bound_ptr_at_zero();
            (base.as_ptr(), len, cap, base, capabilities)
        };

        // Avoid an extra allocation if possible.
        if len == cap {
            #[cfg(all(creusot, bytes_original_freeze_gate))]
            { unreachable!("selected spare-capacity Shared path"); }
            #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
            {
                let vec = ManuallyDrop::into_inner(vec);
                return Bytes::from(vec.into_boxed_slice());
            }
        }

        let shared = Box::new(Shared {
            buf: ptr,
            cap,
            ref_cnt: {
                #[cfg(all(creusot, bytes_original_freeze_gate))]
                { original_atomic_usize_new(1) }
                #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
                { AtomicUsize::new(1) }
            },
        });

        #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
        let shared = Box::into_raw(shared);
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        let (shared, shared_owner) = boxed_alignment::into_raw_aligned(shared);
        #[cfg(all(creusot, bytes_original_freeze_gate))]
        boxed_alignment::aligned_address_has_clear_low_bit(
            crate::provenance_specs::pointer_addr(shared), core::mem::align_of::<Shared>()
        );
        // The pointer should be aligned, so this assert should
        // always succeed.
        debug_assert!(
            0 == (crate::provenance_specs::pointer_addr(shared) & KIND_MASK),
            "internal: Box<Shared> should have an aligned pointer",
        );
        Bytes {
            #[cfg(all(creusot, bytes_original_freeze_gate))]
            original_frozen: Some(OriginalFrozenProof { base, capabilities, shared, shared_owner }),
            ptr,
            len,
            data: {
                #[cfg(all(creusot, bytes_original_freeze_gate))]
                { original_atomic_ptr_new(shared as _) }
                #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
                { AtomicPtr::new(shared as _) }
            },
            vtable: {
                #[cfg(all(creusot, bytes_original_freeze_gate))]
                { original_shared_vtable() }
                #[cfg(not(all(creusot, bytes_original_freeze_gate)))]
                { &SHARED_VTABLE }
            },
        }
    }
// ORIGINAL_FREEZE_END bytes_from_vec
}

#[requires(input@.len() < usize::MAX@)]
#[ensures(result.0.original_frozen_valid())]
#[ensures(result.0.original_frozen_bytes() == input@)]
#[ensures(result.1@ == input@.len())]
pub fn original_freeze_and_read(input:&[u8])->(Bytes,usize) {
 let mut value=BytesMut::with_capacity(input.len()+1);
 value.extend_from_slice(input);
 let frozen=value.freeze();
 let slice=frozen.as_slice();
 proof_assert!(slice@ == input@);
 let observed=slice.len();
 (frozen,observed)
}

#[requires(input@.len() < usize::MAX@)]
#[ensures(result.0.original_frozen_valid())]
#[ensures(result.0.original_frozen_bytes() == input@)]
#[ensures(result.1 == if input@.len() == 0 { None } else { Some(input@[0]) })]
pub fn original_freeze_and_load_byte(input:&[u8])->(Bytes,Option<u8>) {
 let mut value=BytesMut::with_capacity(input.len()+1);
 value.extend_from_slice(input);
 let frozen=value.freeze();
 let slice=frozen.as_slice();
 let observed=if slice.len()==0 { None } else { Some(slice[0]) };
 (frozen,observed)
}
#[cfg(feature="negative_retarget_read")]
#[requires(input@.len() < usize::MAX@)]
pub fn negative_retarget_read(input:&[u8])->Bytes {
 let mut value=BytesMut::with_capacity(input.len()+1);
 value.extend_from_slice(input);
 let mut frozen=value.freeze();
 // Deliberately retarget the native field without a matching physical capability.
 frozen.ptr=ptr::null();
 let _slice=frozen.as_slice();
 frozen
}
