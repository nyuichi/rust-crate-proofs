#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-shared-singleton-reserve-1147c8afe82114c8/out/scalable_tickets.rs"]
mod scalable_tickets;
