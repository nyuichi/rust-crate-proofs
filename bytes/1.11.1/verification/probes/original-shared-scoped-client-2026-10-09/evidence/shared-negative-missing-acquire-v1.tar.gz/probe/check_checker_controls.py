#!/usr/bin/env python3
"""Replay no-solver mutations against the independent native-client checker."""
from __future__ import annotations

import importlib.util
import json
import pathlib
import sys
import argparse
import hashlib
from typing import Callable

ROOT = pathlib.Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures" / "checker-controls.json"
CLIENT = ROOT / "src" / "native_client.rs"
CHECKER = ROOT / "check_correspondence.py"


def load_checker():
    spec = importlib.util.spec_from_file_location("scope_client_correspondence", CHECKER)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load independent correspondence checker")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def replace_once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise RuntimeError(f"fixture mutation anchor must occur once: {old!r}")
    return source.replace(old, new, 1)


def replace_in_marker(source: str, marker: str, old: str, new: str) -> str:
    begin = f"// ORIGINAL_SHARED_BEGIN {marker}\n"
    end = f"// ORIGINAL_SHARED_END {marker}\n"
    if source.count(begin) != 1 or source.count(end) != 1:
        raise RuntimeError(f"fixture marker must occur once: {marker}")
    a = source.index(begin)
    b = source.index(end, a) + len(end)
    chunk = source[a:b]
    changed = replace_once(chunk, old, new)
    return source[:a] + changed + source[b:]


def mutations(source: str) -> dict[str, str]:
    changed: dict[str, str] = {}
    changed["unretired_extra_clone"] = replace_once(
        source, "    let fourth = second.clone();",
        "    let fourth = second.clone();\n    let extra = first.clone();")
    changed["escaped_bytes_owner"] = replace_once(source, "    observed\n}", "    fourth\n}")
    changed["unfinished_callback"] = replace_once(
        source, "    let fourth = second.clone();",
        "    let fourth = second.clone();\n    unknown_callback(&fourth);")
    changed["thread_escape"] = replace_once(
        source, "    let fourth = second.clone();",
        "    let fourth = second.clone();\n    std::thread::spawn(move || fourth.clone());")
    changed["raw_alias"] = replace_once(
        source, "    let fourth = second.clone();",
        "    let fourth = second.clone();\n    let raw = &fourth as *const Bytes;")
    changed["forgotten_handle"] = replace_once(
        source, "    let fourth = second.clone();",
        "    let fourth = second.clone();\n    core::mem::forget(fourth);")
    changed["wrong_clone_source"] = replace_once(source, "let third = first.clone();", "let third = second.clone();")
    changed["borrow_from_wrong_owner"] = replace_once(
        source, "let borrowed = AsRef::<[u8]>::as_ref(&fourth);",
        "let borrowed = AsRef::<[u8]>::as_ref(&second);")
    changed["copy_before_peer_cleanup"] = replace_once(
        source,
        "    second.cleanup();\n    let observed = borrowed.to_vec();",
        "    let observed = borrowed.to_vec();\n    second.cleanup();")
    changed["retire_borrow_owner_before_copy"] = replace_once(
        source,
        "    second.cleanup();\n    let observed = borrowed.to_vec();\n    fourth.cleanup();",
        "    second.cleanup();\n    fourth.cleanup();\n    let observed = borrowed.to_vec();")
    changed["duplicate_cleanup"] = replace_once(
        source, "    fourth.cleanup();\n    observed",
        "    fourth.cleanup();\n    fourth.cleanup();\n    observed")
    changed["omitted_cleanup"] = replace_once(source, "    first.cleanup();\n", "")
    changed["wrong_native_order"] = replace_once(
        source,
        "    third.cleanup();\n    first.cleanup();\n    let fourth = second.clone();",
        "    let fourth = second.clone();\n    third.cleanup();\n    first.cleanup();")
    changed["comment_cannot_replace_event"] = replace_once(source, "    third.cleanup();", "    // third.cleanup();")
    changed["string_cannot_replace_event"] = replace_once(
        source, "    third.cleanup();", '    let fake = "third.cleanup();";')
    return changed


def production_mutations(source: str) -> dict[str, str]:
    """Adversarial edits to real production spans; the checker reparses them."""
    changed: dict[str, str] = {}
    changed["wrong_vtable_clone_target"] = replace_in_marker(
        source, "shared_vtable", "    clone: shared_clone,", "    clone: static_clone,")
    changed["wrong_clone_helper_target"] = replace_in_marker(
        source, "shared_clone", "shallow_clone_arc(shared as _, ptr, len)", "shared_clone(shared as _, ptr, len)")
    changed["duplicate_release_callback"] = replace_in_marker(
        source, "shared_drop", "        release_shared(shared.cast());", "        release_shared(shared.cast());\n        release_shared(shared.cast());")
    changed["wrong_native_event_order"] = replace_in_marker(
        source, "release_shared", "    (*ptr).ref_cnt.load(Ordering::Acquire);\n\n    // Explicit cleanup has the same payload/control effects as dropping the Box.",
        "    free_shared(ptr);\n    (*ptr).ref_cnt.load(Ordering::Acquire);\n\n    // Explicit cleanup has the same payload/control effects as dropping the Box.")
    changed["missing_acquire"] = replace_in_marker(
        source, "release_shared", "    (*ptr).ref_cnt.load(Ordering::Acquire);\n", "")
    changed["omitted_payload_free"] = replace_in_marker(
        source, "free_shared", "    dealloc(buf, Layout::from_size_align(cap, 1).unwrap());\n", "")
    changed["omitted_control_free"] = replace_in_marker(
        source, "free_shared", "    dealloc(ptr.cast(), Layout::new::<Shared>());\n", "")
    changed["unconditional_from_requirement"] = replace_in_marker(
        source, "bytes_from_vec_impl", "    fn from(vec: Vec<u8>) -> Bytes {",
        "    #[requires(vec@.len() < creusot_std::std::vec::capacity_model(vec))]\n"
        "    fn from(vec: Vec<u8>) -> Bytes {")
    changed["wrong_clone_signature"] = replace_in_marker(
        source, "bytes_clone_impl", "fn clone(&self) -> Bytes {", "fn clone(&mut self) -> Bytes {")
    changed["fake_comment_native_free"] = replace_in_marker(
        source, "release_shared", "    free_shared(ptr);\n", "    // free_shared(ptr);\n")
    changed["fake_string_native_free"] = replace_in_marker(
        source, "release_shared", "    free_shared(ptr);\n", '    let fake = "free_shared(ptr);";\n')
    return changed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=pathlib.Path,
                        default=ROOT / "fixtures" / "checker-control-results.json")
    args = parser.parse_args()
    spec = json.loads(FIXTURES.read_text())
    checker = load_checker()
    source = CLIENT.read_text()
    production_source = checker.BYTES_SOURCE.read_text()
    refcount_source = checker.REFCOUNT_SOURCE.read_text()
    try:
        positive = checker.audit_native_client(source)
    except checker.CorrespondenceError as exc:
        print(json.dumps({"status": "controls_failed", "error": f"positive client rejected: {exc}"}, indent=2))
        return 2

    try:
        production_positive = checker.audit_production_chain(production_source, refcount_source)
    except checker.CorrespondenceError as exc:
        print(json.dumps({"status": "controls_failed", "error": f"positive production source rejected: {exc}"}, indent=2))
        return 2

    rows = []
    client_controls = mutations(source)
    source_controls = production_mutations(production_source)
    by_name = {**client_controls, **source_controls}
    expected_names = {row["name"] for row in spec["controls"]}
    if set(by_name) != expected_names:
        print(json.dumps({"status": "controls_failed", "error": "fixture names and mutations differ"}, indent=2))
        return 2
    for row in spec["controls"]:
        try:
            if row["name"] in client_controls:
                checker.audit_native_client(client_controls[row["name"]])
            else:
                checker.audit_production_chain(source_controls[row["name"]], refcount_source)
        except checker.CorrespondenceError as exc:
            rows.append({"name": row["name"], "class": row["class"], "rejected": True,
                         "reason": str(exc)})
        else:
            rows.append({"name": row["name"], "class": row["class"], "rejected": False,
                         "reason": "mutated client passed"})
    passed = all(row["rejected"] for row in rows)
    result = {
        "status": "controls_pass" if passed else "controls_failed",
        "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        "native_client_sha256": hashlib.sha256(CLIENT.read_bytes()).hexdigest(),
        "positive_status": "native_client_and_production_structural_pass",
        "positive_events": len(positive["events"]),
        "production_native_chain": production_positive["native_clone_target"],
        "controls": rows,
        "control_count": len(rows),
        "prover_invoked": False,
        "fixture_boundary": spec["boundary"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
