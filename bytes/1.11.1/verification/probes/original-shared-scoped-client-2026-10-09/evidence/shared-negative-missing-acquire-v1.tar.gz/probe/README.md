# Actual Shared closed client

This increment connects the closed issuance cursor to the original Shared Bytes
fields, constructor, shared-reference Clone, vtable callbacks, borrowed slice,
and explicit consuming cleanup. It does not admit automatic Drop, unwinding,
arbitrary concurrent clients, other representations, or the complete crate.
Only this client assumes input length is less than capacity. The existing
unrestricted constructor/refinement proof remains separate and unchanged.

`src/native_client.rs` uses the actual public API. `native-check.sh` compiles this
exact file against the production crate and exercises five inputs including an
empty vector with spare capacity. The proof shadow has the same ownership trace:
three handles, two early retirements, another clone, a borrowed slice held while
its peer retires, a content copy, and final retirement. Returned ticket identities
are observed rather than presumed or limited by a quota.

The cursor is a separate affine ghost argument; the Bytes sidecar contains only
its invariant descriptor and the existing ownership resources. Existing generic
three-native-argument erasure preserves native callback signatures. Cleanup has
an erased output channel containing `KeptAlive` or `Reclaimed(buffer, control)`.
The latter carries two opaque affine effect receipts from actual free calls.
The typed receipt records consumption of storage ownership, not execution of
`T::drop`; zero-sized disposal performs no physical free. Shared has nonzero
layout. Buffer and control deallocation remain distinct.

Trusted boundaries are explicit: pinned private Std/toolchain semantics,
closed-source ghost/native correspondence, existing callback reification and
three-argument erasure, scoped field events, physical provenance/allocation
adapters, and generic typed-free effect interpretation. Their contracts preserve
exact state observation, native pointer/model/lifetime identity, memory order,
allocation/layout, and consumed ownership. Bytes-specific issuance, release,
lastness, Acquire recovery, content and final-completion laws are body proved.
The local pointer wrappers retain the existing address-only STD-PTRWRAP-01
contract and all RawVec offset helper targets; no pointer dereference authority
is introduced.

Run `run-proof.sh` with elevated execution for Why3's Unix sockets. It uses one
prover, the shared lock, a 1024 MiB budget, and no sc-drf feature. Every generated
Coma target is included. Canonical capture requires the independent correspondence
checker to pass; diagnostic runs cannot be labeled canonical. `evidence.py`
hashes archived probe sources, generated targets/results, external source inputs,
private Std, tool configuration and run log. Structural checker controls and
semantic missing-Acquire/payload-free/control-free controls have separate labels.

Final validation and archive receipt are recorded after the controls and restored
canonical replay; intermediate diagnostic evidence is immutable.
