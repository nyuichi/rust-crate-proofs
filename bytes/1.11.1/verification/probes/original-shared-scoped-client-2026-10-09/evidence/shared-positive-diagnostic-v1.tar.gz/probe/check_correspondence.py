#!/usr/bin/env python3
"""Independent, fail-closed source/effect check for the actual Shared client.

This is intentionally a small closed-language checker, not a Rust parser or a
proof of the generic cursor, event, physical-free, or native MIR TCB. A passing
result must be derived from source text and exact extracted source spans; a
stored hash/receipt is never treated as correspondence evidence by itself.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import sys
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parent
CRATE_ROOT = pathlib.Path(__file__).resolve().parents[3]
DRIVER = ROOT / "src" / "native_client.rs"
SHADOW = ROOT / "src" / "public_shared.rs"
BYTES_SOURCE = CRATE_ROOT / "src" / "bytes.rs"
REFCOUNT_SOURCE = CRATE_ROOT / "src" / "ref_count_ops.rs"
GENERATED = ROOT / "generated"

EXPECTED_NATIVE_CLIENT = r'''//! Native source client mirrored by the scoped proof shadow in `public_shared.rs`.
//!
//! Keep this body as ordinary public-API use: construction remains
//! `Bytes::from`, clones remain `Clone::clone(&self)`, and explicit cleanup
//! consumes the original handles. The independent correspondence checker
//! compares this closed client with the proof shadow and the extracted
//! production constructor, trait, vtable, and callback sources.

use super::*;
use alloc::vec::Vec;

#[cfg_attr(creusot, requires(input@.len() < creusot_std::std::vec::capacity_model(input)))]
#[cfg_attr(creusot, ensures(result@ == input@))]
pub(crate) fn actual_public_shared_driver(input: Vec<u8>) -> Vec<u8> {
    let first = Bytes::from(input);
    let second = first.clone();
    let third = first.clone();
    third.cleanup();
    first.cleanup();
    let fourth = second.clone();
    let borrowed = AsRef::<[u8]>::as_ref(&fourth);
    second.cleanup();
    let observed = borrowed.to_vec();
    fourth.cleanup();
    observed
}'''

EXPECTED_EVENTS = [
    {"kind": "from_vec", "input": "input", "ticket": "first"},
    {"kind": "clone", "source": "first", "ticket": "second"},
    {"kind": "clone", "source": "first", "ticket": "third"},
    {"kind": "cleanup", "ticket": "third"},
    {"kind": "cleanup", "ticket": "first"},
    {"kind": "clone", "source": "second", "ticket": "fourth"},
    {"kind": "borrow", "source": "fourth", "view": "borrowed"},
    {"kind": "cleanup", "ticket": "second"},
    {"kind": "copy", "view": "borrowed", "source": "fourth", "result": "observed"},
    {"kind": "cleanup", "ticket": "fourth"},
    {"kind": "return", "value": "observed"},
]

SHARED_MARKERS = (
    "bytes_cleanup", "bytes_clone_impl", "bytes_from_vec_impl", "bytes_as_slice",
    "bytes_as_ref_impl", "shared_vtable", "shared_table_native", "shared_clone",
    "shared_drop", "shallow_clone_arc", "release_shared", "free_shared",
)


class CorrespondenceError(Exception):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise CorrespondenceError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def rust_tokens(text: str) -> list[str]:
    """A closed token reader: comments vanish and literals are opaque."""
    out: list[str] = []
    i, n = 0, len(text)
    multi = ("::", "->", "=>", "==", "!=", "<=", ">=", "&&", "||", "..", "+=", "-=", "*=", "/=")
    while i < n:
        if text[i].isspace():
            i += 1
            continue
        if text.startswith("//", i):
            end = text.find("\n", i)
            i = n if end < 0 else end + 1
            continue
        if text.startswith("/*", i):
            depth = 1
            i += 2
            while i < n and depth:
                if text.startswith("/*", i):
                    depth += 1
                    i += 2
                elif text.startswith("*/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            require(depth == 0, "unterminated Rust block comment")
            continue
        raw = re.match(r"(?:br|rb|cr|r)(#{0,})\"", text[i:])
        if raw:
            hashes = raw.group(1)
            i += len(raw.group(0))
            end = text.find('"' + hashes, i)
            require(end >= 0, "unterminated Rust raw string")
            i = end + len(hashes) + 1
            out.append("<literal>")
            continue
        if text.startswith(("b\"", "c\""), i):
            i += 1
        if text[i] == '"':
            i += 1
            escaped = False
            while i < n:
                char = text[i]
                i += 1
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    break
            else:
                raise CorrespondenceError("unterminated Rust string literal")
            out.append("<literal>")
            continue
        # A character literal is opaque; a lifetime (`'a`, `'static`) remains
        # punctuation plus an identifier because it has no adjacent closing quote.
        if text[i] == "'":
            j = i + 1
            if j < n and text[j] == "\\":
                j += 2
                while j < n and text[j].isalnum():
                    j += 1
            else:
                j += 1
            if j < n and text[j] == "'":
                out.append("<literal>")
                i = j + 1
                continue
        ident = re.match(r"[A-Za-z_][A-Za-z0-9_]*", text[i:])
        if ident:
            out.append(ident.group(0))
            i += len(ident.group(0))
            continue
        number = re.match(r"[0-9][A-Za-z0-9_]*", text[i:])
        if number:
            out.append(number.group(0))
            i += len(number.group(0))
            continue
        op = next((op for op in multi if text.startswith(op, i)), None)
        if op:
            out.append(op)
            i += len(op)
            continue
        out.append(text[i])
        i += 1
    return out


def mask_noncode(text: str) -> str:
    """Blank comments and quoted literals while preserving source offsets."""
    chars = list(text)
    i, n = 0, len(text)

    def blank(a: int, b: int) -> None:
        for k in range(a, b):
            if chars[k] != "\n":
                chars[k] = " "

    while i < n:
        raw = re.match(r"(?:br|rb|cr|r)(#{0,})\"", text[i:])
        if raw:
            h = raw.group(1)
            a = i
            i += len(raw.group(0))
            end = text.find('"' + h, i)
            require(end >= 0, "unterminated raw string while masking Rust")
            i = end + len(h) + 1
            blank(a, i)
            continue
        if text[i] in "\"" or text.startswith(("b\"", "c\""), i):
            a = i
            if text.startswith(("b\"", "c\""), i):
                i += 1
            i += 1
            escaped = False
            while i < n:
                ch = text[i]
                i += 1
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    break
            else:
                raise CorrespondenceError("unterminated string while masking Rust")
            blank(a, i)
            continue
        if text[i] == "'":
            a = i
            j = i + 1
            if j < n and text[j] == "\\":
                j += 2
                while j < n and text[j].isalnum():
                    j += 1
            else:
                j += 1
            if j < n and text[j] == "'":
                blank(a, j + 1)
                i = j + 1
                continue
        if text.startswith("//", i):
            a = i
            end = text.find("\n", i)
            i = n if end < 0 else end
            blank(a, i)
            continue
        if text.startswith("/*", i):
            a, depth = i, 1
            i += 2
            while i < n and depth:
                if text.startswith("/*", i):
                    depth += 1
                    i += 2
                elif text.startswith("*/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            require(depth == 0, "unterminated block comment while masking Rust")
            blank(a, i)
            continue
        i += 1
    return "".join(chars)


def find_function(source: str, name: str) -> tuple[list[str], int, int]:
    tokens = rust_tokens(source)
    pattern = ["fn", name, "("]
    found = [i for i in range(len(tokens) - len(pattern) + 1) if tokens[i:i + len(pattern)] == pattern]
    require(len(found) == 1, f"expected one `{name}` definition, found {len(found)}")
    start = found[0]
    brace = next((i for i in range(start + len(pattern), len(tokens)) if tokens[i] == "{"), None)
    require(brace is not None, f"function `{name}` has no body")
    depth = 0
    for i in range(brace, len(tokens)):
        if tokens[i] == "{":
            depth += 1
        elif tokens[i] == "}":
            depth -= 1
            if depth == 0:
                return tokens[brace + 1:i], start, i + 1
    raise CorrespondenceError(f"function `{name}` has an unclosed body")


def audit_native_client(source: str) -> dict[str, Any]:
    actual, start, end = find_function(source, "actual_public_shared_driver")
    expected, _, _ = find_function(EXPECTED_NATIVE_CLIENT, "actual_public_shared_driver")
    require(rust_tokens(source) == rust_tokens(EXPECTED_NATIVE_CLIENT),
            "native client is outside the single reviewed straight-line witness")
    # Independently recount operations in executable code, rather than trusting
    # the JSON receipt or treating comments/string contents as events.
    methods = [actual[i + 1] for i in range(len(actual) - 1)
               if actual[i] == "." and actual[i + 1] in {"clone", "cleanup", "to_vec"}]
    require(methods == ["clone", "clone", "cleanup", "cleanup", "clone", "cleanup", "to_vec", "cleanup"],
            f"native client operation order changed: {methods}")
    require(actual == expected, "native client body differs from admitted event source")
    live = {"first"}
    issued = {"first"}
    trace: list[dict[str, str]] = [EXPECTED_EVENTS[0]]
    borrowed_view: tuple[str, str] | None = None
    peer_retired_while_borrowed = False
    for kind, source_name, target_name in (
        ("clone", "first", "second"), ("clone", "first", "third"),
        ("cleanup", "third", ""), ("cleanup", "first", ""),
        ("clone", "second", "fourth"), ("borrow", "fourth", "borrowed"),
        ("cleanup", "second", ""), ("copy", "borrowed", "observed"),
        ("cleanup", "fourth", ""),
    ):
        if kind == "clone":
            require(source_name in live and target_name not in issued,
                    f"clone source/output is not affine: {source_name} -> {target_name}")
            live.add(target_name)
            issued.add(target_name)
            trace.append({"kind": "clone", "source": source_name, "ticket": target_name})
        elif kind == "cleanup":
            require(source_name in live, f"cleanup does not consume a live handle: {source_name}")
            require(not (borrowed_view and borrowed_view[0] == source_name),
                    f"cleanup invalidates a still-live borrowed view: {source_name}")
            if borrowed_view and borrowed_view[0] != source_name:
                peer_retired_while_borrowed = True
            live.remove(source_name)
            trace.append({"kind": "cleanup", "ticket": source_name})
        elif kind == "borrow":
            require(source_name in live, f"read uses a dead handle: {source_name}")
            require(borrowed_view is None, "native client introduces more than one borrowed view")
            borrowed_view = (source_name, target_name)
            trace.append({"kind": "borrow", "source": source_name, "view": target_name})
        else:
            require(borrowed_view is not None and borrowed_view[1] == source_name,
                    f"copy uses an unknown borrowed view: {source_name}")
            owner = borrowed_view[0]
            require(owner in live, f"copy uses a borrowed view after its owner retired: {owner}")
            require(peer_retired_while_borrowed,
                    "borrowed-slice witness does not span a peer cleanup")
            trace.append({"kind": "copy", "view": source_name, "source": owner, "result": target_name})
            # `to_vec` ends the borrow before the final explicit cleanup.
            borrowed_view = None
    require(not live, f"native client returns with live Bytes handles: {sorted(live)}")
    require(borrowed_view is None, "native client returns with an unfinished borrowed view")
    trace.append({"kind": "return", "value": "observed"})
    require(trace == EXPECTED_EVENTS, "derived native operation trace differs from the admitted trace")
    return {
        "entrypoint": "actual_public_shared_driver",
        "source_sha256": sha(source.encode()),
        "function_token_span": [start, end],
        "events": trace,
        "live_bytes_handles_at_return": 0,
        "closed_language": True,
        "strings_and_comments_are_not_code": True,
    }


def extract_marked(source: str, name: str) -> str:
    begin = f"// ORIGINAL_SHARED_BEGIN {name}\n"
    end = f"// ORIGINAL_SHARED_END {name}\n"
    require(source.count(begin) == 1 and source.count(end) == 1,
            f"production marker for `{name}` is missing or duplicated")
    start = source.index(begin)
    finish = source.index(end, start) + len(end.rstrip("\n"))
    return source[start:finish]


def contains_once(tokens: list[str], needle: list[str], label: str) -> None:
    count = sum(tokens[i:i + len(needle)] == needle for i in range(len(tokens) - len(needle) + 1))
    require(count == 1, f"{label}: expected one occurrence of {' '.join(needle)}, found {count}")


def audit_production_chain(bytes_source: str, refcount_source: str) -> dict[str, Any]:
    spans = {name: extract_marked(bytes_source, name) for name in SHARED_MARKERS}
    tok = {name: rust_tokens(span) for name, span in spans.items()}

    # Exact native table target and proof getter identity.
    for field, target in (("clone", "shared_clone"), ("drop", "shared_drop")):
        contains_once(tok["shared_vtable"], [field, ":", target, ","], "SHARED_VTABLE")
    contains_once(tok["shared_table_native"], ["&", "SHARED_VTABLE"], "native table getter")

    # The actual trait source retains native Clone(&self), From<Vec>, AsRef and
    # explicit consuming cleanup. These are exact extracted production spans,
    # not source-map hashes or similarly named local replacements.
    clone_t = tok["bytes_clone_impl"]
    contains_once(clone_t, ["fn", "clone", "(", "&", "self", ")", "->", "Bytes"],
                  "Bytes Clone trait item")
    contains_once(clone_t, ["self", ".", "vtable", ".", "clone"], "Bytes Clone native dispatch")
    contains_once(clone_t, ["(", "self", ".", "vtable", ".", "clone", ")", "(",
                           "&", "self", ".", "data", ",", "self", ".", "ptr", ",",
                           "self", ".", "len", ")"], "Bytes Clone actual three-argument call")
    drop_t = tok["bytes_cleanup"]
    contains_once(drop_t, ["fn", "cleanup", "(", "self", ")"], "Bytes cleanup signature")
    contains_once(drop_t, ["this", ".", "vtable", ".", "drop"], "Bytes cleanup native dispatch")
    contains_once(drop_t, ["let", "mut", "this", "=", "ManuallyDrop", "::", "new", "(", "self", ")"],
                  "Bytes cleanup suppresses later automatic Drop")
    contains_once(drop_t, ["unsafe", "{", "callback", "(", "&", "mut", "this", ".", "data", ",",
                           "ptr", ",", "len", ")", "}"], "Bytes cleanup actual callback call")
    from_t = tok["bytes_from_vec_impl"]
    contains_once(from_t, ["fn", "from", "(", "vec", ":", "Vec", "<", "u8", ">", ")", "->", "Bytes"],
                  "From<Vec<u8>> trait item")
    contains_once(from_t, ["if", "len", "==", "cap"], "From<Vec> native capacity branch")
    contains_once(from_t, ["&", "SHARED_VTABLE"], "From<Vec> native shared table")
    # From<Vec> retains historical, explicit Creusot-only gate annotations in
    # the archived source. They are disabled in the native cfg and are not used
    # by this proof shadow. Reject an unconditional requires and record that
    # every retained trait-item requires is gated by `creusot`.
    gated_requires = 0
    for index, token in enumerate(from_t):
        if token != "requires":
            continue
        attr_start = max((j for j in range(index) if from_t[j] == "#"), default=-1)
        attr = from_t[attr_start:index]
        require("cfg_attr" in attr and "creusot" in attr,
                "From<Vec> has a non-Creusot/unconditional requires annotation")
        gated_requires += 1

    clone_cb = tok["shared_clone"]
    contains_once(clone_cb, ["data", ".", "load", "(", "Ordering", "::", "Relaxed", ")"],
                  "shared clone Relaxed load")
    contains_once(clone_cb, ["shallow_clone_arc", "(", "shared", "as", "_", ",", "ptr", ",", "len", ")"],
                  "shared clone helper target")
    contains_once(tok["shallow_clone_arc"], ["crate", "::", "ref_count_ops", "::", "increment", "(", "&", "(", "*", "shared", ")", ".", "ref_cnt", ")"],
                  "shallow clone actual guarded refcount helper")
    contains_once(tok["shared_vtable"], ["into_vec", ":", "shared_to_vec", ","], "SHARED_VTABLE::into_vec")
    contains_once(tok["shared_vtable"], ["into_mut", ":", "shared_to_mut", ","], "SHARED_VTABLE::into_mut")
    contains_once(tok["shared_vtable"], ["is_unique", ":", "shared_is_unique", ","], "SHARED_VTABLE::is_unique")
    as_ref_t = tok["bytes_as_ref_impl"]
    contains_once(as_ref_t, ["impl", "AsRef", "<", "[", "u8", "]", ">", "for", "Bytes"],
                  "Bytes AsRef implementation")
    contains_once(as_ref_t, ["self", ".", "as_slice", "(", ")"], "Bytes AsRef native source")
    contains_once(tok["bytes_as_slice"], ["slice", "::", "from_raw_parts", "(", "self", ".", "ptr", ",", "self", ".", "len", ")"],
                  "Bytes slice native projection")
    drop_cb = tok["shared_drop"]
    contains_once(drop_cb, ["release_shared", "(", "shared", ".", "cast", "(", ")", ")"],
                  "shared drop callback target")
    release_t = tok["release_shared"]
    contains_once(release_t, ["ref_cnt", ".", "fetch_sub", "(", "1", ",", "Ordering", "::", "Release", ")"],
                  "Release decrement")
    contains_once(release_t, ["ref_cnt", ".", "load", "(", "Ordering", "::", "Acquire", ")"],
                  "Acquire finalizer load")
    contains_once(release_t, ["free_shared", "(", "ptr", ")"], "shared finalizer target")
    # Preserve ordering, not only the existence of each hook.
    release_body = function_body_after_marker(spans["release_shared"], "release_shared")
    ordered = [["fetch_sub"], ["Ordering", "::", "Acquire"], ["free_shared"]]
    positions = [find_subsequence(release_body, part) for part in ordered]
    require(all(pos is not None for pos in positions) and positions == sorted(positions),
            "shared finalizer must Release-decrement, Acquire, then free in source order")
    free_body = function_body_after_marker(spans["free_shared"], "free_shared")
    dealloc_positions = [i for i in range(len(free_body) - 1) if free_body[i:i + 2] == ["dealloc", "("]]
    require(len(dealloc_positions) == 2 and dealloc_positions[0] < dealloc_positions[1],
            "free_shared must deallocate the payload then the Shared control allocation exactly once")
    contains_once(free_body, ["dealloc", "(", "buf", ",", "Layout", "::", "from_size_align", "(", "cap", ",", "1", ")", ".", "unwrap", "(", ")", ")"],
                  "production payload free")
    contains_once(free_body, ["dealloc", "(", "ptr", ".", "cast", "(", ")", ",", "Layout", "::", "new", "::", "<", "Shared", ">", "(", ")", ")"],
                  "production typed control free")
    helper_t = rust_tokens(refcount_source)
    contains_once(helper_t, ["fetch_update", "(", "Ordering", "::", "Relaxed", ",", "Ordering", "::", "Relaxed"],
                  "native guarded refcount helper")
    contains_once(helper_t, ["crate", "::", "ref_count_limit", "::", "next_ref_count"],
                  "native checked refcount limit")
    return {
        "production_source": "src/bytes.rs",
        "production_marker_spans": {name: sha(value.encode()) for name, value in spans.items()},
        "native_clone_target": "SHARED_VTABLE.clone -> shared_clone -> shallow_clone_arc -> ref_count_ops::increment",
        "native_cleanup_target": "SHARED_VTABLE.drop -> shared_drop -> release_shared -> free_shared",
        "native_release_order": ["fetch_sub(Release)", "load(Acquire)", "free_shared"],
        "payload_and_control_frees": 2,
        "public_trait_signatures_preserved": True,
        "native_from_unrestricted": True,
        "creusot_only_historical_from_requires": gated_requires,
    }


def find_subsequence(tokens: list[str], needle: list[str]) -> int | None:
    for i in range(len(tokens) - len(needle) + 1):
        if tokens[i:i + len(needle)] == needle:
            return i
    return None


def function_body_after_marker(marked: str, name: str) -> list[str]:
    tokens = rust_tokens(marked)
    marker = ["fn", name, "("]
    positions = [i for i in range(len(tokens) - len(marker) + 1) if tokens[i:i + len(marker)] == marker]
    require(len(positions) == 1, f"expected one source function `{name}` in marker")
    open_at = next((i for i in range(positions[0] + len(marker), len(tokens)) if tokens[i] == "{"), None)
    require(open_at is not None, f"source function `{name}` body missing")
    depth = 0
    for i in range(open_at, len(tokens)):
        if tokens[i] == "{": depth += 1
        elif tokens[i] == "}":
            depth -= 1
            if depth == 0:
                return tokens[open_at + 1:i]
    raise CorrespondenceError(f"source function `{name}` body unclosed")


def extract_struct_source(source: str, start_text: str, label: str) -> str:
    require(source.count(start_text) == 1, f"expected unique {label} source declaration")
    start = source.index(start_text)
    mask = mask_noncode(source)
    open_brace = start + len(start_text) - 1
    require(mask[open_brace] == "{", f"bad struct parser anchor for {label}")
    depth = 0
    for i in range(open_brace, len(mask)):
        if mask[i] == "{": depth += 1
        elif mask[i] == "}":
            depth -= 1
            if depth == 0:
                return source[start:i + 1]
    raise CorrespondenceError(f"unclosed {label} source declaration")


def audit_generated_extractions(bytes_source: str, generated: pathlib.Path,
                                bytes_record_source: str, vtable_record_source: str,
                                bytes_mut_source: str) -> dict[str, Any]:
    """Compare extractor output token-for-token with independently found spans."""
    source_spans = {name: extract_marked(bytes_source, name) for name in SHARED_MARKERS}
    traits_path = generated / "public_traits.rs"
    native_path = generated / "native_bindings.rs"
    records_path = generated / "public_records.rs"
    require(records_path.is_file(), f"generated production record extraction missing: {records_path}")
    require(traits_path.is_file(), f"generated production trait extraction missing: {traits_path}")
    require(native_path.is_file(), f"generated native helper extraction missing: {native_path}")
    expected_traits = (source_spans["bytes_clone_impl"] + "\n" + source_spans["bytes_from_vec_impl"] + "\n"
                       + "impl Bytes {\n" + source_spans["bytes_cleanup"] + "\n"
                       + source_spans["bytes_as_slice"] + "\n}\n" + source_spans["bytes_as_ref_impl"] + "\n")
    native_names = ("shared_vtable", "shared_table_native", "shared_clone", "shallow_clone_arc",
                    "shared_drop", "release_shared", "free_shared")
    expected_native = "\n\n".join(source_spans[name] for name in native_names) + "\n"
    require(rust_tokens(traits_path.read_text()) == rust_tokens(expected_traits),
            "generated public_traits.rs tokens differ from actual production marker spans")
    require(rust_tokens(native_path.read_text()) == rust_tokens(expected_native),
            "generated native_bindings.rs tokens differ from actual production marker spans")
    shared_record = extract_struct_source(bytes_mut_source, "struct Shared {", "BytesMut::Shared")
    mutable_record = extract_struct_source(bytes_mut_source, "pub struct BytesMut {", "BytesMut")
    expected_records = (
        bytes_record_source + "\n" + vtable_record_source + "\n" +
        "mod mutable_record {\nuse alloc::vec::Vec;\n"
        "use core::{ptr::NonNull,sync::atomic::AtomicUsize};\n" +
        shared_record + "\n" + mutable_record + "\n}\nuse mutable_record::BytesMut;\n"
    )
    require(rust_tokens(records_path.read_text()) == rust_tokens(expected_records),
            "generated public_records.rs fields differ from actual production records")
    return {
        "public_traits_source_match": True,
        "native_bindings_source_match": True,
        "public_record_fields_source_match": True,
        "generated_dir": generated.as_posix(),
    }


def audit_shadow_source(source: str) -> dict[str, Any]:
    """Validate the finalized proof-side client and helper call surfaces.

    The helper bodies are deliberately not accepted by a cached hash. A final
    version will compare each body to its source parser and validate calls,
    cursor arguments, free receipts, Acquire and native callback targets.
    Until those reviewed source names/signatures are present this check fails
    closed, allowing the checker to be used as a gate while the shadow is being
    built.
    """
    tokens = rust_tokens(source)
    for required_name in ("actual_public_shared_driver", "original_shared_from_vec",
                          "original_shared_clone", "original_shared_cleanup", "free_recovered"):
        require(tokens.count(required_name) >= 1, f"proof shadow is missing `{required_name}`")
    for required_name in ("ScopeCursor", "KeptAlive", "Reclaimed", "physical_projection", "deallocate_typed_box"):
        require(required_name in tokens, f"proof shadow is missing scoped cleanup evidence `{required_name}`")
    raise CorrespondenceError(
        "proof shadow source parsing is not enabled until the coordinator freezes the helper bodies; "
        "presence-only inspection is deliberately insufficient"
    )


def audit_all(*, driver_source: str, shadow_source: str, bytes_source: str,
              refcount_source: str, bytes_record_source: str, vtable_record_source: str,
              bytes_mut_source: str, generated_dir: pathlib.Path | None = None) -> dict[str, Any]:
    client = audit_native_client(driver_source)
    production = audit_production_chain(bytes_source, refcount_source)
    shadow = audit_shadow_source(shadow_source)
    generated = (audit_generated_extractions(bytes_source, generated_dir, bytes_record_source,
                                            vtable_record_source, bytes_mut_source)
                 if generated_dir else None)
    return {
        "status": "correspondence_pass",
        "native_client": client,
        "production_native_chain": production,
        "proof_shadow": shadow,
        "generated_extractions": generated,
        "semantic_scope": "one closed actual Shared len<capacity client only; source correspondence does not prove generic scoped-field/cursor adequacy, native MIR semantics, arbitrary concurrent history, automatic Drop, or full Bytes admission",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--client", type=pathlib.Path, default=DRIVER)
    parser.add_argument("--shadow", type=pathlib.Path, default=SHADOW)
    parser.add_argument("--bytes-source", type=pathlib.Path, default=BYTES_SOURCE)
    parser.add_argument("--refcount-source", type=pathlib.Path, default=REFCOUNT_SOURCE)
    parser.add_argument("--bytes-record-source", type=pathlib.Path, default=CRATE_ROOT / "src/bytes/bytes_record.rs")
    parser.add_argument("--vtable-record-source", type=pathlib.Path, default=CRATE_ROOT / "src/bytes/vtable_record.rs")
    parser.add_argument("--bytes-mut-source", type=pathlib.Path, default=CRATE_ROOT / "src/bytes_mut.rs")
    parser.add_argument("--generated", type=pathlib.Path,
                        default=pathlib.Path(os.environ.get("OUT_DIR", GENERATED)))
    parser.add_argument("--skip-generated", action="store_true")
    args = parser.parse_args()
    try:
        result = audit_all(
            driver_source=args.client.read_text(),
            shadow_source=args.shadow.read_text(),
            bytes_source=args.bytes_source.read_text(),
            refcount_source=args.refcount_source.read_text(),
            bytes_record_source=args.bytes_record_source.read_text(),
            vtable_record_source=args.vtable_record_source.read_text(),
            bytes_mut_source=args.bytes_mut_source.read_text(),
            generated_dir=None if args.skip_generated else args.generated,
        )
    except (OSError, CorrespondenceError) as exc:
        print(json.dumps({"status": "coverage_failure", "error": str(exc)}, indent=2))
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
