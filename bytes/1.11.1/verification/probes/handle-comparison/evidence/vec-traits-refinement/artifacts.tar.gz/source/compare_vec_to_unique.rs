#[cfg(all(creusot, feature = "actual-traits", feature = "readonly-deref", feature = "vec-traits"))]
#[cfg_attr(creusot, ensures(result == left.deep_model().cmp_log(right.deep_model())))]
pub fn compare_vec_to_unique(left: Vec<u8>, right: Vec<u8>) -> cmp::Ordering {
    let right_handle = BytesMut::from_vec(right);
    let actual = left.partial_cmp(&right_handle).unwrap();
    right_handle.proof_release_unique_at_zero();
    actual
}
