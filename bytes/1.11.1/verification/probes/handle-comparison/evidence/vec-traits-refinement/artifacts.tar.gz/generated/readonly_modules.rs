#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-handle-comparison-8d65b11ac5269259/out/readonly_raw_vec.rs"]
mod raw_vec;
#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-handle-comparison-8d65b11ac5269259/out/readonly_shared_protocol.rs"]
mod shared_protocol;
#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-handle-comparison-8d65b11ac5269259/out/readonly_provenance_specs.rs"]
mod provenance_specs;
