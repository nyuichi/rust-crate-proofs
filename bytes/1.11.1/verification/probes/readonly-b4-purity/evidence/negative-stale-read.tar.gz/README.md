# Read-only B4 ghost classification candidate

The isolated positive gate proves **34 files**. Its native matrix passes all
value pairs and capacities. A generated copy of the current physical module
adds `#[check(ghost)]` only to immutable `borrow_bound`; mutable and uninitialized
write bridges remain ordinary program functions. Build-time checks ensure that
removing this annotation reproduces the source, apart from native module-path
relocation. Production source has not been annotated by this probe.

An actual `Deref` implementation reads a live initialized region through that
bridge. The caller writes a byte using ordinary mutable B4, checks both ghost
and native reads, ends their shared borrows, performs another real write, and
checks both reads again before actual deallocation. Ghost evaluation observes
existing bytes; it neither mutates the slot ledger nor changes initialization.
The shared physical-region borrow prevents recovery or writes while the reader
is live. This justifies the narrow immutable classification, subject to the
existing physical-access TCB; it is not a proof of that trusted raw-slice bridge.

`negative_ghost_write` rejects specifically because mutable B4 is non-ghost.
`negative_stale_read` asserts that a later read returns the previous distinct
byte and must remain unproved. Full evidence includes source snapshots, generated
bridge, Coma, proof JSON and logs under `evidence`.

This candidate does not establish default native Bytes/BytesMut Deref, their
missing cfg-independent ownership invariants, shared fractional access, mutable
Deref, Clone, Drop or Send/Sync. Classifying a mutable bridge as ghost remains
unsound and is explicitly excluded.
