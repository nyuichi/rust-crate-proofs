# First promotion with normal automatic Drop — AM, 2026-10-09

Astra recommendation after audited/published AL. Native nonempty Box witness:
construct original; create/drop child in an inner lexical scope; read/copy
original; evaluate return; drop original normally. AL ownership core is frozen
byte-for-byte. Body-proved child/root consuming adapters are elaborated only at
certified native normal Drop edges. No unwind/full-crate admission. Development
in progress, no new admission.
