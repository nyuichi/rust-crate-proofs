# Generic normal-edge Drop elaboration (label 2026-10-09)

This is the next bounded architecture experiment recommended by Astra after the
full-domain constructor increment. It reopens the stock Drop-to-Goto obstruction
with a different input to Creusot: a checked external effect elaboration before
borrow and liveness analysis. It does not modify Creusot and does not assume any
bytes-specific destructor, last-owner or complete-issuance theorem.

`native.rs` is the unchanged native input for this experiment. SetTrueOnDrop
reproduces the effect shape of the retained automatic-drop diagnostic; ToggleOnDrop
adds a non-idempotent exact-once discriminator. Three native scope witnesses
cover true, toggle, and a final toggle after an original write. Native tests run
these actual scope-exit destructors, not proof shadows.

The pinned Rust native MIR after ElaborateDrops records the real normal Drop
edges and separate unwind successors. The elaborator generates a proof shadow
with identical fields/lifetimes but no Drop trait implementation. It copies each
native destructor body into an ordinary &mut helper and inserts one call at each
supported normal Drop edge. This avoids retaining an implicit destructor in
addition to the inserted call. The copied destructor, effect/frame summary and
caller postcondition must all be body-proved; there is no #[trusted] helper or
caller. `generated/active.rs` is the selected proof input, never a production file.

The helper frame preserves the original nested borrow's future:
`^(guard.0) == ^((^guard).0)`. Specifying only the updated field's value leaves
the original loan unconstrained and cannot propagate the effect to the caller.
An unconditional future value assertion would be unsound because the caller may
legally mutate the guard later. The new relational frame is itself body-proved.

An independent correspondence checker reconstructs the mapping from native
source/MIR and selected shadow; it checks target, place, type, order, exact count,
and copied destructor body. Generator hashes alone are not correspondence
proof. Native compiler/spec erasure and checker adequacy remain **explicit generic
tool TCB**, including preservation of borrow interpretation. The removal path is
supported native MIR Drop/liveness effect lowering passing the same controls.
Std mem::drop only ensures resolve(t), so it does not already supply this effect.

Scope is freshly declared local guards, straight-line normal return, known
monomorphic Drop bodies, scalar checked operations and fields without independent
drop glue. Unknown calls, alias escape, unsafe/raw use, threads, forgotten guards,
unsupported moves/drop flags or field glue are rejected. Unwind edges are retained
in the mapping and excluded from the normal-return theorem; panic completion and
exceptional cleanup are not established by this gate.

Positive proof is accepted only with a successful independent correspondence
check and every selected Coma target proven. Diagnostic variants deliberately
omit, duplicate, reorder or replace a call, or give a false helper summary.
Correspondence failures and semantic VC failures are reported separately.
Toggle makes omission and duplication observably wrong. No failed feature is
positive evidence. Unknown effects are checker controls, not guessed semantics.

The complete bytes target remains NOT ADMITTED. Success here would establish a
small tool-effect prerequisite, then Astra should be consulted again to choose
its extension to actual closed Bytes clients and complete event tracking. It
would not itself prove native Bytes automatic Drop, all Clone issuance, promotion,
branch-aware cleanup, or the remaining API.

The positive body gate currently proves seven files / twelve actual prover
leaves / zero nulls: the three scope callers, two destructor effects, set_true,
and a helper-interface caller that mutates the same borrowed flag after the
effect. The latter proves false after a later write, distinguishing the sound
relational loan frame from an unconditional future-value promise. Only the three
native scope witnesses receive source/MIR correspondence claims.

The retained positive-v1 capture is historical development evidence. Final
correspondence hardening, control results, immutable matching-source capture and
independent audit will be recorded after completion.
