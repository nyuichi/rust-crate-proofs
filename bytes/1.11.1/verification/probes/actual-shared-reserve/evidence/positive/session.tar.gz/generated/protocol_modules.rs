#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-actual-shared-reserve-90c9de69f85e8a93/out/scalable_tickets.rs"]
mod scalable_tickets;
