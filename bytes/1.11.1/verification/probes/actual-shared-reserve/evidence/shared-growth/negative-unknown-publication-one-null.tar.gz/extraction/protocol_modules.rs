#[path = "/workspace/bytes-proof-tools/targets/bytes/debug/build/bytes-actual-shared-reserve-2b9e8dd8f0fa496f/out/scalable_tickets.rs"]
mod scalable_tickets;
