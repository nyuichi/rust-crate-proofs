#[allow(dead_code)]

pub mod take {
#[cfg(creusot)]
use creusot_std::prelude::*;
pub struct Take<T> {
    inner: T,
    limit: usize,
}
#[cfg_attr(creusot, ensures(result.inner_logic() == inner))]
#[cfg_attr(creusot, ensures(result.limit_logic() == limit))]
pub fn new<T>(inner: T, limit: usize) -> Take<T> {
    Take { inner, limit }
}
impl<T> Take<T> {
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn inner_logic(self) -> T { self.inner }
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn limit_logic(self) -> usize { self.limit }
    #[cfg_attr(creusot, ensures(result == self.inner_logic()))]
    pub fn into_inner(self) -> T {
        self.inner
    }
    #[cfg_attr(creusot, check(ghost))]
    #[cfg_attr(creusot, ensures(*result == self.inner_logic()))]
    pub fn get_ref(&self) -> &T {
        &self.inner
    }
    #[cfg_attr(creusot, ensures(^result == (^self).inner_logic()))]
    #[cfg_attr(creusot, ensures((^self).limit_logic() == self.limit_logic()))]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.inner
    }
    #[cfg_attr(creusot, check(ghost))]
    #[cfg_attr(creusot, ensures(result == self.limit_logic()))]
    pub fn limit(&self) -> usize {
        self.limit
    }
    #[cfg_attr(creusot, ensures((^self).limit_logic() == lim))]
    #[cfg_attr(creusot, ensures((^self).inner_logic() == self.inner_logic()))]
    pub fn set_limit(&mut self, lim: usize) {
        self.limit = lim
    }
}
}

pub mod limit {
#[cfg(creusot)]
use creusot_std::prelude::*;
pub struct Limit<T> {
    inner: T,
    limit: usize,
}
    #[cfg_attr(creusot, ensures(result.inner_logic() == inner))]
    #[cfg_attr(creusot, ensures(result.limit_logic() == limit))]
pub(super) fn new<T>(inner: T, limit: usize) -> Limit<T> {
    Limit { inner, limit }
}
impl<T> Limit<T> {
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn inner_logic(self) -> T { self.inner }
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn limit_logic(self) -> usize { self.limit }
    #[cfg_attr(creusot, ensures(result == self.inner_logic()))]
    pub fn into_inner(self) -> T {
        self.inner
    }
    #[cfg_attr(creusot, ensures(*result == self.inner_logic()))]
    pub fn get_ref(&self) -> &T {
        &self.inner
    }
    #[cfg_attr(creusot, ensures(^result == (^self).inner_logic()))]
    #[cfg_attr(creusot, ensures((^self).limit_logic() == self.limit_logic()))]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.inner
    }
    #[cfg_attr(creusot, ensures(result == self.limit_logic()))]
    pub fn limit(&self) -> usize {
        self.limit
    }
    #[cfg_attr(creusot, ensures((^self).limit_logic() == lim))]
    #[cfg_attr(creusot, ensures((^self).inner_logic() == self.inner_logic()))]
    pub fn set_limit(&mut self, lim: usize) {
        self.limit = lim
    }
}

#[cfg_attr(creusot, ensures(result.0 == inner))]
#[cfg_attr(creusot, ensures(result.1@ == new_limit@))]
pub fn metadata_round_trip<T>(inner: T, initial_limit: usize, new_limit: usize) -> (T, usize) {
    let mut value = new(inner, initial_limit);
    let _ = value.get_ref();
    value.set_limit(new_limit);
    let observed = value.limit();
    let owned = value.into_inner();
    (owned, observed)
}

pub fn new_for_native<T>(inner: T, limit: usize) -> Limit<T> {
    new(inner, limit)
}
}

pub mod chain {
#[cfg(creusot)]
use creusot_std::prelude::*;
pub struct Chain<T, U> {
    a: T,
    b: U,
}
impl<T, U> Chain<T, U> {
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn a_logic(self) -> T { self.a }
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn b_logic(self) -> U { self.b }
    #[cfg_attr(creusot, ensures(result.a_logic() == a))]
    #[cfg_attr(creusot, ensures(result.b_logic() == b))]
    pub(crate) fn new(a: T, b: U) -> Chain<T, U> {
        Chain { a, b }
    }
    #[cfg_attr(creusot, ensures(result.0 == self.a_logic()))]
    #[cfg_attr(creusot, ensures(result.1 == self.b_logic()))]
    pub fn into_inner(self) -> (T, U) {
        (self.a, self.b)
    }
}
}

pub mod reader {
#[cfg(creusot)]
use creusot_std::prelude::*;
pub struct Reader<B> {
    buf: B,
}
#[cfg_attr(creusot, ensures(result.buf_logic() == buf))]
pub fn new<B>(buf: B) -> Reader<B> {
    Reader { buf }
}
impl<B> Reader<B> {
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn buf_logic(self) -> B { self.buf }
    #[cfg_attr(creusot, check(ghost))]
    #[cfg_attr(creusot, ensures(*result == self.buf_logic()))]
    pub fn get_ref(&self) -> &B {
        &self.buf
    }
    #[cfg_attr(creusot, ensures(^result == (^self).buf_logic()))]
    pub fn get_mut(&mut self) -> &mut B {
        &mut self.buf
    }
    #[cfg_attr(creusot, ensures(result == self.buf_logic()))]
    pub fn into_inner(self) -> B {
        self.buf
    }
}
}

pub mod writer {
#[cfg(creusot)]
use creusot_std::prelude::*;
pub struct Writer<B> {
    buf: B,
}
#[cfg_attr(creusot, ensures(result.buf_logic() == buf))]
pub fn new<B>(buf: B) -> Writer<B> {
    Writer { buf }
}
impl<B> Writer<B> {
#[cfg(creusot)]
#[logic(open(self))]
pub(crate) fn buf_logic(self) -> B { self.buf }
    #[cfg_attr(creusot, check(ghost))]
    #[cfg_attr(creusot, ensures(*result == self.buf_logic()))]
    pub fn get_ref(&self) -> &B {
        &self.buf
    }
    #[cfg_attr(creusot, ensures(^result == (^self).buf_logic()))]
    pub fn get_mut(&mut self) -> &mut B {
        &mut self.buf
    }
    #[cfg_attr(creusot, ensures(result == self.buf_logic()))]
    pub fn into_inner(self) -> B {
        self.buf
    }
}
}
