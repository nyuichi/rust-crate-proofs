use std::{env, fs, path::PathBuf};

fn extract(source: &str, start_marker: &str, body_marker: &str) -> (String, usize, usize) {
    let start = source.find(start_marker).expect(start_marker);
    assert!(source[start + start_marker.len()..].find(start_marker).is_none(), "duplicate {start_marker}");
    let body_start = source.find(body_marker).expect(body_marker);
    assert!(source[body_start + body_marker.len()..].find(body_marker).is_none(), "duplicate {body_marker}");
    assert!(start <= body_start);
    let open = body_start + source[body_start..].find('{').expect("opening brace");
    let mut depth = 0usize;
    for (offset, byte) in source.as_bytes()[open..].iter().enumerate() {
        match byte {
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    return (source[start..open + offset + 1].to_owned(), start, open + offset + 1);
                }
            }
            _ => {}
        }
    }
    panic!("unterminated item {start_marker}")
}

fn contract(item: String, signature: &str, clause: &str) -> String {
    assert_eq!(item.matches(signature).count(), 1, "unique signature {signature}");
    item.replace(signature, &format!("    #[cfg_attr(creusot, ensures({clause}))]\n{signature}"))
}

fn main() {
    let root = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap())
        .join("../../..").canonicalize().unwrap();
    let source_path = root.join("src/bytes.rs");
    println!("cargo:rerun-if-changed={}", source_path.display());
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-env-changed=BYTES_PROOF_CALLBACK_STUBS");
    println!("cargo:rerun-if-env-changed=BYTES_OBSERVER_SCOPE");
    println!("cargo:rustc-check-cfg=cfg(bytes_observer_scope, values(\"observers\", \"from_static\", \"all\"))");
    let proof_callback_stubs = env::var_os("BYTES_PROOF_CALLBACK_STUBS").is_some();
    let scope = env::var("BYTES_OBSERVER_SCOPE").unwrap_or_else(|_| "all".to_owned());
    assert!(matches!(scope.as_str(), "observers" | "from_static" | "all"));
    println!("cargo:rustc-cfg=bytes_observer_scope=\"{scope}\"");
    let source = fs::read_to_string(&source_path).expect("read bytes.rs");

    let mut selected = Vec::new();
    for (name, start, body) in [
        ("Bytes", "pub struct Bytes {", "pub struct Bytes {"),
        ("Vtable", "pub(crate) struct Vtable {", "pub(crate) struct Vtable {"),
        ("new", "    #[inline]\n    #[cfg(not(all(loom, test)))]\n    pub const fn new() -> Self {", "    pub const fn new() -> Self {"),
        ("from_static", "    #[inline]\n    #[cfg(not(all(loom, test)))]\n    pub const fn from_static(bytes: &'static [u8]) -> Self {", "    pub const fn from_static(bytes: &'static [u8]) -> Self {"),
        ("len", "    #[inline]\n    pub const fn len(&self) -> usize {", "    pub const fn len(&self) -> usize {"),
        ("is_empty", "    #[inline]\n    pub const fn is_empty(&self) -> bool {", "    pub const fn is_empty(&self) -> bool {"),
        ("STATIC_VTABLE", "const STATIC_VTABLE: Vtable = Vtable {", "const STATIC_VTABLE: Vtable = Vtable {"),
        ("static_clone", "unsafe fn static_clone(", "unsafe fn static_clone("),
        ("static_to_vec", "unsafe fn static_to_vec(", "unsafe fn static_to_vec("),
        ("static_to_mut", "unsafe fn static_to_mut(", "unsafe fn static_to_mut("),
        ("static_is_unique", "fn static_is_unique(", "fn static_is_unique("),
        ("static_drop", "unsafe fn static_drop(", "unsafe fn static_drop("),
    ] {
        let (mut fragment, first, mut last) = extract(&source, start, body);
        if name == "STATIC_VTABLE" {
            let suffix = source[last..].trim_start();
            assert!(suffix.starts_with(';'));
            fragment.push(';');
            last += source[last..].len() - suffix.len() + 1;
        }
        let line = source[..first].bytes().filter(|byte| *byte == b'\n').count() + 1;
        let hash = fnv1a64(fragment.as_bytes());
        selected.push((name, fragment, line, first, last, hash));
    }

    let mut items = selected.iter().map(|(_, text, _, _, _, _)| text.clone()).collect::<Vec<_>>();
    let contracts = [
        ("new", "pub const fn new() -> Self {", "result.len@ == 0"),
        ("from_static", "pub const fn from_static(bytes: &'static [u8]) -> Self {", "result.len@ == bytes@.len()"),
        ("len", "pub const fn len(&self) -> usize {", "result@ == self.len@"),
        ("is_empty", "pub const fn is_empty(&self) -> bool {", "result == (self.len@ == 0)"),
    ];
    for (name, signature, clause) in contracts {
        let index = selected.iter().position(|(found, ..)| *found == name).unwrap();
        items[index] = contract(items[index].clone(), signature, clause);
    }

    let mut generated = String::from("#[cfg(creusot)] use creusot_std::prelude::*;\nuse alloc::vec::Vec;\nuse core::{ptr, slice};\nuse core::sync::atomic::AtomicPtr;\nuse crate::BytesMut;\n\n");
    generated.push_str(&items[0]);
    generated.push_str("\n\n");
    generated.push_str(&items[1]);
    generated.push_str("\n\nimpl Bytes {\n");
    if scope == "all" {
        generated.push_str(&items[2]);
        generated.push('\n');
    }
    if scope != "observers" {
        generated.push_str(&items[3]);
        generated.push('\n');
    }
    for index in 4..=5 {
        generated.push_str(&items[index]);
        generated.push('\n');
    }
    generated.push_str("}\n\n");
    if scope != "observers" {
        generated.push_str(&items[6]);
    }
    if scope != "observers" && proof_callback_stubs {
        generated.push_str("\n\nextern \"Rust\" {\n");
        generated.push_str("    fn static_clone(data: &AtomicPtr<()>, ptr: *const u8, len: usize, vtable: &'static Vtable) -> Bytes;\n");
        generated.push_str("    fn static_to_vec(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> Vec<u8>;\n");
        generated.push_str("    fn static_to_mut(data: &AtomicPtr<()>, ptr: *const u8, len: usize) -> BytesMut;\n");
        generated.push_str("    fn static_is_unique(data: &AtomicPtr<()>) -> bool;\n");
        generated.push_str("    fn static_drop(data: &mut AtomicPtr<()>, ptr: *const u8, len: usize);\n}\n\n");
    } else if scope != "observers" {
        for index in 7..=11 {
            generated.push_str(&items[index]);
            generated.push('\n');
        }
    }

    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    fs::write(out.join("actual_bytes_observers.rs"), generated).unwrap();
    fs::write(out.join("bytes_source_snapshot.rs"), source).unwrap();
    let mut fragments = String::new();
    for (name, text, line, first, last, hash) in &selected {
        fragments.push_str(&format!("{name}: src/bytes.rs:{line}, bytes {first}..{last}, fnv1a64={hash:016x}, {} bytes\n", text.len()));
    }
    fragments.push_str(&format!("Selected generated scope: {scope}. Callbacks are retained byte-for-byte in the source snapshot and native build. When BYTES_PROOF_CALLBACK_STUBS is set, Creusot uses unresolved callback declarations only to form the exact STATIC_VTABLE value; no callback is called, selected for proof, or given a trusted contract.\n"));
    fs::write(out.join("source_fragments.txt"), fragments).unwrap();
    let native_callbacks = selected.iter().skip(7).map(|(_, text, ..)| text.as_str()).collect::<Vec<_>>().join("\n\n");
    fs::write(out.join("static_callbacks_source_snapshot.rs"), native_callbacks).unwrap();
}

fn fnv1a64(bytes: &[u8]) -> u64 {
    let mut hash = 0xcbf29ce484222325u64;
    for byte in bytes {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(0x100000001b3);
    }
    hash
}
