# Source-sliced `Bytes` metadata observers and constructors

This gate extracts the actual `Bytes` field layout, `Vtable`, `new`,
`from_static`, `len`, `is_empty`, and `STATIC_VTABLE` from `src/bytes.rs`.
Generated method copies receive only field-metadata contracts: `new` has
length zero, `from_static` preserves the input static slice length, `len`
returns the stored length, and `is_empty` is equivalent to that length being
zero. The caller checks compose the two constructors with those observers.

No `View` or `DeepModel` is assigned to `Bytes`; no raw pointer is dereferenced,
and no physical access authority, byte-content claim, refcount law, clone, Drop,
AsRef, or Buf behavior is included. The temporary objects in the proof callers
are explicitly forgotten after reading only the scalar metadata. Native tests
also inspect only `len` and `is_empty` and forget their objects.

The `STATIC_VTABLE` constant itself is extracted unchanged. Exact callback source
is recorded in the generated source snapshot and compiled in native mode. The
Creusot build uses external declarations with matching signatures solely to
form the same static table value; the callbacks are neither called nor selected
for proof, and no callback contract is trusted. The callback signature mentions
`BytesMut`, so the isolated probe supplies only an opaque local return-type
stand-in; it does not compile or claim the real `BytesMut` implementation. An
initial local-path dependency attempt made Creusot compile the entire bytes
crate and stopped at unrelated Send/Sync and Deref frontend requirements. The
probe removes that dependency and keeps the metadata boundary isolated.

Run the native metadata tests with `cargo test --locked --offline`. Run the
pinned, serialized proof gate with `bash run.sh`. The result applies only to
these exact constructor/observer bodies and their metadata postconditions; it
does not supply an initialized byte view for `Bytes` or establish ownership or
refcount behavior.
