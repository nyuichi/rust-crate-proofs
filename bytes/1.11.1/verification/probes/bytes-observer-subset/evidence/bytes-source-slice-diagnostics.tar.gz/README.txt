Failed/reduced diagnostic history for the Bytes metadata source-sliced probes. These are not proof-positive results and are kept separately from the positive observer archive.

The foreign-function collision logs show the initial shared-extern-block approach. Luna xhigh review traced the `open_inv_params` ICE to Creusot's foreign-item visitor using the same parent DefId for declarations in one extern block. The live probe build now emits each foreign function declaration in its own unsafe extern block; full constructor scope is being retried.

The observer-only type mismatch was corrected by comparing `self.len@` with logical zero. The first observer rerun had no `why3find.json`; the standard config was added. The native test under the observers-only generated scope failed because that scope intentionally omits constructors; full-scope native tests pass and are recorded in the positive archive.

The truncate first attempt groups external declarations and retains the exact compiler diagnostics plus ICE. Live code has since been changed to separate each declaration into its own block. This failed attempt does not characterize the new attempt.
