#[cfg(creusot)] use creusot_std::prelude::*;
use alloc::vec::Vec;
use core::{ptr, slice};
use core::sync::atomic::AtomicPtr;
use crate::BytesMut;

pub struct Bytes {
    #[cfg(not(bytes_proof_frozen))]
    ptr: *const u8,
    #[cfg(bytes_proof_frozen)]
    pub(crate) ptr: crate::ownership_proof::raw_vec::BoundPtr,
    #[cfg(bytes_proof_frozen)]
    pub(crate) frozen: Option<crate::ownership_proof::frozen_region::FrozenReader>,
    #[cfg(not(bytes_proof_frozen))]
    len: usize,
    #[cfg(bytes_proof_frozen)]
    pub(crate) len: usize,
    // inlined "trait object"
    data: AtomicPtr<()>,
    vtable: &'static Vtable,
}

pub(crate) struct Vtable {
    /// Marks the two Vec-backed tables whose storage must be promoted before truncation.
    pub promotable: bool,
    /// fn(data, ptr, len, current_vtable)
    ///
    /// Pass the current table so callbacks that preserve the storage kind do
    /// not have to refer back to the table that contains the callback.
    pub clone: unsafe fn(&AtomicPtr<()>, *const u8, usize, &'static Vtable) -> Bytes,
    /// fn(data, ptr, len)
    ///
    /// `into_*` consumes the `Bytes`, returning the respective value.
    pub into_vec: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> Vec<u8>,
    pub into_mut: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> BytesMut,
    /// fn(data)
    pub is_unique: unsafe fn(&AtomicPtr<()>) -> bool,
    /// fn(data, ptr, len)
    pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),
}

impl Bytes {
    #[inline]
        #[cfg_attr(creusot, ensures(result@ == self.len@))]
pub const fn len(&self) -> usize {
        self.len
    }
    #[inline]
        #[cfg_attr(creusot, ensures(result == (self.len@ == 0)))]
pub const fn is_empty(&self) -> bool {
        self.len == 0
    }
}

