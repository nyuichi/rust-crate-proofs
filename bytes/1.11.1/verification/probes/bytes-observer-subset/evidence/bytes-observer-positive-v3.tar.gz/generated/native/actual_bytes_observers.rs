#[cfg(creusot)] use creusot_std::prelude::*;
use alloc::vec::Vec;
use core::{ptr, slice};
use core::sync::atomic::AtomicPtr;
use crate::BytesMut;

pub struct Bytes {
    #[cfg(not(bytes_proof_frozen))]
    ptr: *const u8,
    #[cfg(bytes_proof_frozen)]
    pub(crate) ptr: crate::ownership_proof::raw_vec::BoundPtr,
    #[cfg(bytes_proof_frozen)]
    pub(crate) frozen: Option<crate::ownership_proof::frozen_region::FrozenReader>,
    #[cfg(not(bytes_proof_frozen))]
    len: usize,
    #[cfg(bytes_proof_frozen)]
    pub(crate) len: usize,
    // inlined "trait object"
    data: AtomicPtr<()>,
    vtable: &'static Vtable,
}

pub(crate) struct Vtable {
    /// Marks the two Vec-backed tables whose storage must be promoted before truncation.
    pub promotable: bool,
    /// fn(data, ptr, len, current_vtable)
    ///
    /// Pass the current table so callbacks that preserve the storage kind do
    /// not have to refer back to the table that contains the callback.
    pub clone: unsafe fn(&AtomicPtr<()>, *const u8, usize, &'static Vtable) -> Bytes,
    /// fn(data, ptr, len)
    ///
    /// `into_*` consumes the `Bytes`, returning the respective value.
    pub into_vec: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> Vec<u8>,
    pub into_mut: unsafe fn(&AtomicPtr<()>, *const u8, usize) -> BytesMut,
    /// fn(data)
    pub is_unique: unsafe fn(&AtomicPtr<()>) -> bool,
    /// fn(data, ptr, len)
    pub drop: unsafe fn(&mut AtomicPtr<()>, *const u8, usize),
}

impl Bytes {
    #[inline]
    #[cfg(not(all(loom, test)))]
        #[cfg_attr(creusot, ensures(result.len@ == 0))]
pub const fn new() -> Self {
        // Make it a named const to work around
        // "unsizing casts are not allowed in const fn"
        const EMPTY: &[u8] = &[];
        Bytes::from_static(EMPTY)
    }
    #[inline]
    #[cfg(not(all(loom, test)))]
        #[cfg_attr(creusot, ensures(result.len@ == bytes@.len()))]
pub const fn from_static(bytes: &'static [u8]) -> Self {
        Bytes {
            ptr: bytes.as_ptr(),
            len: bytes.len(),
            data: AtomicPtr::new(ptr::null_mut()),
            vtable: &STATIC_VTABLE,
        }
    }
    #[inline]
        #[cfg_attr(creusot, ensures(result@ == self.len@))]
pub const fn len(&self) -> usize {
        self.len
    }
    #[inline]
        #[cfg_attr(creusot, ensures(result == (self.len@ == 0)))]
pub const fn is_empty(&self) -> bool {
        self.len == 0
    }
}

const STATIC_VTABLE: Vtable = Vtable {
    promotable: false,
    clone: static_clone,
    into_vec: static_to_vec,
    into_mut: static_to_mut,
    is_unique: static_is_unique,
    drop: static_drop,
};

unsafe fn static_clone(
    _: &AtomicPtr<()>,
    ptr: *const u8,
    len: usize,
    vtable: &'static Vtable,
) -> Bytes {
    Bytes {
        ptr,
        len,
        data: AtomicPtr::new(ptr::null_mut()),
        vtable,
    }
}
unsafe fn static_to_vec(_: &AtomicPtr<()>, ptr: *const u8, len: usize) -> Vec<u8> {
    let slice = slice::from_raw_parts(ptr, len);
    slice.to_vec()
}
unsafe fn static_to_mut(_: &AtomicPtr<()>, ptr: *const u8, len: usize) -> BytesMut {
    let slice = slice::from_raw_parts(ptr, len);
    BytesMut::from(slice)
}
fn static_is_unique(_: &AtomicPtr<()>) -> bool {
    false
}
unsafe fn static_drop(_: &mut AtomicPtr<()>, _: *const u8, _: usize) {
    // nothing to drop for &'static [u8]
}
