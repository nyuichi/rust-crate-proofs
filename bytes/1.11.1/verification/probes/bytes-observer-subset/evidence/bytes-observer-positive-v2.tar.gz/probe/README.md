# Source-sliced `Bytes` metadata observers

The probe can generate source slices for `new`, `from_static`, `len`,
`is_empty`, and `STATIC_VTABLE`, but the positive Creusot run is intentionally
narrow: `BYTES_OBSERVER_SCOPE=observers bash run.sh` generates the exact
`Bytes` layout, `Vtable` layout, `len`, and `is_empty` bodies, and proves their
field-metadata postconditions. `new` and `from_static` remain unproved in this
checkpoint. The default full-scope translation previously hit a Creusot
`open_inv_params` ICE while several callback declarations shared one extern
block; those declarations are being split before retrying constructor scope.

No `View` or `DeepModel` is assigned to `Bytes`; no raw pointer is dereferenced,
and no physical access authority, byte-content claim, refcount law, clone, Drop,
AsRef, or Buf behavior is included. The native full-scope tests inspect only
length and emptiness, then forget the handles; they pass 2/2. The native result
does not widen the Creusot proof scope.

The full source slice preserves `STATIC_VTABLE`, and exact static callback
source is recorded in the source snapshot and compiled in native mode. In
proof mode, unresolved declarations are used only to form the static table;
callbacks are neither called nor selected for proof, and no callback contract
is trusted. The callback signature mentions `BytesMut`, so the isolated probe
uses an opaque local return-type stand-in and does not claim the real
`BytesMut` implementation. An initial local-path dependency attempt made
Creusot compile the whole bytes crate and stopped at Send/Sync and Deref
frontend requirements; the probe removes that dependency.

The positive evidence archive records the exact two-method proof, full-scope
native test, source snapshot, generated observer-only Rust, COMA, and proof
JSON. It supplies no initialized byte view for `Bytes` and establishes no
ownership or refcount behavior.
