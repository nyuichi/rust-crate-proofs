#![allow(unexpected_cfgs,unused_variables,dead_code)]
#![recursion_limit="512"]
use creusot_std::{prelude::*, ghost::{Perm,invariant::Protocol,resource::{Authority,Fragment}},
    logic::{Id,FMap,ra::{RA,excl::Excl}},
    std::sync::{atomic::{AtomicUsize as ModelAtomic,ordering::Relaxed},committer::Committer,
        view::{SyncView,ReleaseSyncView,HasTimestamp}}};
mod event;
use event::{EventAtomic,EventProtocol,RawAtomic};
type Registrations=FMap<Int,Excl<()>>;

#[logic(open(self))]
fn prefix(map:Registrations,n:Int)->bool {
    pearlite! {0<=n && (forall<i:Int> map.contains(i) == (0<=i && i<n))}
}
#[check(ghost)]
#[requires(prefix(auth@,*next))]
#[ensures(prefix((^auth)@,*next+1))]
#[ensures(result@ == FMap::singleton(*next,Excl(())))]
#[ensures(result.id() == auth.id() && (^auth).id() == auth.id())]
fn issue(auth:&mut Authority<Registrations>,next:Snapshot<Int>)->Fragment<Registrations> {
    let before=snapshot!(auth@);
    let one=snapshot!(FMap::singleton(*next,Excl(())));
    proof_assert!(forall<key:Int> (*before).get(key).op((*one).get(key)) != None);
    let result=auth.add_fragment(one);
    proof_assert!(auth@.ext_eq((*before).insert(*next,Excl(()))));
    result
}
struct State {own:Perm<ModelAtomic>, latest:Int, issued:Authority<Registrations>, next:Int}
impl Protocol for State {
    type Public=(ModelAtomic,Id);
    #[logic] fn public(self)->Self::Public {(*self.own.ward(),self.issued.id())}
    #[logic(prophetic)] fn protocol(self)->bool {pearlite! {
        prefix(self.issued@,self.next) &&
        self.own.val().get(self.latest) != None &&
        self.own.val().get(self.latest).unwrap_logic().0@ == self.next % (usize::MAX@+1) &&
        (forall<t:Int> self.own.val().get(t) != None ==> t<=self.latest)
    }}
}
impl EventProtocol for State {
    #[logic] fn atomic(self)->ModelAtomic {*self.own.ward()}
}
struct Ticket {id:Int,fragment:Fragment<Registrations>}
impl Ticket {
    #[logic(open(self))] fn valid(self,registration:Id)->bool {pearlite! {
        self.fragment.id()==registration && self.fragment@==FMap::singleton(self.id,Excl(()))
    }}
}
struct Registry {atomic:EventAtomic<State>}
impl Registry {
    #[logic(open(self))] fn registration(self)->Id {self.atomic.public().1}
    #[ensures(result.1.inner_logic().valid(result.0.registration()))]
    fn new()->(Self,Ghost<Ticket>) {
        let mut current=SyncView::new();
        let (raw,own)=RawAtomic::new(1,current.borrow_mut());
        let mut authority=Authority::<Registrations>::alloc();
        let ticket=ghost! {Ticket{id:0int,fragment:issue(&mut authority,snapshot!(0int))}};
        let state=ghost! {State {own:own.into_inner(),latest:snapshot!(raw.model().get_timestamp(*current)).into_ghost().into_inner(),
            issued:authority.into_inner(),next:1int}};
        (Self{atomic:EventAtomic::bind(raw,state)},ticket)
    }

    /// Ordinary shared receiver; no Tokens or mutable source-ticket borrow.
    #[requires(source.valid(self.registration()))]
    #[ensures(result.1.inner_logic().valid(self.registration()))]
    #[ensures(result.1.inner_logic().id != source.id)]
    fn clone_registration(&self,source:Ghost<&Ticket>)->(usize,Ghost<Ticket>) {
        let mut output=ghost! {None::<Ticket>};
        let mut current=SyncView::new();
        let release=ReleaseSyncView::new();
        let old=self.atomic.increment(ghost! {|state:&mut State,c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>| {
            state.issued.frag_lemma(&source.fragment);
            proof_assert!(state.issued@.contains(source.id));
            proof_assert!(source.id < state.next);
            let next=snapshot!(state.next);
            let fragment=issue(&mut state.issued,next);
            let previous=c.shoot_load(&state.own,&mut current);
            proof_assert!(c.timestamp() == state.latest);
            let before=snapshot!(c.val_load()@);
            c.shoot_store(&mut state.own,&mut current,release.into_inner());
            state.latest=snapshot!(c.timestamp()+1).into_ghost().into_inner();
            state.next=state.next+1;
            *output=Some(Ticket{id:next.into_ghost().into_inner(),fragment});
        }});
        (old,ghost! {output.into_inner().unwrap()})
    }
}

pub fn shared_receiver_two_clones()->(usize,usize) {
    let (registry,first)=Registry::new();
    let (a,second)=registry.clone_registration(first.borrow());
    let (b,third)=registry.clone_registration(first.borrow());
    proof_assert!(first.id != second.id && first.id != third.id);
    // All three actual affine fragments remain live. No reclamation claim.
    (a,b)
}

#[cfg(feature="negative_duplicate")]
fn duplicate_ticket(ticket:Ticket)->(Ticket,Ticket) {(ticket,ticket)}

#[cfg(feature="negative_reentry")]
#[requires(source.valid(registry.registration()))]
fn recursive_operation(registry:&Registry,source:Ghost<&Ticket>) {
    registry.atomic.increment(ghost! {|state:&mut State,c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>| {
        let _=registry.clone_registration(source);
    }});
}

#[cfg(feature="negative_empty_commit")]
fn empty_commit(registry:&Registry) {
    registry.atomic.increment(ghost! {|state:&mut State,c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>| {}});
}

#[cfg(feature="negative_wrong_ward")]
#[requires(!c.shot_store())]
#[requires(c.ward() != *other.ward())]
#[check(ghost)]
fn wrong_ward(c:&mut Committer<ModelAtomic,usize,Relaxed,Relaxed>,other:&mut Perm<ModelAtomic>,current:&mut SyncView,release:ReleaseSyncView) {
    c.shoot_store(other,current,release);
}

#[cfg(all(test,not(creusot)))]
mod tests {
    use super::*;
    #[test] fn native_shared_receiver(){
        for _ in 0..32 {assert_eq!(shared_receiver_two_clones(),(1,2));}
    }
    #[test] fn native_parallel_increments(){
        for _ in 0..32 {
            let (registry,first)=Registry::new();
            let results=std::thread::scope(|s|{
                let a=s.spawn(||registry.clone_registration(first.borrow()).0);
                let b=s.spawn(||registry.clone_registration(first.borrow()).0);
                (a.join().unwrap(),b.join().unwrap())
            });
            assert!(results==(1,2)||results==(2,1));
        }
    }
}
