# Validated increment: advanced-transactional probe

This snapshot records the focused pre-integration proof result. The isolated
probe source transfers fields to a private `RawTransition`, then reconstructs
a valid `BytesMut`; the final `mem::replace` returns a canonical empty
placeholder which is forgotten to suppress its destructor.

Pinned toolchain: Creusot 0.13; Why3 commit `54c92f96`; why3find commit
`eab37557`; tool root `/workspace/bytes-proof-tools`.

The serialized focused run passed three files: `RawTransition::from_valid`,
`RawTransition::advance_to_valid`, and `BytesMut::advance_transactionally`.
The exact generated Coma sources, proof JSON, extraction, source input, and
complete run log are included. This is a focused probe proof, not an integrated
production proof and does not establish production `Drop` behavior.
