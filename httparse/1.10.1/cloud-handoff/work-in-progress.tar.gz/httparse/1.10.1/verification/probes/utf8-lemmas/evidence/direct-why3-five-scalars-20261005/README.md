# Concrete UTF-8 scalar proof checkpoint

Date: 2026-10-05. This bundle records the five independently selected scalar
encoding targets from `utf8-lemmas`. The exact COMA inputs, matching probe
source, standard-library source snapshots, raw Why3 output, stderr, and exit
codes are included here. `SHA256SUMS` freezes the bundle contents.

## Results

All 35 split goals returned `Valid` under Z3 4.15.3. Every result has an empty
counterexample list and each process exited with code 0.

| Target | Code point | Split goals | Result | Steps per goal | Z3 time per goal |
|---|---:|---:|---|---:|---:|
| `utf8_u00e9` | U+00E9 | 6 | 6 Valid | 28,661–52,884 | 0.019958–0.049806 s |
| `utf8_u20ac` | U+20AC | 7 | 7 Valid | 28,661–159,724 | 0.008707–0.060648 s |
| `utf8_u_d7ff` | U+D7FF | 7 | 7 Valid | 28,661–115,260 | 0.009158–0.044003 s |
| `utf8_u_e000` | U+E000 | 7 | 7 Valid | 28,661–101,114 | 0.016488–0.038081 s |
| `utf8_u10ffff` | U+10FFFF | 8 | 8 Valid | 28,661–309,375 | 0.009710–0.095437 s |

COMA input SHA-256 values:

| Target | SHA-256 |
|---|---|
| `utf8_u00e9` | `5099b61f4f985f88fb4f0cd7b3f0c0ceab88e44d22e33e2fb538dcfbf9e2e251` |
| `utf8_u20ac` | `fdf7eca1b0bb37b4caaa7b46302b0eae7a7beb3cdcc5d9f01a5997f7faa02d05` |
| `utf8_u_d7ff` | `73dfb9ac8f392118cdf87d380f4e3237e2f92e6d159c585d09217274eb8aee9e` |
| `utf8_u_e000` | `8a9d5435e0f3a2a550a9ac15f219f814618e24a844dd7a85c122b53a1c0f2d45` |
| `utf8_u10ffff` | `a1af56ded7d72330f1db1e51a9f6ed91ed846078e0cea550c7c4654118721389` |

The goals check each code point's model value, UTF-8 byte count, every indexed
byte, and equality with the expected byte sequence. Exact COMA hashes are
recorded in `SHA256SUMS`.

## Provenance

The runs used the isolated string-model compiler at
`/workspace/proof-tools/targets/httparse-string-model/debug/creusot-rustc`
(SHA-256 `a1ea923760d0225f828e90e2b405c4f7d3de4177868aad6f04f158472778f293`),
Why3 1.8.2+git configuration `/workspace/scratch/httparse-string-model/why3.conf`
(SHA-256 `e1124888733158546f027f02926484f591bed63bb5e10f861a6c93a54330ea07`),
and isolated Creusot prelude
`/workspace/scratch/httparse-string-model/creusot-data/share/why3find/packages/creusot/creusot/prelude.coma`
(SHA-256 `cca0368e966eacff2188dae670d35678fd95e801a2fce5a3154a61d300b2798b`).
The Z3 executable was version 4.15.3 (SHA-256
`80ee070b8ffc2fa964b0b879250b2110c47f84c1256a1f9ab76fc7cf95e46292`). The
coordinated Why3 profile had one prover and a 1000 MiB memory limit. The proof
queue wrapper held its shared lock for each invocation.

The generated Why3 COMA contains the open `to_utf8_char` body, but uses the
existing `utf8_byte_spec` numeric contract and `to_utf8_char_spec` length
contract. This run proves the five concrete callers relative to those imported
standard contracts; it does not independently prove the `utf8_byte` contract.
No httparse-specific axiom or compiler change was introduced.

## Exact invocation and scope

Each selected COMA was run separately through
`/workspace/rust-crate-proofs/httparse/1.10.1/run-proof.bash` with the isolated
environment restored after wrapper activation, then:

```text
why3 prove -C /workspace/scratch/httparse-string-model/why3.conf \
  -L /workspace/scratch/httparse-string-model/creusot-data/share/why3find/packages/creusot \
  -L <probe>/verif <selected-scalar.coma> -a split_vc \
  -P Z3,4.15.3 -t 30 -m 1000 --json
```

The raw command output is preserved in each target directory. This checkpoint
proves five scalar cases only. It does not establish a universal theorem for
all valid Rust `char` values, the singleton or push-back sequence bridges, or
the `Seq::create` string-literal caller obligations.
