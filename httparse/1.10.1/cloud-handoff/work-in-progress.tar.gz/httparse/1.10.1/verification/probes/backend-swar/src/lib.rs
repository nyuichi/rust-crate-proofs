#![allow(unexpected_cfgs)]

#[cfg(all(target_pointer_width = "64", target_endian = "little"))]
mod x86_64_le {
    use creusot_std::prelude::{ensures, extern_spec, logic, requires, DeepModel, Int};

    #[logic(open)]
    fn pack8(bytes: [u8; 8]) -> Int {
        bytes[0].deep_model()
            + 256 * (bytes[1].deep_model()
                + 256 * (bytes[2].deep_model()
                    + 256 * (bytes[3].deep_model()
                        + 256 * (bytes[4].deep_model()
                            + 256 * (bytes[5].deep_model()
                                + 256 * (bytes[6].deep_model()
                                    + 256 * bytes[7].deep_model()))))))
    }

    extern_spec! {
        impl usize {
            #[ensures(result@ == pack8(bytes))]
            fn from_ne_bytes(bytes: [u8; 8]) -> usize;

            #[ensures(pack8(result) == self@)]
            fn to_ne_bytes(self) -> [u8; 8];
        }
    }

    /// Fixed-width injectivity of the base-256 byte representation. This is
    /// body-checked locally so the round-trip caller needs no symbolic `pow(i)`.
    #[requires(pack8(left) == pack8(right))]
    #[ensures(left@ == right@)]
    fn pack8_injective(left: [u8; 8], right: [u8; 8]) {
        creusot_std::prelude::proof_assert!(left@[0]@ == right@[0]@);
        creusot_std::prelude::proof_assert!(left@[1]@ == right@[1]@);
        creusot_std::prelude::proof_assert!(left@[2]@ == right@[2]@);
        creusot_std::prelude::proof_assert!(left@[3]@ == right@[3]@);
        creusot_std::prelude::proof_assert!(left@[4]@ == right@[4]@);
        creusot_std::prelude::proof_assert!(left@[5]@ == right@[5]@);
        creusot_std::prelude::proof_assert!(left@[6]@ == right@[6]@);
        creusot_std::prelude::proof_assert!(left@[7]@ == right@[7]@);
    }

    /// Round-trips the exact actual `usize` native-endian conversion pair.
    #[ensures(result@ == bytes@)]
    pub fn native_endian_roundtrip(bytes: [u8; 8]) -> [u8; 8] {
        let decoded = usize::from_ne_bytes(bytes);
        let encoded = decoded.to_ne_bytes();
        pack8_injective(bytes, encoded);
        encoded
    }
}

#[cfg(not(all(target_pointer_width = "64", target_endian = "little")))]
compile_error!("this probe's byte-weight contracts are specific to x86-64 little-endian");
