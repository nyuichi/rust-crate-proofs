Execution order: initialized constructor, non-Complete initialized client, uninitialized constructor, capacity, used_len, write, commit_prefix, then three remaining clients.

## Outcome

Fresh translation passed and exactly matched the 18-path inventory. The
prepared runner acquired the shared proof lock and checked the isolated
`why3.conf` SHA-256 (`e1124888733158546f027f02926484f591bed63bb5e10f861a6c93a54330ea07`), one-prover/1000 MiB settings, environment-file SHA-256, and the exact
Creusot package path returned by `why3find query creusot`.

The first selected target, `header_storage/impl_HeaderStorage/initialized.coma`
(COMA SHA-256 `73693299530cda2a79d824967eaf06cfd16b22b220ccb1380edd12b615fe9a9c`),
returned `Unknown (unknown) (0.19s, 568463 steps)` on its combined constructor
ensures goal using direct Why3 with Z3 4.15.3, `-t 30 -m 1000`. The runner
stopped immediately. The representative client and remaining eight targets
were not launched. This is an inconclusive VC result, not a proof and not an
infrastructure failure; the revised storage closure remains open.

Raw command output is in `logs/01-initialized.log`. This run uses adapter source
SHA-256 `43e3da589746e1d11ebe0f4f9ab799f9c40ec815855449bfd9c21c6e5ee53081`.
