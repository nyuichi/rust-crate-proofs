# HeaderStorage fourth-projection translation checkpoint

This is a translation-only checkpoint. `verify-selected.sh translate` completed
successfully and checked that the generated inventory exactly matches all 18
paths in `TRANSLATION-TARGETS.txt`; the ten selected target paths are unchanged.
No Why3 solver was run here. This translation does not change the status of any
proof obligation. The previous solver run remains archived separately and is
historical evidence for a source version without the fourth prophecy projection;
its 32 successful method leaves and the non-Complete caller timeout are not
reused for this revision.

The corrected adapter has four structural views of the nested mutable borrow:

- current/current (`view`): the current typed storage model;
- future/current (`future_slots`): the final outer slice binding's current
  slots;
- current/future (`inner_future_slots`): the current outer binding's final
  inner-slice contents;
- future/future (`final_binding_slots`): `(^^headers)@`, the final contents
  after both nested mutable-borrow projections.

Both constructors link the three prophetic projections to their corresponding
borrow views. `write` and `commit_prefix` preserve the outer, inner and final
prophecy projections. `commit_prefix` keeps the existing split-at-mut prefix
and tail lens clauses; no new future-length invariant or custom `Fin` boundary
was added. The definitions use only the existing typed reference prophecy and
`MaybeUninit` view.

The source snapshot pins `src/header_storage.rs` at the SHA-256 listed in
`INPUT-IDENTITY-SHA256SUMS`. The fourth projection closes the missing
constructor/poststorage to caller/final-backing linkage identified in the prior
client timeout diagnosis; only a later authorized fresh solver run can assess
whether the selected targets now discharge.
