#![cfg_attr(not(feature = "std"), no_std)]

use creusot_std::logic::Mapping;
use creusot_std::prelude::*;

// These source-clone proof targets mirror creusot-std/src/logic/seq.rs:
// `flat_map_singleton` has an empty body with the same postcondition, and
// `flat_map_push_back` has the same recursive body and tail equality assertion.
// The exact source snapshot is hashed in evidence/SOURCE-SHA256SUMS.
#[logic(open)]
#[ensures(Seq::singleton(x).flat_map(f) == f.get(x))]
pub fn checked_std_flat_map_singleton<T, U>(x: T, f: Mapping<T, Seq<U>>) {}

#[logic(open)]
#[ensures(s.push_back(x).flat_map(f) == s.flat_map(f).concat(f.get(x)))]
#[variant(s.len())]
pub fn checked_std_flat_map_push_back<T, U>(s: Seq<T>, x: T, f: Mapping<T, Seq<U>>) {
    if s.len() > 0 {
        checked_std_flat_map_push_back::<T, U>(s.tail(), x, f);
        proof_assert! { s.tail().push_back(x) == s.push_back(x).tail() }
    }
}
