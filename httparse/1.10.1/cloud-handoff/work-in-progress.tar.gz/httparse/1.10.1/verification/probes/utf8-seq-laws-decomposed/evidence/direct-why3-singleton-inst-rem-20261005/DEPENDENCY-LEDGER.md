# Guided-singleton candidate dependency ledger

| Helper contract used by guided target | Evidence in this probe |
| --- | --- |
| `singleton_shape_T_spec` | `vc_singleton_shape_T`: three split goals, all Valid. |
| `flat_map_empty_T_spec` | `vc_flat_map_empty_T`: two direct split goals Valid; line-42 child was OOM directly and then Valid under the stronger ground-instantiated task in `direct-why3-flat-map-empty-inst-rem-20261005/`. |
| `concat_right_empty_U_spec` | `vc_concat_right_empty_T`: four split goals, all Valid; generic contract is instantiated for `Seq<U>`. |

`flat_map_empty_T_spec` also depends on `empty_len_T_spec`, whose target `vc_empty_len_T` is Valid. The guided target itself has four split goals, all Valid under the tested ground-instantiation transformation. Across these selected candidate obligations, the core evidence is 15 Valid split goals; the original OOM attempt remains recorded separately and is not counted as Valid.

The harness proves a distinct guided lemma against the imported `Seq::flat_map` definition. It does not establish verbatim source linkage to creusot-std's separate empty-body `flat_map_singleton` declaration; that linkage is still open.
