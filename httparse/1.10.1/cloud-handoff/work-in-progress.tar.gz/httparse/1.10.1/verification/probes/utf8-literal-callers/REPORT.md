# UTF-8 literal caller checkpoint

## Scope

This third isolated probe preserves the earlier seven-target `utf8-lemmas`
evidence and two-target `utf8-seq-laws` evidence. It combines local copies of
the checked scalar lemmas and standard sequence-law clones with concrete literal
model and byte callers. It changes no shared standard-library or compiler files
and introduces no trusted annotation or axiom.

The proof manifest contains 21 targets:

- 5 checked scalar encoding candidates;
- 2 source-clone standard `flat_map` law candidates;
- 2 local UTF-8 composition wrappers whose bodies call those clones;
- 5 literal `Seq.create` to singleton model bridges;
- 1 boundary-string `Seq.create` to singleton/snoc model bridge;
- 5 exact single-scalar literal byte callers;
- 1 exact three-scalar boundary-string byte caller.

Each scalar byte caller includes the literal-model bridge, local singleton
wrapper, and matching scalar encoding target. The boundary caller includes its
literal-model bridge, one local singleton bridge, two local push-back bridges,
and all three scalar encoding targets. Generated caller COMAs reference the
local wrapper contracts. The local wrapper target COMAs depend on the local
source-clone helper laws; they do not use the standard `flat_map_singleton` or
`flat_map_push_back` postconditions as antecedents. The helper clones still
require the source correspondence review recorded in the sibling
`utf8-seq-laws` report.

## Translation status

Creusot translation completed with exit code 0. Direct Why3 type-only checking
completed with exit code 0 over exactly the 21 modules in `proof-targets.txt`.
Logs are in `evidence/translation.log` and `evidence/typecheck.log`; source,
configuration, package, and COMA hashes are in
`evidence/LITERAL-SHA256SUMS`.

No solver was run. No `Valid` result is claimed. The COMAs make the proof
dependencies and concrete goals available for the authorized solver pass.
Earlier compile-only attempts are retained as `translation-attempt-*.log`;
they are source/API iteration diagnostics, not proof failures.

## Literal targets

The five individual literal targets are `é`, `€`, U+D7FF, U+E000, and U+10FFFF.
For each one, the model bridge checks that the literal model has length one and
its sole indexed character equals the corresponding singleton. Its byte caller
states exact equality with the corresponding 2-, 3-, 3-, 3-, or 4-byte sequence.

The combined boundary string is U+D7FF, U+E000, U+10FFFF. Its model bridge
checks length three and all three indexed characters against
`singleton(U+D7FF).push_back(U+E000).push_back(U+10FFFF)`. Its byte caller states
exact equality with all ten expected UTF-8 bytes.

## Remaining universal theorem

The concrete targets do not establish UTF-8 encoding for every valid Rust
`char`. The next general lemma should split the open standard `to_utf8` body at
0x80, 0x800, and 0x10000. In each branch, prove the exact output length, bounds
0..255 for every `utf8_byte` argument, and each byte's quotient/remainder
formula from `utf8_byte`'s numeric contract. Rust `char` validity supplies the
scalar range 0..0x110000 with the surrogate interval excluded. Keep that
validity premise tied to the isolated standard Char model; add no axiom and do
not unfold the recursive byte constructor.
