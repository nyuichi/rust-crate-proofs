# Decomposed UTF-8 core direct Why3 run

This dependency-ordered run stopped at the first non-Valid split result. It used the frozen isolated string-model profile and did not run push-back helper, scalar, literal, or universal targets.

| Selected target | Split outcomes | Status |
| --- | --- | --- |
| `vc_empty_len_T` | 1 | Valid |
| `vc_singleton_shape_T` | 3 | 3 Valid |
| `vc_concat_right_empty_T` | 4 | 4 Valid |
| `vc_flat_map_empty_T` | 3 | Valid, Out of memory, Valid |
| `vc_flat_map_singleton_guided_T` | Not submitted | Not run after the earlier non-Valid result |

The first non-Valid result was the second split goal of `vc_flat_map_empty_T`: Z3 returned `Out of memory`, status `exited with status 101`, after 5.5491 seconds. Its counterexample list is empty. This is an unproved goal/resource failure, not a counterexample. The CLI exited with status 2 for that target.

Raw stdout/JSONL, stderr, exit status, and COMA SHA-256 are retained under the numbered per-target directories. The exact command and profile provenance are `RUN-COMMAND.txt` and `provenance.sha256`. The source, COMA, and environment manifests passed; their check output is `source-manifest-check.log`.

The shared proof wrapper exited after the non-Valid target. Root confirmed the proof lock is released and no active Why3/Z3 process remains.
