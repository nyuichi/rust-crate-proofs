export CREUSOT_DATA_HOME=/workspace/scratch/httparse-string-model/creusot-data
export CREUSOT_RUSTC=/workspace/proof-tools/targets/httparse-string-model/debug/creusot-rustc
export WHY3CONFIG=/workspace/scratch/httparse-string-model/why3.conf
export CARGO_TARGET_DIR=/workspace/proof-tools/targets/httparse-string-model
export CARGO_NET_OFFLINE=true
export DUNE_DIR_LOCATIONS=why3find:lib:/workspace/scratch/httparse-string-model/creusot-data/share/why3find
export XDG_CONFIG_HOME=/workspace/scratch/httparse-string-model/config
export XDG_CACHE_HOME=/workspace/scratch/httparse-string-model/cache
