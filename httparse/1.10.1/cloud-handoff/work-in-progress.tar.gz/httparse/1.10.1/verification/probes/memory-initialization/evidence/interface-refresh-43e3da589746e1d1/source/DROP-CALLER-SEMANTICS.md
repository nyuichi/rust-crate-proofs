# Implicit Drop caller translation and typed storage boundary

This note records a translation diagnostic and a candidate adapter model. It
does not claim any solver result or production parser proof. Production
`lib.rs` remains outside this probe.

## What the translated caller contains

The probe defines `DropMarker::drop` to write `7` through a borrowed `usize`
and defines `implicit_drop_caller`, which has both a normal scope exit and an
early `return`. The caller translation contains
`-{resolve_DropMarker _marker}-` on both exits. It does not call the separately
translated `drop_DropMarker` body, whose Coma does contain the assignment to
`7`. Therefore this translation pipeline does not expose an implicit
destructor's body effect to a caller proof. A parser proof must not count
`ShrinkOnDrop::drop` as a proved caller-side slice-binding update.

The captured Coma files are under
`evidence/implicit-drop-translation-2026-10-05/`. They are retained as
translation evidence only; `implicit_drop_caller` is not part of a successful
proof set.

## Public behavior comparison for the current parser

`parse_headers_iter_uninit` uses `ShrinkOnDrop` to shorten its local mutable
slice binding to the count of complete headers on Complete, Partial, and Error.
It writes a slot only after the complete name and value have been parsed; its
tail is otherwise untouched. The changed fat-pointer metadata is local to the
caller's reborrow.

`parse_headers_iter` is private and is currently called by public
`parse_headers`. That API takes its `dst` slice by value. On Complete it
returns the shortened prefix in `Status::Complete((position, headers))`. On
Partial or Error, `complete!` returns no header slice, so shortening the local
`dst` binding is not observable to the caller. Complete parsed headers already
written to the caller-owned backing array remain there on every result; slots
after the written prefix remain as they were.

Request and Response parsing have two wrapper families:

- Private `Request::parse_with_config` is called by public `Request::parse`
  and `ParserConfig::parse_request`. It takes the initialized `self.headers`
  binding, then calls private `Request::parse_with_config_and_uninit_headers`
  through the existing cast. On Complete the helper publishes the shortened
  initialized prefix. On Partial or Error the outer wrapper restores the
  original full binding. Parsed prefix writes remain in the backing array on
  all results. Request fields are still assigned in their existing parse
  order.
- Private `Response::parse_with_config` is called by public `Response::parse`
  and `ParserConfig::parse_response`; it calls private
  `Response::parse_with_config_and_uninit_headers`. It has the same initialized
  binding behavior, with version, code, and reason assigned in their existing
  order.
- Public `Request::parse_with_uninit_headers` and
  `ParserConfig::parse_request_with_uninit_headers`, plus
  `ParserConfig::parse_response_with_uninit_headers`, pass a caller-owned
  `[MaybeUninit<Header>]` slice by value to the private uninitialized helper.
  On Complete the helper converts and publishes the shortened initialized
  prefix into `self.headers`. On Partial or Error it returns before publishing
  a header slice; the backing storage still contains the parsed initialized
  prefix and its tail is unchanged. The Response uninitialized helper is
  private; it is reached through the `ParserConfig` method.

Private `parse_headers_iter` currently has one caller: public `parse_headers`.
It calls `parse_headers_iter_uninit` after the parser's `Bytes` view and then
returns the shortened `dst` only on Complete. No other production caller of
`parse_headers_iter` was found in the reviewed source.

These are wrapper-level behaviors. A future common parser helper must not claim
that its private local binding has the same postcondition as the current
all-exit guard if it commits only on Complete. Instead, the adapter keeps its
binding full throughout parsing and the public wrappers commit only on
Complete. This preserves the externally visible behavior above while removing
an unproved implicit-Drop dependency.

## Typed adapter translated in the probe

The probe-only `HeaderStorage` in `src/header_storage.rs` has initialized and
uninitialized variants, each borrowing the caller's slice binding. Its single
logical counter is `used_len`; the API and intended contracts are:

| Method | Contract boundary |
| --- | --- |
| `initialized` | Current slots equal the full input slice mapped to `Some`; `used_len = 0`; every current slot is initialized. `future_slots` links the future local binding and `inner_future_slots` links the future contents of the inner slice borrow. |
| `uninitialized` | Current slots equal the input `MaybeUninit` views exactly; `used_len = 0`; no tail-initialization condition. The two future projections distinguish the local binding from its full backing slice. |
| `capacity` / `used_len` | Read the backing slice length and the canonical count, respectively. |
| `write(index, value)` | Requires `index = used_len < capacity` and an initialized prefix. Sets exactly that slot to `Some(value)`, increments `used_len`, preserves the mode and both borrow prophecies; the initialized branch retains the all-Some property. |
| `commit_prefix` | Requires `used_len <= capacity`, the initialized-prefix predicate, and matching inner-future/current capacities. Shortens the outer binding to `0..used_len`; the inner future retains full capacity, exports the same prefix, and frames the tail against current backing slots. This is called only for Complete. |

The initialized variant performs ordinary `Header` assignment. This matches the
existing write's no-drop behavior for the actual `Header` type (`Copy`, no
`Drop` implementation); it does not establish a generic `T` equivalence.
`commit_prefix` uses safe `mem::take` and `split_at_mut`; there is no raw pointer
identity claim. The uninitialized variant's tail remains unconstrained except
for explicit frame statements in callers.

Four translated clients exercise the intended public cutpoints. The
non-Complete clients assert the original full parent-slice length, exact
written slot zero, and unchanged tail. The Complete clients assert a local
published binding length of one while also asserting that the original parent
slice remains full length and that the backing tail is unchanged. The
uninitialized clients express slot values through `MaybeUninit`'s `Option`
view, so their input tail may be either initialized or uninitialized.

The initial interface had a narrow direct-Why3 checkpoint: the initialized
constructor was `Valid (0.02s, 42131 steps)`. The non-Complete initialized
client proved its `write` precondition (`Valid (0.02s, 47882 steps)`), but its
caller ensures timed out after 30 seconds and 565536238 steps. No later target
ran and no complete storage proof was established. Exact COMA inputs and raw
logs are retained under
`evidence/selected-solver-run-20261005T044741856965836Z/`.

Read-only COMA review then found the missing interface links: the original
`HeaderStorage::view` was opaque, and a single future projection did not
distinguish the final local binding from the inner backing slice's future
contents. The revised probe opens the enum view, exposes both future
projections, preserves both through `write`, and states a prefix/tail lens for
`commit_prefix`. This is a new source version; the earlier proof result applies
only to its archived input. The new source still needs fresh translation and
solver validation. The current production parser does not use this adapter.
Parser integration remains blocked until the complete selected method/client
closure passes and its field-update order and capacity-check timing are
reviewed.

The retained translation files include the two constructors, `write`,
`commit_prefix`, and the four representative clients under
`evidence/implicit-drop-translation-2026-10-05/{adapter,clients}/`. Their
postconditions are also stated in the source contracts. In particular, the
Complete clients assert that the local published binding is one slot long,
while the caller's original full slice still has its original length and
unchanged tail; the non-Complete clients assert the full local binding length,
one exact written prefix slot, and unchanged tail.

`future_slots` is a `logic(open, prophetic)` projection that applies `^` only
to the enum's nested `&mut &mut [..]` field and then models that typed slice.
The constructors state equality between this projection and the source
binding's future view. The adapter has no custom `Fin` implementation and gives
no future interpretation to its owned `used_len` counter.

## Reproduction and hashes

From this directory, translation only was run with:

```text
CARGO_NET_OFFLINE=true cargo creusot --no-check-version --simple-triggers=false -- --manifest-path Cargo.toml
```

No Why3 process, solver, runtime test, or production parser edit was involved.
The toolchain was cargo-creusot `0.11.0-dev`, rustc nightly `2026-02-27`, Why3
`1.8.2+git`, why3find `1.2.0+dev`.

At the captured translation, `src/header_storage.rs` SHA-256 was
`dea860169c775b9ee130adbb6f27a230ccb70c9b605ccf865d974138168b8f3f`, and the
probe harness `src/lib.rs` SHA-256 was
`7939dc5c85622646ef935a7c3bfa30c30bcc573caa693794b53caf2b1d15034d`. The
saved caller Coma SHA-256 is
`682848769e8170d2f1da9e3ed8c08eda8a6741ada4d6283744bec213a9cc8940`, and the
saved destructor Coma SHA-256 is
`0cdd67d3b7c00877e61b4d04b917bb7aca928ce369b9bc3f1cb9c958a35dd0b5`.
