# Fourth-projection HeaderStorage solver run

Status: pending.

This run uses the immutable 18-target COMA translation archived with adapter
source SHA-256 `f057994e473e68ea2292a19d24dc5ddd0c894e5d207abc8800f8d304ff817094`.
The selected ten targets run in dependency order: initialized, uninitialized,
capacity, used_len, write, commit_prefix, non-Complete initialized client,
Complete initialized client, non-Complete uninitialized client, Complete
uninitialized client. Each direct Why3 call uses the pinned isolated config,
Z3 4.15.3, split_vc, a 30-second per-goal limit, one prover, and a 1000 MiB
memory limit. The shared proof queue lock is held for the complete batch.
The runner stops on the first non-Valid or missing result. No translation,
source edit, or cache reuse is performed by this run.

Status: stopped at first non-Valid target, exit status 2.
