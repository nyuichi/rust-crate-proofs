# Guided-singleton transform preflight

- Input COMA: `utf8-seq-laws-decomposed/verif/httparse_string_model_harness_rlib/flat_map_laws/flat_map_singleton_guided.coma`
- Frozen COMA identity: recorded in `input.sha256` and `COMA-SHA256SUMS`.
- Transforms, in order: `split_vc`; `inst_rem flat_map_T_def (singleton(x):seq(t_T)),f`.
- The export-only preflight produced four tasks under `preflight/exported/`; hashes are in `preflight/SHA256SUMS`.
- All four exported tasks contain the selected ground equation for `flat_map_T(singleton(x), f)`, omit the quantified `flat_map_T_def`, retain the checked local helper contracts (`singleton_shape_T_spec`, `flat_map_empty_T_spec`, and `concat_right_empty_U_spec`), and retain the original goal name.
- The ground equation is the standard recursive `Seq::flat_map` definition instantiated at the singleton and the same mapping. Removing the universal while retaining this instance yields a stronger proof obligation, with no additional axiom.
- This export used `-o` and invoked no prover. The actual proof command used the same input/transforms and omitted `-o`.
