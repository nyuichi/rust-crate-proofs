# Selected typed-storage proof closure

The proposed selected closure is the exact ten-target list in
[`SELECTED-PROOF-TARGETS.txt`](SELECTED-PROOF-TARGETS.txt). The run order starts
with the initialized constructor and its non-Complete client to check mutable
binding linkage, then proves the uninitialized constructor, both accessors,
`write`, `commit_prefix`, and the remaining three representative clients.
`implicit_drop_caller` and the standalone `Drop::drop` body are translation-only
diagnostics and never enter this positive target list.

COMA static inspection shows that the logic definitions `HeaderStorage::view`,
`HeaderStorage::future_slots`, `HeaderStorage::inner_future_slots`, and `HeaderStorageView::{slots, used_len,
is_initialized, initialized_prefix, fully_initialized}` are embedded in the
selected method/client COMA files. `initialized_prefix` indexes slots only
under the explicit prefix bound. Translation emitted no separate logic-view
or Wf `.coma` target. `verify-selected.sh`
checks the exact complete generated target inventory against
[`TRANSLATION-TARGETS.txt`](TRANSLATION-TARGETS.txt), so a newly emitted target
(including a future Wf target) stops the run for review instead of silently
expanding the proof set. Add any reviewed new target by its exact path to the
inventory and, if it belongs in the positive closure, to the selected list.

`HeaderStorage::view` is explicitly open so callers can unfold the typed enum
model. The two prophetic projections distinguish the future local slice
binding (`future_slots`) from the future contents of the inner slice borrow
(`inner_future_slots`). Constructors link both projections to their source
borrow; `write` preserves both; `commit_prefix` shortens the outer future
binding and states the inner full-backing prefix/tail lens laws.

The VC context includes the existing Creusot sequence/map and
`MaybeUninit<T>::View` models emitted in COMA. These remain standard-library
model/axiom dependencies; this batch proves the adapter bodies and callers
against them. It does not prove a generic layout cast, a pointer identity
relation, `ShrinkOnDrop` caller effects, or production parser integration.

Every selected target was freshly translated once before the prior solver
checkpoint. The initialized constructor passed, while the following
non-Complete initialized caller timed out on its caller ensures after the
`write` precondition passed. That prior source version lacked the open view and
two-prophecy contracts now present in the adapter. Its result is recorded in
`evidence/selected-solver-run-20261005T044741856965836Z/RUN.md` and does not
apply to this refreshed source. The refreshed source has translation-only
status until a separately authorized solver run.

The runner creates a fresh translation before every `prove` invocation, checks
the generated target inventory, and then proves one COMA target at a time with
direct Why3 (`Z3 4.15.3`, 30 seconds per goal, one active prover, 1000 MiB).
It stops on the first non-Valid result and preserves exact logs plus source,
configuration, and COMA hashes under a per-run evidence directory.
