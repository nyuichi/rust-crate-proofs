# `skip_empty_lines` cursor-prefix induction candidate

**Status: fresh translation and all 20 selected Why3 `--type-only` checks passed. No solver was invoked, so no proof result is claimed.** This is a proof-only model update. It does not modify the extracted parser body or wire the helper into production `lib.rs`.

## Why the cursor bridge is explicit

The preceding 19-target candidate passed Why3 type-only, but `complete_line_prefix_at_cursor` was still an empty checked ghost function. Its body goal had to derive the relation between a complete scanned prefix and the endpoint of the maximal complete-line run. Prefix concatenation alone did not provide the induction needed for that bridge.

This candidate adds `complete_line_prefix_cursor_induction`, a recursive logic helper with variant `cursor - start`. It advances over the known scanned prefix one LF byte or one CRLF pair at a time and carries the endpoint relation through that induction. `complete_line_prefix_at_cursor` invokes it from a proof assertion.

The helper needs the endpoint value to stay equal across each recursive step. To expose that fact without an assumption, `complete_line_prefix_end` now has a checked recurrence postcondition: at a terminal start it returns `start`; at LF it equals the endpoint beginning at `start + 1`; at CRLF it equals the endpoint beginning at `start + 2`. The existing function body must establish this additional postcondition. Its original range, complete-prefix, and maximal-stop postconditions remain.

The model still distinguishes complete LF/CRLF endings, an incomplete trailing CR, and non-newline bytes. No runtime behavior, parser cursor, committed mark, error consumption, trusted call, or weakened contract was changed. The runtime source equivalence record remains 104 tokens with SHA-256 `cc731c7e0eeb496982e24cd47b3e563091f7a49afbbf00ed0c7b07947bdc8296`.

## Translation and selected closure

Translation exited 0 and emitted 64 CoMa files. [`all-coma-inventory.tsv`](all-coma-inventory.tsv) and [`fresh-coma.SHA256SUMS`](fresh-coma.SHA256SUMS) identify the preserved output. [`proof-targets.tsv`](proof-targets.tsv) records 20 exact target files in dependency order: 10 `Bytes`/`Iterator` dependencies, 9 model targets, and the extracted parser last. [`dependencies.tsv`](dependencies.tsv) records the explicit cursor induction and endpoint recurrence dependencies.

Why3 `--type-only` completed for all 20 selected targets at [`type-only-20261005T071837Z/`](type-only-20261005T071837Z/). The result is `type-only-ok-all-20`, and the run identity confirms `solver_invocations=0`. All selected CoMa hashes were unchanged before and after type-only. The exact run uses the frozen string-model Why3 config snapshot and Creusot package manifest recorded in its run identity.

The model, extracted parser, harness inputs, and their SHA-256 values are preserved under `inputs/`. The previous 19-target type-only candidate and earlier bounded solver timeout remain unchanged in their own evidence directories. In particular, the earlier timeout was not retried here.

## Proof status and next verification step

Type-only checks establish that Why3 accepts the selected CoMa syntax and symbols; they do not establish any goal's validity. The induction body, strengthened endpoint postcondition, wrappers, cursor bridge, model, and extracted parser still require solver checks under the separately controlled bounded-proof grant.
