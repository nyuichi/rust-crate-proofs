# `skip_empty_lines` concatenation induction candidate

**Status: fresh translation and all 19 selected Why3 `--type-only` checks passed. No solver was invoked, so this is not proof evidence.** The production parser remains unwired. This is the exact candidate before the later cursor-prefix induction candidate in `../cursor-induction-prep-20261005T071604Z/`.

## Candidate

`src/verification/empty_lines.rs` adds `complete_line_prefix_concat`, a recursive logic helper with variant `mid - start`. It takes the already-scanned prefix `[start, mid)` and a complete suffix `[mid, stop)`. Each induction step advances one byte for LF or two bytes for CRLF. The helper returns `mid`; its postconditions state both `result == mid` and `complete_line_prefix(input, start, stop)`.

The LF and CRLF wrappers establish finite one-byte or two-byte suffixes and call the composition helper. The parser model and extracted runtime body are otherwise unchanged. No axioms, trusted calls, or weakened contracts were added.

The bool-return draft is retained under [`rejected-bool-candidate/`](rejected-bool-candidate/). Its CoMa contains a body goal with the recursive body and both ensures; it was not missing a body goal or merely axiomatizing its postconditions. The Int-return form was selected because its result directly exposes `result == mid`, which the wrappers use. The bool candidate was translation-only and was never solver-run.

## Previous bounded proof run

The unchanged pre-induction model and timeout CoMa/log are preserved under [`archive/`](archive/). The archived model SHA-256 is recorded in `archive/ARCHIVE.tsv`. The original bounded run is at `../direct-why3-20261005T062922467607808Z/`; it produced 69 Valid split leaves across 12 target files, one exact `TrivialTrueNoTask` target, and then a 30-second timeout at `complete_line_prefix_extend_crlf`. Later targets, including the extracted parser, were not attempted. That timeout has not been retried.

## Translation and type-only result

The translation emitted 63 CoMa files; paths and SHA-256 values are in [`all-coma-inventory.tsv`](all-coma-inventory.tsv), with each file preserved under [`fresh-coma/`](fresh-coma/). The selected closure has 19 unique targets: 10 `Bytes`/`Iterator` dependencies, 8 model targets, and the extracted parser last. [`proof-targets.tsv`](proof-targets.tsv) records the exact target hashes and order; [`dependencies.tsv`](dependencies.tsv) records the lemma edges.

Why3 `--type-only` completed for all 19 selected targets at [`type-only-20261005T071146Z/`](type-only-20261005T071146Z/). The result is `type-only-ok-all-19`, with `solver_invocations=0`; every selected CoMa hash was unchanged before and after the run. The current sibling candidate adds an explicit cursor induction bridge and has its own 20-target type-only result.

The exact source snapshots and hashes are in `inputs/source/` and `inputs/SOURCE-SHA256SUMS.tsv`. Production and extracted `skip_empty_lines` runtime bodies still match across 104 tokens, SHA-256 `cc731c7e0eeb496982e24cd47b3e563091f7a49afbbf00ed0c7b07947bdc8296`.
