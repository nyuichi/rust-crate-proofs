#!/usr/bin/env bash
set -euo pipefail
probe_dir=$1
run_dir=$2
isolated_env=/workspace/scratch/httparse-string-model/creusot-env.sh
isolated_config=/workspace/scratch/httparse-string-model/why3.conf
expected_config_sha256=e1124888733158546f027f02926484f591bed63bb5e10f861a6c93a54330ea07
expected_env_sha256=2660d36ccbf8cac8a8cba2b61a4e46db17b494518afd6631086519c111350ac6
expected_package=/workspace/scratch/httparse-string-model/creusot-data/share/why3find/packages/creusot
proof_runner=/workspace/rust-crate-proofs/httparse/1.10.1/run-proof.bash

[[ $(sha256sum "$probe_dir/src/header_storage.rs" | cut -d' ' -f1) == f057994e473e68ea2292a19d24dc5ddd0c894e5d207abc8800f8d304ff817094 ]]
cmp "$probe_dir/src/header_storage.rs" "$run_dir/source/header_storage.rs"
cmp "$probe_dir/src/lib.rs" "$run_dir/source/lib.rs"
cmp "$probe_dir/SELECTED-PROOF-TARGETS.txt" "$run_dir/source/SELECTED-PROOF-TARGETS.txt"
cmp "$probe_dir/TRANSLATION-TARGETS.txt" "$run_dir/source/TRANSLATION-TARGETS.txt"
[[ $(sha256sum "$run_dir/source/SELECTED-PROOF-TARGETS.txt" | cut -d' ' -f1) == 8510e675761cabee131c54724ddb736890ba29414b5a132dc2652df4c5874a8c ]]
[[ $(sha256sum "$run_dir/source/TRANSLATION-TARGETS.txt" | cut -d' ' -f1) == aa81244d3027591e640c01b689f2f81fd03cd0872c09161f6c47bd8d6ea20d91 ]]
[[ $(find "$run_dir/coma" -type f -name '*.coma' | wc -l) -eq 18 ]]
[[ $(wc -l < "$run_dir/source/SELECTED-PROOF-TARGETS.txt") -eq 10 ]]
(cd "$run_dir/coma" && sha256sum -c ../COMA-SHA256SUMS > /dev/null)

source /workspace/proof-tools/activate.sh
why3_bin=$(command -v why3)
why3find_bin=/workspace/scratch/httparse-string-model/creusot-data/bin/why3find
expected_why3_sha256=cced91edcb7d8edfb3540f060c1f4609cd02f69bc0e48bc22f8e35d58731bdff
expected_why3find_sha256=c83c6c6ed7684495afd5547b40cb620674ca7cc9ebe95c4354f224a3ff1db976
expected_z3_sha256=80ee070b8ffc2fa964b0b879250b2110c47f84c1256a1f9ab76fc7cf95e46292
[[ $(sha256sum "$isolated_config" | cut -d' ' -f1) == "$expected_config_sha256" ]]
[[ $(sha256sum "$isolated_env" | cut -d' ' -f1) == "$expected_env_sha256" ]]
[[ $(sha256sum "$why3_bin" | cut -d' ' -f1) == "$expected_why3_sha256" ]]
[[ $(sha256sum "$why3find_bin" | cut -d' ' -f1) == "$expected_why3find_sha256" ]]
[[ $(sha256sum /workspace/scratch/httparse-string-model/creusot-data/bin/z3 | cut -d' ' -f1) == "$expected_z3_sha256" ]]

set +e
WHY3CONFIG="$isolated_config" "$proof_runner" bash -c '
  set -euo pipefail
  probe_dir=$1
  run_dir=$2
  env_file=$3
  expected_config=$4
  expected_config_sha256=$5
  expected_env_sha256=$6
  expected_package=$7
  why3find_bin=$8
  source "$env_file"
  cd "$probe_dir"
  config_sha=$(sha256sum "$WHY3CONFIG" | cut -d" " -f1)
  env_sha=$(sha256sum "$env_file" | cut -d" " -f1)
  [[ "$WHY3CONFIG" == "$expected_config" ]]
  [[ "$config_sha" == "$expected_config_sha256" ]]
  [[ "$env_sha" == "$expected_env_sha256" ]]
  grep -Eq "^running_provers_max = 1$" "$WHY3CONFIG"
  grep -Eq "^memlimit = 1000$" "$WHY3CONFIG"
  why3find_bin="$CREUSOT_DATA_HOME/bin/why3find"
  why3_bin=$(command -v why3)
  query_output=$("$why3find_bin" query creusot)
  package_path=$(printf "%s\n" "$query_output" | sed -n "s/^[[:space:]]*path: //p")
  [[ "$package_path" == "$expected_package" ]]
  printf "Shared proof queue lock held across selected batch.\n"
  printf "Why3 config: %s (sha256 %s)\n" "$WHY3CONFIG" "$config_sha"
  printf "Isolated env: %s (sha256 %s)\n" "$env_file" "$env_sha"
  printf "Creusot package: %s\n%s\n" "$package_path" "$query_output"
  printf "Execution order is the checked 10-line selected-target manifest.\n"
  i=0
  while IFS= read -r target; do
    i=$((i + 1))
    log_path="$run_dir/logs/$(printf "%02d" "$i")-$(basename "$target" .coma).log"
    coma="$run_dir/coma/$target"
    [[ -s "$coma" ]]
    printf "Starting target %d/10: %s\n" "$i" "$target"
    {
      printf "Why3 config: %s (sha256 %s)\n" "$WHY3CONFIG" "$config_sha"
      printf "Isolated env: %s (sha256 %s)\n" "$env_file" "$env_sha"
      printf "Creusot package: %s\n" "$package_path"
      printf "why3find query creusot:\n%s\n" "$query_output"
      printf "COMA target: %s\n" "$target"
      sha256sum "$coma"
      printf "Proof command: %s -C %s prove -L %s -L %s -a split_vc -P Z3,4.15.3 -t 30 -m 1000 %s\n" \
        "$why3_bin" "$WHY3CONFIG" "$expected_package" "$run_dir/coma/verif" "$coma"
    } > "$log_path"
    if "$why3_bin" -C "$WHY3CONFIG" prove \
      -L "$expected_package" \
      -L "$run_dir/coma/verif" \
      -a split_vc \
      -P Z3,4.15.3 \
      -t 30 -m 1000 \
      "$coma" >> "$log_path" 2>&1; then
      result=0
    else
      result=$?
    fi
    cat "$log_path"
    if (( result != 0 )); then
      printf "Target %s exited with status %d; stop.\n" "$target" "$result" >&2
      exit "$result"
    fi
    if grep -Eiq "(^|[^[:alpha:]])(unknown|timeout|invalid|failure|out of memory|step limit)([^[:alpha:]]|$)" "$log_path"; then
      printf "Target %s returned a non-Valid or inconclusive result; stop.\n" "$target" >&2
      exit 1
    fi
    if ! grep -Eiq "Prover result is: Valid|\\bValid \\(" "$log_path"; then
      printf "Target %s has no Valid result; stop.\n" "$target" >&2
      exit 1
    fi
  done < "$run_dir/source/SELECTED-PROOF-TARGETS.txt"
' _ "$probe_dir" "$run_dir" "$isolated_env" "$isolated_config" \
  "$expected_config_sha256" "$expected_env_sha256" "$expected_package" "$why3find_bin" \
  > "$run_dir/driver.log" 2>&1
result=$?
set -e
cat "$run_dir/driver.log"
if (( result == 0 )); then
  printf 'All ten selected targets reported Valid.\n' | tee "$run_dir/SUCCESS.txt"
  printf '\nStatus: all ten selected targets reported Valid.\n' >> "$run_dir/RUN.md"
else
  printf 'Selected batch stopped with exit status %d.\n' "$result" | tee "$run_dir/STOPPED.txt"
  printf '\nStatus: stopped at first non-Valid target, exit status %d.\n' "$result" >> "$run_dir/RUN.md"
fi
exit "$result"
