#![cfg_attr(not(feature = "std"), no_std)]

// This module contains only ordinary sequence facts. It intentionally does not
// mention flat_map so its VCs stay independent of the recursive definition.
mod sequence_only {
    use creusot_std::prelude::*;

    #[logic]
    #[ensures(Seq::<T>::empty().len() == 0)]
    pub fn empty_len<T>() {}

    #[logic]
    #[ensures(Seq::singleton(x).len() == 1)]
    #[ensures(Seq::singleton(x)[0] == x)]
    #[ensures(Seq::singleton(x).tail() == Seq::empty())]
    pub fn singleton_shape<T>(x: T) {
        proof_assert! { Seq::singleton(x).tail().len() == 0 };
        proof_assert! { Seq::singleton(x).tail().ext_eq(Seq::empty()) }
    }

    #[logic]
    #[ensures(s.concat(Seq::empty()) == s)]
    pub fn concat_right_empty<T>(s: Seq<T>) {
        proof_assert! { s.concat(Seq::empty()).len() == s.len() };
        proof_assert! {
            forall<i> 0 <= i && i < s.len() ==> s.concat(Seq::empty())[i] == s[i]
        };
        proof_assert! { s.concat(Seq::empty()).ext_eq(s) };
    }

    #[logic]
    #[requires(s.len() > 0)]
    #[ensures(s.tail().push_back(x) == s.push_back(x).tail())]
    pub fn push_back_tail_nonempty<T>(s: Seq<T>, x: T) {
        proof_assert! { s.tail().push_back(x) == s.push_back(x).tail() };
    }

    #[logic]
    #[ensures(a.concat(b.concat(c)) == a.concat(b).concat(c))]
    pub fn concat_associative<T>(a: Seq<T>, b: Seq<T>, c: Seq<T>) {
        proof_assert! {
            a.concat(b.concat(c)).len() == a.concat(b).concat(c).len()
        };
        proof_assert! {
            forall<i> 0 <= i && i < a.len() ==>
                a.concat(b.concat(c))[i] == a.concat(b).concat(c)[i]
        };
        proof_assert! {
            forall<i> a.len() <= i && i < a.len() + b.len() ==>
                a.concat(b.concat(c))[i] == a.concat(b).concat(c)[i]
        };
        proof_assert! {
            forall<i> a.len() + b.len() <= i && i < a.len() + b.len() + c.len() ==>
                a.concat(b.concat(c))[i] == a.concat(b).concat(c)[i]
        };
        proof_assert! { a.concat(b.concat(c)).ext_eq(a.concat(b).concat(c)) };
    }
}

// Keep recursive flat-map facts in a separate module, consuming only the
// body-checked sequence lemmas above.
mod flat_map_laws {
    use creusot_std::logic::Mapping;
    use creusot_std::prelude::*;

    use super::sequence_only;

    #[logic]
    #[ensures(Seq::<T>::empty().flat_map(f) == Seq::empty())]
    pub fn flat_map_empty<T, U>(f: Mapping<T, Seq<U>>) {
        sequence_only::empty_len::<T>();
        proof_assert! { Seq::<T>::empty().len() == 0 };
        proof_assert! { Seq::<T>::empty().flat_map(f) == Seq::empty() }
    }

    #[logic]
    #[ensures(Seq::singleton(x).flat_map(f) == f.get(x))]
    pub fn flat_map_singleton_guided<T, U>(x: T, f: Mapping<T, Seq<U>>) {
        sequence_only::singleton_shape(x);
        flat_map_empty::<T, U>(f);
        sequence_only::concat_right_empty::<U>(f.get(x));

        proof_assert! {
            Seq::singleton(x).flat_map(f)
                == f.get(x).concat(Seq::singleton(x).tail().flat_map(f))
        };
        proof_assert! { Seq::singleton(x).tail().flat_map(f) == Seq::<U>::empty() };
        proof_assert! { f.get(x).concat(Seq::<U>::empty()) == f.get(x) };
    }
}
