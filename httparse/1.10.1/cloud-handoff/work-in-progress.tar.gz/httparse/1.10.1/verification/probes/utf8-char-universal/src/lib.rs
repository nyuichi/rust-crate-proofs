#![cfg_attr(not(feature = "std"), no_std)]

use creusot_std::prelude::*;
use creusot_std::std::char::utf8_byte;

#[check(ghost)]
#[ensures(0 <= c@ && c@ < 0x110000 && !(0xD800 <= c@ && c@ < 0xE000))]
pub fn valid_rust_char_domain(c: char) {
    proof_assert!(0 <= c@);
    proof_assert!(c@ < 0x110000);
    proof_assert!(!(0xD800 <= c@ && c@ < 0xE000));
}

#[check(ghost)]
#[requires(0 <= c@ && c@ < 0x80)]
#[ensures(c.to_utf8() == seq![utf8_byte(c@)])]
pub fn utf8_char_one_byte(c: char) {
    valid_rust_char_domain(c);
    let encoded = snapshot!(c.to_utf8());
    proof_assert!(0 <= c@ && c@ <= 255);
    proof_assert!(utf8_byte(c@)@ == c@);
    proof_assert!(encoded.len() == 1);
    proof_assert!(encoded[0]@ == c@);
    proof_assert!(encoded.ext_eq(seq![utf8_byte(c@)]));
    proof_assert!(c.to_utf8() == seq![utf8_byte(c@)]);
}

#[check(ghost)]
#[requires(0x80 <= c@ && c@ < 0x800)]
#[ensures(c.to_utf8() == seq![
    utf8_byte(0xC0 + c@ / 64),
    utf8_byte(0x80 + c@ % 64),
])]
pub fn utf8_char_two_bytes(c: char) {
    valid_rust_char_domain(c);
    let encoded = snapshot!(c.to_utf8());
    proof_assert!(0 <= 0xC0 + c@ / 64 && 0xC0 + c@ / 64 <= 255);
    proof_assert!(0 <= 0x80 + c@ % 64 && 0x80 + c@ % 64 <= 255);
    proof_assert!(utf8_byte(0xC0 + c@ / 64)@ == 0xC0 + c@ / 64);
    proof_assert!(utf8_byte(0x80 + c@ % 64)@ == 0x80 + c@ % 64);
    proof_assert!(encoded.len() == 2);
    proof_assert!(encoded[0]@ == 0xC0 + c@ / 64);
    proof_assert!(encoded[1]@ == 0x80 + c@ % 64);
    proof_assert!(encoded.ext_eq(seq![
        utf8_byte(0xC0 + c@ / 64),
        utf8_byte(0x80 + c@ % 64),
    ]));
    proof_assert!(c.to_utf8() == seq![
        utf8_byte(0xC0 + c@ / 64),
        utf8_byte(0x80 + c@ % 64),
    ]);
}

#[check(ghost)]
#[requires(0x800 <= c@ && c@ < 0x10000)]
#[ensures(c.to_utf8() == seq![
    utf8_byte(0xE0 + c@ / 4096),
    utf8_byte(0x80 + (c@ / 64) % 64),
    utf8_byte(0x80 + c@ % 64),
])]
pub fn utf8_char_three_bytes(c: char) {
    valid_rust_char_domain(c);
    let encoded = snapshot!(c.to_utf8());
    proof_assert!(0 <= 0xE0 + c@ / 4096 && 0xE0 + c@ / 4096 <= 255);
    proof_assert!(0 <= 0x80 + (c@ / 64) % 64 && 0x80 + (c@ / 64) % 64 <= 255);
    proof_assert!(0 <= 0x80 + c@ % 64 && 0x80 + c@ % 64 <= 255);
    proof_assert!(utf8_byte(0xE0 + c@ / 4096)@ == 0xE0 + c@ / 4096);
    proof_assert!(utf8_byte(0x80 + (c@ / 64) % 64)@ == 0x80 + (c@ / 64) % 64);
    proof_assert!(utf8_byte(0x80 + c@ % 64)@ == 0x80 + c@ % 64);
    proof_assert!(encoded.len() == 3);
    proof_assert!(encoded[0]@ == 0xE0 + c@ / 4096);
    proof_assert!(encoded[1]@ == 0x80 + (c@ / 64) % 64);
    proof_assert!(encoded[2]@ == 0x80 + c@ % 64);
    proof_assert!(encoded.ext_eq(seq![
        utf8_byte(0xE0 + c@ / 4096),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]));
    proof_assert!(c.to_utf8() == seq![
        utf8_byte(0xE0 + c@ / 4096),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]);
}

#[check(ghost)]
#[requires(0x10000 <= c@ && c@ < 0x110000)]
#[ensures(c.to_utf8() == seq![
    utf8_byte(0xF0 + c@ / 262144),
    utf8_byte(0x80 + (c@ / 4096) % 64),
    utf8_byte(0x80 + (c@ / 64) % 64),
    utf8_byte(0x80 + c@ % 64),
])]
pub fn utf8_char_four_bytes(c: char) {
    valid_rust_char_domain(c);
    let encoded = snapshot!(c.to_utf8());
    proof_assert!(0 <= 0xF0 + c@ / 262144 && 0xF0 + c@ / 262144 <= 255);
    proof_assert!(0 <= 0x80 + (c@ / 4096) % 64 && 0x80 + (c@ / 4096) % 64 <= 255);
    proof_assert!(0 <= 0x80 + (c@ / 64) % 64 && 0x80 + (c@ / 64) % 64 <= 255);
    proof_assert!(0 <= 0x80 + c@ % 64 && 0x80 + c@ % 64 <= 255);
    proof_assert!(utf8_byte(0xF0 + c@ / 262144)@ == 0xF0 + c@ / 262144);
    proof_assert!(utf8_byte(0x80 + (c@ / 4096) % 64)@ == 0x80 + (c@ / 4096) % 64);
    proof_assert!(utf8_byte(0x80 + (c@ / 64) % 64)@ == 0x80 + (c@ / 64) % 64);
    proof_assert!(utf8_byte(0x80 + c@ % 64)@ == 0x80 + c@ % 64);
    proof_assert!(encoded.len() == 4);
    proof_assert!(encoded[0]@ == 0xF0 + c@ / 262144);
    proof_assert!(encoded[1]@ == 0x80 + (c@ / 4096) % 64);
    proof_assert!(encoded[2]@ == 0x80 + (c@ / 64) % 64);
    proof_assert!(encoded[3]@ == 0x80 + c@ % 64);
    proof_assert!(encoded.ext_eq(seq![
        utf8_byte(0xF0 + c@ / 262144),
        utf8_byte(0x80 + (c@ / 4096) % 64),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]));
    proof_assert!(c.to_utf8() == seq![
        utf8_byte(0xF0 + c@ / 262144),
        utf8_byte(0x80 + (c@ / 4096) % 64),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]);
}

#[check(ghost)]
#[ensures(c.to_utf8() == if c@ < 0x80 {
    seq![utf8_byte(c@)]
} else if c@ < 0x800 {
    seq![utf8_byte(0xC0 + c@ / 64), utf8_byte(0x80 + c@ % 64)]
} else if c@ < 0x10000 {
    seq![
        utf8_byte(0xE0 + c@ / 4096),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]
} else {
    seq![
        utf8_byte(0xF0 + c@ / 262144),
        utf8_byte(0x80 + (c@ / 4096) % 64),
        utf8_byte(0x80 + (c@ / 64) % 64),
        utf8_byte(0x80 + c@ % 64),
    ]
})]
pub fn utf8_char_piecewise(c: char) {
    valid_rust_char_domain(c);
}
