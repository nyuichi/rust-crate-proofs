Only `why3 prove --type-only` was run. No prover option or solver command was used.
