# UTF-8 literal caller proof preparation

This isolated harness connects five literal scalar models to exact UTF-8 byte
sequences and adds one three-scalar boundary-string caller. Each caller invokes
local checked composition wrappers, which in turn use the checked source-clone
sequence helper targets. It does not invoke the standard helper contracts
directly from the literal caller.

For each scalar, a separate checked target proves the literal `Seq.create`
model equals a singleton by length and index. A final target proves the exact
byte sequence. The boundary string target proves its `Seq.create` model equals
a singleton followed by two `push_back` operations, then proves the ten-byte
sequence. `proof-targets.txt` lists all 21 targets, including the scalar,
source-clone helper, local bridge, model, and caller dependencies.

`verify.sh translate` translates the harness and `verify.sh typecheck` checks
the exact COMA inventory. The runner has no solver mode. No solver has run, so
the functions remain proof candidates, not completed proof results.
