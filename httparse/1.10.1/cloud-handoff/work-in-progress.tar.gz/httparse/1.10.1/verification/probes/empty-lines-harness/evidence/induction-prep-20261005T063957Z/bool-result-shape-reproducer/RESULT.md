# Bool-return contract translation shape

`translate.sh` exited 0 and emitted `verif/httparse_bool_result_shape_reproducer_rlib/false_bool.coma`. That file contains a body goal, `vc_false_bool: false`, for the deliberately false `#[logic]` function with `#[ensures(result)]`.

This translation-only reproducer shows that a bool-return logic function with an ensures clause does produce a body VC in this compiler profile. No Why3 type-only command or solver was run, so no validity result is claimed.
