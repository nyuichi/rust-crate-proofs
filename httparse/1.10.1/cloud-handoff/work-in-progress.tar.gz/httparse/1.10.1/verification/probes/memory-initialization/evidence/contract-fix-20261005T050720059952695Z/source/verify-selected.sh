#!/usr/bin/env bash
set -euo pipefail

script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
repo_root=$(cd "$script_dir/../../../../.." && pwd)
crate_dir=$(cd "$script_dir/../../.." && pwd)
manifest="$script_dir/Cargo.toml"
package_name=httparse-memory-initialization-probe
coma_dir="$script_dir/verif/httparse_memory_initialization_probe_rlib"
proof_runner="$crate_dir/run-proof.bash"
selected_manifest="$script_dir/SELECTED-PROOF-TARGETS.txt"
translation_manifest="$script_dir/TRANSLATION-TARGETS.txt"
isolated_env=/workspace/scratch/httparse-string-model/creusot-env.sh
isolated_config=/workspace/scratch/httparse-string-model/why3.conf
expected_config_sha256=e1124888733158546f027f02926484f591bed63bb5e10f861a6c93a54330ea07
expected_env_sha256=2660d36ccbf8cac8a8cba2b61a4e46db17b494518afd6631086519c111350ac6
expected_creusot_package=/workspace/scratch/httparse-string-model/creusot-data/share/why3find/packages/creusot

check_source_files() {
  [[ -r "$manifest" ]] || { printf 'Missing manifest: %s\n' "$manifest" >&2; exit 2; }
  [[ -r "$selected_manifest" ]] || { printf 'Missing selected-target manifest: %s\n' "$selected_manifest" >&2; exit 2; }
  [[ -r "$translation_manifest" ]] || { printf 'Missing translation-target manifest: %s\n' "$translation_manifest" >&2; exit 2; }
  [[ -x "$proof_runner" ]] || { printf 'Missing shared proof runner: %s\n' "$proof_runner" >&2; exit 2; }
  [[ -r "$isolated_env" && -r "$isolated_config" ]] || {
    printf 'Missing pinned isolated Why3 environment under /workspace/scratch/httparse-string-model\n' >&2
    exit 2
  }
}

fresh_translate() {
  source /workspace/proof-tools/activate.sh
  mkdir -p "$script_dir/target" /workspace/scratch/httparse-memory-initialization/translation-config \
    /workspace/scratch/httparse-memory-initialization/translation-cache
  rm -rf "$coma_dir"
  CARGO_TARGET_DIR="$script_dir/target" cargo clean --manifest-path "$manifest" --package "$package_name"
  cd "$script_dir"
  env -u WHY3CONFIG \
    CREUSOT_DATA_HOME=/workspace/proof-tools/creusot-data \
    DUNE_DIR_LOCATIONS=why3find:lib:/workspace/proof-tools/creusot-data/share/why3find \
    XDG_CONFIG_HOME=/workspace/scratch/httparse-memory-initialization/translation-config \
    XDG_CACHE_HOME=/workspace/scratch/httparse-memory-initialization/translation-cache \
    CARGO_TARGET_DIR="$script_dir/target" \
    CARGO_NET_OFFLINE=true \
    cargo creusot --no-check-version --simple-triggers=false -- --manifest-path "$manifest"
  check_generated_targets
}

check_generated_targets() {
  local -a expected generated selected
  mapfile -t expected < "$translation_manifest"
  mapfile -t generated < <(find "$script_dir/verif" -type f -name '*.coma' -printf 'verif/%P\n' | sort)
  if ! diff -u <(printf '%s\n' "${expected[@]}") <(printf '%s\n' "${generated[@]}"); then
    printf 'Generated COMA inventory differs from the reviewed manifest. Inspect exact added/missing paths before proof.\n' >&2
    exit 2
  fi
  mapfile -t selected < "$selected_manifest"
  (( ${#selected[@]} == 10 )) || {
    printf 'Expected exactly ten reviewed positive targets; found %d.\n' "${#selected[@]}" >&2
    exit 2
  }
  for target in "${selected[@]}"; do
    [[ -s "$script_dir/$target" ]] || {
      printf 'Selected fresh COMA target is missing or empty: %s\n' "$script_dir/$target" >&2
      exit 2
    }
  done
  [[ -s "$script_dir/verif/httparse_memory_initialization_probe_rlib/implicit_drop_caller.coma" ]] || {
    printf 'Translation-only Drop caller diagnostic was not generated.\n' >&2
    exit 2
  }
}

run_one_target() {
  local target=$1 log_path=$2 result=0
  WHY3CONFIG="$isolated_config" "$proof_runner" bash -c '
    set -euo pipefail
    probe_dir=$1
    env_file=$2
    expected_config=$3
    expected_config_sha256=$4
    expected_env_sha256=$5
    expected_package=$6
    target=$7
    shift 7
    source "$env_file"
    cd "$probe_dir"
    config_sha=$(sha256sum "$WHY3CONFIG" | cut -d" " -f1)
    env_sha=$(sha256sum "$env_file" | cut -d" " -f1)
    [[ "$WHY3CONFIG" == "$expected_config" ]] || { echo "Unexpected WHY3CONFIG: $WHY3CONFIG" >&2; exit 2; }
    [[ "$config_sha" == "$expected_config_sha256" ]] || { echo "Why3 config hash changed: $config_sha" >&2; exit 2; }
    [[ "$env_sha" == "$expected_env_sha256" ]] || { echo "Isolated environment hash changed: $env_sha" >&2; exit 2; }
    grep -Eq "^running_provers_max = 1$" "$WHY3CONFIG" || { echo "Expected one active prover" >&2; exit 2; }
    grep -Eq "^memlimit = 1000$" "$WHY3CONFIG" || { echo "Expected 1000 MiB per prover" >&2; exit 2; }
    why3find_bin="$CREUSOT_DATA_HOME/bin/why3find"
    why3_bin=$(command -v why3)
    [[ -x "$why3find_bin" && -x "$why3_bin" ]] || { echo "Missing Why3 tools" >&2; exit 2; }
    query_output=$("$why3find_bin" query creusot)
    package_path=$(printf "%s\n" "$query_output" | sed -n "s/^[[:space:]]*path: //p")
    [[ "$package_path" == "$expected_package" ]] || {
      printf "Unexpected Creusot package: %s\n" "$package_path" >&2
      exit 2
    }
    coma="$probe_dir/$target"
    [[ -s "$coma" ]] || { echo "Missing fresh target: $coma" >&2; exit 2; }
    printf "Why3 config: %s (sha256 %s)\n" "$WHY3CONFIG" "$config_sha"
    printf "Isolated env: %s (sha256 %s)\n" "$env_file" "$env_sha"
    printf "Creusot package: %s\n" "$package_path"
    printf "why3find query creusot:\n%s\n" "$query_output"
    printf "COMA target: %s\n" "$target"
    sha256sum "$coma"
    printf "Proof command: %s -C %s prove -L %s -L %s -a split_vc -P Z3,4.15.3 -t 30 -m 1000 %s\n" \
      "$why3_bin" "$WHY3CONFIG" "$expected_package" "$probe_dir/verif" "$coma"
    "$why3_bin" -C "$WHY3CONFIG" prove \
      -L "$expected_package" \
      -L "$probe_dir/verif" \
      -a split_vc \
      -P Z3,4.15.3 \
      -t 30 -m 1000 \
      "$coma"
  ' _ "$script_dir" "$isolated_env" "$isolated_config" "$expected_config_sha256" \
    "$expected_env_sha256" "$expected_creusot_package" "$target" >"$log_path" 2>&1 || result=$?
  cat "$log_path"
  if (( result != 0 )); then
    printf 'Target %s exited with status %d; stopping the proof batch.\n' "$target" "$result" >&2
    return "$result"
  fi
  if grep -Eiq '(^|[^[:alpha:]])(unknown|timeout|invalid|failure|out of memory|step limit)([^[:alpha:]]|$)' "$log_path"; then
    printf 'Target %s has a non-Valid/inconclusive result; stopping the proof batch.\n' "$target" >&2
    return 1
  fi
  if ! grep -Eiq 'Prover result is: Valid|\bValid \(' "$log_path"; then
    printf 'Target %s log contains no Valid result; stopping rather than treating it as proved.\n' "$target" >&2
    return 1
  fi
}

prove_selected() {
  local run_stamp run_dir target i
  local -a selected order
  fresh_translate
  mapfile -t selected < "$selected_manifest"
  run_stamp=$(date -u +%Y%m%dT%H%M%S%NZ)
  run_dir="$script_dir/evidence/selected-solver-run-$run_stamp"
  mkdir -p "$run_dir/logs" "$run_dir/coma"
  cp "$selected_manifest" "$translation_manifest" "$script_dir/PROOF-CLOSURE.md" "$run_dir/"
  cp "$script_dir/src/header_storage.rs" "$script_dir/src/lib.rs" "$script_dir/Cargo.toml" "$script_dir/Cargo.lock" "$run_dir/"
  cp "$crate_dir/src/message.rs" "$run_dir/message.rs"
  while IFS= read -r target; do
    mkdir -p "$run_dir/coma/$(dirname "$target")"
    cp "$script_dir/$target" "$run_dir/coma/$target"
  done < "$translation_manifest"
  {
    source /workspace/proof-tools/activate.sh
    why3_binary=$(command -v why3)
    sha256sum "$isolated_config" "$isolated_env" "$script_dir/why3find.json" \
      "$why3_binary" /workspace/scratch/httparse-string-model/creusot-data/bin/why3find \
      /workspace/scratch/httparse-string-model/creusot-data/bin/z3 \
      "$script_dir/src/header_storage.rs" "$script_dir/src/lib.rs" "$script_dir/Cargo.toml" "$script_dir/Cargo.lock" \
      "$script_dir/SELECTED-PROOF-TARGETS.txt" "$script_dir/TRANSLATION-TARGETS.txt" \
      "$script_dir/PROOF-CLOSURE.md" "$script_dir/verify-selected.sh" "$crate_dir/src/message.rs" \
      "$repo_root/creusot-libs/creusot-std/src/std/mem.rs" \
      "$repo_root/creusot-libs/creusot-std/src/std/slice.rs" \
      "$expected_creusot_package/creusot/prelude.coma" "$expected_creusot_package/creusot/slice.coma" \
      "$expected_creusot_package/creusot/int.coma" "$expected_creusot_package/creusot/float.coma"
    (cd "$script_dir" && while IFS= read -r target; do sha256sum "$target"; done < "$translation_manifest")
  } > "$run_dir/SHA256SUMS"
  printf '%s\n' 'Execution order: initialized constructor, non-Complete initialized client, uninitialized constructor, capacity, used_len, write, commit_prefix, then three remaining clients.' > "$run_dir/RUN.md"
  order=(
    "${selected[0]}"
    "${selected[1]}"
    "${selected[2]}"
    "${selected[3]}"
    "${selected[4]}"
    "${selected[5]}"
    "${selected[6]}"
    "${selected[7]}"
    "${selected[8]}"
    "${selected[9]}"
  )
  for i in "${!order[@]}"; do
    target=${order[$i]}
    printf -v log_name '%02d-%s.log' "$((i + 1))" "$(basename "$target" .coma)"
    printf 'Starting target %d/10: %s\n' "$((i + 1))" "$target"
    if ! run_one_target "$target" "$run_dir/logs/$log_name"; then
      printf 'Stopped at first non-Valid target. Evidence: %s\n' "$run_dir" >&2
      return 1
    fi
  done
  printf 'All selected targets reported Valid. Evidence: %s\n' "$run_dir"
}

check_source_files
case "${1:-}" in
  translate)
    fresh_translate
    ;;
  prove)
    prove_selected
    ;;
  *)
    printf 'Usage: %s [translate|prove]\n' "$0" >&2
    exit 2
    ;;
esac
