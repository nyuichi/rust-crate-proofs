# Decomposed UTF-8 sequence-law checkpoint

This isolated probe separates ordinary sequence facts from recursive
`flat_map` reasoning. Translation and Why3 type-only checking passed for the
exact seven COMA files listed in `proof-targets.txt`. This checkpoint proves
selected candidate lemmas only; it does not establish source linkage to the
standard-library helper implementations or literal callers.

## Verified candidate obligations

| Target | Direct/alternate split outcomes | Counted Valid |
|---|---|---:|
| `vc_empty_len_T` | 1 direct Valid | 1 |
| `vc_singleton_shape_T` | 3 direct Valid | 3 |
| `vc_concat_right_empty_T` | 4 direct Valid | 4 |
| `vc_flat_map_empty_T` | 2 direct Valid; original third child was Out of memory, then that child proved Valid under `inst_rem flat_map_T_def (empty:seq(t_T)),f` | 3 |
| `vc_flat_map_singleton_guided_T` | 4 Valid under `inst_rem flat_map_T_def (singleton(x):seq(t_T)),f` | 4 |
| **Total** | 15 selected split goals Valid | **15** |

The flat-map-empty total consists of two direct Valid outcomes and one Valid
outcome for the same COMA child under the explicit ground-instantiation
transformation. The original direct attempt remains recorded as `Valid`, `Out
of memory`, `Valid`; the OOM has no counterexample and is not counted as a
Valid result. The `inst_rem` task retains the ground recursive equation while
removing its universal form, so the proof obligation is stronger. The
singleton-guided target is a separate lemma that exposes one recursive
unfolding and consumes the checked sequence-fact contracts.

Exact raw results, input hashes, task exports, and solver provenance are in
`evidence/direct-why3-core-20261005/`,
`evidence/direct-why3-flat-map-empty-inst-rem-20261005/`, and
`evidence/direct-why3-singleton-inst-rem-20261005/`. The dependency ledger
there explains the 15-goal count and preserves the original OOM attempt.

## Open scope

`vc_push_back_tail_nonempty_T` and `vc_concat_associative_T` were translated and
type-checked but not sent to a solver. The sequence and flat-map targets are
local candidate lemmas; they do not prove the separate standard-library
`flat_map_singleton` helper body or establish verbatim linkage to the source
helper. The original source-clone singleton attempt in
`../utf8-seq-laws/evidence/direct-why3-utf8-dependencies-20261005/` returned
Out of memory; its direct result and exact source/COMA identity are retained
as historical evidence.

No push-back bridge, universal character-encoding theorem, string-literal
`Seq::create` model, or exact literal byte caller was proved here. The full
UTF-8/library verification gate remains open.
