# Guided singleton direct Why3 result

The one authorized guided-singleton COMA was exported first, checked for the intended ground instance, then proved with the same transform and no `-o`. No source/compiler/model changes occurred. No push-back, scalar, literal, or universal target ran.

- Selected target: `vc_flat_map_singleton_guided_T`, split into four tasks.
- Result: 4/4 Valid, all with empty counterexample lists and exit status 0.
- Per-task Z3 data: 36,908 steps / 0.018615 s; 36,955 / 0.013010 s; 37,036 / 0.015891 s; 37,041 / 0.012501 s.
- Prover: Z3 4.15.3, fixed 30-second cap, 1000 MiB; wrapper confirmed one concurrent prover and held the shared proof lock.
- The transform was `split_vc` followed by `inst_rem flat_map_T_def (singleton(x):seq(t_T)),f`. Its export-only task hashes and the exact COMA hash are retained in this directory.
- The wrapper exited and released the lock. No active Why3/Z3 process remains.

Raw actual prover output is `proof/all-split-goals/prover-output.jsonl`; stderr and CLI exit status are adjacent. The original source clone is not claimed as verified by this candidate target.
