#![allow(dead_code)]

extern crate creusot_std;

#[cfg(creusot)]
use creusot_std::prelude::{ensures, requires, DeepModel};

mod actual_message {
    use creusot_std::prelude::ensures;

    include!("../../../../src/message.rs");
}

pub use actual_message::Header;

pub mod header_storage;

#[cfg(creusot)]
pub(crate) fn initialized_storage_client<'r, 'h, 'b>(
    headers: &'r mut &'h mut [Header<'b>],
    value: Header<'b>,
) {
    let mut storage = header_storage::HeaderStorage::initialized(headers);
    if storage.capacity() > 0 {
        storage.write(0, value);
    }
    storage.commit_prefix();
}

#[cfg(creusot)]
pub(crate) fn uninitialized_storage_client<'r, 'h, 'b>(
    headers: &'r mut &'h mut [core::mem::MaybeUninit<Header<'b>>],
    value: Header<'b>,
) {
    let mut storage = header_storage::HeaderStorage::uninitialized(headers);
    if storage.capacity() > 0 {
        storage.write(0, value);
    }
    storage.commit_prefix();
}

/// Model a Partial or Error path: write one complete header, then keep the
/// original full binding while exposing the same prefix update and tail frame.
#[cfg(creusot)]
#[requires(headers@.len() > 0)]
#[ensures(result@ == headers@.len())]
#[ensures((^headers)@.len() == headers@.len())]
#[ensures((^headers)@[0].deep_model() == value.deep_model())]
#[ensures(forall<i: creusot_std::prelude::Int> 1 <= i && i < headers@.len()
    ==> (^headers)@[i].deep_model() == headers@[i].deep_model())]
pub(crate) fn non_complete_initialized_client<'b>(
    headers: &mut [Header<'b>],
    value: Header<'b>,
) -> usize {
    let mut binding = &mut *headers;
    {
        let mut storage = header_storage::HeaderStorage::initialized(&mut binding);
        storage.write(0, value);
    }
    binding.len()
}

/// Model a Complete path: publish exactly the initialized prefix and retain
/// the original full parent slice with the unchanged backing tail.
#[cfg(creusot)]
#[requires(headers@.len() > 0)]
#[ensures(result@ == 1)]
#[ensures((^headers)@.len() == headers@.len())]
#[ensures((^headers)@[0].deep_model() == value.deep_model())]
#[ensures(forall<i: creusot_std::prelude::Int> 1 <= i && i < headers@.len()
    ==> (^headers)@[i].deep_model() == headers@[i].deep_model())]
pub(crate) fn complete_initialized_client<'b>(
    headers: &mut [Header<'b>],
    value: Header<'b>,
) -> usize {
    let mut binding = &mut *headers;
    {
        let mut storage = header_storage::HeaderStorage::initialized(&mut binding);
        storage.write(0, value);
        storage.commit_prefix();
    }
    binding.len()
}

/// Model a Partial or Error path for potentially uninitialized storage. Only
/// slot zero is known Some; the remaining tail is framed but unconstrained.
#[cfg(creusot)]
#[requires(headers@.len() > 0)]
#[ensures(result@ == headers@.len())]
#[ensures((^headers)@.len() == headers@.len())]
#[ensures(match ((^headers)@[0])@ {
    None => false,
    Some(header) => header.deep_model() == value.deep_model(),
})]
#[ensures(forall<i: creusot_std::prelude::Int> 1 <= i && i < headers@.len()
    ==> match ((^headers)@[i])@ {
        None => (headers@[i])@ == None,
        Some(header) => match (headers@[i])@ {
            None => false,
            Some(old) => header.deep_model() == old.deep_model(),
        },
    })]
pub(crate) fn non_complete_uninitialized_client<'b>(
    headers: &mut [core::mem::MaybeUninit<Header<'b>>],
    value: Header<'b>,
) -> usize {
    let mut binding = &mut *headers;
    {
        let mut storage = header_storage::HeaderStorage::uninitialized(&mut binding);
        storage.write(0, value);
    }
    binding.len()
}

/// Model the Complete conversion cutpoint: the local binding publishes one
/// initialized header while the original capacity and tail remain available
/// through the parent slice reference.
#[cfg(creusot)]
#[requires(headers@.len() > 0)]
#[ensures(result@ == 1)]
#[ensures((^headers)@.len() == headers@.len())]
#[ensures(match ((^headers)@[0])@ {
    None => false,
    Some(header) => header.deep_model() == value.deep_model(),
})]
#[ensures(forall<i: creusot_std::prelude::Int> 1 <= i && i < headers@.len()
    ==> match ((^headers)@[i])@ {
        None => (headers@[i])@ == None,
        Some(header) => match (headers@[i])@ {
            None => false,
            Some(old) => header.deep_model() == old.deep_model(),
        },
    })]
pub(crate) fn complete_uninitialized_client<'b>(
    headers: &mut [core::mem::MaybeUninit<Header<'b>>],
    value: Header<'b>,
) -> usize {
    let mut binding = &mut *headers;
    {
        let mut storage = header_storage::HeaderStorage::uninitialized(&mut binding);
        storage.write(0, value);
        storage.commit_prefix();
    }
    binding.len()
}

// A separate translation-only probe checks whether implicit scope-exit and
// early-return drops appear in the caller's generated verification body.
#[cfg(creusot)]
struct DropMarker<'a> {
    target: &'a mut usize,
}

#[cfg(creusot)]
impl Drop for DropMarker<'_> {
    fn drop(&mut self) {
        *self.target = 7;
    }
}

#[cfg(creusot)]
#[ensures((^target)@ == 7)]
pub(crate) fn implicit_drop_caller(target: &mut usize, early: bool) {
    let _marker = DropMarker { target };
    if early {
        return;
    }
}

// Kept out of the positive storage translation. This feature isolates the
// current string-literal model blocker from the actual Header storage goals.
#[cfg(feature = "header-string-ice")]
#[ensures(result.name@ == ""@)]
pub fn empty_header_name_model() -> Header<'static> {
    actual_message::EMPTY_HEADER
}
