# HeaderStorage integration plan

This is a design note only. It does not edit production source or establish a
parser proof. The production body review is pinned to
`httparse/1.10.1/src/lib.rs` SHA-256
`60be3d56fc440a1b76c39fb11d5e367e4d3e67a6c26d5f3f645e742143ee60a2` and
`src/config.rs` SHA-256
`bdf99e033ccbd58bfe115fa99f346d722a667cabb430a46ee08a2942e3e6dd7a`.
Refresh this inventory if the parser bodies change before integration.

## Existing call paths and mutable state

`ParserConfig::parse_request_with_uninit_headers` and its response counterpart
delegate directly to each message's
`parse_with_config_and_uninit_headers` (`src/lib.rs:95-122`). The corresponding
private methods parse the start line, then call `parse_headers_iter_uninit`
with request-specific or response-specific `HeaderParserConfig` values
(`src/lib.rs:128-164,272-333`). They assign `self.headers` only after the
header parser returns `Complete` and then call `assume_init_slice`.

The initialized APIs follow a separate wrapper path. Request and Response
`parse_with_config` first `mem::take` their `self.headers`, cast its wide
pointer from `[Header]` to `[MaybeUninit<Header>]`, and delegate to the
uninitialized method (`src/lib.rs:178-194,253-269`). On `Complete`, the inner
method installs the shortened initialized prefix. On `Partial` or `Error`,
the outer wrapper restores the original full-length `[Header]` slice. Header
slot writes made before that status remain in the caller's backing storage.

Standalone `parse_headers` calls `parse_headers_iter` and returns its local
`dst` only on `Complete` (`src/lib.rs:498-519`). `parse_headers_iter` currently
reinterprets that initialized slice binding with `deinit_slice_mut` and calls
the same uninitialized helper. The cast helpers are at `src/lib.rs:521-529`.
`parse_headers_iter_uninit` is the shared scanning loop
(`src/lib.rs:549-786`); its only current callers are the Request and Response
uninitialized methods and `parse_headers_iter`.

The exact current `ShrinkOnDrop` is local to that scanning helper
(`src/lib.rs:559-573`). It counts writes and shortens its local
`&mut [MaybeUninit<Header>]` binding on every exit, including `Complete`,
`Partial`, parser `Error`, and `TooManyHeaders`. `parse_headers_iter` exposes
that shortened binding to `parse_headers` only on `Complete`. Request and
Response uninitialized methods likewise use it for `assume_init_slice` only on
`Complete`; their `complete!` early return skips the field assignment on
`Partial` or `Error`. For the initialized wrappers, the outer method restores
its separate original wide pointer on non-Complete results. The helper's
non-Complete local binding length is therefore not returned by any current
public API, but its already-written slots are observable through the backing
buffer.

The `complete!` macro propagates `Error` and returns `Partial` immediately;
`next!` also returns `Partial` when the input ends (`src/macros.rs:3-30`).
There is no rollback of header slots or message fields on either path.

## Public behavior to preserve

The message fields are updated incrementally and are not cleared on entry.
Fields not reached during a later parse keep any older values; fields already
assigned remain updated if the parse subsequently returns `Partial` or
`Error`.

The exact assignment cutpoints are significant. Request stores `method` only
after `parse_method` completes, `path` only after `parse_uri` completes, and
`version` only after `parse_version` completes; a later delimiter or header
failure does not roll those writes back. Response similarly stores `version`
after version parsing and `code` after code parsing. It stores `reason` only
after a reason phrase completes, or stores `Some("")` after the newline-only
status form. Thus an incomplete or invalid reason phrase leaves any previous
`reason` value intact even though `version` and `code` may already be updated.
These cutpoints are present in the current bodies at `src/lib.rs:137-147` and
`src/lib.rs:281-316`.

| Entry point | `Complete` | `Partial` or `Error` |
| --- | --- | --- |
| Request initialized parse (`parse`, configured `parse_request`) | `method`, `path`, and `version` are set as the request line succeeds. `self.headers` points to the parsed initialized prefix; its length is the number of written headers. The returned offset is request-line bytes plus header-block bytes. | Successfully parsed request-line fields remain updated; unreached fields retain their previous values. The full original `self.headers` binding is restored. Every complete header written before the exit remains in its slot; the untouched tail keeps its previous initialized values. No cursor/offset is returned. |
| Request uninitialized parse (`parse_with_uninit_headers`, configured uninitialized entry) | Request-line fields are set as above. `self.headers` is assigned the converted initialized prefix only after the header block completes. The returned offset is the same sum. | Request-line fields reached before the exit remain updated. `self.headers` stays as it was before the call. The caller's `MaybeUninit` backing receives each fully parsed header prefix write; the rest of the tail remains unconstrained. No cursor/offset is returned. The parameter slice binding is a local function value and its prior Drop shrink is not visible to the caller. |
| Response initialized parse (`parse`, configured `parse_response`) | `version`, `code`, and `reason` are assigned at their existing parsing cutpoints. `self.headers` becomes the parsed initialized prefix. The returned offset is status-line bytes plus header-block bytes. | Reached response fields remain updated; not-yet-reached fields retain prior values. The full original `self.headers` binding is restored. Complete header writes remain in the prefix; the untouched tail keeps prior initialized values. No cursor/offset is returned. |
| Response uninitialized parse (configured uninitialized entry) | `version`, `code`, and `reason` are assigned at their existing cutpoints. On header-block completion, `self.headers` becomes the converted initialized prefix. The returned offset is the same sum. | Reached fields remain updated; not-yet-reached fields retain prior values. `self.headers` stays unchanged. Completed header writes remain in the caller's `MaybeUninit` backing and its tail remains unconstrained. No cursor/offset is returned. The parameter slice binding is local. |
| `parse_headers(src, dst)` | Returns `Complete((pos, prefix))`, where `prefix` is the written initialized header prefix and `pos` ends after the terminating blank line. | Returns only `Partial` or `Error`; it returns no header slice and no cursor. Writes of complete headers before the exit remain in the caller's backing array. The old Drop-shortened `dst` binding is local and is not returned on these paths. |

The header scanner writes a slot only after it has parsed a complete header
name and value line. It calls `iter.next()` after that parsing and before
trailing-value trimming (`src/lib.rs:760-776`); the `None` branch breaks with
the initial `Err(Error::TooManyHeaders)`. Thus capacity failure occurs after
the candidate line has been consumed but before a slot is written. An
incomplete candidate returns `Partial` before the capacity check. Ignored
invalid lines consume input but do not use a slot. The replacement must retain
this ordering, write each completed header at exactly `used_len`, and advance
the initialized prefix only after the write. The blank-line terminator is
recognized before the capacity check, so a buffer exactly full of headers
still completes when no additional header follows.

`Bytes` is local to each request, response, or standalone header call. Its
cursor changes on `Partial` and `Error`, but no cursor is stored in the public
message values and no offset is returned on those statuses. On `Complete`, the
existing calculations must remain unchanged: request and response save the
start-line length before parsing headers, then add the header-block length;
`parse_headers_iter_uninit` reports bytes through the terminating empty line.

`ParserConfig` is borrowed immutably and never changed. Preserve this mapping
(`src/config.rs:8-16`; call sites at `src/lib.rs:139-158,284-329`):

| Parser | Configuration passed to the header loop |
| --- | --- |
| Request | `allow_space_before_first_header_name`; `ignore_invalid_headers_in_requests`; `allow_spaces_after_header_name = false`; `allow_obsolete_multiline_headers = false`. The request-line multiple-space flag controls the two existing `skip_spaces` cutpoints before URI and version. |
| Response | `allow_spaces_after_header_name_in_responses`; `allow_obsolete_multiline_headers_in_responses`; `allow_space_before_first_header_name`; `ignore_invalid_headers_in_responses`. The response-status multiple-space flag controls the existing `skip_spaces` cutpoint after the status delimiter. |
| Standalone `parse_headers` | `HeaderParserConfig::default()`: all four header flags are false. |

The complementary request/response-only flags are ignored by the other parser,
as today. All seven `ParserConfig` values remain unchanged across every result.

## Small shared-source refactor after adapter closure

First finish the selected `HeaderStorage` proof closure and representative
callers. Until then, keep the following as a plan, not production code:

1. Extract only the common header-scanning loop into a private
   `parse_headers_iter_with_storage(&mut HeaderStorage, &mut Bytes,
   &HeaderParserConfig) -> Result<usize>`. Keep parsing rules, labels, error
   branches, cursor operations, and trim order intact. Replace the slice
   iterator with `index = storage.used_len()`. At the same location as the
   current `iter.next()` capacity check—after the complete candidate value
   line, before trailing-value trimming—test whether `index == capacity`; if
   so, leave the initial `Err(Error::TooManyHeaders)` result unchanged and
   exit the loop. Otherwise trim and call
   `storage.write(index, Header { name, value })`. This preserves the
   `index == used_len < capacity` proof boundary and the old failure timing.
2. Keep Request and Response start-line parsing separate, but factor each
   existing body through a private `parse_*_with_storage(...,
   &mut HeaderStorage)` core that performs its current field updates and calls
   the common header scanner. The core returns the same `Result<usize>` and
   does not publish or convert `self.headers`; preserve each field assignment
   at its current source location.
3. The initialized Request and Response wrappers can construct
   `HeaderStorage::Initialized` around the full slice moved out by
   `mem::take`, call the appropriate core, and call `commit_prefix` only when
   the result is `Complete`. After the adapter borrow ends, put its binding
   back into `self.headers` on every result. That yields the parsed prefix on
   `Complete` and restores the full binding on `Partial`/`Error`, while
   retaining completed slot writes. It removes their `[Header]` to
   `[MaybeUninit<Header>]` cast.
4. The explicit uninitialized wrappers can construct
   `HeaderStorage::Uninitialized` around their local slice binding and call
   the same per-message core. On `Complete`, call `commit_prefix`, convert
   only that initialized prefix, and assign `self.headers` at the existing
   completion cutpoint. On `Partial` or `Error`, do not commit or convert, and
   leave the existing message header field unchanged. Keep the `MaybeUninit`
   tail unconstrained.
5. Make `parse_headers_iter` use the initialized storage variant and retain
   `parse_headers`'s `Complete((pos, prefix))` result. On non-Complete results,
   no public header-slice result exists, so preserving backing slot writes
   while leaving the local binding full matches public behavior. Remove
   `deinit_slice_mut` and `ShrinkOnDrop` only after all three caller families
   use explicit Complete-only finalization.

`HeaderStorage` is specialized to `Header`; do not add a generic cast or a
`T: Copy` requirement to justify it. Its initialized variant keeps the complete
backing slice valid, and its uninitialized variant models only the written
prefix as initialized. No pointer-identity contract or new unsafe axiom is
needed for this plan.

## Remaining verification boundary

The current Creusot translation of an implicit `Drop` call records
`resolve_DropMarker` at the caller but does not establish the body effects of
`ShrinkOnDrop::drop`. Therefore the existing all-exit guard cannot be counted
as a proved caller effect. The refactor above replaces that dependence with
explicit `commit_prefix` calls on `Complete` and preserved full bindings on
`Partial` and `Error`.

Uninitialized-to-initialized conversion remains open. The current private
`assume_init_slice` is a wide-pointer cast (`src/lib.rs:526-529`), and the
Creusot stdlib does not yet provide a checked `slice_assume_init_mut` contract
that supplies the required slice permission bridge. Before wiring the public
uninitialized APIs, audit and model the pinned standard-library conversion for
the exact all-prefix-elements-initialized precondition and returned slice
metadata. Do not infer that contract from the probe's `Option` model or add a
crate-local trusted assumption.

The probe storage closure also remains open until its selected method and
caller VCs pass. Even after that closure, this note does not claim proofs of
the parser algorithms, the standard conversion TCB, or complete integrated
Request/Response behavior.
