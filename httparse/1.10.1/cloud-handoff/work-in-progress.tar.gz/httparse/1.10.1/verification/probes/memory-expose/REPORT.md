# Exposed provenance candidate

This scratch crate tests the proposed numeric contract independently of the
whole `httparse` module. It does not establish a contract for the standard
library or prove `Bytes::pos`.

## Translation

Command, run from this directory after sourcing
`/workspace/proof-tools/activate.sh`:

```sh
CARGO_NET_OFFLINE=true cargo creusot --no-check-version
```

Translation and the isolated caller proof succeed. The generated CoMa for
`pointer_distance` contains:

- the precondition `addr_logic(start) <= addr_logic(cursor)`;
- calls to the proposed `expose_provenance` spec for both pointers;
- the postcondition `result == addr_logic(cursor) - addr_logic(start)`.

The precondition is satisfiable (for example, equal pointers meet it), and the
postcondition specifies the exact numeric difference rather than `true`. This
is not a vacuous contract. With the adjacent one-prover configuration, the
target-scoped command

```sh
../../../../../tools/creusot-toolpatch/scripts/run-proof.sh cargo creusot --no-check-version --simple-triggers=false prove pointer_distance --why3session --no-cache -- --offline
```

could not start because that script requires the itoa-specific patched
`creusot-rustc`, which is not installed in this environment. The root-approved
fallback ran the same proof directly while holding
`/tmp/itoa-creusot-proof.lock`, outside the sandbox, using the activated Why3
configuration (one prover, 1000 MiB per prover):

```sh
CARGO_NET_OFFLINE=true cargo creusot --no-check-version --simple-triggers=false prove pointer_distance --why3session --no-cache -- --offline
```

Result: `Theory verif.httparse_memory_expose_probe_rlib.pointer_distance.Coma:
✔ (2)`. This proves the candidate caller against the local extern contract; it
does not prove that standard-library contract or integrate it into `httparse`.

## Scope and trust

The candidate `extern_spec!` says only that `expose_provenance()` returns the
pointer's numeric address. It does not model the Rust exposed-provenance set,
create `Perm` or `PtrLive` permissions, or justify a later integer-to-pointer
cast. It could support the numeric arithmetic in `Bytes::pos`/`len`; raw reads,
slice creation, lifetime, and aliasing still need their own pointer-permission
proofs. Review and integration into `creusot-libs` remain open.
