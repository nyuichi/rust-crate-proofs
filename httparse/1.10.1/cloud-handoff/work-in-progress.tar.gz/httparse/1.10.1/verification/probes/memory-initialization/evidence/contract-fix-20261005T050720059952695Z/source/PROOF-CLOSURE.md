# Selected typed-storage proof closure

The proposed selected closure is the exact ten-target list in
[`SELECTED-PROOF-TARGETS.txt`](SELECTED-PROOF-TARGETS.txt). The run order starts
with the initialized constructor and its non-Complete client to check mutable
binding linkage, then proves the uninitialized constructor, both accessors,
`write`, `commit_prefix`, and the remaining three representative clients.
`implicit_drop_caller` and the standalone `Drop::drop` body are translation-only
diagnostics and never enter this positive target list.

COMA static inspection shows that the logic definitions `HeaderStorage::view`,
`HeaderStorage::future_slots`, `HeaderStorage::inner_future_slots`, and `HeaderStorageView::{slots, used_len,
is_initialized, initialized_prefix, fully_initialized}` are embedded in the
selected method/client COMA files. `initialized_prefix` indexes slots only
under the explicit prefix bound. Translation emitted no separate logic-view
or Wf `.coma` target. `verify-selected.sh`
checks the exact complete generated target inventory against
[`TRANSLATION-TARGETS.txt`](TRANSLATION-TARGETS.txt), so a newly emitted target
(including a future Wf target) stops the run for review instead of silently
expanding the proof set. Add any reviewed new target by its exact path to the
inventory and, if it belongs in the positive closure, to the selected list.

`HeaderStorage::view` is explicitly open so callers can unfold the typed enum
model. The two prophetic projections distinguish the future local slice
binding (`future_slots`) from the future contents of the inner slice borrow
(`inner_future_slots`). Constructors link both projections to their source
borrow without equating current and future slice lengths; `write` preserves
both; `commit_prefix` preserves the outer future binding and states the inner
published-prefix/tail lens laws.

The VC context includes the existing Creusot sequence/map and
`MaybeUninit<T>::View` models emitted in COMA. These remain standard-library
model/axiom dependencies. The selected targets are intended to check the
adapter bodies and callers against them; they do not prove a generic layout
cast, a pointer identity relation, `ShrinkOnDrop` caller effects, or production
parser integration.

Every selected target was freshly translated once before the prior solver
checkpoint. The initialized constructor passed, while the following
non-Complete initialized caller timed out on its caller ensures after the
`write` precondition passed. That prior source version lacked the open view and
two-prophecy contracts now present in the adapter. Its result is recorded in
`evidence/selected-solver-run-20261005T044741856965836Z/RUN.md` and does not
apply to this refreshed source. The refreshed source was translated again
before a newly authorized solver run. Its first selected target, the
initialized constructor, returned `Unknown` on its combined ensures goal; the
runner stopped before the remaining nine targets. The exact attempt is archived
in `evidence/selected-solver-run-20261005T045937024964262Z/`. This revision has
no proved storage closure.

The runner creates a fresh translation before every `prove` invocation, checks
the generated target inventory, and then proves one COMA target at a time with
direct Why3 (`Z3 4.15.3`, 30 seconds per goal, one active prover, 1000 MiB).
It stops on the first non-Valid result and preserves exact logs plus source,
configuration, and COMA hashes under a per-run evidence directory.

The latest read-only COMA diagnosis found the extra constructor condition
`inner_future_slots().len() == slots().len()` unsupported by the borrow model:
the typed borrow prophecy links to an arbitrary future inner slice, and no
premise equates its length with the current slice. The probe removes this
condition from both constructors while retaining their structural prophecy
links. The `commit_prefix` precondition for matching lengths is also removed;
its body obtains the old length from `split_at_mut`, preserves the outer future
binding, and specifies that the new inner future is the published prefix while
the old tail matches the current backing tail. The existing `Unknown` result
is inconclusive and is not claimed as proof of the diagnosis. The corrected
source freshly translated with the exact 18-target inventory and is archived
under `evidence/contract-fix-20261005T050720059952695Z/`; no solver ran on
this revision. No current storage closure is proved.
