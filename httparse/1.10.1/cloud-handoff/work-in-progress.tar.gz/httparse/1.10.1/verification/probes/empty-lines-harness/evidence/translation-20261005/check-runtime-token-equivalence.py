#!/usr/bin/env python3
"""Compare the runtime body in lib.rs with the extracted helper body."""

from pathlib import Path
import hashlib
import re
import sys


def function_body(source: str) -> str:
    start = source.index("fn skip_empty_lines(")
    opening = source.index("{", start)
    depth = 0
    quote = None
    escaped = False
    line_comment = False
    block_comment = 0
    for i in range(opening, len(source)):
        char = source[i]
        following = source[i + 1] if i + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            continue
        if block_comment:
            if char == "/" and following == "*":
                block_comment += 1
            elif char == "*" and following == "/":
                block_comment -= 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char == "/" and following == "/":
            line_comment = True
            continue
        if char == "/" and following == "*":
            block_comment = 1
            continue
        if char in ('"', "'"):
            quote = char
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[opening : i + 1]
    raise ValueError("unclosed skip_empty_lines function")


def balanced_end(source: str, opening: int, left: str, right: str) -> int:
    depth = 0
    quote = None
    escaped = False
    for i in range(opening, len(source)):
        char = source[i]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in ('"', "'"):
            quote = char
        elif char == left:
            depth += 1
        elif char == right:
            depth -= 1
            if depth == 0:
                return i + 1
    raise ValueError("unbalanced runtime instrumentation")


def strip_creusot_instrumentation(source: str) -> str:
    while True:
        marker = re.search(r"#\[cfg\(creusot\)\]", source)
        if marker is None:
            break
        i = marker.end()
        while source[i].isspace():
            i += 1
        if source.startswith("ghost!", i):
            end = balanced_end(source, source.index("{", i), "{", "}")
            while end < len(source) and source[end].isspace():
                end += 1
            if end < len(source) and source[end] == ";":
                end += 1
        elif source.startswith("let ", i):
            end = i
            parens = brackets = braces = 0
            quote = None
            escaped = False
            while end < len(source):
                char = source[end]
                if quote:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == quote:
                        quote = None
                elif char in ('"', "'"):
                    quote = char
                elif char == "(":
                    parens += 1
                elif char == ")":
                    parens -= 1
                elif char == "[":
                    brackets += 1
                elif char == "]":
                    brackets -= 1
                elif char == "{":
                    braces += 1
                elif char == "}":
                    braces -= 1
                elif char == ";" and parens == brackets == braces == 0:
                    end += 1
                    break
                end += 1
        else:
            raise ValueError("unexpected cfg(creusot) item")
        source = source[: marker.start()] + source[end:]

    for attribute in ("invariant", "variant"):
        marker = "#[" + attribute + "("
        while marker in source:
            start = source.index(marker)
            i = start + 2
            parens = 0
            quote = None
            escaped = False
            while i < len(source):
                char = source[i]
                if quote:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == quote:
                        quote = None
                elif char in ('"', "'"):
                    quote = char
                elif char == "(":
                    parens += 1
                elif char == ")":
                    parens -= 1
                elif char == "]" and parens == 0:
                    i += 1
                    break
                i += 1
            source = source[:start] + source[i:]

    return re.sub(r"//[^\n]*", "", source)


TOKEN = re.compile(
    r"(?:b)?'(?:\\.|[^'\\])*'|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|"
    r"=>|::|->|==|!=|<=|>=|&&|\|\||\.\.|[^\s]"
)


def tokens(source: str) -> list[str]:
    return TOKEN.findall(strip_creusot_instrumentation(function_body(source)))


production = Path(sys.argv[1]).read_text()
extracted = Path(sys.argv[2]).read_text()
production_tokens = tokens(production)
extracted_tokens = tokens(extracted)
if production_tokens != extracted_tokens:
    limit = min(len(production_tokens), len(extracted_tokens))
    mismatch = next(
        (i for i in range(limit) if production_tokens[i] != extracted_tokens[i]),
        limit,
    )
    print(f"runtime token mismatch at {mismatch}", file=sys.stderr)
    raise SystemExit(1)

payload = "\n".join(production_tokens).encode()
print("runtime function bodies equal after removing Creusot-only contracts/ghost items")
print(f"runtime token count: {len(production_tokens)}")
print(f"normalized token SHA-256: {hashlib.sha256(payload).hexdigest()}")
