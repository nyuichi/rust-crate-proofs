Execution order: initialized constructor, non-Complete initialized client, uninitialized constructor, capacity, used_len, write, commit_prefix, then three remaining clients.

## Outcome

Fresh translation passed and matched all 18 paths in
`TRANSLATION-TARGETS.txt`. Two selected positive targets were attempted in
order under the shared `run-proof.bash` lock, using Why3 1.8.2, Z3 4.15.3,
`running_provers_max = 1`, `memlimit = 1000`, and a 30-second per-goal cap.

1. `header_storage/impl_HeaderStorage/initialized.coma` passed its constructor
   ensures goal: `Valid (0.02s, 42131 steps)`.
2. `non_complete_initialized_client.coma` proved the `write` requires goal:
   `Valid (0.02s, 47882 steps)`. Its caller ensures goal timed out after 30.00s
   and 565536238 steps. The runner stopped immediately; no later target ran.

The timeout is a meaningful inconclusive client result, not an infrastructure
failure. The early smoke therefore does not establish that the binding and
tail contract is usable within this budget. The adapter's complete proof
closure remains open. The raw stdout and command provenance are in
`logs/01-initialized.log` and `logs/02-non_complete_initialized_client.log`.
