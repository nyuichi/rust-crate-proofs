#![allow(dead_code)]

use creusot_std::prelude::{ensures, logic};

#[logic]
#[ensures(result)]
pub fn false_bool() -> bool {
    false
}
