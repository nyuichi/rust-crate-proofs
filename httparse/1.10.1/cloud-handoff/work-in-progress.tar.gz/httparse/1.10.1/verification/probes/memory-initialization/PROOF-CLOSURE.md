# Selected typed-storage proof closure

The reviewed positive set is the exact 11-target list in
[`SELECTED-PROOF-TARGETS.txt`](SELECTED-PROOF-TARGETS.txt): initialized,
uninitialized, capacity, used_len, write, the private generic
`retain_prefix`, commit_prefix, then the four representative initialized and
uninitialized clients. The generic helper runs before commit_prefix so the
branch bodies can consume its raw-slice contract. The complete translation
inventory is fixed by [`TRANSLATION-TARGETS.txt`](TRANSLATION-TARGETS.txt).
`implicit_drop_caller` and the standalone `Drop::drop` body remain
translation-only diagnostics and are excluded from the positive set.

`HeaderStorage::view` remains open. Its four nested-reference views are
current/current (`view`), future/current (`future_slots`), current/future
(`inner_future_slots`), and future/future (`final_binding_slots`). Constructors
link the three prophetic projections to their source borrow. `write` preserves
all three. `commit_prefix` preserves the outer future binding and the final
backing prophecy, with the existing published-prefix and tail-frame clauses.
No arbitrary inner-future length equality is assumed.

`retain_prefix<'h, T>(&mut &'h mut [T], used)` keeps future observations in its
contracts and has no snapshot, custom `Fin`, unsafe cast, or trusted body. Its
precondition is `used@ <= binding@.len()`. Its postconditions relate the
shortened current outer binding to the old prefix, preserve the future inner
slice length, set the final outer-plus-inner slice length to `used`, equate
that final slice with the old future-inner prefix, and frame the old tail.
Its executable body is the same `mem::take`, `split_at_mut`, and prefix
assignment used by the two typed `commit_prefix` branches. The helper uses the
existing `split_at_mut` contract; it adds no standard-library trust.

The VC context still includes Creusot's sequence/map and
`MaybeUninit<T>::View` models. The selected closure does not prove a generic
layout cast, pointer identity, `ShrinkOnDrop` caller effects, or production
parser integration.

## Frozen proof history

The four-corner source at SHA-256
`f057994e473e68ea2292a19d24dc5ddd0c894e5d207abc8800f8d304ff817094` was
freshly translated to 18 COMA files. Its selected run passed the two
constructors, capacity, used_len, and write (24 Valid leaves). commit_prefix
produced seven Valid leaves and one `Unknown` on the uninitialized branch's
combined ensures goal at COMA lines 501--519. No representative client ran.
That input, exact solver logs, and the three-way final prophecy are frozen in
`evidence/selected-solver-run-4corners-20261005T061730Z/`; these results do
not apply to the generic-helper revision.

An attempted body snapshot cutpoint for the outer final reference did not
translate. The failing syntax and exact compiler diagnostics are preserved in
`evidence/fourcorner-frame-translation-20261005T062736Z/` and
`evidence/fourcorner-frame-translation-fixed-20261005T062819Z/`. No solver ran
on those attempts. The successful four-corner translation remains archived in
`evidence/fourth-projection-translation-20261005T060956Z/`.

The current 11-target set is a new, unproved closure. Refresh and inspect its
exact 19-file generated inventory before solver use. Run direct Why3 targets
with `run-proof.bash`, one prover, 1000 MiB, Z3 4.15.3, and a 30-second
per-goal limit. Stop on the first non-Valid result. Only the exact current
source and COMA hashes from a fresh run count toward this revision.
