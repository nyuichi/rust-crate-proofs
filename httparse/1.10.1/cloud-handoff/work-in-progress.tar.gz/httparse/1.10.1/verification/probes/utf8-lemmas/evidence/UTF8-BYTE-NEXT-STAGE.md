# Next-stage UTF-8 numeric helper proof plan

This is source preparation only. The candidate file
`utf8-byte-body-candidate.rs` is not part of the seven-target probe, has not
been translated, and has no solver result.

## Candidate body obligation

`checked_utf8_byte_body` mirrors the recursive `utf8_byte` implementation in
the pinned isolated `creusot-std/src/std/char.rs`. Its precondition is
`0 <= value <= 255`; its postcondition is `result@ == value`; and its variant is
`value`. The pinned source hash is recorded in
`evidence/TRANSLATION-SHA256SUMS` (SHA-256
`5d6108fd738ae1e3e84afcbff384ba7fb9a0cd9cfe0b16f7d8afb16e27d8ddb2`). The
inductive body has three obligations:

1. At zero, the `u8` view of `0u8` equals zero.
2. At a positive value, `value - 1` remains in `[0, 255]`, so the recursive
   call's checked postcondition gives `previous@ == value - 1`.
3. That value is below 255, making the exact `u8` increment safe and proving
   the returned view equals `value`.

The candidate does not call the imported `utf8_byte`; doing so would consume
the same postcondition whose body needs verification. Translation review must
confirm that the candidate's recursive definition and its postcondition VC are
both emitted, and that the VC does not assume the standard `utf8_byte_spec`.
If the generated target is opaque or circular, stop and revise the isolated
standard source instead of treating the candidate contract as evidence.

## Linkage and following targets

The candidate is a source clone, so proving it alone does not prove the
separately compiled standard-library symbol. Before closing that dependency,
either compile a body-check directly against the exact isolated standard
source, or add an explicit, body-checked equivalence that unfolds both exact
definitions. Preserve the pinned `char.rs` source hash and review a textual
body match. Do not use `utf8_byte_spec` as an antecedent to prove itself.

After this numeric contract is body-checked and linked, prepare one universal
`to_utf8` character target. It should split the actual open `CharExt::to_utf8`
definition at `0x80`, `0x800`, and `0x10000`, use the existing `Char` scalar
range and surrogate exclusion, prove each branch's output length and byte
range, then prove each quotient/remainder byte. Do not add an encoding axiom or
assume any literal `Seq::create` goal. The singleton/push-back contracts and
the literal sequence model need their own proved dependencies before literal
byte callers are attempted.

The current 35 scalar goals and 15 decomposed sequence-law goals remain the
only UTF-8 proof counts. They depend on the imported numeric/length contracts
and local candidate helper contracts exactly as recorded in their reports.
