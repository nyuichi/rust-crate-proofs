use creusot_std::prelude::*;

pub fn pointer_index(ptr: *const u8, origin: *const u8) -> Ghost<Int> {
    ghost!({
        snapshot!(ptr.sub_logic(origin)).into_ghost().into_inner()
    })
}
