# Selected typed-storage proof closure

The selected closure is the exact ten-target list in
[`SELECTED-PROOF-TARGETS.txt`](SELECTED-PROOF-TARGETS.txt). The run order starts
with the initialized constructor and its non-Complete client to check mutable
binding linkage, then proves the uninitialized constructor, both accessors,
`write`, `commit_prefix`, and the remaining three representative clients.
`implicit_drop_caller` and the standalone `Drop::drop` body are translation-only
diagnostics and never enter this positive target list.

COMA static inspection shows that the logic definitions `HeaderStorage::view`,
`HeaderStorage::future_slots`, and `HeaderStorageView::{slots, used_len,
is_initialized, initialized_prefix, fully_initialized}` are embedded in the
selected method/client COMA files. Translation emitted no separate logic-view
or Wf `.coma` target; the bodies have no partial indexing. `verify-selected.sh`
checks the exact complete generated target inventory against
[`TRANSLATION-TARGETS.txt`](TRANSLATION-TARGETS.txt), so a newly emitted target
(including a future Wf target) stops the run for review instead of silently
expanding the proof set. Add any reviewed new target by its exact path to the
inventory and, if it belongs in the positive closure, to the selected list.

The VC context includes the existing Creusot sequence/map and
`MaybeUninit<T>::View` models emitted in COMA. These remain standard-library
model/axiom dependencies; this batch proves the adapter bodies and callers
against them. It does not prove a generic layout cast, a pointer identity
relation, `ShrinkOnDrop` caller effects, or production parser integration.

The runner creates a fresh translation before every `prove` invocation, checks
the generated target inventory, and then proves one COMA target at a time with
direct Why3 (`Z3 4.15.3`, 30 seconds per goal, one active prover, 1000 MiB).
It stops on the first non-Valid result and preserves exact logs plus source,
configuration, and COMA hashes under a per-run evidence directory.
