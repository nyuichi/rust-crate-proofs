# `skip_empty_lines` proof checkpoint

**Status: the current 20-target proof-only model candidate translates and passes Why3 `--type-only`; no solver was invoked. No proof result is claimed.** The extracted helper remains unwired in production `lib.rs`.

## Runtime and model boundary

The isolated harness uses the actual `src/iter.rs`, `src/macros.rs`, `src/status.rs`, `src/error.rs`, and extracted `src/skip_empty_lines.rs`, plus the independent `src/verification/empty_lines.rs` model. The production and extracted runtime bodies have equal token streams after removing only Creusot contracts, loop facts, and ghost statements. The reproducible comparison in [`check-runtime-token-equivalence.py`](evidence/translation-20261005/check-runtime-token-equivalence.py) has 104 matching runtime tokens and SHA-256 `cc731c7e0eeb496982e24cd47b3e563091f7a49afbbf00ed0c7b07947bdc8296`.

The exact model preserves the helper's cursor and commit behavior:

- Repeated LF and CRLF endings are consumed. At the first other byte, `slice()` commits the cursor there and leaves that byte unconsumed.
- Exhaustion after complete endings returns partial at `end` and retains the entry mark.
- A final CR is consumed before `next()` observes EOF; that path returns partial at `end` and retains the entry mark.
- After CR, `next()` consumes one following byte. LF completes a CRLF ending; any other byte is consumed before `Error::NewLine` returns, with the entry mark retained.

The parser model records the unchanged input, entry mark, end, cursor bounds, complete LF/CRLF prefix, maximal endpoint relation, and decreasing `end - cursor` measure.

## Earlier bounded solver attempt

The frozen run is at [`direct-why3-20261005T062922467607808Z/`](evidence/direct-why3-20261005T062922467607808Z/). It produced 69 Valid split leaves across 12 target files, one exact `TrivialTrueNoTask` target, and then a fixed 30-second timeout at `complete_line_prefix_extend_crlf`. The timeout CoMa and raw log are preserved in that run and under [`induction-prep-20261005T063957Z/archive/`](evidence/induction-prep-20261005T063957Z/archive/). The timeout has not been retried.

## Prior 19-target candidate

[`induction-prep-20261005T063957Z/`](evidence/induction-prep-20261005T063957Z/) records the concatenation induction candidate. Its 19 selected targets passed Why3 `--type-only` in [`type-only-20261005T071146Z/`](evidence/induction-prep-20261005T063957Z/type-only-20261005T071146Z/), with no solver invocation. The Int-return concatenation helper returns `mid` and states both `result == mid` and the joined complete-prefix predicate. Its LF and CRLF wrappers supply finite one-byte and two-byte suffixes.

The first bool-return form is preserved under `rejected-bool-candidate/`. It does emit a body goal with its recursive body and ensures; it was not missing a body VC or relying only on axiomatized postconditions. The Int-return form was selected because its result directly supplies `result == mid`. Neither version was solver-run.

## Current cursor-prefix induction candidate

[`cursor-induction-prep-20261005T071604Z/`](evidence/cursor-induction-prep-20261005T071604Z/) contains the current fresh translation, 20-target closure, exact inputs, and type-only run. This adds `complete_line_prefix_cursor_induction`, a recursive helper with variant `cursor - start`, to derive the loop cursor's relation to the maximal endpoint by stepping through LF and CRLF prefixes. `complete_line_prefix_at_cursor` invokes that helper through a proof assertion.

To expose the endpoint equality needed at each induction step, `complete_line_prefix_end` has a stronger recursive postcondition for its stop, LF, and CRLF cases. Its body has a corresponding verification goal. The 20 selected CoMas all passed Why3 `--type-only` in [`type-only-20261005T071837Z/`](evidence/cursor-induction-prep-20261005T071604Z/type-only-20261005T071837Z/); pre- and post-run CoMa hashes match, and `solver_invocations=0`. Translation emitted 64 CoMa files. The selected closure has 10 `Bytes`/`Iterator` dependencies, 9 model targets, and the extracted parser last.

Type-only checks establish that Why3 accepts the selected CoMa syntax and symbols. The strengthened endpoint goal, induction helper, wrappers, cursor bridge, model, and parser still need solver verification under the separately controlled bounded-proof run. The production parser remains unwired.

## Reproduction

From `httparse/1.10.1`, run `./verification/probes/empty-lines-harness/translate.sh translate` to regenerate the isolated translation. The current translation inputs, source hashes, raw build log, full CoMa snapshot, selected closure, and exact type-only run are preserved in `evidence/cursor-induction-prep-20261005T071604Z/`.
