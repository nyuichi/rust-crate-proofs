#![cfg_attr(not(feature = "std"), no_std)]

use creusot_std::logic::Mapping;
use creusot_std::prelude::*;

// Local copies of the two pinned standard helper laws. Their source-clone
// correspondence is tracked by the sibling utf8-seq-laws probe.
#[logic(open)]
#[ensures(Seq::singleton(x).flat_map(f) == f.get(x))]
pub fn checked_std_flat_map_singleton<T, U>(x: T, f: Mapping<T, Seq<U>>) {}

#[logic(open)]
#[ensures(s.push_back(x).flat_map(f) == s.flat_map(f).concat(f.get(x)))]
#[variant(s.len())]
pub fn checked_std_flat_map_push_back<T, U>(s: Seq<T>, x: T, f: Mapping<T, Seq<U>>) {
    if s.len() > 0 {
        checked_std_flat_map_push_back::<T, U>(s.tail(), x, f);
        proof_assert! { s.tail().push_back(x) == s.push_back(x).tail() }
    }
}

#[logic]
#[ensures(Seq::singleton(c).to_bytes() == c.to_utf8())]
pub fn utf8_singleton_local(c: char) {
    checked_std_flat_map_singleton(c, |x: char| x.to_utf8());
}

#[logic]
#[ensures(s.push_back(c).to_bytes() == s.to_bytes().concat(c.to_utf8()))]
pub fn utf8_push_back_local(s: Seq<char>, c: char) {
    checked_std_flat_map_push_back(s, c, |x: char| x.to_utf8());
}

#[check(ghost)]
#[ensures('\u{00E9}'.to_utf8() == seq![0xC3u8, 0xA9u8])]
pub fn utf8_u00e9() {
    let encoded = snapshot!('\u{00E9}'.to_utf8());
    proof_assert!('\u{00E9}'@ == 233);
    proof_assert!(encoded.len() == 2);
    proof_assert!(encoded[0]@ == 195);
    proof_assert!(encoded[1]@ == 169);
    proof_assert!(encoded.ext_eq(seq![0xC3u8, 0xA9u8]));
}

#[check(ghost)]
#[ensures('\u{20AC}'.to_utf8() == seq![0xE2u8, 0x82u8, 0xACu8])]
pub fn utf8_u20ac() {
    let encoded = snapshot!('\u{20AC}'.to_utf8());
    proof_assert!('\u{20AC}'@ == 8364);
    proof_assert!(encoded.len() == 3);
    proof_assert!(encoded[0]@ == 226);
    proof_assert!(encoded[1]@ == 130);
    proof_assert!(encoded[2]@ == 172);
    proof_assert!(encoded.ext_eq(seq![0xE2u8, 0x82u8, 0xACu8]));
}

#[check(ghost)]
#[ensures('\u{D7FF}'.to_utf8() == seq![0xEDu8, 0x9Fu8, 0xBFu8])]
pub fn utf8_u_d7ff() {
    let encoded = snapshot!('\u{D7FF}'.to_utf8());
    proof_assert!('\u{D7FF}'@ == 55295);
    proof_assert!(encoded.len() == 3);
    proof_assert!(encoded[0]@ == 237);
    proof_assert!(encoded[1]@ == 159);
    proof_assert!(encoded[2]@ == 191);
    proof_assert!(encoded.ext_eq(seq![0xEDu8, 0x9Fu8, 0xBFu8]));
}

#[check(ghost)]
#[ensures('\u{E000}'.to_utf8() == seq![0xEEu8, 0x80u8, 0x80u8])]
pub fn utf8_u_e000() {
    let encoded = snapshot!('\u{E000}'.to_utf8());
    proof_assert!('\u{E000}'@ == 57344);
    proof_assert!(encoded.len() == 3);
    proof_assert!(encoded[0]@ == 238);
    proof_assert!(encoded[1]@ == 128);
    proof_assert!(encoded[2]@ == 128);
    proof_assert!(encoded.ext_eq(seq![0xEEu8, 0x80u8, 0x80u8]));
}

#[check(ghost)]
#[ensures('\u{10FFFF}'.to_utf8() == seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8])]
pub fn utf8_u10ffff() {
    let encoded = snapshot!('\u{10FFFF}'.to_utf8());
    proof_assert!('\u{10FFFF}'@ == 1114111);
    proof_assert!(encoded.len() == 4);
    proof_assert!(encoded[0]@ == 244);
    proof_assert!(encoded[1]@ == 143);
    proof_assert!(encoded[2]@ == 191);
    proof_assert!(encoded[3]@ == 191);
    proof_assert!(encoded.ext_eq(seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8]));
}

#[check(ghost)]
#[ensures("é"@ == Seq::singleton('é'))]
pub fn literal_eacute_model() {
    let chars = snapshot!("é"@);
    proof_assert!(chars.len() == 1);
    proof_assert!(chars[0]@ == 'é'@);
    proof_assert!(chars.ext_eq(Seq::singleton('é')));
}

#[check(ghost)]
#[ensures("€"@ == Seq::singleton('€'))]
pub fn literal_euro_model() {
    let chars = snapshot!("€"@);
    proof_assert!(chars.len() == 1);
    proof_assert!(chars[0]@ == '€'@);
    proof_assert!(chars.ext_eq(Seq::singleton('€')));
}

#[check(ghost)]
#[ensures("\u{D7FF}"@ == Seq::singleton('\u{D7FF}'))]
pub fn literal_d7ff_model() {
    let chars = snapshot!("\u{D7FF}"@);
    proof_assert!(chars.len() == 1);
    proof_assert!(chars[0]@ == '\u{D7FF}'@);
    proof_assert!(chars.ext_eq(Seq::singleton('\u{D7FF}')));
}

#[check(ghost)]
#[ensures("\u{E000}"@ == Seq::singleton('\u{E000}'))]
pub fn literal_e000_model() {
    let chars = snapshot!("\u{E000}"@);
    proof_assert!(chars.len() == 1);
    proof_assert!(chars[0]@ == '\u{E000}'@);
    proof_assert!(chars.ext_eq(Seq::singleton('\u{E000}')));
}

#[check(ghost)]
#[ensures("\u{10FFFF}"@ == Seq::singleton('\u{10FFFF}'))]
pub fn literal_10ffff_model() {
    let chars = snapshot!("\u{10FFFF}"@);
    proof_assert!(chars.len() == 1);
    proof_assert!(chars[0]@ == '\u{10FFFF}'@);
    proof_assert!(chars.ext_eq(Seq::singleton('\u{10FFFF}')));
}

#[check(ghost)]
#[ensures("\u{D7FF}\u{E000}\u{10FFFF}"@ == Seq::singleton('\u{D7FF}').push_back('\u{E000}').push_back('\u{10FFFF}'))]
pub fn literal_boundary_string_model() {
    let chars = snapshot!("\u{D7FF}\u{E000}\u{10FFFF}"@);
    proof_assert!(chars.len() == 3);
    proof_assert!(chars[0]@ == '\u{D7FF}'@);
    proof_assert!(chars[1]@ == '\u{E000}'@);
    proof_assert!(chars[2]@ == '\u{10FFFF}'@);
    proof_assert!(chars.ext_eq(Seq::singleton('\u{D7FF}').push_back('\u{E000}').push_back('\u{10FFFF}')));
}

#[check(ghost)]
#[ensures("é"@.to_bytes() == seq![0xC3u8, 0xA9u8])]
pub fn literal_eacute_bytes() {
    literal_eacute_model();
    proof_assert!(utf8_singleton_local('é') == ());
    utf8_u00e9();
    proof_assert!("é"@ == Seq::singleton('é'));
    proof_assert!(Seq::singleton('é').to_bytes() == 'é'.to_utf8());
    proof_assert!('é'.to_utf8() == seq![0xC3u8, 0xA9u8]);
    proof_assert!("é"@.to_bytes().ext_eq(seq![0xC3u8, 0xA9u8]));
    proof_assert!("é"@.to_bytes() == seq![0xC3u8, 0xA9u8]);
}

#[check(ghost)]
#[ensures("€"@.to_bytes() == seq![0xE2u8, 0x82u8, 0xACu8])]
pub fn literal_euro_bytes() {
    literal_euro_model();
    proof_assert!(utf8_singleton_local('€') == ());
    utf8_u20ac();
    proof_assert!("€"@ == Seq::singleton('€'));
    proof_assert!(Seq::singleton('€').to_bytes() == '€'.to_utf8());
    proof_assert!('€'.to_utf8() == seq![0xE2u8, 0x82u8, 0xACu8]);
    proof_assert!("€"@.to_bytes().ext_eq(seq![0xE2u8, 0x82u8, 0xACu8]));
    proof_assert!("€"@.to_bytes() == seq![0xE2u8, 0x82u8, 0xACu8]);
}

#[check(ghost)]
#[ensures("\u{D7FF}"@.to_bytes() == seq![0xEDu8, 0x9Fu8, 0xBFu8])]
pub fn literal_d7ff_bytes() {
    literal_d7ff_model();
    proof_assert!(utf8_singleton_local('\u{D7FF}') == ());
    utf8_u_d7ff();
    proof_assert!("\u{D7FF}"@ == Seq::singleton('\u{D7FF}'));
    proof_assert!(Seq::singleton('\u{D7FF}').to_bytes() == '\u{D7FF}'.to_utf8());
    proof_assert!('\u{D7FF}'.to_utf8() == seq![0xEDu8, 0x9Fu8, 0xBFu8]);
    proof_assert!("\u{D7FF}"@.to_bytes().ext_eq(seq![0xEDu8, 0x9Fu8, 0xBFu8]));
    proof_assert!("\u{D7FF}"@.to_bytes() == seq![0xEDu8, 0x9Fu8, 0xBFu8]);
}

#[check(ghost)]
#[ensures("\u{E000}"@.to_bytes() == seq![0xEEu8, 0x80u8, 0x80u8])]
pub fn literal_e000_bytes() {
    literal_e000_model();
    proof_assert!(utf8_singleton_local('\u{E000}') == ());
    utf8_u_e000();
    proof_assert!("\u{E000}"@ == Seq::singleton('\u{E000}'));
    proof_assert!(Seq::singleton('\u{E000}').to_bytes() == '\u{E000}'.to_utf8());
    proof_assert!('\u{E000}'.to_utf8() == seq![0xEEu8, 0x80u8, 0x80u8]);
    proof_assert!("\u{E000}"@.to_bytes().ext_eq(seq![0xEEu8, 0x80u8, 0x80u8]));
    proof_assert!("\u{E000}"@.to_bytes() == seq![0xEEu8, 0x80u8, 0x80u8]);
}

#[check(ghost)]
#[ensures("\u{10FFFF}"@.to_bytes() == seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8])]
pub fn literal_10ffff_bytes() {
    literal_10ffff_model();
    proof_assert!(utf8_singleton_local('\u{10FFFF}') == ());
    utf8_u10ffff();
    proof_assert!("\u{10FFFF}"@ == Seq::singleton('\u{10FFFF}'));
    proof_assert!(Seq::singleton('\u{10FFFF}').to_bytes() == '\u{10FFFF}'.to_utf8());
    proof_assert!('\u{10FFFF}'.to_utf8() == seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8]);
    proof_assert!("\u{10FFFF}"@.to_bytes().ext_eq(seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8]));
    proof_assert!("\u{10FFFF}"@.to_bytes() == seq![0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8]);
}

#[check(ghost)]
#[ensures("\u{D7FF}\u{E000}\u{10FFFF}"@.to_bytes() == seq![
    0xEDu8, 0x9Fu8, 0xBFu8,
    0xEEu8, 0x80u8, 0x80u8,
    0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8,
])]
pub fn literal_boundary_string_bytes() {
    literal_boundary_string_model();
    proof_assert!(utf8_singleton_local('\u{D7FF}') == ());
    proof_assert!(utf8_push_back_local(Seq::singleton('\u{D7FF}'), '\u{E000}') == ());
    proof_assert!(
        utf8_push_back_local(
            Seq::singleton('\u{D7FF}').push_back('\u{E000}'),
            '\u{10FFFF}',
        ) == ()
    );
    utf8_u_d7ff();
    utf8_u_e000();
    utf8_u10ffff();
    proof_assert!("\u{D7FF}\u{E000}\u{10FFFF}"@ == Seq::singleton('\u{D7FF}').push_back('\u{E000}').push_back('\u{10FFFF}'));
    proof_assert!(
        "\u{D7FF}\u{E000}\u{10FFFF}"@.to_bytes().ext_eq(seq![
            0xEDu8, 0x9Fu8, 0xBFu8,
            0xEEu8, 0x80u8, 0x80u8,
            0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8,
        ])
    );
    proof_assert!(
        "\u{D7FF}\u{E000}\u{10FFFF}"@.to_bytes() == seq![
            0xEDu8, 0x9Fu8, 0xBFu8,
            0xEEu8, 0x80u8, 0x80u8,
            0xF4u8, 0x8Fu8, 0xBFu8, 0xBFu8,
        ]
    );
}
