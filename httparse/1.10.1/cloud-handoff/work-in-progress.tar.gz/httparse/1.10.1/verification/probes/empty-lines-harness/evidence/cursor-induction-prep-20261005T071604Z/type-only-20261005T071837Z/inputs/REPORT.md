# `skip_empty_lines` proof checkpoint

**Status: exact helper/model candidate translated. The previous bounded solver attempt stopped on a CRLF-prefix timeout. A proof-only concatenation induction candidate has since been translated but not type-only checked or solver-run.** The isolated harness does not edit or compile the full production `lib.rs` as a crate, and the helper remains unwired in the production parser.

## Runtime and model boundary

The harness path-includes the actual `src/iter.rs`, `src/macros.rs`, `src/status.rs`, `src/error.rs`, and extracted `src/skip_empty_lines.rs`, plus the independent `src/verification/empty_lines.rs` model. The production function body and extracted runtime body have equal token streams after removing only Creusot contracts, loop facts, and ghost statements. The check is reproducible with [`check-runtime-token-equivalence.py`](evidence/translation-20261005/check-runtime-token-equivalence.py); the current comparison has 104 matching runtime tokens and SHA-256 `cc731c7e0eeb496982e24cd47b3e563091f7a49afbbf00ed0c7b07947bdc8296`.

The exact model preserves the runtime's byte consumption and commit behavior:

- Repeated LF and CRLF endings are consumed. At the first other byte, `slice()` commits the cursor there and leaves that byte unconsumed.
- Exhaustion after complete endings returns partial at `end` and retains the entry mark.
- A final CR is consumed by `bump()` before `next()` observes EOF; that path returns partial at `end` and retains the entry mark.
- After CR, `next()` consumes one following byte. LF completes a CRLF ending; any other byte is consumed before `Error::NewLine` returns, with the entry mark retained.

The parser loop preserves the input, entry mark, and end; bounds the cursor; records that the scanned bytes form a complete LF/CRLF prefix; bounds the cursor by the maximal complete-ending endpoint; and decreases `end - cursor`. The exact model keeps absolute mark and cursor offsets.

## Previous bounded solver attempt

The frozen run is at [`direct-why3-20261005T062922467607808Z/`](evidence/direct-why3-20261005T062922467607808Z/). It proved 69 split leaves across 12 target files, classified `complete_line_ending_at` as `TrivialTrueNoTask` because its CoMa had no task, then stopped at target 14, `complete_line_prefix_extend_crlf`, on the fixed 30-second timeout. Targets 15–18 were unattempted, including the extracted parser. The pre-induction source, timeout CoMa, and raw timeout log are also copied under [`induction-prep-20261005T063957Z/archive/`](evidence/induction-prep-20261005T063957Z/archive/); hashes appear in `archive/ARCHIVE.tsv`. The timeout has not been retried.

A prior 18-target closure passed Why3's `--type-only` preflight for the pre-induction source. That result is preserved under [`type-only-20261005T060436Z/`](evidence/type-only-20261005T060436Z/) and does not type-check or prove the new induction candidate.

## Current concatenation induction candidate

[`induction-prep-20261005T063957Z/`](evidence/induction-prep-20261005T063957Z/) contains the current fresh translation and a 19-target dependency closure: 10 `Bytes`/`Iterator` dependencies, 8 model targets, and the extracted parser last. The new `complete_line_prefix_concat` helper uses the `mid - start` variant; its recursive branches advance by one for LF and two for CRLF. Its CoMa contains a body goal whose postconditions include both `result == mid` and the joined complete-prefix predicate. The LF and CRLF wrappers construct finite one-byte and two-byte suffixes and call the induction helper.

An initial bool-return form was rejected after CoMa inspection: it translated as a predicate with axiomatized postconditions but no body goal. It is preserved and explicitly excluded from evidence under `rejected-bool-candidate/`. The current Int-return form emits `vc_complete_line_prefix_concat`; the solver has not yet checked that goal or the 19-target closure. No trusted assumptions, axioms, or weakened contracts were added.

The current `./verification/probes/empty-lines-harness/translate.sh translate` exited 0 and emitted 63 CoMa files. [`all-coma-inventory.tsv`](evidence/induction-prep-20261005T063957Z/all-coma-inventory.tsv) and [`fresh-coma.SHA256SUMS`](evidence/induction-prep-20261005T063957Z/fresh-coma.SHA256SUMS) identify the preserved output; [`proof-targets.tsv`](evidence/induction-prep-20261005T063957Z/proof-targets.tsv) and [`dependencies.tsv`](evidence/induction-prep-20261005T063957Z/dependencies.tsv) record the selected closure and lemma edges. No Why3 type-only or solver run was made on these changed targets, so no proof result is claimed for them.

## Reproduction

From `httparse/1.10.1`, run `./verification/probes/empty-lines-harness/translate.sh translate` to regenerate the isolated translation. The exact translation inputs, source hashes, raw warning/build log, full CoMa snapshot, selected files, and target hashes are preserved under `verification/probes/empty-lines-harness/evidence/induction-prep-20261005T063957Z/`.
