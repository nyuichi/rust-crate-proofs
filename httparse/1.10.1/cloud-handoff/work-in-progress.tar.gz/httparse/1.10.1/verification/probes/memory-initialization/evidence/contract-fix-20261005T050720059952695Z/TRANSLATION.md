# Typed storage contract correction: translation only

This snapshot records the contract correction following read-only COMA review.
The initialized and uninitialized constructors retain their structural links
for both mutable-borrow prophecies, but no longer claim that a current slice
and its arbitrary future inner slice have the same length. `commit_prefix` no
longer assumes equal lengths; it states that the body preserves the outer
future binding and relates the inner future to the committed prefix, with the
old backing tail framed against the current tail.

The command `./verify-selected.sh translate` completed successfully. The
runner compared the freshly generated COMA paths with
`TRANSLATION-TARGETS.txt`; the inventory is exactly 18 paths, and all ten
selected COMA targets are present. `generated-targets.txt` records the exact
fresh inventory. The captured command output is in `translation.log`.

No Why3 proof phase or runtime test was run for this source version. The prior
solver `Unknown` belongs to source hash
`43e3da589746e1d11ebe0f4f9ab799f9c40ec815855449bfd9c21c6e5ee53081` and does
not apply to this corrected translation. This snapshot contains the source,
selected-target list, all 18 translated COMA files, pinned translation/proof
configuration inputs, and hashes for independent inspection.
