# Targeted flat-map empty base-step result

This run proved only the previously unproved line-42 child from the direct `flat_map_empty_T` attempt. It used Astra's export-preflighted Why3 transformation on the same frozen COMA; no source or compiler file changed and no other target was submitted.

- Selected goal: `vc_flat_map_empty_T`, original COMA line 42.
- Input COMA SHA-256: `input.sha256` (same hash as `COMA-SHA256SUMS`).
- Applied transforms, in order: `split_vc`; `inst_rem flat_map_T_def (empty:seq(t_T)),f`; select `-g :42`.
- Astra export-only task SHA-256: `preflight/task.sha256`; task SMT is copied to `preflight/task.smt2`.
- Z3 4.15.3 result: `Valid`, status `exited with status 0`, 32,858 steps, 0.020754 seconds, empty counterexample list. The CLI exit code is 0.
- The exported/transformed task retains the standard recursive equation instantiated at the selected empty sequence and mapping, along with `empty_len_T_spec`; it removes the universally quantified recursive equation. This leaves a weaker assumption context and a stronger proof obligation, with no added axiom.
- Raw result JSONL and stderr are in `proof/line-42/`.
- The wrapper used the isolated profile, max one prover and 1000 MiB, and released the shared lock at exit. No active solver remains.

This closes the one selected transformed child. The earlier report `direct-why3-core-20261005/RUN-REPORT.md` retains the original direct split outcomes. The guided singleton target was not run.
