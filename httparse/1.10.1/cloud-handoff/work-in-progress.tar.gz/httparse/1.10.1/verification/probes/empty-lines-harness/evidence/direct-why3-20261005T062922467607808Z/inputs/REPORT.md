# `skip_empty_lines` translation checkpoint

**Status: exact extracted helper/model prepared and translated successfully;
solver not run.** This isolated harness does not edit or include the full
production `lib.rs` as a crate. The new helper has not been wired into the
production parser.

## Runtime and model boundary

The harness path-includes the actual `src/iter.rs`, `src/macros.rs`,
`src/status.rs`, `src/error.rs`, and extracted `src/skip_empty_lines.rs`, plus
the independent `src/verification/empty_lines.rs` model. The production
function body and extracted runtime body have equal token streams after
removing only added Creusot contracts, loop facts, and ghost statements. The
check is reproducible with
[`check-runtime-token-equivalence.py`](evidence/translation-20261005/check-runtime-token-equivalence.py);
the recorded result has 104 matching runtime tokens.

The model preserves the runtime's byte consumption and commit behavior:

- Repeated LF and CRLF endings are consumed. At the first other byte,
  `slice()` commits the cursor there and leaves that byte unconsumed.
- Exhaustion after complete endings returns partial at `end` and retains the
  entry mark.
- A final CR is consumed by `bump()` before `next()` observes EOF; that path
  returns partial at `end` and retains the entry mark.
- After CR, `next()` consumes one following byte. LF completes a CRLF ending;
  any other byte is consumed before `Error::NewLine` returns, with the entry
  mark retained.

The loop preserves the input, entry mark, and end; bounds the cursor; records
that the scanned bytes form a complete LF/CRLF prefix; bounds the cursor by
the maximal complete-ending endpoint; and decreases `end - cursor`. Checked
ghost lemmas extend the prefix after LF or CRLF and connect its endpoint to
the current cursor. The exact model keeps absolute mark and cursor offsets.

## Translation and candidate closure

The isolated `./translate.sh translate` command completed with exit code 0,
using the string-model Creusot compiler, offline Cargo, and default `std`
feature. The raw warning/build log and exit code are preserved under
[`evidence/translation-20261005/`](evidence/translation-20261005/). Translation
emitted 62 CoMa files. Their paths and hashes are recorded in
[`all-coma-inventory.tsv`](evidence/translation-20261005/all-coma-inventory.tsv).
All 62 files are preserved verbatim under
[`fresh-coma/`](evidence/translation-20261005/fresh-coma/) with a separate
[`SHA256SUMS`](evidence/translation-20261005/fresh-coma.SHA256SUMS) snapshot
manifest.

The minimal review candidate has 18 unique target files: 10 `Bytes` and
`Iterator` dependencies, 7 exact model and checked-lemma targets, and the
actual helper. Their dependency order, purposes, and fresh CoMa hashes appear
in [`proof-targets.tsv`](evidence/proof-targets.tsv).
The edge-by-edge source dependency map appears in
[`dependencies.tsv`](evidence/dependencies.tsv). Open outcome predicates and
`verification_model::valid_cursor` are expanded from their logic definitions
and do not add target files to this candidate.

The exact 18-target closure passed Why3's `--type-only` preflight with exit
code 0. The per-target command and raw logs, read-only config snapshot,
isolated package manifest, selected CoMa copies, and pre/post hashes are kept
under [`evidence/type-only-20261005T060436Z/`](evidence/type-only-20261005T060436Z/),
with a verified [`RUN-SHA256SUMS`](evidence/type-only-20261005T060436Z/RUN-SHA256SUMS)
manifest for the frozen run files.
No solver was invoked, so this checkpoint makes no `Valid` or
proof-completion claim. Existing same-source `Bytes` proof artifacts in other
probes are references, not results for these fresh COMA hashes. In
particular, the required `Iterator::next` dependency is included because
`expect!` expands through `next!`; its ghost `bytes_subsequence_head`
dependency is included as well.

## Reproduction

Run `./verification/probes/empty-lines-harness/translate.sh translate` from
`httparse/1.10.1` to refresh this isolated translation. To repeat only the
type check, run
`./verification/probes/empty-lines-harness/evidence/run-type-only.sh`. That
script uses the spaces probe's read-only effective Why3 config and invokes
only `why3 prove --type-only`; it contains no solver command. The
input/configuration hashes, raw translation and type-only logs, selected
candidate hashes, and full emitted CoMa snapshot are kept under
`verification/probes/empty-lines-harness/evidence/`.
