# Standard `Seq::flat_map` helper VC preparation

## Scope and provenance

This isolated harness mirrors the two helper contracts and bodies in the pinned
`creusot-std` `logic/seq.rs` copy. The standard source excerpt and hash are in
`evidence/standard-helper-source.txt`; the source clone is in `src/lib.rs`.
The singleton clone preserves its empty body and postcondition. The push-back
clone preserves the recursive structure, variant, contract, and tail equality
assertion, with only the method name/receiver spelling adapted for a free
function in the harness. This is a source-clone proof target, not a change to
the standard library.

The generated COMA files provide explicit standalone targets:

| Target | Goal structure |
|---|---|
| `checked_std_flat_map_singleton` | Postcondition goal `flat_map(singleton(x), f) = f(x)` with no helper-contract antecedent. |
| `checked_std_flat_map_push_back` | Recursive body VC with the recursive-call postcondition as induction hypothesis, the length-decrease condition, tail equality assertion, and the target postcondition. |

The two exact module paths are listed in `proof-targets.txt`. Hashes for the
probe source, standard source, compiler/config/prelude, logs, and generated
COMAs are recorded in `evidence/SOURCE-SHA256SUMS`.

## Translation status

Creusot translation completed with exit code 0 and generated exactly two COMA
modules. Direct Why3 type-only checking completed with exit code 0. Logs are
under `evidence/`. An earlier translation attempt failed because Rust rejects
an inherent impl for the dependency-owned `Seq` type; that compiler diagnostic
is retained as `evidence/translation-attempt-1.log`. The checked clones are
module-level functions, so the current translation succeeds.

The singleton clone was sent to Z3 4.15.3 with a fixed 30-second cap and
1000 MiB memory limit. It returned `Out of memory` after 13.2702 seconds, with
an empty counterexample list; this is non-Valid and not a counterexample. The
exact result, source and COMA hashes, and an export-only command explicitly
marked as not a proof are retained under
`evidence/direct-why3-utf8-dependencies-20261005/`. The push-back clone was not
submitted to a solver. Neither clone currently supplies a proof of its
standard-library counterpart. The existing UTF-8 wrapper COMAs remain
unchanged and still import standard helper postconditions as antecedents; this
probe does not rewrite or close those callers.

## Remaining connection to standard helpers

The clone contracts exactly match the pinned standard contracts. The singleton
implementation is empty and the push-back body matches structurally, but
source similarity alone is not a proof artifact tying separately compiled
symbols together. Preserve this source hash and review the correspondence when
the clone goals are proved. A later integration can either verify the standard
library methods directly or record the explicit clone-to-source refinement
review alongside the proof manifest. Do not count the wrapper antecedents as
standalone helper evidence.

## Follow-up for complete string-byte coverage

The five finite scalar candidates cover selected branch and Unicode-boundary
examples. A universal valid-`char` lemma still needs to split the open standard
`to_utf8` definition at codepoint thresholds 0x80, 0x800, and 0x10000. For each
branch, prove the result length (1, 2, 3, or 4), each constructed byte's range
0..255, and each output index's quotient/remainder formula using the exact
`utf8_byte` numeric postcondition. Keep the standard Char model's scalar range
and surrogate exclusion as the source of validity; do not introduce a new
encoding axiom or unfold the recursive byte constructor.

For literal callers, the next small targets are concrete:

1. For each one-character literal, prove its generated `Seq.create` model is
   extensionally equal to `Seq::singleton` by equal length and index 0.
2. Compose that fact with the checked singleton bridge and the matching scalar
   encoding goal, then prove byte extensionality by length and finite indices.
3. For the three-character boundary string, show the `Seq.create` model equals
   `singleton(U+D7FF).push_back(U+E000).push_back(U+10FFFF)` using equal length
   and indices 0..2. Apply singleton once and push-back twice, then prove the
   3+3+4 byte concatenation equals the ten-byte expected sequence by length and
   indices 0..9.

Keep the helper goals, universal scalar lemma, literal-model equalities, and
literal byte callers as explicit targets in the proof manifest so callers
cannot rely on unproved helper contracts invisibly.
