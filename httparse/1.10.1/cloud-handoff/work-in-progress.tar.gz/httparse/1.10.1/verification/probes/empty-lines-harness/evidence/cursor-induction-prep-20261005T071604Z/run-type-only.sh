#!/usr/bin/env bash
set -euo pipefail
stage_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
evidence_dir=$(cd "$stage_dir/.." && pwd)
CANDIDATE_DIR="$stage_dir" exec bash "$evidence_dir/run-type-only-induction.sh"
