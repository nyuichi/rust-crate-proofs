# Header slice initialization bridge: probe proposal

This was the initial representation-bridge preparation note, not proof
evidence. No solver or runtime test was run, and no trusted contract was added
to the `httparse` converter. The source review used `lib.rs` SHA-256
`d2ce3b18454b17efd578550bd439319cb9e6707a00b16f3962a7444fb5a13307`,
`message.rs` SHA-256
`cb6885224d430899f81b7bee1a79238e4660d058e92f9d29b00c65482d7a94b4`, and the
current `creusot-std` `mem.rs`, `slice.rs`, and `ptr.rs` hashes
`f1d90dce02e7ef410da7c226c06c9c4be34795263c7a1fe21c35366cc34d8786`,
`07ffe0cc8dfabab4b26da57d28aec80007a4b09491563f4f53bbeeb69756b7cc`, and
`e7aaf642680aaed7229cb185aedd8cea81a2624fd8c48774f3203edc1a134829`.

## Runtime boundary

`deinit_slice_mut` reinterprets the fat pointer binding
`&mut &mut [T]` as `&mut &mut [MaybeUninit<T>]` (`src/lib.rs:554-558`).
`assume_init_slice` reinterprets a `&mut [MaybeUninit<T>]` as `&mut [T]`
(`src/lib.rs:559-563`). Both preserve the underlying allocation; the first
must preserve the slice data pointer and length, and the second must also
require that every element in the returned slice is initialized.

`parse_headers_iter_uninit` starts `num_headers` at zero. It writes a
`MaybeUninit::new(Header { .. })` into the next `iter_mut` slot only after the
whole header has parsed, then increments the count (`src/lib.rs:608-616,
811-815`). `ShrinkOnDrop::drop` takes the current slice binding, selects
`..num_headers`, and restores that shorter slice (`src/lib.rs:592-605`). This
destructor runs for success, error, and partial returns. Its essential
condition is that the count stays within the original capacity and every slot
below it has `MaybeUninit` view `Some(Header)`; it says nothing about the tail.

The tail must remain unconstrained in the shared uninitialized API. The
initialized-header path can instead begin with `Some` in every slot and, on a
non-complete result, restores the original full `Header` slice even though the
visible prefix was shortened inside the helper. The public uninitialized
request/response paths convert only the shortened prefix after a complete
parse. `parse_headers_iter` likewise shortens an already initialized
`&mut [Header]`. `Header` is `Copy + Clone` in both runtime and Creusot builds
and has no `Drop` implementation (`src/message.rs:91-104`); keep the generic
converter free of an added `T: Copy` bound unless its API is deliberately
specialized and reviewed.

## Representation and proof cutpoints

Use one canonical length `n`, the number of successfully written headers, and
model a slice of `MaybeUninit<T>` as `Seq<Option<T>>` using the existing
`MaybeUninit<T>::View`. The central predicate is:

```text
0 <= n <= slots.len()
forall i. 0 <= i < n ==> slots[i]@ == Some(value_i)
```

Do not constrain `i >= n`. Track allocation identity separately from the
sequence view: a slice `View` gives elements and length, but does not establish
that a wide-pointer cast retains the same data pointer or provenance. On a
shrink, prove the data pointer is unchanged and only the slice metadata changes
from capacity to `n`.

The existing `IterMut` model is a useful loop boundary: its `IteratorSpec`
states that consumed mutable references plus the remaining iterator equal the
original `to_mut_seq` (`creusot-std/src/std/slice.rs:549-594`), and
`SliceExt::to_mut_seq` relates each reference to its indexed slot. The body
proof can use `n` both as the number of consumed slots and the initialized
prefix length; do not introduce another equivalent counter.

The converters need separate contracts:

- For `deinit_slice_mut`, relate input and output data pointer, length, and
  per-slot values. Since the input is `&mut [T]`, its entire slice is
  initialized; each output slot must have view `Some(input[i])`. This
  representation bridge is not currently supplied by the existing permission
  cast contracts.
- For `assume_init_slice`, require that every element in the current (already
  shortened) slice has view `Some(_)`. Preserve its data pointer, length, and
  exact sequence of values in the `&mut [T]` result.
- For `ShrinkOnDrop`, require `n <= original_len` and the initialized-prefix
  predicate; ensure the binding has length `n`, retains its data pointer, and
  the prefix values are unchanged. Do not claim that the original capacity is
  initialized.

The loop body can then establish the `ShrinkOnDrop` precondition locally:
`MaybeUninit::new` gives the new slot `Some(header)`, and incrementing `n`
extends the prefix by one. `IterMut::next` must show this is exactly slot `n`.
This isolates the initialized-storage invariant from parser syntax and byte
semantics.

## Standard-library evidence and missing contracts

The verifier models `MaybeUninit<T>` as `Option<T>` and specifies scalar
`new`, `uninit`, `write`, and `assume_init*` operations in
`creusot-std/src/std/mem.rs:4-11,68-105`. It has no slice `assume_init_mut`
contract. `Perm<*const T>::cast` preserves the pointer expression, but there
is no contract that reinterprets a slice permission from element type `T` to
`MaybeUninit<T>` (`creusot-std/src/std/ptr.rs:388-405,723-765`). These are the
missing pieces for body-checking either raw wide-pointer cast using current
support alone.

The pinned compiler is rustc `1.95.0-nightly`
(`6a979b3e32522049d0acb4a47f7ae44b7c8abfd5`). Its
`library/core/src/mem/maybe_uninit.rs` has SHA-256
`7d022987cc482ebcc1b66e470ad50bc1a4c93fcf063d4df202177b4e6caef2e0`.
Lines 204-240 promise equal size, alignment, and ABI, while warning that
reinterpreting `&mut T` as `&mut MaybeUninit<T>` and exposing it to safe code is
unsound. Lines 1482-1512 specify and implement slice `assume_init_ref` and
`assume_init_mut`: every element must already be initialized, and the body
casts the wide pointer back to `[T]`. This supports an audited standard-library
contract for that standard method, but layout equality by itself does not
prove the initialized-prefix invariant or create a Creusot `Perm` for the
reinterpreted slice.

## Superseding implementation direction

Root review selected a safe typed adapter with a logical `used_len` and an
explicit Complete-only `commit_prefix`; the old all-exit `ShrinkOnDrop`
behavior must not be counted as a caller proof. The updated adapter contracts,
public behavior inventory, translation-only Drop diagnostic, saved Coma, and
representative client cutpoints are documented in
[`DROP-CALLER-SEMANTICS.md`](DROP-CALLER-SEMANTICS.md). The probe model does not
assert a raw-pointer identity relation.

The first typed-adapter source version translated successfully. In its narrow
direct-Why3 checkpoint, the initialized constructor was Valid; the
non-Complete initialized client proved its `write` precondition but timed out
on its caller ensures after 30 seconds. No later target ran. The frozen inputs
and logs are under
[`evidence/selected-solver-run-20261005T044741856965836Z/`](evidence/selected-solver-run-20261005T044741856965836Z/).

Read-only COMA diagnosis found that the first version's `View` implementation
was opaque and its one prophetic projection conflated the future local binding
with the backing slice's future contents. The probe source now has an open
`HeaderStorage::view`, separate `future_slots` and `inner_future_slots`
projections, two prophecy frames on `write`, and a split prefix/tail lens for
`commit_prefix`. This revised source requires a fresh translation and a new
proof run; the prior partial result does not apply to it. The Drop diagnostic
still shows only `resolve_DropMarker` in the caller translation, not the body
of `Drop::drop`. Production parser integration remains blocked until the
revised typed-storage method/client closure passes and the Request/Response
field ordering and capacity-check cutpoint are reviewed.

## Earlier standard-library bridge questions

The pinned `MaybeUninit::assume_init_mut` implementation and the missing
cross-type permission bridge remain relevant only if later production code
retains an actual slice reinterpretation. The selected safe adapter avoids
`deinit_slice_mut` and does not itself perform slice `assume_init`; that final
uninitialized-to-initialized conversion remains a separate standard-library
contract boundary to audit before wiring the public uninitialized APIs.
