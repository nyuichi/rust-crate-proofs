#![allow(dead_code)]

use creusot_std::prelude::*;

extern_spec! {
    impl<T: ?Sized> *const T {
        // Candidate std contract: expose the address as an integer while retaining
        // Rust's exposure side effect. This does not make the integer a permission.
        #[check(terminates)]
        #[ensures(result == self.addr_logic())]
        fn expose_provenance(self) -> usize;
    }
}

/// Isolated arithmetic shape used by `Bytes::pos`.
#[requires(start.addr_logic()@ <= cursor.addr_logic()@)]
#[ensures(result@ == cursor.addr_logic()@ - start.addr_logic()@)]
pub fn pointer_distance(start: *const u8, cursor: *const u8) -> usize {
    cursor.expose_provenance() - start.expose_provenance()
}
