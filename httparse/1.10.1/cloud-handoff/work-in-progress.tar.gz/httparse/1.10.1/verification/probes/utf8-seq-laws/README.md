# Standard sequence flat-map law proof preparation

This isolated companion to `utf8-lemmas` prepares checked source-clone VCs for
the two generic `Seq` laws used by the UTF-8 composition wrappers. The cloned
signatures, postconditions, and bodies mirror the pinned standard-library
source recorded in `evidence/SOURCE-SHA256SUMS`. The push-back target copies the
recursive call and tail equality assertion. The singleton target has the same
empty body and postcondition as the standard helper.

The clone goals are not themselves proof results and do not silently replace
the standard-library methods. Their use as evidence for those methods still
requires an explicit source correspondence review. The seven earlier UTF-8
COMAs remain untouched in the sibling `utf8-lemmas` directory.

`verify.sh translate` generates exactly the two modules listed in
`proof-targets.txt`; `verify.sh typecheck` checks only their Why3 syntax and
types. A direct solver run was made only for the singleton clone and returned
Out of memory. The recursive push-back clone was not submitted to a solver.
