use creusot_std::prelude::*;

pub fn pointer_lt(lhs: *const u8, rhs: *const u8) -> bool {
    lhs.addr() < rhs.addr()
}
