#!/usr/bin/env bash
set -euo pipefail

probe_dir=$(cd "$(dirname "$0")" && pwd)
mode=${1:-translate}
shift || true

if [[ ! -x /workspace/proof-tools/targets/httparse-string-model/debug/creusot-rustc || \
      ! -f /workspace/scratch/httparse-string-model/creusot-env.sh ]]; then
  printf 'The isolated string-model compiler environment is not available.\n' >&2
  exit 2
fi

source /workspace/proof-tools/activate.sh
source /workspace/scratch/httparse-string-model/creusot-env.sh
export RUSTUP_TOOLCHAIN=nightly-2026-02-27
export CARGO_NET_OFFLINE=true
export CREUSOT_DATA_HOME=/workspace/scratch/httparse-string-model/creusot-data
export CREUSOT_RUSTC=/workspace/proof-tools/targets/httparse-string-model/debug/creusot-rustc
export CARGO_TARGET_DIR=/workspace/proof-tools/targets/httparse-utf8-char-universal
export WHY3CONFIG=/workspace/scratch/httparse-string-model/why3.conf
export DUNE_DIR_LOCATIONS=why3find:lib:/workspace/scratch/httparse-string-model/creusot-data/share/why3find
export XDG_CONFIG_HOME=/workspace/scratch/httparse-string-model/config
export XDG_CACHE_HOME=/workspace/scratch/httparse-string-model/cache

cd "$probe_dir"
case "$mode" in
  translate)
    if [[ "$CARGO_TARGET_DIR" != /workspace/proof-tools/targets/httparse-utf8-char-universal ]]; then
      printf 'Unexpected target directory; refusing to clean %s\n' "$CARGO_TARGET_DIR" >&2
      exit 2
    fi
    rm -rf "$CARGO_TARGET_DIR"
    rm -rf "$probe_dir/verif"
    cargo creusot -- --manifest-path "$probe_dir/Cargo.toml" "$@"
    ;;
  native)
    cargo check --offline --manifest-path "$probe_dir/Cargo.toml" "$@"
    ;;
  typecheck)
    mapfile -t relative_targets < <(sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d' "$probe_dir/proof-targets.txt")
    mapfile -t actual_targets < <(find "$probe_dir/verif" -type f -name '*.coma' -printf 'verif/%P\n' | sort)
    mapfile -t expected_targets < <(printf '%s\n' "${relative_targets[@]}" | sort)
    if (( ${#actual_targets[@]} != ${#expected_targets[@]} )) || \
       [[ "${actual_targets[*]}" != "${expected_targets[*]}" ]]; then
      printf 'Translated COMA inventory differs from proof-targets.txt\nExpected:\n%s\nActual:\n%s\n' \
        "${expected_targets[*]}" "${actual_targets[*]}" >&2
      exit 2
    fi
    targets=()
    for target in "${relative_targets[@]}"; do
      if [[ ! -f "$probe_dir/$target" ]]; then
        printf 'Missing translated target: %s\n' "$target" >&2
        exit 2
      fi
      targets+=("$probe_dir/$target")
    done
    /workspace/scratch/httparse-string-model/creusot-data/bin/why3 prove --type-only \
      -C "$WHY3CONFIG" \
      -L /workspace/scratch/httparse-string-model/creusot-data/share/why3find/packages/creusot \
      -L "$probe_dir/verif" "${targets[@]}" "$@"
    ;;
  *)
    printf 'Usage: %s [translate|native|typecheck] [flags...]\n' "$0" >&2
    printf 'This probe intentionally has no solver mode.\n' >&2
    exit 2
    ;;
esac
