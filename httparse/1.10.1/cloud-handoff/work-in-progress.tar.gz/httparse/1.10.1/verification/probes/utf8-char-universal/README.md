# Generic valid-`char` UTF-8 layout candidate

This isolated source-only candidate splits `CharExt::to_utf8` into its four
standard codepoint ranges. The five listed function modules check the exact
length and every byte index in each branch, together with the 0..255 bounds
required by the existing `utf8_byte` contract. A separate domain target checks
that Rust `char` values satisfy the existing scalar range and surrogate
exclusion. The sixth target states the complete piecewise sequence equation
over those four codepoint ranges.

The six-target inventory is fixed in `proof-targets.txt` before translation.
The source adds no axioms, trusted annotations, compiler switches, or new
validity assumptions. The six-target inventory was reviewed before translation;
no solver mode is provided by the runner.
