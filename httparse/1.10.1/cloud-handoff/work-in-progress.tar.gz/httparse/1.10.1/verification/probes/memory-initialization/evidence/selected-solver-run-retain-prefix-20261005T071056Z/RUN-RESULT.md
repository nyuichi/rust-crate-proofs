# Retain-prefix solver run result

The exact archived input passed type checking on all 11 selected COMA targets.
The proof command used direct Why3 with the frozen COMA in `inputs/translation`,
the isolated string-model config, Z3 4.15.3, one active prover, 1000 MiB, and
a 30-second per-goal limit. The shared proof lock is released.

| Order | Target | Status | Valid leaves | Timeout | Other non-Valid |
|---:|---|---|---:|---:|---:|
| 1 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/initialized.coma` | VALID | 1 | 0 | 0 |
| 2 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/uninitialized.coma` | VALID | 1 | 0 | 0 |
| 3 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/capacity.coma` | VALID | 4 | 0 | 0 |
| 4 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/used_len.coma` | VALID | 4 | 0 | 0 |
| 5 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/write.coma` | VALID | 14 | 0 | 0 |
| 6 | `verif/httparse_memory_initialization_probe_rlib/header_storage/retain_prefix.coma` | VALID | 11 | 0 | 0 |
| 7 | `verif/httparse_memory_initialization_probe_rlib/header_storage/impl_HeaderStorage/commit_prefix.coma` | STOPPED | 7 | 1 | 0 |
| 8 | `verif/httparse_memory_initialization_probe_rlib/non_complete_initialized_client.coma` | NOT_RUN | 0 | 0 | 0 |
| 9 | `verif/httparse_memory_initialization_probe_rlib/complete_initialized_client.coma` | NOT_RUN | 0 | 0 | 0 |
| 10 | `verif/httparse_memory_initialization_probe_rlib/non_complete_uninitialized_client.coma` | NOT_RUN | 0 | 0 | 0 |
| 11 | `verif/httparse_memory_initialization_probe_rlib/complete_uninitialized_client.coma` | NOT_RUN | 0 | 0 | 0 |

The run produced 42 Valid leaves and stopped at the first non-Valid target,
`commit_prefix` (selected target 7). Its raw Why3 log contains a `Timeout` at
COMA lines 281–299, the combined `Commit_prefix ensures` source goal: 30.00
s, 497,620,632 steps. The other emitted leaves in that target were Valid
(7 Valid, 1 Timeout). No representative client was started. The raw runner
stop record is `STOP.txt`; full output is in `logs/prove/`.

A first typecheck preflight omitted `proof-tools/activate.sh`, so `why3` was not
on PATH and no COMA was typechecked in that attempt. After activating
proof-tools and restoring the isolated string-model environment inside the
child shell, all 11 exact archived targets typechecked successfully. No solver
ran during that preflight.

No timeout increase, retry, source edit, or proof trust change was made after the
non-Valid result. These results apply only to the source and COMA hashes frozen
in this run.
