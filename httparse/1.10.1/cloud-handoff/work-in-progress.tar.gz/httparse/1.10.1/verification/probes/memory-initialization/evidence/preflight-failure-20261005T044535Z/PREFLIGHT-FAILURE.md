# Preflight stopped before solver launch

The first authorized runner attempt freshly translated the probe and matched the reviewed 18-target COMA inventory. It then stopped while building the run hash manifest because the four bundled Creusot theory files are nested under `creusot/` within the path reported by `why3find query creusot`. The shell reported `sha256sum: ... No such file or directory`. This happened before the run loop, config query, or any `why3 prove` command; solver outcome count is zero.

The partial directory preserves that fresh translation snapshot for audit only. It is not proof evidence. The runner has been corrected to hash the exact nested package files and will use a new per-run timestamp for the next authorized invocation.
