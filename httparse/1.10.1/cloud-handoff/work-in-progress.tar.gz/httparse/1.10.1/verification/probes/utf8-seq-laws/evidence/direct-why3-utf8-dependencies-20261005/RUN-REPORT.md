# UTF-8 dependency-first direct Why3 run

This bounded run stopped at the first selected goal, as instructed. No push-back or scalar target was submitted.

## Selected actual proof

- Probe: `utf8-seq-laws`
- Target: `checked_std_flat_map_singleton.coma`
- COMA SHA-256: recorded in `01-singleton/input.sha256`
- Goal: `vc_checked_std_flat_map_singleton_T`
- Prover: Z3 4.15.3
- Why3 CLI: direct `why3 prove`, `split_vc`, 30 second time limit, 1000 MiB prover memory limit
- Result: Z3 answer `Out of memory`; prover status `exited with status 101`; elapsed 13.2702 seconds; empty counterexample list. This is non-Valid and not a counterexample.
- Why3 command exit status: recorded in `01-singleton/exit-status.txt`
- Raw process output: `01-singleton/prover-output.jsonl`; stderr: `01-singleton/stderr.log`
- The coordinated wrapper verified `running_provers_max=1`, `memlimit=1000 MiB`, held `/tmp/itoa-creusot-proof.lock`, then exited. The lock is released.

## Export-only command

The first command included Why3's `-o`, which exports SMT goals and does not prove them. It is retained under `01-singleton/exported-smt-not-a-proof/` with `EXPORT-NOTE.txt` and excluded from proof outcomes. It did not invoke a solver.

## Provenance

- Original compiler, config, installed prelude, Why3, Z3, and copied standard-library source identities are listed in `provenance.sha256`.
- The frozen `utf8-seq-laws` source/translation manifest was checked successfully; output is `source-manifest-check.log`.
- The exact selected COMA identity and per-run output hashes are in `01-singleton/input.sha256` and `01-singleton/SHA256SUMS`.
