# Interface revision translation snapshot

The exact adapter source hash is recorded in `SHA256SUMS`.

A fresh translation of the updated probe completed successfully and the
current generated inventory exactly matched all 18 reviewed paths in
`TRANSLATION-TARGETS.txt`. No new standalone logic-view/Wf target appeared.

Static COMA inspection confirms that `view_HeaderStorage` is unfolded into the
selected functions; `future_slots` projects `headers.final.current`, while
`inner_future_slots` projects `headers.current.final`. Constructor
postconditions link both projections. `write` carries both prophecy-frame
postconditions. `commit_prefix` relates the shortened outer binding and the
full inner backing slice through prefix and tail subsequences. These contracts
translated; no solver checked them.

This is a translation-only snapshot. The earlier proof run remains frozen under
`../selected-solver-run-20261005T044741856965836Z/`; its initialized constructor
success and non-Complete caller timeout apply to its older adapter source and
do not validate this revision. No solver or runtime test was run for this
snapshot. `implicit_drop_caller` and the Drop body are present only as
translation diagnostics and excluded from the positive target list.
