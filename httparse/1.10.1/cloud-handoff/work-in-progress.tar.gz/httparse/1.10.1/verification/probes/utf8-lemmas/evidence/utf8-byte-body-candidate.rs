//! Source-only candidate for body-checking the recursive numeric byte helper.
//!
//! This file is intentionally not included by `src/lib.rs`, the target list,
//! or `verify.sh`. It has not been compiled, translated, or proved.

use creusot_std::prelude::*;

#[logic(open)]
#[requires(0 <= value && value <= 255)]
#[ensures(result@ == value)]
#[variant(value)]
pub fn checked_utf8_byte_body(value: Int) -> u8 {
    if value == 0 {
        0u8
    } else {
        proof_assert!(0 <= value - 1 && value - 1 <= 255);
        let previous = checked_utf8_byte_body(value - 1);
        proof_assert!(previous@ == value - 1);
        proof_assert!(previous@ < 255);
        pearlite! { previous + 1u8 }
    }
}
