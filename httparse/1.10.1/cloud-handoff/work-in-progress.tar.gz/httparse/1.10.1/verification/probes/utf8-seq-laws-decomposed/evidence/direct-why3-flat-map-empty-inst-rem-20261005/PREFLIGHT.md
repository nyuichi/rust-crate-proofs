# Export-only transform preflight

- Input COMA: `httparse/1.10.1/verification/probes/utf8-seq-laws-decomposed/verif/httparse_string_model_harness_rlib/flat_map_laws/flat_map_empty.coma`
- Frozen input SHA-256: recorded in `input.sha256`; it matches `utf8-seq-laws-decomposed/evidence/COMA-SHA256SUMS`.
- Astra export-only task: copied to `preflight/task.smt2`; its SHA-256 is `preflight/task.sha256`.
- Exact Why3 transforms, in order: `-a split_vc -a 'inst_rem flat_map_T_def (empty:seq(t_T)),f' -g :42`.
- This was an export-only `-o` preflight and did not call a prover.
- The exported SMT retains the ground instance `flat_map_T(empty1,f) = if length(empty1)=0 then empty2 else ...` and the existing `empty_len_T_spec`. The recursive `flat_map_T_def` universal is absent. Removing the universal while retaining this selected ground instance leaves fewer assumptions, so the goal is at least as strong as the original selected obligation; no new axiom is introduced.

The proof invocation uses exactly the same target and transform sequence, without `-o`, with Z3 4.15.3, 30 seconds, and 1000 MiB.
