# HeaderStorage retain-prefix translation checkpoint

Translation only; no Why3 solver was run. `bash ./verify-selected.sh translate`
completed successfully and its exact inventory check passed. The source
`src/header_storage.rs` SHA-256 is `abd48063e39a036d5df401341d4a9c18f6d8c034a00d7f5afaa4d40f12f38db7`. The translation contains
19 COMA files and the reviewed selected manifest contains
11 exact targets. This source revision has no positive proof results.

The generic private `retain_prefix<'h, T>` helper factors the unchanged
`mem::take` / `split_at_mut` / prefix assignment from the two typed
`commit_prefix` branches. Its single precondition is
`used@ <= binding@.len()`. Its five postconditions connect the returned outer
binding to the old prefix, preserve the old future inner length, establish the
final shortened length and prefix relation, and frame the old tail. All four
nested-borrow observations remain in logic contracts; there is no snapshot,
custom `Fin`, unsafe cast, or added trusted contract. The helper uses the
existing `split_at_mut` contract.

`commit_prefix` still carries the adapter-level outer-future and final-backing
frame clauses and the inner prefix/tail lens clauses. The selected manifest is
ordered as constructors, capacity, used length, write, generic helper,
commit-prefix, and four representative clients. The generated COMA, source,
configuration, and standard-library model inputs are archived here for review.

The earlier four-corner run is historical evidence for a different source and
COMA input. Its 31 Valid leaves and one Unknown are not reused for this helper
revision. The current helper and all selected targets remain unproved pending
source/COMA contract review and a separate solver grant.
