//! Typed storage adapter used to isolate the header-buffer proof boundary.

use core::mem::MaybeUninit;
use creusot_std::prelude::{ensures, requires};

#[cfg(creusot)]
use creusot_std::prelude::{logic, Int, Seq, View};

use crate::Header;

/// A proof model for the backing slots and the number of headers written.
#[cfg(creusot)]
#[derive(Clone, Copy)]
pub enum HeaderStorageView<'b> {
    /// The complete backing slice contains initialized `Header` values.
    Initialized {
        slots: Seq<Option<Header<'b>>>,
        used_len: Int,
    },
    /// Only slots whose view is `Some` are known to contain headers.
    Uninitialized {
        slots: Seq<Option<Header<'b>>>,
        used_len: Int,
    },
}

#[cfg(creusot)]
impl<'b> HeaderStorageView<'b> {
    /// The current exposed slots, retaining the distinction between modes.
    #[logic(open)]
    pub fn slots(self) -> Seq<Option<Header<'b>>> {
        match self {
            Self::Initialized { slots, .. } | Self::Uninitialized { slots, .. } => slots,
        }
    }

    /// Number of successfully written header slots.
    #[logic(open)]
    pub fn used_len(self) -> Int {
        match self {
            Self::Initialized { used_len, .. } | Self::Uninitialized { used_len, .. } => used_len,
        }
    }

    /// Whether the entire current storage view is in initialized mode.
    #[logic(open)]
    pub fn is_initialized(self) -> bool {
        match self {
            Self::Initialized { .. } => true,
            Self::Uninitialized { .. } => false,
        }
    }

    /// The successfully written prefix contains only initialized headers.
    #[logic(open)]
    pub fn initialized_prefix(self) -> bool {
        pearlite! {
            0 <= self.used_len()
                && self.used_len() <= self.slots().len()
                && forall<i: Int> 0 <= i && i < self.used_len()
                    ==> self.slots()[i] != None
        }
    }

    /// Every slot in an initialized backing slice has a value.
    #[logic(open)]
    pub fn fully_initialized(self) -> bool {
        pearlite! {
            forall<i: Int> 0 <= i && i < self.slots().len()
                ==> self.slots()[i] != None
        }
    }
}

/// A typed view over either initialized or potentially uninitialized headers.
///
/// `used_len` is the sole logical prefix counter. The backing slice binding is
/// shortened only by `commit_prefix`, which callers invoke for Complete.
pub enum HeaderStorage<'s, 'h, 'b> {
    /// Existing `Header` values occupy every slot in the slice.
    Initialized {
        headers: &'s mut &'h mut [Header<'b>],
        used_len: usize,
    },
    /// Only the prefix recorded by `used_len` is required to be initialized.
    Uninitialized {
        headers: &'s mut &'h mut [MaybeUninit<Header<'b>>],
        used_len: usize,
    },
}

#[cfg(creusot)]
impl<'s, 'h, 'b> View for HeaderStorage<'s, 'h, 'b> {
    type ViewTy = HeaderStorageView<'b>;

    #[logic(open)]
    fn view(self) -> Self::ViewTy {
        pearlite! {
            match self {
                Self::Initialized { headers, used_len } => HeaderStorageView::Initialized {
                    slots: headers@.map(|header: Header<'b>| Some(header)),
                    used_len: used_len@,
                },
                Self::Uninitialized { headers, used_len } => HeaderStorageView::Uninitialized {
                    slots: headers@.map(|slot: MaybeUninit<Header<'b>>| slot@),
                    used_len: used_len@,
                },
            }
        }
    }
}

impl<'s, 'h, 'b> HeaderStorage<'s, 'h, 'b> {
    /// Future slots of the nested mutable slice binding.
    ///
    /// This projects prophecy only through the existing typed `&mut` fields;
    /// it assigns no future meaning to the owned counter or enum itself.
    #[cfg(creusot)]
    #[logic(open, prophetic)]
    pub fn future_slots(self) -> Seq<Option<Header<'b>>> {
        pearlite! {
            match self {
                Self::Initialized { headers, .. } => {
                    (^headers)@.map(|header: Header<'b>| Some(header))
                },
                Self::Uninitialized { headers, .. } => {
                    (^headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@)
                },
            }
        }
    }

    /// Future contents of the inner slice borrow, independent of the future
    /// local slice binding stored through the outer mutable reference.
    #[cfg(creusot)]
    #[logic(open, prophetic)]
    pub fn inner_future_slots(self) -> Seq<Option<Header<'b>>> {
        pearlite! {
            match self {
                Self::Initialized { headers, .. } => {
                    (^*headers)@.map(|header: Header<'b>| Some(header))
                },
                Self::Uninitialized { headers, .. } => {
                    (^*headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@)
                },
            }
        }
    }

    /// Final contents of the nested backing slice borrow.
    ///
    /// This fourth corner of the nested mutable-borrow prophecy connects the
    /// future contents observed through the adapter to the caller's final
    /// backing slice contents.
    #[cfg(creusot)]
    #[logic(open, prophetic)]
    pub fn final_binding_slots(self) -> Seq<Option<Header<'b>>> {
        pearlite! {
            match self {
                Self::Initialized { headers, .. } => {
                    (^^headers)@.map(|header: Header<'b>| Some(header))
                },
                Self::Uninitialized { headers, .. } => {
                    (^^headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@)
                },
            }
        }
    }

    /// Borrow an initialized slice binding without changing its length.
    #[ensures(result@.is_initialized())]
    #[ensures(result@.slots() == headers@.map(|header: Header<'b>| Some(header)))]
    #[ensures(result@.used_len() == 0)]
    #[ensures(result@.fully_initialized())]
    #[ensures(result.future_slots() == (^headers)@.map(|header: Header<'b>| Some(header)))]
    #[ensures(result.inner_future_slots() == (^*headers)@.map(|header: Header<'b>| Some(header)))]
    #[ensures(result.final_binding_slots() == (^^headers)@.map(|header: Header<'b>| Some(header)))]
    pub fn initialized(headers: &'s mut &'h mut [Header<'b>]) -> Self {
        Self::Initialized {
            headers,
            used_len: 0,
        }
    }

    /// Borrow a potentially uninitialized slice binding without changing it.
    #[ensures(!result@.is_initialized())]
    #[ensures(result@.slots() == headers@.map(|slot: MaybeUninit<Header<'b>>| slot@))]
    #[ensures(result@.used_len() == 0)]
    #[ensures(result.future_slots() == (^headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@))]
    #[ensures(result.inner_future_slots() == (^*headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@))]
    #[ensures(result.final_binding_slots() == (^^headers)@.map(|slot: MaybeUninit<Header<'b>>| slot@))]
    pub fn uninitialized(headers: &'s mut &'h mut [MaybeUninit<Header<'b>>]) -> Self {
        Self::Uninitialized {
            headers,
            used_len: 0,
        }
    }

    /// Capacity of the original/current backing binding.
    #[ensures(result@ == self@.slots().len())]
    pub fn capacity(&self) -> usize {
        match self {
            Self::Initialized { headers, .. } => headers.len(),
            Self::Uninitialized { headers, .. } => headers.len(),
        }
    }

    /// Number of complete header values written so far.
    #[ensures(result@ == self@.used_len())]
    pub fn used_len(&self) -> usize {
        match self {
            Self::Initialized { used_len, .. } | Self::Uninitialized { used_len, .. } => *used_len,
        }
    }

    /// Write the next complete header and advance the canonical prefix length.
    #[requires(index@ == self@.used_len())]
    #[requires(index@ < self@.slots().len())]
    #[requires(self@.initialized_prefix())]
    #[ensures((^self)@.slots() == self@.slots().set(index@, Some(value)))]
    #[ensures((^self)@.used_len() == self@.used_len() + 1)]
    #[ensures((^self)@.is_initialized() == self@.is_initialized())]
    #[ensures((^self)@.initialized_prefix())]
    #[ensures((^self)@.is_initialized() ==> (^self)@.fully_initialized())]
    #[ensures((^self).future_slots() == self.future_slots())]
    #[ensures((^self).inner_future_slots() == self.inner_future_slots())]
    #[ensures((^self).final_binding_slots() == self.final_binding_slots())]
    pub fn write(&mut self, index: usize, value: Header<'b>) {
        match self {
            Self::Initialized { headers, used_len } => {
                (**headers)[index] = value;
                *used_len += 1;
            }
            Self::Uninitialized { headers, used_len } => {
                let _ = (**headers)[index].write(value);
                *used_len += 1;
            }
        }
    }

    /// Publish the initialized prefix by shortening the backing slice binding.
    ///
    /// Call this only when the parse result is Complete. Partial and Error
    /// results keep the original full binding.
    #[requires(self@.used_len() <= self@.slots().len())]
    #[requires(self@.initialized_prefix())]
    #[ensures((^self)@.slots() == self@.slots().subsequence(0, self@.used_len()))]
    #[ensures((^self)@.used_len() == self@.used_len())]
    #[ensures((^self)@.is_initialized() == self@.is_initialized())]
    #[ensures((^self)@.initialized_prefix())]
    #[ensures((^self).future_slots() == self.future_slots())]
    #[ensures((^self).final_binding_slots() == self.final_binding_slots())]
    #[ensures(self.inner_future_slots().len() == self@.slots().len())]
    #[ensures((^self).inner_future_slots().len() == self@.used_len())]
    #[ensures(self.inner_future_slots().subsequence(0, self@.used_len()) == (^self).inner_future_slots())]
    #[ensures(self.inner_future_slots().subsequence(self@.used_len(), self@.slots().len())
        == self@.slots().subsequence(self@.used_len(), self@.slots().len()))]
    pub fn commit_prefix(&mut self) {
        match self {
            Self::Initialized { headers, used_len } => {
                let full = core::mem::take(*headers);
                let (prefix, _) = full.split_at_mut(*used_len);
                **headers = prefix;
            }
            Self::Uninitialized { headers, used_len } => {
                let full = core::mem::take(*headers);
                let (prefix, _) = full.split_at_mut(*used_len);
                **headers = prefix;
            }
        }
    }
}
