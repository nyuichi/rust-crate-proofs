#!/usr/bin/env bash
set -euo pipefail

probe_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
crate_dir=$(cd "$probe_dir/../../.." && pwd)
candidate_dir="${CANDIDATE_DIR:-$probe_dir/evidence/induction-prep-20261005T063957Z}"
manifest="$candidate_dir/proof-targets.tsv"
dependencies="$candidate_dir/dependencies.tsv"
verif_dir="$probe_dir/string/verif"
spaces_run="$crate_dir/verification/probes/spaces-harness/evidence/direct-why3-20261005T052959319229043Z"
source /workspace/proof-tools/activate.sh
source /workspace/scratch/httparse-string-model/creusot-env.sh

run_stamp=$(date -u +%Y%m%dT%H%M%SZ)
run_dir="$candidate_dir/type-only-$run_stamp"
mkdir -p "$run_dir/logs" "$run_dir/coma" "$run_dir/inputs/source"
cp "$manifest" "$dependencies" "$probe_dir/REPORT.md" "$run_dir/inputs/"
cp "$probe_dir/src/lib.rs" "$run_dir/inputs/"
cp "$probe_dir/string/Cargo.toml" "$probe_dir/string/Cargo.lock" "$run_dir/inputs/"
cp "$crate_dir/src/skip_empty_lines.rs" "$crate_dir/src/verification/empty_lines.rs" \
   "$crate_dir/src/verification/model.rs" "$crate_dir/src/iter.rs" \
   "$crate_dir/src/macros.rs" "$crate_dir/src/status.rs" "$crate_dir/src/error.rs" \
   "$run_dir/inputs/source/"

why3_config_source="$spaces_run/why3-effective.conf"
why3_config="$run_dir/why3-effective.conf"
cp "$why3_config_source" "$why3_config"
why3=$(command -v why3)
package="$CREUSOT_DATA_HOME/share/why3find/packages/creusot"
[[ -x "$why3" && -s "$why3_config" && -s "$package/creusot/int.coma" \
   && -s "$package/creusot/prelude.coma" && -d "$verif_dir" ]]
grep -Eq '^running_provers_max = 1$' "$why3_config"
grep -Eq '^memlimit = 1000$' "$why3_config"

config_sha=$(sha256sum "$why3_config" | cut -d' ' -f1)
package_manifest="$run_dir/creusot-package-files.sha256"
find "$package" -type f -print0 | sort -z | xargs -0 sha256sum > "$package_manifest"
package_manifest_sha=$(sha256sum "$package_manifest" | cut -d' ' -f1)
{
  printf 'run_dir=%s\n' "$run_dir"
  printf 'why3=%s\nwhy3_version=%s\n' "$why3" "$($why3 --version)"
  printf 'why3_config_source=%s\nwhy3_config_snapshot=%s\nwhy3_config_sha256=%s\n' \
    "$why3_config_source" "$why3_config" "$config_sha"
  printf 'creusot_package=%s\npackage_manifest_sha256=%s\n' "$package" "$package_manifest_sha"
  printf 'verif_loadpath=%s\n' "$verif_dir"
  printf 'command_template=%s prove --type-only -C %s -L %s -L %s -F coma <target.coma>\n' \
    "$why3" "$why3_config" "$package" "$verif_dir"
  printf 'solver_invocations=0\n'
} > "$run_dir/run-identity.txt"
printf 'Only `why3 prove --type-only` was run. No prover option or solver command was used.\n' > "$run_dir/RUN.md"
printf 'order\ttarget\tsha256\n' > "$run_dir/pre-run-coma-sha256.tsv"
printf 'order\ttarget\tsha256\tstatus\n' > "$run_dir/post-run-coma-sha256.tsv"
printf 'order\ttarget\tcommand\tstatus\n' > "$run_dir/commands.tsv"
: > "$run_dir/type-preflight.log"

expected_count=$(awk -F '\t' 'NR > 1 { count++ } END { print count + 0 }' "$manifest")
index=0
run_status=0
while IFS=$'\t' read -r order group target expected_hash purpose proof_status; do
  [[ "$order" == order ]] && continue
  index=$((index + 1))
  coma="$verif_dir/httparse_empty_lines_string_harness_rlib/$target.coma"
  actual_hash=$(sha256sum "$coma" | cut -d' ' -f1)
  if [[ "$actual_hash" != "$expected_hash" ]]; then
    printf 'STOP: fresh CoMa hash mismatch for %s expected=%s actual=%s\n' \
      "$target" "$expected_hash" "$actual_hash" >> "$run_dir/type-preflight.log"
    run_status=2
    break
  fi
  printf '%s\t%s\t%s\n' "$order" "$target" "$actual_hash" >> "$run_dir/pre-run-coma-sha256.tsv"
  mkdir -p "$run_dir/coma/$(dirname "$target")"
  cp "$coma" "$run_dir/coma/$target.coma"
  log="$run_dir/logs/$(printf '%02d' "$index").log"
  command="$why3 prove --type-only -C $why3_config -L $package -L $verif_dir -F coma $coma"
  printf '%s\t%s\t%s\t' "$order" "$target" "$command" >> "$run_dir/commands.tsv"
  printf 'Type-only: %s\n' "$target" >> "$run_dir/type-preflight.log"
  set +e
  "$why3" prove --type-only -C "$why3_config" -L "$package" -L "$verif_dir" -F coma "$coma" > "$log" 2>&1
  type_status=$?
  set -e
  cat "$log" >> "$run_dir/type-preflight.log"
  if (( type_status != 0 )); then
    printf 'TYPE_ONLY_ERROR(exit=%d)\n' "$type_status" >> "$run_dir/commands.tsv"
    printf 'STOP: first type-only error at %s (exit %d); no solver was invoked.\n' \
      "$target" "$type_status" >> "$run_dir/type-preflight.log"
    run_status=$type_status
    break
  fi
  printf 'TypeOnlyOK\n' >> "$run_dir/commands.tsv"
done < "$manifest"

while IFS=$'\t' read -r order group target expected_hash purpose proof_status; do
  [[ "$order" == order ]] && continue
  coma="$verif_dir/httparse_empty_lines_string_harness_rlib/$target.coma"
  actual_hash=$(sha256sum "$coma" | cut -d' ' -f1)
  status=unchanged
  if [[ "$actual_hash" != "$expected_hash" ]]; then
    status=CHANGED
    run_status=2
  fi
  printf '%s\t%s\t%s\t%s\n' "$order" "$target" "$actual_hash" "$status" \
    >> "$run_dir/post-run-coma-sha256.tsv"
done < "$manifest"
if [[ "$(sha256sum "$why3_config" | cut -d' ' -f1)" != "$config_sha" ]]; then
  printf 'Why3 config snapshot changed during preflight.\n' >> "$run_dir/type-preflight.log"
  run_status=2
fi
printf 'selected_targets_attempted=%d\nselected_targets_expected=%d\n' "$index" "$expected_count" >> "$run_dir/run-identity.txt"
if (( run_status == 0 && index == expected_count )); then
  printf 'status=type-only-ok-all-%d\nsolver_invocations=0\n' "$expected_count" > "$run_dir/RESULT.txt"
elif (( run_status == 0 )); then
  printf 'status=type-only-incomplete-attempted-%d\nsolver_invocations=0\n' "$index" > "$run_dir/RESULT.txt"
else
  printf 'status=type-only-stopped-with-%d\nsolver_invocations=0\n' "$run_status" > "$run_dir/RESULT.txt"
fi
printf 'selected_targets_expected=%s\n' "$expected_count" >> "$run_dir/run-identity.txt"
printf '%s\n' "$run_dir"
cat "$run_dir/RESULT.txt"
exit "$run_status"
