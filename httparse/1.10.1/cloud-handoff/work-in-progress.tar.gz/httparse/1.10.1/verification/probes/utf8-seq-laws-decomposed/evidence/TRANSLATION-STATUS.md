# Translation, type-check, and selected proof status

Creusot translation generated exactly the seven files in `proof-targets.txt`;
Why3 type-only checking completed successfully for all seven. The selected
sequence/flat-map candidate obligations have 15 Valid split outcomes, as
itemized in the root `README.md` and `direct-why3-singleton-inst-rem-20261005/DEPENDENCY-LEDGER.md`.
The original direct OOM for one empty-flat-map child remains recorded
separately; the corresponding ground-instantiated, stronger task is Valid.

This does not prove the two unsubmitted sequence-only targets, standard helper
source linkage, push-back bridge, UTF-8 numeric helper contract, universal
character encoding, string literals, or runtime parser behavior. No source or
compiler changes were made during these solver checkpoints.
