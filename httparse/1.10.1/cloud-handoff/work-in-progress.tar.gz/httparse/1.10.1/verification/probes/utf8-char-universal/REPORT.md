# Universal UTF-8 layout source-preparation checkpoint

## Proposed target inventory

The pre-translation inventory is the six modules in `proof-targets.txt`:

1. `valid_rust_char_domain`: checks the existing Char model's `0 <= c@ <
   0x110000` and `not (0xD800 <= c@ < 0xE000)` facts.
2. `utf8_char_one_byte`: exact one-byte branch for `0 <= c@ < 0x80`.
3. `utf8_char_two_bytes`: exact two-byte branch for `0x80 <= c@ < 0x800`.
4. `utf8_char_three_bytes`: exact three-byte branch for `0x800 <= c@ < 0x10000`.
5. `utf8_char_four_bytes`: exact four-byte branch for `0x10000 <= c@ < 0x110000`.
6. `utf8_char_piecewise`: states the complete piecewise sequence equality over
   all four codepoint ranges; the four branch targets separately expose their
   exact output-length, byte-range, and byte-index obligations.

Each branch proof explicitly asserts the 0..255 range of every argument to the
existing standard `utf8_byte` constructor, then asserts its numeric model,
output length, every output index, and extensional equality with the sequence
of standard `utf8_byte` results. The validity target uses the matching
prelude's existing Char invariant; it does not weaken or replace that model.

## Status

The approved inventory translated successfully to exactly the six listed
modules. Direct Why3 type-only checking exited successfully on those exact
modules. Logs are in `evidence/translation.log` and `evidence/typecheck.log`;
source, compiler, config, package, and COMA hashes are in
`evidence/CHAR-UNIVERSAL-SHA256SUMS`.

The first translation-only attempt tried to branch on `c as u32`; the pinned
Creusot compiler rejects casts from `char` to `u32`. That compile diagnostic is
retained in `evidence/translation-attempt-1.log`. The current source states the
complete partition in its logical postcondition and contains no runtime cast.
No solver has run for this probe. The translated goals are proof candidates,
not proof results. No standard encoding body verification is claimed from the
open function definition alone; the four branch obligations remain selected
targets for a future solver run.

The exact existing Char TCB source and prelude invariant are recorded in
`evidence/char-model-source.txt`. It connects the source-level `char@` view to
the installed prelude's range and surrogate exclusion; no local validity axiom
was added. This candidate states no httparse-specific fact.
