# Retain-prefix selected solver run

Frozen input is `inputs/translation`. The 11 selected COMAs typechecked under
the isolated string-model profile. Direct Why3 proof execution then passed
selected targets 1–6 and stopped at the first non-Valid result in target 7,
`commit_prefix` (one 30-second Timeout in a combined ensures goal). No clients
were attempted. See `RUN-RESULT.md`, `LEAF-COUNTS.tsv`, and raw logs. The
shared lock has been released.
