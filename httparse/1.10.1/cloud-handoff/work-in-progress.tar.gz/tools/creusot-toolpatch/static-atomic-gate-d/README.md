# Gate D: bind std_detect observations to fixed CPU capabilities

Gate D is a separate compiler delta layered after frozen Gate C. It recognizes
only the two direct helpers emitted by the pinned x86 feature-detection macro:

| Feature | DefPath | DefPathHash |
| --- | --- | --- |
| AVX2 | `std_detect::detect::arch::x86::__is_feature_detected::avx2` | `DefPathHash(Fingerprint(16463344075432050222, 17978152209004961407))` |
| SSE4.2 | `std_detect::detect::arch::x86::__is_feature_detected::sse4_2` | `DefPathHash(Fingerprint(16463344075432050222, 3968141329746303579))` |

The helpers must be external, non-generic `fn() -> bool` items from the pinned
`std_detect` crate. The compiler checks the metadata SVH
`8ee8611d378dca395effd0b02bc6a117`, the DefPathHash, the exact loaded artifact
path under the target sysroot, and the artifact SHA-256. The admitted
`libstd_detect` rmeta and rlib hashes are recorded and checked by the runner.
The audit records each direct call's exact body and MIR location. Normal and
proof builds must report the same locations and identities; translation
re-audits those calls from the live body. Local same-name functions,
duplicates, missing calls, indirect calls, mismatched identities, and cfg
overrides fail closed.

At each authenticated call, the translation makes a fresh Boolean observation
`r` and assumes only `r -> StaticAtomicCaps.avx2_usable` or
`r -> StaticAtomicCaps.sse42_usable`. A false observation grants no fact and
the model does not identify the observation with the capability symbol.
The assumption is an explicit external TCB rule. It relies on the pinned
standard detector's true result implying usable instructions, including OS
state, and on that usability remaining stable for the participating threads
and process lifetime. The reviewed pinned sources are
`std_detect/src/detect/macros.rs`, `detect/arch/x86.rs`, `detect/os/x86.rs`, and
`detect/cache.rs`. AVX2 detection checks XSAVE/OSXSAVE and XCR0 XMM/YMM state;
SSE4.2 checks its CPUID bit. CPU migration compatibility and the OS state are
trusted assumptions in this model, not proved theorems. Environment overrides
only clear detected feature bits, which is compatible with the one-way rule.

The target profile stays x86_64 Linux with AVX2 and SSE4.2 disabled in the
effective target features and cfg. The standard macro has a `target_feature`
cfg shortcut; builds globally enabling either feature are rejected.

## Scope and result

The fixture exercises the two real macro expansions in a body that also uses
the Gate B modeled `AtomicU8`. The runner completed normal/proof audit,
translation, and Why3 `--type-only` checks for all three emitted COMA modules.
The local detector lookalike and duplicate-site cases were rejected. No solver
was run.

This result validates the Gate D translation rule and its type correctness for
the fixture. It does not prove `httparse`'s actual dispatch, cache stores, or
target-feature calls. In particular, the four actual SIMD wrapper DefIds and
their `target_features` caller preconditions remain a separate audit and proof
step. The Gate B Atomic history contracts and the Gate D detector/OS/migration
mapping are external TCB assumptions.

## Reproduction

`build-compiler.sh` recreates the compiler from upstream commit
`437d3d8d00b8114d7a3b4f7b8738d594a395f5bc`, then applies narrowcast, Gate A,
Gate B, frozen Gate C, and the Gate D patch in that order. It builds only into
the isolated Gate D target directory and retains the generated Why3 package
there. `run-gate-d-fixtures.sh` checks the compiler, package, target cfg,
std_detect artifacts and source files before running the fixture cases.
It stores logs, audit reports, generated COMA, type-only commands, and
provenance under `/tmp/httparse-static-atomic-gate-d/<run-id>` by default.

```sh
tools/creusot-toolpatch/static-atomic-gate-d/build-compiler.sh
tools/creusot-toolpatch/static-atomic-gate-d/run-gate-d-fixtures.sh
```
