# Gate D translation evidence

This is the final Gate D runner output from run ID
`8ed2e1cc1e3c465a5d97d6d0c45f28bdcccf49b346ef54176812451a5bb812eb`.
The run completed a positive normal/proof audit, static-atomic translation,
and Why3 `--type-only` checks for `CACHE.coma`, `read_cache.coma`, and
`runtime_detect.coma`. It did not run a solver.

The `negative/` subdirectories preserve the expected audit failures for a local
detector lookalike, duplicate detector site, wrong profile, target-feature
override, manual cfg overrides, and caller-supplied capability path.
`std_detect-artifacts/` and `std_detect-source/` preserve the exact sysroot
inputs inspected by this delta. `generated-prelude-package/` is the package
used for type checking. `SHA256SUMS` records the patch, build and runner
scripts, isolated compiler, package manifest, and sysroot artifact digests.

Every claim here is limited to audit, translation, and type checking; detector
semantics, the CPU/OS/migration TCB, and actual httparse dispatch remain
unproved.
