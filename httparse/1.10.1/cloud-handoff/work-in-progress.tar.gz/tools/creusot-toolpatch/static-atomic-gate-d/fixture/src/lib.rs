use creusot_std::prelude::*;
use std::sync::atomic::{AtomicU8, Ordering};

#[logic(open, inline)]
pub fn value_invariant(value: u8, avx2: bool, sse42: bool) -> bool {
    pearlite! {
        value@ == 0
            || (value@ == 1 && avx2)
            || (value@ == 2 && sse42)
            || value@ == 3
    }
}

static CACHE: AtomicU8 = AtomicU8::new(0);

// This body matches the ordinary macro expansion under the Gate C baseline:
// both helpers are direct, zero-argument sysroot calls when reached.
#[cfg(feature = "wrong-lookalike")]
fn avx2() -> bool {
    true
}

#[cfg(feature = "wrong-lookalike")]
fn sse4_2() -> bool {
    false
}

pub fn runtime_detect() -> u8 {
    #[cfg(feature = "wrong-lookalike")]
    let supports_avx2 = avx2();
    #[cfg(not(feature = "wrong-lookalike"))]
    let supports_avx2 = std::arch::is_x86_feature_detected!("avx2");

    #[cfg(feature = "duplicate-site")]
    let _second_avx2_observation = std::arch::is_x86_feature_detected!("avx2");

    let value = if supports_avx2 {
        1
    } else {
        #[cfg(feature = "wrong-lookalike")]
        let supports_sse42 = sse4_2();
        #[cfg(not(feature = "wrong-lookalike"))]
        let supports_sse42 = std::arch::is_x86_feature_detected!("sse4.2");

        if supports_sse42 { 2 } else { 3 }
    };

    CACHE.store(value, Ordering::Relaxed);
    CACHE.load(Ordering::Relaxed)
}

pub fn read_cache() -> u8 {
    CACHE.load(Ordering::Relaxed)
}
