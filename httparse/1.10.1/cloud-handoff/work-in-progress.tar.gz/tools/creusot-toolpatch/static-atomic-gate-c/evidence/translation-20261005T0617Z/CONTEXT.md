# Gate C translation checkpoint

This run used the isolated compiler rebuilt by `static-atomic-gate-c/build-compiler.sh` from the pinned source and ordered patch stack recorded in `PROVENANCE.tsv`. The fixture runner completed the positive translation and four fail-closed cases. `positive/normal.audit` and `positive/proof.audit` have matching executable MIR and profile headers; `positive/coverage.tsv` records the translated initializer, predicate dependency, and all audited accessors. The generated COMA files are preserved under `positive/modules/`.

The positive result is translation evidence only. No Why3 solver or VC proof was run in this bundle. It does not connect detector return values or `#[target_feature]` calls to the capability symbols and does not close httparse runtime dispatch verification. The `read_twice` observations remain independent.
