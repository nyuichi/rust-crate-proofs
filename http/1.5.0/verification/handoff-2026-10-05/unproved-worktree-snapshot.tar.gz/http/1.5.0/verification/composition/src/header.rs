//! Actual HeaderMap and HeaderName source modules for the Builder header leaf.
//!
//! HeaderValue remains the pinned runtime value type, matching the standalone
//! HeaderMap proof harness. This local wrapper keeps the checked-in map and
//! name modules in the same Creusot crate as Request/Response.

pub const MAX_HEADER_NAME_LEN: usize = (1 << 16) - 1;

#[path = "../../../src/header/name.rs"]
pub mod name;
pub use name::{HeaderName, InvalidHeaderName};

pub use http_runtime::header::{HeaderValue, InvalidHeaderValue, ToStrError};

#[path = "../../../src/header/map_capacity.rs"]
mod map_capacity;
#[path = "../../../src/header/map.rs"]
pub mod map;
pub use map::{
    AsHeaderName, Drain, Entry, GetAll, HeaderMap, IntoHeaderName, IntoIter, Iter, IterMut, Keys,
    MaxSizeReached, OccupiedEntry, VacantEntry, ValueDrain, ValueIter, ValueIterMut, Values,
    ValuesMut,
};
